#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

////////////////////////////////////////////////////////////////////////////
//
// Batch Rename Files with Live Preview
//
// Professional utility for batch renaming files with preview and validation
//
// Pete Proulx March 2023, Enhanced May 2025
// Ron Brecher Technical Reviewer
// Masters of PixInsight V2.0
//
////////////////////////////////////////////////////////////////////////////

#define TITLE "Batch Rename Files with Preview - Masters of PixInsight"
#feature-id    MoP V8> Batch Rename File by Text String
#feature-info  Professional batch file renaming script with preview and validation - www.mastersofpixinsight.com


// Enhanced file selection with better filtering
function selectFiles() {
    let ofd = new OpenFileDialog;
    ofd.caption = "Select Files to Rename";
    ofd.multipleSelections = true;
    ofd.filters = [
        ["All Files", "*"],
        ["Image Files", "*.xisf *.fit *.fits *.tif *.tiff *.jpg *.jpeg *.png"],
        ["XISF Files", "*.xisf"],
        ["FITS Files", "*.fit *.fits"],
        ["TIFF Files", "*.tif *.tiff"]
    ];

    if (ofd.execute()) {
        return ofd.fileNames;
    }
    return [];
}

// Enhanced filename generation with validation
function getNewFileName(originalPath, searchText, replaceText, protectExtension) {
    try {
        // Ensure we have valid strings
        searchText = searchText || "";
        replaceText = replaceText || "";

        if (!originalPath || searchText === "") {
            return originalPath ? File.extractNameAndSuffix(originalPath) : "";
        }

        if (protectExtension) {
            let baseName = File.extractName(originalPath);
            let extension = File.extractExtension(originalPath);
            // Use simple string replace instead of regex for safety
            let newBaseName = baseName.split(searchText).join(replaceText);
            return newBaseName + extension;
        } else {
            let fullName = File.extractNameAndSuffix(originalPath);
            // Use simple string replace instead of regex for safety
            return fullName.split(searchText).join(replaceText);
        }
    } catch (error) {
        Console.warningln("Error in getNewFileName: " + error.message);
        return originalPath ? File.extractNameAndSuffix(originalPath) : ""; // Return original if error
    }
}

// Validation functions
function validateInputs(searchText, replaceText) {
    let errors = [];

    // Ensure we have strings
    searchText = searchText || "";
    replaceText = replaceText || "";

    if (!searchText || searchText.trim() === "") {
        errors.push("Search text cannot be empty");
    }

    if (searchText.length > 100) {
        errors.push("Search text too long (max 100 characters)");
    }

    if (replaceText.length > 100) {
        errors.push("Replace text too long (max 100 characters)");
    }

    // Check for invalid filename characters in replace text
    let invalidChars = ['/', '\\', ':', '*', '?', '"', '<', '>', '|'];
    for (let i = 0; i < invalidChars.length; i++) {
        if (replaceText.indexOf(invalidChars[i]) !== -1) {
            errors.push("Replace text contains invalid character: " + invalidChars[i]);
            break;
        }
    }

    return errors;
}

// Check for naming conflicts
function checkForConflicts(fileList, searchText, replaceText, protectExtension) {
    let conflicts = [];
    let newNames = new Set();

    // Ensure we have valid strings
    searchText = searchText || "";
    replaceText = replaceText || "";

    if (searchText === "") {
        return conflicts; // No conflicts if no search text
    }

    for (let i = 0; i < fileList.numberOfChildren; ++i) {
        let node = fileList.child(i);
        let originalPath = node.filePath || "";
        let newFileName = getNewFileName(originalPath, searchText, replaceText, protectExtension);

        if (originalPath && newFileName) {
            let directory = File.extractDrive(originalPath) + File.extractDirectory(originalPath);
            let newFullPath = directory + "/" + newFileName;

            // Check for duplicate new names
            let lowerCasePath = newFullPath.toLowerCase();
            if (newNames.has(lowerCasePath)) {
                conflicts.push("Duplicate name would be created: " + newFileName);
            } else {
                newNames.add(lowerCasePath);
            }

            // Check if file already exists
            if (File.exists(newFullPath) && newFullPath !== originalPath) {
                conflicts.push("File already exists: " + newFileName);
            }
        }
    }

    return conflicts;
}

// Enhanced dialog creation
function createRenameFileDialog() {
    let dialog = new Dialog;
    dialog.windowTitle = "Batch Rename Files with Preview - Masters of PixInsight";

    let labelWidth = 120;
    let editWidth = 400;  // Increased for longer file names
    let uiMargin = 8;

    // Main title
    let titleLabel = new Label(dialog);
    titleLabel.text = "Batch Rename Files with Preview";
    titleLabel.textAlignment = TextAlignment.Center;
    titleLabel.styleSheet = "font-weight: bold; font-size: 16px; padding: 8px;";

    // Website label
    let websiteLabel = new Label(dialog);
    websiteLabel.text = "www.mastersofpixinsight.com";
    websiteLabel.textAlignment = TextAlignment.Center;
    websiteLabel.styleSheet = "font-size: 12px; padding: 4px;";

    // Instructions GroupBox
    let instructionsGroupBox = new GroupBox(dialog);
    instructionsGroupBox.title = "How This Script Works";
    instructionsGroupBox.titleCheckBox = false;

    let instructionsText = new Label(dialog);
    instructionsText.text =
        "This script safely renames multiple files with live preview:\n\n" +
        "• Add files using the 'Add Files' button below\n" +
        "• Enter text to search for and replace text\n" +
        "• Preview shows new names before any changes are made\n" +
        "• Enable 'Protect Extensions' to preserve file extensions\n" +
        "• Script validates names and checks for conflicts\n" +
        "• Click 'Rename Files' only when you're satisfied with the preview\n\n" +
        "Important: File renaming cannot be undone. Always check the preview!";
    instructionsText.wordWrap = true;
    instructionsText.textAlignment = TextAlignment.Left;
    instructionsText.styleSheet = "line-height: 1.4;";

    let instructionsSizer = new VerticalSizer;
    instructionsSizer.margin = 8;
    instructionsSizer.add(instructionsText);
    instructionsGroupBox.sizer = instructionsSizer;

    // Search/Replace GroupBox
    let searchReplaceGroupBox = new GroupBox(dialog);
    searchReplaceGroupBox.title = "Search and Replace Settings";
    searchReplaceGroupBox.titleCheckBox = false;

    let searchReplaceSizer = new VerticalSizer;
    searchReplaceSizer.margin = 8;
    searchReplaceSizer.spacing = 6;

    // Search text row
    let searchSizer = new HorizontalSizer;
    searchSizer.spacing = 6;

    dialog.label1 = new Label(dialog);
    dialog.label1.text = "Search for text:";
    dialog.label1.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
    dialog.label1.setFixedWidth(labelWidth);
    dialog.label1.styleSheet = "font-weight: bold;";

    dialog.searchText = new Edit(dialog);
    dialog.searchText.setFixedWidth(editWidth);
    dialog.searchText.toolTip = "Enter the text you want to find and replace in filenames";

    searchSizer.add(dialog.label1);
    searchSizer.add(dialog.searchText);
    searchReplaceSizer.add(searchSizer);

    // Replace text row
    let replaceSizer = new HorizontalSizer;
    replaceSizer.spacing = 6;

    dialog.label2 = new Label(dialog);
    dialog.label2.text = "Replace with:";
    dialog.label2.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
    dialog.label2.setFixedWidth(labelWidth);
    dialog.label2.styleSheet = "font-weight: bold;";

    dialog.replaceText = new Edit(dialog);
    dialog.replaceText.setFixedWidth(editWidth);
    dialog.replaceText.toolTip = "Enter the replacement text (leave empty to remove the search text)";

    replaceSizer.add(dialog.label2);
    replaceSizer.add(dialog.replaceText);
    searchReplaceSizer.add(replaceSizer);

    // Options row
    let optionsSizer = new HorizontalSizer;
    optionsSizer.spacing = 10;

    dialog.protectExtensionCheckBox = new CheckBox(dialog);
    dialog.protectExtensionCheckBox.text = "Protect file extensions";
    dialog.protectExtensionCheckBox.checked = true;
    dialog.protectExtensionCheckBox.toolTip = "When checked, only the filename is changed, extensions are preserved";
    dialog.protectExtensionCheckBox.styleSheet = "font-weight: bold;";

    optionsSizer.add(dialog.protectExtensionCheckBox);
    searchReplaceSizer.add(optionsSizer);

    // Help text
    let helpText = new Label(dialog);
    helpText.text = "Tip: Use 'Protect Extensions' to safely rename without affecting .xisf, .fits, etc.";
    helpText.styleSheet = "font-style: italic; font-size: 11px;";
    searchReplaceSizer.add(helpText);

    searchReplaceGroupBox.sizer = searchReplaceSizer;

    // File Management GroupBox
    let fileManagementGroupBox = new GroupBox(dialog);
    fileManagementGroupBox.title = "File Management";
    fileManagementGroupBox.titleCheckBox = false;

    let fileManagementSizer = new VerticalSizer;
    fileManagementSizer.margin = 8;
    fileManagementSizer.spacing = 6;

    // Column resize tip
    let resizeTipText = new Label(dialog);
    resizeTipText.text = "Tip: Double-click column separators to auto-resize columns to fit content";
    resizeTipText.styleSheet = "font-style: italic; font-size: 11px;";
    fileManagementSizer.add(resizeTipText);

    // File list with preview
    dialog.fileList = new TreeBox(dialog);
    dialog.fileList.setMinSize(1000, 350);
    dialog.fileList.multipleSelection = true;
    dialog.fileList.numberOfColumns = 3;
    dialog.fileList.setHeaderText(0, "Original Filename");
    dialog.fileList.setHeaderText(1, "New Filename (Preview)");
    dialog.fileList.setHeaderText(2, "Status");
    dialog.fileList.headerVisible = true;
    dialog.fileList.toolTip = "Files to be renamed - check the preview column before proceeding";

    // Set better initial column widths
    dialog.fileList.setColumnWidth(0, 350);  // Original filename - wider for long names
    dialog.fileList.setColumnWidth(1, 350);  // Preview - same width
    dialog.fileList.setColumnWidth(2, 100);  // Status - narrower

    fileManagementSizer.add(dialog.fileList);

    // File management buttons
    let fileButtonsSizer = new HorizontalSizer;
    fileButtonsSizer.spacing = 8;

    dialog.addFilesButton = new PushButton(dialog);
    dialog.addFilesButton.text = "Add Files";
    dialog.addFilesButton.icon = dialog.scaledResource(":/icons/add.png");
    dialog.addFilesButton.toolTip = "Select files to add to the rename list";
    dialog.addFilesButton.styleSheet = "font-weight: bold; padding: 6px 12px;";
    dialog.addFilesButton.onClick = function () {
        let selectedFiles = selectFiles();
        for (let i = 0; i < selectedFiles.length; i++) {
            let filePath = selectedFiles[i];
            let node = new TreeBoxNode(dialog.fileList);
            node.setText(0, File.extractNameAndSuffix(filePath));
            node.setText(1, "Enter search text"); // Preview will be updated
            node.setText(2, "Waiting");
            node.setToolTip( 0, "Full path: " + filePath );
            // Store full path in node for later use
            node.filePath = filePath;
        }
        dialog.updatePreview();
    };

    dialog.removeSelectedButton = new PushButton(dialog);
    dialog.removeSelectedButton.text = "Remove Selected";
    dialog.removeSelectedButton.icon = dialog.scaledResource(":/icons/remove.png");
    dialog.removeSelectedButton.toolTip = "Remove selected files from the rename list";
    dialog.removeSelectedButton.styleSheet = "padding: 6px 12px;";
    dialog.removeSelectedButton.onClick = function () {
        let selectedNodes = dialog.fileList.selectedNodes;
        for (let i = selectedNodes.length - 1; i >= 0; i--) {
            dialog.fileList.remove(dialog.fileList.childIndex(selectedNodes[i]));
        }
        dialog.updatePreview();
    };

    dialog.clearAllButton = new PushButton(dialog);
    dialog.clearAllButton.text = "Clear All";
    dialog.clearAllButton.toolTip = "Remove all files from the list";
    dialog.clearAllButton.onClick = function () {
        dialog.fileList.clear();
        dialog.updatePreview();
    };

    dialog.updatePreviewButton = new PushButton(dialog);
    dialog.updatePreviewButton.text = "Update Preview";
    dialog.updatePreviewButton.toolTip = "Refresh the preview with current search/replace settings";
    dialog.updatePreviewButton.styleSheet = "font-weight: bold;";
    dialog.updatePreviewButton.onClick = function () {
        dialog.updatePreview();
    };

    fileButtonsSizer.add(dialog.addFilesButton);
    fileButtonsSizer.add(dialog.removeSelectedButton);
    fileButtonsSizer.add(dialog.clearAllButton);
    fileButtonsSizer.addStretch();
    fileButtonsSizer.add(dialog.updatePreviewButton);

    fileManagementSizer.add(fileButtonsSizer);
    fileManagementGroupBox.sizer = fileManagementSizer;

    // Main action buttons
    let mainButtonsSizer = new HorizontalSizer;
    mainButtonsSizer.spacing = 10;

    // New Instance button
    dialog.newInstanceButton = new ToolButton(dialog);
    dialog.newInstanceButton.icon = dialog.scaledResource(":/process-interface/new-instance.png");
    dialog.newInstanceButton.setScaledFixedSize(24, 24);
    dialog.newInstanceButton.toolTip = "Create Process Icon - Drag to save current settings";
    dialog.newInstanceButton.onMousePress = function () {
        this.hasFocus = true;
        this.pushed = false;
        this.dialog.newInstance();
    };

    dialog.renameButton = new PushButton(dialog);
    dialog.renameButton.text = "Rename Files";
    dialog.renameButton.icon = dialog.scaledResource(":/icons/ok.png");
    dialog.renameButton.styleSheet = "font-weight: bold; padding: 8px 16px;";
    dialog.renameButton.onClick = function () {
        this.dialog.ok();
    };

    dialog.cancelButton = new PushButton(dialog);
    dialog.cancelButton.text = "Cancel";
    dialog.cancelButton.icon = dialog.scaledResource(":/icons/cancel.png");
    dialog.cancelButton.onClick = function () {
        this.dialog.cancel();
    };

    mainButtonsSizer.add(dialog.newInstanceButton);
    mainButtonsSizer.addStretch();
    mainButtonsSizer.add(dialog.renameButton);
    mainButtonsSizer.add(dialog.cancelButton);

    // Update preview function
    dialog.updatePreview = function() {
        let searchText = this.searchText.text || "";
        let replaceText = this.replaceText.text || "";
        let protectExtension = this.protectExtensionCheckBox.checked;

        for (let i = 0; i < this.fileList.numberOfChildren; ++i) {
            let node = this.fileList.child(i);
            let originalPath = node.filePath || "";
            let originalFileName = File.extractNameAndSuffix(originalPath) || node.text(0);

            if (searchText && searchText.trim() !== "") {
                let newFileName = getNewFileName(originalPath || originalFileName, searchText, replaceText, protectExtension);
                node.setText(1, newFileName);

                // Update status
                if (newFileName === originalFileName) {
                    node.setText(2, "No change");
                } else {
                    node.setText(2, "Will rename");
                }
            } else {
                node.setText(1, "Enter search text");
                node.setText(2, "Waiting");
            }
        }
    };

    // Auto-update preview when text changes
    dialog.searchText.onTextUpdated = function(value) {
        this.dialog.updatePreview();
    };

    dialog.replaceText.onTextUpdated = function(value) {
        this.dialog.updatePreview();
    };

    dialog.protectExtensionCheckBox.onCheck = function(checked) {
        this.dialog.updatePreview();
    };

    // Main layout
    let mainSizer = new VerticalSizer;
    mainSizer.margin = 12;
    mainSizer.spacing = 12;
    mainSizer.add(titleLabel);
    mainSizer.add(websiteLabel);
    mainSizer.add(instructionsGroupBox);
    mainSizer.add(searchReplaceGroupBox);
    mainSizer.add(fileManagementGroupBox);
    mainSizer.add(mainButtonsSizer);

    dialog.sizer = mainSizer;
    dialog.adjustToContents();
    // Make dialog 50% bigger for better file name visibility
    dialog.setMinWidth(Math.max(dialog.width, 1200));
    dialog.setMinHeight(Math.max(dialog.height, 800));

    return dialog;
}

// Enhanced main function with comprehensive validation
function main() {
    let dialog = createRenameFileDialog();

    if (dialog.execute()) {
        let searchText = dialog.searchText.text;
        let replaceText = dialog.replaceText.text;
        let protectExtension = dialog.protectExtensionCheckBox.checked;

        // Validate inputs
        let validationErrors = validateInputs(searchText, replaceText);
        if (validationErrors.length > 0) {
            let errorMessage = "Please fix the following issues:\n\n" + validationErrors.join("\n");
            Console.writeln("════════════════════════════════════════");
            Console.writeln("VALIDATION ERROR");
            Console.writeln("════════════════════════════════════════");
            Console.writeln(errorMessage);
            Console.writeln("════════════════════════════════════════");
            return;
        }

        // Check if there are files to process
        if (dialog.fileList.numberOfChildren === 0) {
            Console.writeln("════════════════════════════════════════");
            Console.writeln("NO FILES SELECTED");
            Console.writeln("════════════════════════════════════════");
            Console.writeln("No files selected for renaming.");
            Console.writeln("════════════════════════════════════════");
            return;
        }

        // Check for conflicts
        let conflicts = checkForConflicts(dialog.fileList, searchText, replaceText, protectExtension);
        if (conflicts.length > 0) {
            let conflictMessage = "The following conflicts were detected:\n\n" +
                                conflicts.slice(0, 5).join("\n") +
                                (conflicts.length > 5 ? "\n... and " + (conflicts.length - 5) + " more" : "") +
                                "\n\nPlease resolve these conflicts before proceeding.";
            Console.writeln("════════════════════════════════════════");
            Console.writeln("NAMING CONFLICTS DETECTED");
            Console.writeln("════════════════════════════════════════");
            Console.writeln(conflictMessage);
            Console.writeln("════════════════════════════════════════");
            return;
        }

        // Final confirmation
        let fileCount = dialog.fileList.numberOfChildren;
        let confirmMessage = "Are you sure you want to rename " + fileCount + " file(s)?\n\n" +
                           "Search for: '" + searchText + "'\n" +
                           "Replace with: '" + replaceText + "'\n" +
                           "Protect extensions: " + (protectExtension ? "Yes" : "No") + "\n\n" +
                           "This action cannot be undone!";

        // Show confirmation in console and proceed
        Console.writeln("════════════════════════════════════════");
        Console.writeln("CONFIRMATION REQUIRED");
        Console.writeln("════════════════════════════════════════");
        Console.writeln(confirmMessage);
        Console.writeln("════════════════════════════════════════");
        Console.writeln("Proceeding with file renaming operation...");

// User already confirmed by clicking Rename Files

        // Process the files
        Console.writeln("═══════════════════════════════════════");
        Console.writeln("BATCH FILE RENAMING STARTED - MASTERS OF PIXINSIGHT");
        Console.writeln("═══════════════════════════════════════");
        Console.writeln("Search text: '" + searchText + "'");
        Console.writeln("Replace text: '" + replaceText + "'");
        Console.writeln("Protect extensions: " + (protectExtension ? "Yes" : "No"));
        Console.writeln("Files to process: " + fileCount);
        Console.writeln("───────────────────────────────────────");

        let successCount = 0;
        let errorCount = 0;

        for (let i = 0; i < dialog.fileList.numberOfChildren; ++i) {
            let node = dialog.fileList.child(i);
            let oldFilePath = node.filePath || "";

            if (!oldFilePath) {
                Console.writeln("Skipped: No file path stored");
                continue;
            }

            let oldFileName = File.extractNameAndSuffix(oldFilePath);
            let newFileName = getNewFileName(oldFilePath, searchText, replaceText, protectExtension);

            // Skip if no change needed
            if (oldFileName === newFileName) {
                Console.writeln("Skipped (no change): " + oldFileName);
                continue;
            }

            let directory = File.extractDrive(oldFilePath) + File.extractDirectory(oldFilePath);
            let newFilePath = directory + "/" + newFileName;

            try {
                File.move(oldFilePath, newFilePath);
                Console.writeln("Success: '" + oldFileName + "' -> '" + newFileName + "'");
                successCount++;
            } catch (error) {
                Console.writeln("Error renaming '" + oldFileName + "': " + error.message);
                errorCount++;
            }
        }

        // Summary
        Console.writeln("───────────────────────────────────────");
        Console.writeln("RENAMING SUMMARY:");
        Console.writeln("Successfully renamed: " + successCount);
        if (errorCount > 0) {
            Console.writeln("Errors encountered: " + errorCount);
        }
        Console.writeln("═══════════════════════════════════════");

        // Show completion message
        let summaryMessage = "File renaming completed!\n\n" +
                           "Successfully renamed: " + successCount + " files\n" +
                           (errorCount > 0 ? "Errors: " + errorCount + " files\n" : "") +
                           "\nCheck the console for detailed results.";

        // Use console output instead of problematic MessageBox
        Console.writeln("════════════════════════════════════════");
        Console.writeln("RENAMING COMPLETE - MASTERS OF PIXINSIGHT");
        Console.writeln("════════════════════════════════════════");
        Console.writeln(summaryMessage);
        Console.writeln("════════════════════════════════════════");

        new MessageBox(
            "File renaming completed!\\n\\n" +
            "Successfully renamed: " + successCount + " files\\n" +
            (errorCount > 0 ? "Errors: " + errorCount + " files\\n" : "") +
            "\\nCheck the console for detailed results.",
            "Batch Rename Complete",
            StdIcon.Information,
            StdButton.Ok
        ).execute();

    } else {
        Console.writeln("File renaming process cancelled by user.");
    }
}

// Execute the main function
main();
