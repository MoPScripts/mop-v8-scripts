#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/*
   ImageInsert Script

   This script allows you to insert a small image in a larger one,
   setting the position, margin, optional border width and border color.

   Written by Enzo De Bernardini (PixInsight user)

   Changelog:
   1.0: First release in PixInsight Forum

   ----------------------------------------------------------------------------
   V8 PORT NOTICE
   ----------------------------------------------------------------------------
   Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
   (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
   July 2026. Original script copyright remains with Enzo De Bernardini.
   No rights to the original work are claimed or implied.

   V8 changes: added #engine v8 directive and version guard; removed #include
   directives; converted ii_dialog from __base__/prototype to class extends
   Dialog; expanded all with() statements (banned in V8 strict mode); updated
   PJSR constants to dot notation; fixed ImageWindow construction to use correct
   source dimensions; fixed Crop to execute on mainView; fixed ComboBox window
   arrays to use distinct closures; replaced deprecated setCurrentColor with
   currentColor property.
   ----------------------------------------------------------------------------
*/

#feature-id    ImageInsert : MoP V8 > ImageInsert

#feature-info  "<p>This script allows you to insert a small image in a larger one, setting the position, margins, optional border width and border color.</p>"

#define TITLE  "ImageInsert"
#define VERSION "1.0.0"


#define DEFAULT_TB_MARGIN 10
#define DEFAULT_RL_MARGIN 10
#define DEFAULT_BORDER_WIDTH 1

function Inset()
{
   this.executeMainFunction = function()
   {
      if(this.target_image == this.inset_image)
      {
         var msg = new MessageBox( "Same images selected!", "Image Selection Warning", StdIcon.Warning, StdButton.Ok );
         msg.execute();
         return false;
      }
      else
      {
         makeInset(this.target_image, this.inset_image, this.insetPosition, this.xMargin, this.yMargin, this.borderWidth, this.borderColor, this.croppedInsetClose);
         return true;
      } // if
   }; // executeMainFunction()
}; // Inset()

function makeInset(target_image, inset_image, insetPosition, xMargin, yMargin, borderWidth, borderColor, croppedInsetClose)
{

   var inset_w, inset_h, target_w, target_h, LM, TM, RM, BM, borderColor_r, borderColor_g, borderColor_b;


   // Target
   var target_window = ImageWindow.windowById( target_image );
   var target_img    = target_window.currentView.image;
   var target_view   = target_window.currentView;

   target_w = target_img.width;
   target_h = target_img.height;

   // Inset
   duplicateImage( inset_image, croppedInsetClose );
   var inset_window = ImageWindow.windowById( "InsetTemp" );
   var inset_img    = inset_window.currentView.image;
   var inset_view   = inset_window.currentView;

   inset_w = inset_img.width;
   inset_h = inset_img.height;

   xMargin += borderWidth;
   yMargin += borderWidth;

   // Border Color (rgba to decimal)
   borderColor_r = Color.red( borderColor )/255.0;
   borderColor_g = Color.green( borderColor )/255.0;
   borderColor_b = Color.blue( borderColor )/255.0;
   // ----

   switch( insetPosition )
   {
      case "Top_Left":
         LM = xMargin;
         TM = yMargin;
         RM = target_w - inset_w - xMargin;
         BM = target_h - inset_h - yMargin;
         EX = "iif(x() < (" + ( xMargin - borderWidth ) + ") || x() >= (" + ( inset_w + xMargin + borderWidth ) + ") || y() < " + ( yMargin - borderWidth ) + " || y() >= (" + ( inset_h + yMargin + borderWidth ) + ") , $T, InsetTemp)";
      break;
      case "Top_Right":
         LM = target_w - inset_w - xMargin;
         TM = yMargin;
         RM = xMargin;
         BM = target_h - inset_h - yMargin;
         EX = "iif(x() < (" + ( target_w - inset_w - xMargin - borderWidth ) + ") || x() >= (" + ( target_w - xMargin + borderWidth ) + ") || y() < " + ( yMargin - borderWidth ) + " || y() >= (" + ( inset_h + yMargin + borderWidth ) + ") , $T, InsetTemp)";
      break;
      case "Bottom_Left":
         LM = xMargin;
         TM = target_h - inset_h - yMargin;
         RM = target_w - inset_w - xMargin;
         BM = yMargin;
         EX = "iif(x() < (" + ( xMargin - borderWidth ) + ") || x() >= (" + ( inset_w + xMargin + borderWidth ) + ") || y() < " + ( target_h - inset_h - yMargin - borderWidth ) + " || y() >= (" + ( target_h - yMargin + borderWidth ) + ") , $T, InsetTemp)";
      break;
      case "Bottom_Right":
         LM = target_w - inset_w - xMargin;
         TM = target_h - inset_h - yMargin;
         RM = xMargin;
         BM = yMargin;
         EX = "iif(x() < (" + ( target_w - inset_w - xMargin - borderWidth ) + ") || x() >= (" + ( target_w - xMargin + borderWidth ) + ") || y() < " + ( target_h - inset_h - yMargin - borderWidth ) + " || y() >= (" + ( target_h - yMargin + borderWidth ) + ") , $T, InsetTemp)";
      break;
      case "Center_Left":
         LM = xMargin;
         TM = Math.round(target_h/2) - Math.round(inset_h/2);
         RM = target_w - inset_w - xMargin;
         BM = Math.floor(target_h/2) - Math.round(inset_h/2);
         EX = "iif(x() < (" + ( xMargin - borderWidth ) + ") || x() >= (" + ( inset_w + xMargin + borderWidth ) + ") || y() < " + ( TM - borderWidth ) + " || y() >= (" + ( Math.floor(target_h/2) + Math.round(inset_h/2) + borderWidth ) + ") , $T, InsetTemp)";
      break;
      case "Center_Right":
         LM = target_w - inset_w - xMargin;
         TM = Math.round(target_h/2) - Math.round(inset_h/2);
         RM = xMargin;
         BM = Math.floor(target_h/2) - Math.round(inset_h/2);
         EX = "iif(x() < (" + ( target_w - inset_w - xMargin - borderWidth ) + ") || x() >= (" + ( target_w - xMargin + borderWidth ) + ") || y() < " + ( TM - borderWidth ) + " || y() >= (" + ( Math.floor(target_h/2) + Math.round(inset_h/2) + borderWidth ) + ") , $T, InsetTemp)";
      break;
      case "Center_Top":
         LM = Math.round(target_w/2) - Math.round(inset_w/2);
         TM = yMargin;
         RM = Math.floor(target_w/2) - Math.round(inset_w/2);
         BM = target_h - inset_h - yMargin;
         EX = "iif(x() < (" + ( LM - borderWidth ) + ") || x() >= (" + ( target_w - RM + borderWidth ) + ") || y() < " + ( yMargin - borderWidth ) + " || y() >= (" + ( inset_h + yMargin + borderWidth ) + ") , $T, InsetTemp)";
      break;
      case "Center_Bottom":
         LM = Math.round(target_w/2) - Math.round(inset_w/2);
         TM = target_h - inset_h - yMargin;
         RM = Math.floor(target_w/2) - Math.round(inset_w/2);
         BM = yMargin;
         EX = "iif(x() < (" + ( LM - borderWidth ) + ") || x() >= (" + ( target_w - RM + borderWidth ) + ") || y() < " + ( target_h - inset_h - yMargin - borderWidth ) + " || y() >= (" + ( target_h - yMargin + borderWidth ) + ") , $T, InsetTemp)";
      break;
      case "Center_Center":
         LM = Math.round(target_w/2) - Math.round(inset_w/2);
         TM = Math.round(target_h/2) - Math.round(inset_h/2);
         RM = Math.floor(target_w/2) - Math.round(inset_w/2);
         BM = Math.floor(target_h/2) - Math.round(inset_h/2);
         EX = "iif(x() < (" + ( LM - borderWidth ) + ") || x() >= (" + ( target_w - RM + borderWidth ) + ") || y() < " + ( TM - borderWidth ) + " || y() >= (" + ( Math.floor(target_h/2) + Math.round(inset_h/2) + borderWidth ) + ") , $T, InsetTemp)";
      break;
   }; // switch


   // Croping the inset to target size
   var P = new Crop;
   P.leftMargin = LM;
   P.topMargin = TM;
   P.rightMargin = RM;
   P.bottomMargin = BM
   P.mode = 1; // AbsolutePixels - adds padding to expand image
   P.xResolution = 72.000;
   P.yResolution = 72.000;
   P.metric = false;
   P.forceResolution = false;
   P.red = borderColor_r;
   P.green = borderColor_g;
   P.blue = borderColor_b;
   P.alpha = 1.000000;

   P.executeOn( inset_window.mainView );
   // ----

   // PixelMath
   var P = new PixelMath;
   P.expression = EX;
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.symbols = "";
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0.0000000000;
   P.rescaleUpper = 1.0000000000;
   P.truncate = true;
   P.truncateLower = 0.0000000000;
   P.truncateUpper = 1.0000000000;
   P.createNewImage = true;
   P.newImageId = "ImageInset";
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.SameAsTarget;
   P.newImageSampleFormat = PixelMath.SameAsTarget;
   target_window.mainView.beginProcess( UndoFlag.NoSwapFile );
   P.executeOn( target_window.mainView, false );
   target_window.mainView.endProcess();

   // ----

   // Close or preserve intermediate image
   if( croppedInsetClose )
   {
      inset_window.forceClose();
   }
   else
   {
      inset_window.zoomToOptimalFit();
      inset_window.mainView.id = "InsetCropped";
   }; // if croppedInsetClose
   // ----


}; // makeInset()

// ----

// Function by Juan Conejero - Sep 17, 2007 (and modified by me - Dec 11, 2011)
// http://pixinsight.com/forum/index.php?topic=295.msg1003#msg1003
function duplicateImage( dw, dshow )
{
   var w = ImageWindow.windowById( dw );
   var v = w.mainView;

   // Always create as 32-bit float to handle any source format (8-bit JPEG,
   // 16-bit TIFF, 32-bit XISF etc). PixInsight processes work correctly on
   // float images regardless of the original bit depth.
   var bps      = ( v.image.sampleType != 0 ) ? v.image.bitsPerSample : 32;
   var isFloat  = true;

   var copy_img = new ImageWindow (
      v.image.width,
      v.image.height,
      v.image.numberOfChannels,
      bps,
      isFloat,
      v.image.colorSpace != ColorSpace.Gray,
      "InsetTemp" );

   copy_img.mainView.beginProcess( UndoFlag.NoSwapFile );
   copy_img.mainView.image.assign( v.image );
   copy_img.mainView.endProcess();

   if( !dshow )
   {
      copy_img.show();
   };

};
// ----

// UI Start

var engine = new Inset;

class ii_dialog extends Dialog
{
constructor()
{
   super();

   this.helpLabel = new Label (this);
   this.helpLabel.frameStyle = FrameStyle.Box;
   this.helpLabel.margin = 4;
   this.helpLabel.wordWrapping = true;
   this.helpLabel.useRichText = true;
   this.helpLabel.text = "<b>" + TITLE + " v" + VERSION + "</b> &mdash; Insert a small image in a larger one.";
   this.helpLabel.setScaledMinWidth( 490 );

   // Target Image Selection
   this.TargetImage_ComboBox = new ComboBox( this );
   this.TargetImage_ComboBox.setScaledMinWidth( 380 );
   var target_windows = Array.from( ImageWindow.windows );
      for ( var j = 0; j < target_windows.length; ++j )
      {
         this.TargetImage_ComboBox.addItem( target_windows[j].mainView.id );
      } // for
      this.TargetImage_ComboBox.onItemSelected = function(j) { engine.target_image = target_windows[j].mainView.id; };
      engine.target_image = target_windows[0].mainView.id;
   // ----

   // Inset Image Selection
   this.InsetImage_ComboBox = new ComboBox( this );
   this.InsetImage_ComboBox.setScaledMinWidth( 380 );
   var inset_windows = Array.from( ImageWindow.windows );
      for ( var j = 0; j < inset_windows.length; ++j )
      {
         this.InsetImage_ComboBox.addItem( inset_windows[j].mainView.id );
      } // for
      this.InsetImage_ComboBox.onItemSelected = function(j) { engine.inset_image = inset_windows[j].mainView.id; };
      engine.inset_image = inset_windows[0].mainView.id;
   // ----

   // Image Selection Labels
   // Target
   this.TargetImage_Label = new Label (this);
   this.TargetImage_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.TargetImage_Label.margin = 6;
   this.TargetImage_Label.text = "Main Image";
   // Inset
   this.InsetImage_Label = new Label (this);
   this.InsetImage_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.InsetImage_Label.margin = 6;
   this.InsetImage_Label.text = "Inset Image";
   // ----

   this.TargetImage_Sizer = new HorizontalSizer;
      this.TargetImage_Sizer.add( this.TargetImage_Label );
      this.TargetImage_Sizer.addStretch();
      this.TargetImage_Sizer.add( this.TargetImage_ComboBox, 100 );
      this.TargetImage_Sizer.addSpacing( 6 );

   this.InsetImage_Sizer = new HorizontalSizer;
      this.InsetImage_Sizer.add( this.InsetImage_Label );
      this.InsetImage_Sizer.addStretch();
      this.InsetImage_Sizer.add( this.InsetImage_ComboBox, 100 );
      this.InsetImage_Sizer.addSpacing( 6 );

   this.Images_GroupBox = new GroupBox (this);
   this.Images_GroupBox.title = "Images Selection:";
   this.Images_GroupBox.sizer = new VerticalSizer;
   this.Images_GroupBox.sizer.addSpacing( 6 );
   this.Images_GroupBox.sizer.add ( this.TargetImage_Sizer );
   this.Images_GroupBox.sizer.spacing = 4;
   this.Images_GroupBox.sizer.add ( this.InsetImage_Sizer );
   this.Images_GroupBox.sizer.addSpacing( 6 );

   // Settings
   // Location Selection
   this.Location_ComboBox = new ComboBox( this );

   var l = new Array (
      "Top_Left",
      "Top_Right",
      "Bottom_Left",
      "Bottom_Right",
      "Center_Left",
      "Center_Right",
      "Center_Top",
      "Center_Bottom",
      "Center_Center"
   );

      for( var i = 0 ; i < l.length ; i++)
      {
         this.Location_ComboBox.addItem( l[i] );
      } // for
      this.Location_ComboBox.onItemSelected = function(i) { engine.insetPosition = l[i]; };
      this.Location_ComboBox.currentItem = 1;
      engine.insetPosition = l[1];

   // Margin Y
   this.yMargin_SpinBox = new SpinBox( this );
      this.yMargin_SpinBox.minValue = 0;
      this.yMargin_SpinBox.maxValue = 500;
      this.yMargin_SpinBox.value = DEFAULT_TB_MARGIN;
      this.yMargin_SpinBox.toolTip = "Vertical margin from main image (top or bottom)";

      this.yMargin_SpinBox.onValueUpdated = function( value )
      {
         engine.yMargin = value;
      };
      engine.yMargin = DEFAULT_TB_MARGIN;

   // Margin X
   this.xMargin_SpinBox = new SpinBox( this );
      this.xMargin_SpinBox.minValue = 0;
      this.xMargin_SpinBox.maxValue = 500;
      this.xMargin_SpinBox.value = DEFAULT_RL_MARGIN;
      this.xMargin_SpinBox.toolTip = "Horizontal margin from main image (left or right)";

      this.xMargin_SpinBox.onValueUpdated = function( value )
      {
         engine.xMargin = value;
      };
      engine.xMargin = DEFAULT_RL_MARGIN;

   // Settings Labels
   // Location
   this.Location_Label = new Label (this);
   this.Location_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.Location_Label.margin = 6;
   this.Location_Label.text = "Inset Location";
   // Vertical Margin
   this.yMargin_Label = new Label (this);
   this.yMargin_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.yMargin_Label.margin = 6;
   this.yMargin_Label.text = "Vertical Margin";
   // Horizontal Margin
   this.xMargin_Label = new Label (this);
   this.xMargin_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.xMargin_Label.margin = 6;
   this.xMargin_Label.text = "Horizontal Margin";
   // ----

   this.Settings_Sizer = new HorizontalSizer;
      this.Settings_Sizer.add( this.Location_Label );
      this.Settings_Sizer.add( this.Location_ComboBox, 100 );
      this.Settings_Sizer.addStretch();
      this.Settings_Sizer.add( this.yMargin_Label );
      this.Settings_Sizer.add( this.yMargin_SpinBox );
      this.Settings_Sizer.addStretch();
      this.Settings_Sizer.add( this.xMargin_Label );
      this.Settings_Sizer.add( this.xMargin_SpinBox );
      this.Settings_Sizer.addSpacing( 6 );

   // ----

   // Border Settings

   // Border Width
   this.borderWidth_SpinBox = new SpinBox( this );
      this.borderWidth_SpinBox.minValue = 0;
      this.borderWidth_SpinBox.maxValue = 20;
      this.borderWidth_SpinBox.value = DEFAULT_BORDER_WIDTH;
      this.borderWidth_SpinBox.toolTip = "Border width around inset image.";

      this.borderWidth_SpinBox.onValueUpdated = function( value )
      {
         engine.borderWidth = value;
      };
      engine.borderWidth = DEFAULT_BORDER_WIDTH;

   // Color
   this.borderColor_ComboBox = new ColorComboBox( this );
   this.borderColor_ComboBox.currentColor = 0xffffffff;
   this.borderColor_ComboBox.toolTip = "Border Color.";
   this.borderColor_ComboBox.onColorSelected = function( rgba )
   {
      engine.borderColor = rgba;
   };
   engine.borderColor = 4294967295;

   // Border Settings Labels
   // Width
   this.borderWidth_Label = new Label( this );
   this.borderWidth_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.borderWidth_Label.text = "Border Width";
   this.borderWidth_Label.margin = 6;
   // Color
   this.borderColor_Label = new Label( this );
   this.borderColor_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.borderColor_Label.text = "Border color";
   this.Location_Label.margin = 6;
   // ---

   this.border_Sizer = new HorizontalSizer;
      this.border_Sizer.add( this.borderWidth_Label );
      this.border_Sizer.addSpacing( 5 );
      this.border_Sizer.add( this.borderWidth_SpinBox );
      this.border_Sizer.addStretch();
      this.border_Sizer.add( this.borderColor_Label );
      this.border_Sizer.addSpacing( 6 );
      this.border_Sizer.add( this.borderColor_ComboBox, 100 );
      this.border_Sizer.addStretch();

   // ----


   // Close Temp Cropped Inset Image
   this.croppedInsetClose_CheckBox = new CheckBox( this );
      this.croppedInsetClose_CheckBox.text = "Close intermediate image";
      this.croppedInsetClose_CheckBox.checked = true;
      this.croppedInsetClose_CheckBox.toolTip = "Close temporal intermediate generated cropped image. Uncheck to preserve.";

      this.croppedInsetClose_CheckBox.onCheck = function( checked )
      {
         engine.croppedInsetClose = checked;
      };
      engine.croppedInsetClose = true;
   // ----

   this.Options_Sizer = new HorizontalSizer;
      this.Options_Sizer.addSpacing( 6 );
      this.Options_Sizer.add( this.croppedInsetClose_CheckBox );

   this.Settings_GroupBox = new GroupBox (this);
   this.Settings_GroupBox.title = "Inset Settings:";
   this.Settings_GroupBox.sizer = new VerticalSizer;
   this.Settings_GroupBox.sizer.addSpacing( 6 );
   this.Settings_GroupBox.sizer.add ( this.Settings_Sizer );
   this.Settings_GroupBox.sizer.addSpacing( 6 );
   this.Settings_GroupBox.sizer.add ( this.border_Sizer );
   this.Settings_GroupBox.sizer.addSpacing( 6 );
   this.Settings_GroupBox.sizer.add ( this.Options_Sizer );
   this.Settings_GroupBox.sizer.addSpacing( 6 );

   // Buttons

   this.ok_Button = new PushButton (this);
   this.ok_Button.text = "OK";
   this.ok_Button.icon = this.scaledResource( ":/icons/ok.png" );
   this.ok_Button.onClick = function() {
      var result = engine.executeMainFunction();
      if( result )
      {
         this.dialog.cancel();
      };
   };

   this.cancel_Button = new PushButton (this);
   this.cancel_Button.text = "Cancel";
   this.cancel_Button.icon = this.scaledResource( ":/icons/cancel.png" );
   this.cancel_Button.onClick = function() {
      this.dialog.cancel();
   };

   this.buttons_Sizer = new HorizontalSizer;
   this.buttons_Sizer.spacing = 6;
   this.buttons_Sizer.addStretch();
   this.buttons_Sizer.add (this.ok_Button);
   this.buttons_Sizer.add (this.cancel_Button);

   this.sizer = new VerticalSizer;
   this.sizer.margin = 6;
   this.sizer.spacing = 6;
   this.sizer.add ( this.helpLabel );
   this.sizer.addSpacing (4);
   this.sizer.add( this.Images_GroupBox );
   this.sizer.addSpacing (4);
   this.sizer.add( this.Settings_GroupBox );
   this.sizer.addSpacing (4);
   this.sizer.add ( this.buttons_Sizer );

   this.windowTitle = TITLE + " Script v" + VERSION;
   this.adjustToContents();
}
}

// UI End

function main()
{

   Console.hide();
   var window = ImageWindow.activeWindow;

   if ( window.isNull )
   {
      Console.show();
      Console.writeln("\n<b>Error:</b> No active images.");
   }
   else
   {
      var dialog = new ii_dialog();
      dialog.execute();
   }

}; // main()

main();
