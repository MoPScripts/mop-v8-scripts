#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/*
AutoColor.js: Automatic ColorCalibration
================================================================================

Automatic BackgroundNeutralization and ColorCalibration in a single step.
The channel combined RGB becomes a calibrated image ready for further
processing (narrowband, delinearization, luminance, ...).

================================================================================
 *
 *    Copyright Hartmut V. Bornemann, 2016
 *
 * Image calibration is performed by background evaluation and calculation of
 * mean intensities over background of each channel.
 * These values are used by PixInsight standard processes
 * BackgroundNeutralization and ColorCalibration, which perform the adjustment
 * of background and colors as usual.
 *
 * History
 * 01.11.2016 Iterations set to 100
 *
 * ----------------------------------------------------------------------------
 * V8 PORT NOTICE
 * ----------------------------------------------------------------------------
 * Ported to PixInsight 1.9.4 V8 JavaScript engine by Georg Albrecht
 * (ggalbch@gmail.com) with additional packaging by Peter Proulx
 * (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
 * July 2026. Original script copyright remains with Hartmut V. Bornemann.
 * No rights to the original work are claimed or implied.
 *
 * V8 changes: added #engine v8 directive and version guard; replaced the
 * single .prototype. enum reference; added dialog with view selector and
 * New Instance button. Performance optimization by Georg Albrecht: uses
 * Float64Array for sky samples giving faster sort on large images.
 * ----------------------------------------------------------------------------
 */

#feature-id    AutoColor : MoP V8 > AutoColor

#define VERSION "1.2.0"

#feature-info  Automatic BackgroundNeutralization and ColorCalibration in a single step.<br/>\
   Copyright 2016 Hartmut V. Bornemann. V8 port by Georg Albrecht and Pete Proulx.

#define Iterations 100

// ============================================================================
// Dialog
// ============================================================================

class AutoColorDialog extends Dialog
{
constructor()
{
   super();
   var dlg = this;

   // ---- Title ----
   this.titleLabel = new Label( this );
   this.titleLabel.text = "AutoColor";
   this.titleLabel.textAlignment = TextAlignment.Center;
   this.titleLabel.styleSheet = "font-weight: bold; font-size: 15px; padding: 6px;";

   this.websiteLabel = new Label( this );
   this.websiteLabel.text = "www.mastersofpixinsight.com";
   this.websiteLabel.textAlignment = TextAlignment.Center;
   this.websiteLabel.styleSheet = "font-size: 11px; padding: 2px;";

   // ---- Explanation ----
   this.explanationBox = new GroupBox( this );
   this.explanationBox.title = "What This Script Does";
   this.explanationBox.titleCheckBox = false;

   this.explanationText = new Label( this );
   this.explanationText.text =
      "AutoColor performs automatic background neutralization and color " +
      "calibration in a single step, replacing the need to run " +
      "BackgroundNeutralization and ColorCalibration separately.\n\n" +
      "When to use it:\n" +
      "  \u2022  After channel combination on a linear RGB image\n" +
      "  \u2022  Before narrowband processing, delinearization, or luminance extraction\n" +
      "  \u2022  When you want a quick, automatic white balance and background removal\n\n" +
      "What it does:\n" +
      "  1. Samples the image background using a robust statistical sky algorithm\n" +
      "  2. Computes per-channel intensity and background values\n" +
      "  3. Applies BackgroundNeutralization to remove sky gradient color cast\n" +
      "  4. Applies ColorCalibration with computed white balance factors";
   this.explanationText.wordWrapping = true;
   this.explanationText.textAlignment = TextAlignment.Left;
   this.explanationText.styleSheet = "padding: 6px; line-height: 1.4;";

   var explanationSizer = new VerticalSizer;
   explanationSizer.margin = 6;
   explanationSizer.add( this.explanationText );
   this.explanationBox.sizer = explanationSizer;

   // ---- View selection ----
   this.viewGroupBox = new GroupBox( this );
   this.viewGroupBox.title = "Target Image";
   this.viewGroupBox.titleCheckBox = false;

   this.viewLabel = new Label( this );
   this.viewLabel.text = "Image:";
   this.viewLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
   this.viewLabel.setFixedWidth( 60 );

   this.viewList = new ViewList( this );
   this.viewList.getMainViews();
   this.viewList.toolTip = "Select the RGB color image to calibrate.";
   this.viewList.onViewSelected = ( view ) => {
      dlg.selectedView = view;
      dlg.updateInfo();
   };

   // Default to the active window
   let activeWin = ImageWindow.activeWindow;
   if ( activeWin != null && !activeWin.isNull )
   {
      this.viewList.currentView = activeWin.mainView;
      this.selectedView = activeWin.mainView;
   }

   this.viewInfoLabel = new Label( this );
   this.viewInfoLabel.text = "";
   this.viewInfoLabel.styleSheet = "font-style: italic; font-size: 11px; padding: 2px;";

   var viewSizer = new HorizontalSizer;
   viewSizer.spacing = 6;
   viewSizer.add( this.viewLabel );
   viewSizer.add( this.viewList );

   var viewMainSizer = new VerticalSizer;
   viewMainSizer.margin  = 6;
   viewMainSizer.spacing = 4;
   viewMainSizer.add( viewSizer );
   viewMainSizer.add( this.viewInfoLabel );
   this.viewGroupBox.sizer = viewMainSizer;

   // ---- Buttons ----
   this.newInstanceButton = new ToolButton( this );
   this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
   this.newInstanceButton.setScaledFixedSize( 24, 24 );
   this.newInstanceButton.toolTip = "New Instance \u2014 drag to workspace to save settings.";
   this.newInstanceButton.onMousePress = () => {
      dlg.newInstance();
   };

   this.okButton = new PushButton( this );
   this.okButton.text = "Apply";
   this.okButton.icon = this.scaledResource( ":/icons/ok.png" );
   this.okButton.defaultButton = true;
   this.okButton.styleSheet = "font-weight: bold;";
   this.okButton.onClick = () => { dlg.ok(); };

   this.cancelButton = new PushButton( this );
   this.cancelButton.text = "Cancel";
   this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
   this.cancelButton.onClick = () => { dlg.cancel(); };

   var buttonsSizer = new HorizontalSizer;
   buttonsSizer.spacing = 8;
   buttonsSizer.add( this.newInstanceButton );
   buttonsSizer.addStretch();
   buttonsSizer.add( this.okButton );
   buttonsSizer.add( this.cancelButton );

   // ---- Main layout ----
   this.sizer = new VerticalSizer;
   this.sizer.margin  = 10;
   this.sizer.spacing = 8;
   this.sizer.add( this.titleLabel );
   this.sizer.add( this.websiteLabel );
   this.sizer.add( this.explanationBox );
   this.sizer.add( this.viewGroupBox );
   this.sizer.add( buttonsSizer );

   this.windowTitle = "AutoColor v" + VERSION + " \u2014 Masters of PixInsight";
   this.adjustToContents();
   this.setFixedWidth();

   this.updateInfo();
}

updateInfo()
{
   if ( this.selectedView == null || this.selectedView.isNull )
   {
      this.viewInfoLabel.text = "No image selected.";
      this.okButton.enabled = false;
      return;
   }

   let img = this.selectedView.image;
   if ( !img.isColor )
   {
      this.viewInfoLabel.text = "\u26a0\ufe0f Not an RGB image \u2014 AutoColor requires a color image.";
      this.viewInfoLabel.styleSheet = "color: #cc6600; font-style: italic; font-size: 11px;";
      this.okButton.enabled = false;
      return;
   }

   this.viewInfoLabel.text =
      "\u2705 RGB Color  \u2022  " +
      img.width + " \xd7 " + img.height + " px  \u2022  " +
      img.bitsPerSample + "-bit  \u2022  Ready";
   this.viewInfoLabel.styleSheet = "color: #006600; font-style: italic; font-size: 11px;";
   this.okButton.enabled = true;
}

} // class AutoColorDialog

// ============================================================================
// Processing
// ============================================================================

function processView( view )
{
   Console.show();
   Console.writeln( "Auto Color Calibration: " + view.fullId );
   Console.flush();

   var img = view.image;
   if ( img.numberOfChannels != 3 )
   {
      Console.writeln( "This is not a color image." );
      return;
   }

   var channelR, channelG, channelB, target, sigma;
   var nSigma = 0;

   Console.writeln( format( "Image size       %i x %i", img.width, img.height ) );

   var subImage = new Image( img );
   var w = subImage.width;
   var h = subImage.height;

   if ( w > 256 && h > 255 )
   {
      subImage.cropTo( w * 0.1, h * 0.1, w * 0.9, h * 0.9 );
      Console.writeln( format( "Measure subframe %i x %i", subImage.width, subImage.height ) );
   }

   Console.writeln( "Channel intensities over background" );
   Console.flush();

   var S      = [0, 0, 0];
   var I      = [0, 0, 0];
   var strRGB = "RGB";

   for ( var channel = 0; channel < 3; channel++ )
   {
      subImage.selectedChannel = channel;
      S[channel] = ImageBackgroundMean( subImage, Iterations, 1 );
      I[channel] = subImage.mean() - S[channel];
      Console.writeln( format( "Intensity %c %.8f, Background %.8f",
                               strRGB[channel], I[channel], S[channel] ) );
      Console.flush();
   }

   var m = Math.min( I[0], I[1], I[2] );
   channelR = m / I[0];
   channelG = m / I[1];
   channelB = m / I[2];

   target = Math.max( S[0], S[1], S[2] );

   var index = S.indexOf( target );
   subImage.selectedChannel = index;
   sigma  = subImage.stdDev();
   nSigma = 3 * sigma;

   Console.writeln( format( "Target channel: %c", strRGB[index] ) );
   Console.writeln( format( "Target value    %.8f", target ) );
   Console.writeln( format( "Sigma           %.8f", sigma ) );

   bgNeutralization( view, target, nSigma );
   calibration( view, channelR, channelG, channelB, target + nSigma );

   Console.writeln( format( "White balance correction factors:" ) );
   Console.writeln( format( "Red    %.6f", channelR ) );
   Console.writeln( format( "Green  %.6f", channelG ) );
   Console.writeln( format( "Blue   %.6f", channelB ) );
   Console.writeln( "" );
}

// ============================================================================
// Math helpers
// ============================================================================

function ImageBackgroundMean( img, mxiter, readnoise )
{
   if (mxiter == 0) mxiter = 50;
   var minsky = 20;
   var sky = new Float64Array( img.width * img.height );
   img.getSamples( sky );

   var nsky  = sky.length;
   var nlast = nsky - 1;
   sky.sort();
   var skymid = 0.5*sky[Int((nsky-1)/2)] + 0.5*sky[Int(nsky/2)];
   var defSky = skymid;
   var cut  = Math.min( skymid-sky[0], sky[nsky-1]-skymid );
   var cut2 = skymid + cut;
   var cut1 = skymid - cut;

   var j1 = -1;
   var j2 = 0;
   for ( var i = 0; i < nsky; i++ )
   {
      if ( sky[i] >= cut1 )
      {
         j1 = i; j2 = i;
         for ( var j = 0; j < nsky; j++ )
         {
            if ( sky[j] <= cut2 ) j2 = j;
            else break;
         }
         break;
      }
   }

   if ( j1 < 0 )
   {
      Console.writeln( "ERROR - No sky values fall within " + cut1.toFixed(2) + " and " + cut2.toFixed(3) );
      return -1;
   }

   var good  = j2 - j1 + 1;
   var delta = new Array( good );
   for ( var i = 0; i < good; i++ )
      delta[i] = sky[j1 + i] - skymid;

   var sum   = total( delta );
   var sumsq = totalSqrd( delta );
   var maximm = j2;
   var minimm  = j1 - 1;
   var skymed = 0.5*sky[Int((minimm+maximm+1)/2)] + 0.5*sky[Int((minimm+maximm)/2)+1];
   var skymn  = sum / (maximm - minimm);
   var sigma  = Math.sqrt( sumsq/(maximm-minimm) - Math.pow(skymn,2) );
   skymn = skymn + skymid;
   var skymod = (skymed < skymn) ? 3.0*skymed - 2.0*skymn : skymn;
   var clamp = 1;
   var old   = 0;
   var niter = 0;

   while ( true )
   {
      niter += 1;
      if ( niter > mxiter )
      {
         Console.writeln( "ERROR - Too many (" + mxiter + ") iterations, unable to compute sky, default returned" );
         return defSky;
      }
      if ( (maximm - minimm) < minsky )
      {
         Console.writeln( "ERROR - Too few (" + (maximm-minimm).toString() + ") valid sky elements" );
         return -1;
      }
      var r  = Math.log10( maximm - minimm );
      r = Math.max( 2.0, (-0.1042*r + 1.1695)*r + 0.8895 );
      var cut  = r*sigma + 0.5*Math.abs(skymn-skymod);
      cut1 = skymod - cut;
      cut2 = skymod + cut;
      var redo   = false;
      var newmin = minimm;
      var tst_min = sky[newmin+1] >= cut1;
      var done = (newmin == -1) & tst_min;
      if (!done) done = (sky[Math.max(newmin,0)] < cut1) & tst_min;
      if (!done)
      {
         var istep = 1 - 2*boolToInteger(tst_min);
         while (!done)
         {
            newmin = newmin + istep;
            done = (newmin == -1) || (newmin == nlast);
            if (!done) done = (sky[newmin] <= cut1) && (sky[newmin+1] >= cut1);
         }
         if (tst_min) delta = SkySub(sky, newmin+1, minimm, skymid);
         else         delta = SkySub(sky, minimm+1, newmin, skymid);
         sum   -= istep * total(delta);
         sumsq -= istep * totalSqrd(delta);
         redo   = true;
         minimm = newmin;
      }
      var newmax  = maximm;
      var tst_max = sky[maximm] <= cut2;
      done = (maximm == nlast) && tst_max;
      if (!done) done = tst_max && (sky[Math.min((maximm+1),nlast)] > cut2);
      if (!done)
      {
         istep = -1 + 2*boolToInteger(tst_max);
         while (!done)
         {
            newmax = newmax + istep;
            done = (newmax == nlast) || (newmax == -1);
            if (!done) done = (sky[newmax] <= cut2) && (sky[newmax+1] >= cut2);
         }
         if (tst_max) delta = SkySub(sky, maximm+1, newmax, skymid);
         else         delta = SkySub(sky, newmax+1, maximm, skymid);
         sum   += istep * total(delta);
         sumsq += istep * totalSqrd(delta);
         redo   = true;
         maximm = newmax;
      }
      nsky = maximm - minimm;
      if ( nsky < minsky )
      {
         Console.writeln( "ERROR - Outlier rejection left too few sky elements" );
         return -1;
      }
      skymn  = sum / nsky;
      sigma  = Math.sqrt( Math.max(sumsq/nsky - Math.pow(skymn,2), 0) );
      skymn  = skymn + skymid;
      var center = (minimm + 1 + maximm) / 2.0;
      var side   = Math.round(0.2*(maximm-minimm)) / 2.0 + 0.25;
      var J = Math.round( center - side );
      var K = Math.round( center + side );
      if ( readnoise > 0 )
      {
         var L = Math.round( center - 0.25 );
         var M = Math.round( center + 0.25 );
         while ( (J > K) & (K < nsky-1) & (((sky[L]-sky[J]) < r) | ((sky[K]-sky[M]) < r)) )
         { J -= 1; K += 1; }
      }
      skymed = total( SkySub(sky, J, K, 0) ) / (K - J + 1);
      var dmod;
      if ( skymed < skymn ) dmod = 3.0*skymed - 2.0*skymn - skymod;
      else                   dmod = skymn - skymod;
      if ( dmod*old < 0 ) clamp = 0.5*clamp;
      skymod = skymod + clamp*dmod;
      old    = dmod;
      if (!redo) break;
   }
   return skymod;
}

function SkySub( Values, StartIndex, EndIndex, Reduction )
{
   var v = new Array( EndIndex - StartIndex + 1 );
   for ( var i = 0; i <= v.length-1; i++ )
      v[i] = Values[i + StartIndex] - Reduction;
   return v;
}

function boolToInteger( b ) { return b ? 1 : 0; }

function Int( f ) { return f < 0 ? Math.ceil(f) : Math.floor(f); }

function total( array )
{
   var sum = 0;
   for ( var i = 0; i < array.length; i++ ) sum += array[i];
   return sum;
}

function totalSqrd( array )
{
   var sum = 0;
   for ( var i = 0; i < array.length; i++ ) sum += Math.pow( array[i], 2 );
   return sum;
}

function bgNeutralization( view, target, nSigma )
{
   var P = new BackgroundNeutralization;
   P.backgroundReferenceViewId = "";
   P.backgroundLow  = 0.0;
   P.backgroundHigh = target + nSigma;
   P.useROI = false;
   P.roiX0 = 0; P.roiY0 = 0; P.roiX1 = 0; P.roiY1 = 0;
   P.mode = BackgroundNeutralization.TargetBackground;
   P.targetBackground = target;
   P.executeOn( view );
}

function calibration( view, r, g, b, target )
{
   var P = new ColorCalibration;
   P.whiteReferenceViewId = "";
   P.whiteLow  = 0.0;
   P.whiteHigh = 0.9;
   P.whiteUseROI = false;
   P.whiteROIX0 = 0; P.whiteROIY0 = 0; P.whiteROIX1 = 0; P.whiteROIY1 = 0;
   P.structureDetection  = false;
   P.structureLayers     = 5;
   P.noiseLayers         = 1;
   P.manualWhiteBalance  = true;
   P.manualRedFactor     = r;
   P.manualGreenFactor   = g;
   P.manualBlueFactor    = b;
   P.backgroundReferenceViewId = "";
   P.backgroundLow  = 0.0;
   P.backgroundHigh = target;
   P.backgroundUseROI = false;
   P.backgroundROIX0 = 0; P.backgroundROIY0 = 0; P.backgroundROIX1 = 0; P.backgroundROIY1 = 0;
   P.outputWhiteReferenceMask      = false;
   P.outputBackgroundReferenceMask = false;
   P.executeOn( view );
}

// ============================================================================
// Main
// ============================================================================

function main()
{
   let dialog = new AutoColorDialog();

   if ( dialog.execute() )
   {
      let view = dialog.selectedView;
      if ( view == null || view.isNull )
      {
         new MessageBox( "No image selected.", "AutoColor", StdIcon.Error, StdButton.Ok ).execute();
         return;
      }
      processView( view );
   }
}

main();
