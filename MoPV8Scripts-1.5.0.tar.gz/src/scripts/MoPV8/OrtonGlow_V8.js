#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

#feature-id    OrtonGlow : MoP V8 > OrtonGlow

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Roger Pettengell / Paul Hancock.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; removed #include
// directives; converted ScrollControl to class extends ScrollBox and MyDialog
// to class extends Dialog; moved executeAlgorithm from prototype to class
// method; expanded all with() statements; replaced all .prototype. enum
// references and underscore constants to dot notation.
// ----------------------------------------------------------------------------


#feature-info  This script creates an Orton Glow effect, similar to that produced in PS.<br/>\
Copyright &copy; 2024 Paul Hancock.

#define TITLE "Orton Glow"
#define VERSION "1.0         "
#define BUILD "202408192000"
#define DEBUGGING_MODE_ON false

/*****************************************************************************
 * Orton Glow Effect
 *
 * OrtonGlow.js
 * Copyright (C) 2024, Paul Hancock
 *
 * This script creates an Orton Glow effect, similar to that produced in PS.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 0.1    Testing and building
 * 0.2    Testing , preview added
 * 1.0    Ready for the Prime time (hopefully)

 *****************************************************************************/


// include constants

// Global parameters object
var OrtonParameters = {
    targetViewId: undefined,
    blurView: undefined,
    softlight: true,
    screen: false,
    overlay: false,
    opacity: "0.5",
    blur: 25.0,
    glowCreated: false,
    blendingMode: false,
    okToRun: false,
    numIterations: 1,
    openDialogbox: true,

    newInstance: function() {
        Console.writeln("New instance created.");
    },

    save: function() {
        Parameters.set("targetView", this.targetViewId);
        Parameters.set("blurView", this.blurView);
        Parameters.set("softlight", this.softlight);
        Parameters.set("screen", this.screen);
        Parameters.set("overlay", this.overlay);
        Parameters.set("opacity", this.opacity);
        Parameters.set("blur", this.blur);
        Parameters.set("numIterations", this.numIterations);
        Parameters.set("openDialogbox", this.openDialogbox);
    },

    load: function() {
        if (Parameters.has("targetView"))
            this.targetView = ImageWindow.windowById(Parameters.getString("targetView")).mainView;
        if (Parameters.has("softlight"))
            this.softlight = Parameters.getBoolean("softlight");
        if (Parameters.has("screen"))
            this.screen = Parameters.getBoolean("screen");
        if (Parameters.has("overlay"))
            this.overlay = Parameters.getBoolean("overlay");
        if (Parameters.has("opacity"))
            this.opacity = Parameters.getReal("opacity");
        if (Parameters.has("blur"))
            this.blur = Parameters.getReal("blur");
        if (Parameters.has("numIterations"))
            this.numIterations = Parameters.getInteger("numIterations");
        if (Parameters.has("openDialogbox"))
            this.openDialogbox = Parameters.getBoolean("openDialogbox");
    },

    main: function() {
        // Load parameters if available
        this.load();

        // Execute directly if there's a predefined target view (from Parameters)
        if (Parameters.isViewTarget && Parameters.targetView) {
            this.executeAlgorithm(this.numIterations);
        } else {
            // Otherwise, open the dialog for user input
            let dialog = new MyDialog();
            if (dialog.execute()) {
                // Check if a valid target view has been selected
                if (this.targetView && this.targetView.id) {
                    this.executeAlgorithm(this.numIterations);
                } else {
                    Console.writeln("No target view specified.");
                }
            } else {
                Console.writeln("Dialog execution cancelled.");
            }
        }
    },

    executeAlgorithm: function(iteration) {
        if (!this.targetView) {
            Console.writeln("No target view specified.");
            return;
        }
    }
};

// Call the load method to initialize parameters if needed
OrtonParameters.load();

/// use doUpdateImage() to set displayed image
/// largely based on code provided by Juan.
class ScrollControl extends ScrollBox
{
constructor( parent )
{
    super( parent );

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);

    this.viewport.cursor = new Cursor(StdCursor.OpenHand);

    /// get current result image. May be null
    this.getImage = function() {
        return this.displayImage;
    }; //getImage()

    /// called to notify that a redraw of image is necessary with given image
    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();  // Make sure this method correctly calculates and sets scroll ranges
        this.viewport.update();  // Redraw the viewport to reflect the new image and scroll states
    };

    // Ensure that scroll bar initialization method rechecks the necessity of scroll bars after every update
    this.initScrollBars = function() {
        var image = this.getImage();  // Ensure this method accurately fetches the current image
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
        } else {
            this.setHorizontalScrollRange(0, Math.max(0, image.width - this.viewport.width));
            this.setVerticalScrollRange(0, Math.max(0, image.height - this.viewport.height));
        }
        this.viewport.update();  // Make sure to update the viewport after setting scroll ranges
    };

    this.viewport.onResize = function() {
        this.parent.initScrollBars();
    };  //onResize()

    this.onHorizontalScrollPosUpdated = function(x) {
        this.viewport.update();
    };  //onHorizontalScrollPosUpdated()

    this.onVerticalScrollPosUpdated = function(y) {
        this.viewport.update();
    };  // onVerticalScrollPosUpdated()

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor.ClosedHand);
        this.parent.dragOrigin.x = x;
        this.parent.dragOrigin.y = y;
        this.parent.dragging = true;
    }; // onMousePress()

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        if (this.parent.dragging) {
            this.parent.scrollPosition = new Point(this.parent.scrollPosition).translatedBy(this.parent.dragOrigin.x - x, this.parent.dragOrigin.y - y);
            this.parent.dragOrigin.x = x;
            this.parent.dragOrigin.y = y;
        }
    }; // onMouseMove()

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor.OpenHand);
        this.parent.dragging = false;
    }; // onMouseRelease()

    this.viewport.onPaint = function(x0, y0, x1, y1) {
        if (DEBUGGING_MODE_ON) {
            Console.writeln("onPaint() entry");
        }
        var g = new Graphics(this);
        if (DEBUGGING_MODE_ON) {
            Console.writeln("onPaint() calling getImage()");
        }
        var result = this.parent.getImage();
        if (DEBUGGING_MODE_ON) {
            Console.writeln("onPaint() getImage() returned");
        }
        if (result == null) {
            // no current image, just draw a red background
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            result.selectedRect = (new Rect(x0, y0, x1, y1)).translated(this.parent.scrollPosition);
            g.drawBitmap(x0, y0, result.render());
            result.resetRectSelection();
        }
        g.end();
        if (DEBUGGING_MODE_ON) {
            Console.writeln("onPaint() exit");
        }
    }; //onPaint()

    this.initScrollBars();
} // constructor
}  //class ScrollControl

class MyDialog extends Dialog
{
constructor()
{
    super();
    var dlg = this;

    // Right column for preview window
    this.previewControl = new ScrollControl(this);
    this.previewControl.setMinWidth(800);  // Set minimum width
    this.previewControl.setMinHeight(500); // Set minimum height

    this.previewControl.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.displayImage;
        if (result == null) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            result.selectedRect = new Rect(x0, y0, x1, y1).translated(this.scrollPosition);
            g.drawBitmap(x0, y0, result);
            result.resetRectSelection();
        }
        g.end();
    };

    // Function to create, resize and display a temporary image
    this.createTemporaryImage = function(selectedImage) {
        let window = new ImageWindow(selectedImage.width, selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        // Assign image to the temporary window's main view
        window.mainView.beginProcess();
        window.mainView.image.assign(selectedImage);
        window.mainView.endProcess();

        // Resample the image in the window
        var P = new IntegerResample;
        const previewWidth = this.previewControl.width;
        const widthScale = Math.floor(selectedImage.width / previewWidth);
        P.zoomFactor = -Math.max(widthScale, 1);
        P.executeOn(window.mainView);

        // Extract the image data before closing the window
        let resizedImage = new Image(window.mainView.image);

        // Check if the image has valid dimensions
        if (resizedImage.width > 0 && resizedImage.height > 0) {
            // After setting the resized image to the previewControl
            this.previewControl.displayImage = resizedImage;
            this.previewControl.doUpdateImage(resizedImage);  // This method should handle setting the image and initializing scroll bars
            this.previewControl.initScrollBars();  // Add this line to force recheck of scroll bars right after updating
        } else {
            Console.error("Resized image has invalid dimensions.");
        }

        window.forceClose();  // Close the temporary window before setting to display control
        return resizedImage;
    };

    // Add setImage method to previewControl
    this.previewControl.setImage = function(image) {
        this.displayImage = image;
        this.repaint();
    };

    // Function to process the temporary image for preview purposes
    this.processPreview = function(selectedImage) {
        Console.writeln("Starting processPreview...");
        let processingWindow = new ImageWindow(
            selectedImage.width,
            selectedImage.height,
            selectedImage.numberOfChannels,
            selectedImage.bitsPerSample,
            selectedImage.isReal,
            selectedImage.isColor
        );

        if (!processingWindow || processingWindow.isNull) {
            Console.writeln("Failed to create processing window.");
            return;
        }

        processingWindow.hide();
        processingWindow.mainView.beginProcess();
        processingWindow.mainView.image.assign(selectedImage);
        processingWindow.mainView.endProcess();

        if (OrtonParameters.glowCreated == true)
        {
          ApplyOrtonPreview(processingWindow.mainView);
        }


        // After processing, use the dedicated method to create a temporary image from the processed window
        let tempImage = this.createTemporaryImage(processingWindow.mainView.image);
        if (tempImage) {
            this.previewControl.displayImage = tempImage;
            this.previewControl.update(); // Make sure this method refreshes the display
        } else {
            Console.writeln("Failed to create a temporary image for preview.");
        }

        // Close the processing window
        processingWindow.forceClose(); // Use appropriate method to close the window
    };

    // Main layout sizer
    this.mainSizer = new HorizontalSizer;
    this.mainSizer.spacing = 6;
    this.mainSizer.margin = 10;

    // Left column sizer
    this.leftSizer = new VerticalSizer;
    this.leftSizer.spacing = 6;

    // Right column sizer
    this.rightSizer = new VerticalSizer;
    this.rightSizer.spacing = 6;

    // Title and instructions setup
    this.titleSizer = new VerticalSizer;
    this.titleSizer.spacing = 4;
    this.titleBox = new Label(this);
    this.titleBox.text = "Orton Glow Utility - " + VERSION;
    this.titleBox.textAlignment = TextAlignment.Center;
    this.titleBox.frameStyle = FrameStyle.Box;
    this.titleBox.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #f0f0f0;";
    this.titleBox.setFixedHeight(30);
    this.titleSizer.add(this.titleBox);

    this.instructionsBox = new TextBox(this);
    this.instructionsBox.text = "This script provides an environment to create an Orton Glow Effect. " +
                     "<br><br>" +
                     "Simply select your image from the drop down menu and decide on the blending mode." +
                     "The opacity slider determines the percentage of the Orton blending. Larger values for " +
                     "stronger blending and vice versa." +
                     "<br><br>" +
                     "A Good opacity starter values is around the 0.1 region. You can use the Preview Refresh button to test your parameters." +
                     "<br><br>" +
                     "(Ensure that you choose your desired image from the drop down box. Even though it is selected by default and a preview shows the script won't run without that initial selection for some reason I haven't pinpointed yet.)" +
                     "<br><br>" +
                     "Copyright &copy; 2024 Paul Hancock. All Rights Reserved.";
    this.instructionsBox.textAlignment = TextAlignment.Left;
    this.instructionsBox.frameStyle = FrameStyle.Box;
    this.instructionsBox.styleSheet = "font-size: 8pt; padding: 10px; background-color: #e6e6fa;";
    this.instructionsBox.setFixedHeight(300);
    this.titleSizer.add(this.instructionsBox);
    this.leftSizer.add(this.titleSizer);

    // Image selection setup
    this.imageSizer = new HorizontalSizer;
    this.imageLabel = new Label(this);
    this.imageLabel.text = "Select Your Image:";
    this.imageLabel.textAlignment = TextAlignment.Left;
    this.imageList = new ComboBox(this);
    this.imageList.addItem("Select an image");
    // Set the maximum width for the ComboBox
    this.imageList.maxWidth = 450; // Adjust the value as needed

    for (var i = 0; i < ImageWindow.windows.length; ++i) {
        this.imageList.addItem(ImageWindow.windows[i].mainView.id);
    }

    // Always default to "Select an image" - force user to choose
    this.imageList.currentItem = 0;

    this.imageList.onItemSelected = (index) => {
        var window = ImageWindow.windowById(this.imageList.itemText(index));
        if (window && !window.isNull) {
            this.targetView = window.mainView; // Ensure this is being set correctly
            var selectedImage = window.mainView.image;
            var tmpImage = this.createTemporaryImage(selectedImage);
            this.previewControl.displayImage = tmpImage;
            this.previewControl.initScrollBars();
            this.previewControl.viewport.update();
            // Trigger preview refresh directly after setting the image
            this.processPreview(selectedImage); // Assuming processPreview is the method that handles the refresh

            // Save the selected view ID to global parameters for persistence
            OrtonParameters.targetViewId = window.mainView.id; // Ensure OrtonParameters has a property for targetViewId
            Console.writeln(OrtonParameters.targetViewId);
            OrtonParameters.save(); // Call save function to store parameters
            this.glowButton.enabled = true;
            this.convolutionSlider.enabled = true;
        }
    };

    this.imageSizer.add(this.imageLabel);
    this.imageSizer.add(this.imageList);
    this.imageSizer.addSpacing(4);
    //this.leftSizer.add(this.imageSizer);

    //Image Selection Pane
    this.imageSelectionsizer = new HorizontalSizer;
    this.imageSelectionsizer.add(this.imageSizer);
    this.imageSelectionsizer.addSpacing(5);
    this.viewGroup = new GroupBox( this );
    this.viewGroup.title = "Select the Base Image";
    this.viewGroup.sizer = this.imageSelectionsizer;
    this.leftSizer.add(this.viewGroup);

    //Create Glow Image Button
    this.glowButton = new PushButton(this);
    this.glowButton.text = "Create Duplicate for Glow";
    this.glowButton.width = 40;
    this.glowButton.enabled = false;
    this.glowButton.onClick = () => {
      GlowImage();
      Blur();
      OrtonParameters.blurView = OrtonParameters.targetViewId + "_glow";
      OrtonParameters.glowCreated = true;
      this.screen.enabled = true;
      this.softlight.enabled = true;
      this.overlay.enabled = true;
      this.opacitySlider.enabled = true;
    }

   //Add Convolution Amount Slider
   this.convolutionSlider = new NumericControl(this);
   this.convolutionSlider.label.text = "Convolution Blur slider";
   this.convolutionSlider.setRange(0,50);
   this.convolutionSlider.setPrecision(2);
   this.convolutionSlider.slider.setRange(0, 100);
   this.convolutionSlider.setValue(25);
   this.convolutionSlider.enabled = false;
   this.convolutionSlider.onValueUpdated = this.sliderChanged;
   this.convolutionSlider.onValueUpdated = function(b) {
      OrtonParameters.blur = b;
   }

   //Convolution Setting Pane
   this.convolutionSizer = new VerticalSizer;
   this.convolutionSizer.add(this.convolutionSlider);
   this.convolutionSizer.add(this.glowButton);
   this.convolutionSizer.addSpacing(2);
   this.convolutionSizer.addStretch();
   this.convolutionGroup = new GroupBox( this );
   this.convolutionGroup.title = "Create the Blurred Image for the Glow Effect";
   this.convolutionGroup.sizer = this.convolutionSizer;
   this.leftSizer.add(this.convolutionGroup);

   //Choose Screen Blending Mode
   this.screen = new RadioButton(this);
   this.screen.enabled = false;
      this.screen.text = "Screen";
      this.screen.toolTip = "Choose this option if you want to blend using Screen Blending Mode.";

      this.screen.onCheck = function ( checked )
      {
         OrtonParameters.screen = true;
         OrtonParameters.softlight = false;
         OrtonParameters.overlay = false;
         OrtonParameters.blendingMode = true;
         dlg.ortonButton.enabled = true;
      }

   //Choose Soft Light Blending Mode
   this.softlight = new RadioButton(this);
   this.softlight.enabled = false;
      this.softlight.text = "Soft Light";
      this.softlight.toolTip = "Choose this option if you want to blend using Soft Light Blending Mode.";

      this.softlight.onCheck = function ( checked )
      {
         OrtonParameters.screen = false;
         OrtonParameters.softlight = true;
         OrtonParameters.overlay = false;
         OrtonParameters.blendingMode = true;
         dlg.ortonButton.enabled = true;
      }

   //Choose Overlay Blending Mode
   this.overlay = new RadioButton(this);
   this.overlay.enabled = false;
      this.overlay.text = "Overlay";
      this.overlay.toolTip = "Choose this option if you want to blend using Overlay Blending Mode.";

      this.overlay.onCheck = function ( checked )
      {
         OrtonParameters.screen = false;
         OrtonParameters.softlight = false;
         OrtonParameters.overlay = true;
         dlg.ortonButton.enabled = true;
      }

   //Blending Mode Selection Pane
   this.blendingSizer = new VerticalSizer;
   this.blendingSizer.add(this.screen);
   this.blendingSizer.add(this.softlight);
   this.blendingSizer.add(this.overlay);
   this.blendingSizer.addSpacing(2);
   this.blendingGroup = new GroupBox( this );
   this.blendingGroup.title = "Choose the Blending Mode";
   this.blendingGroup.sizer = this.blendingSizer;
   this.leftSizer.add(this.blendingGroup);

   //Add Opacity Slider
   this.opacitySlider = new NumericControl(this);
   this.opacitySlider.label.text = "Opacity slider";
   this.opacitySlider.setRange(0,1);
   this.opacitySlider.setPrecision(2);
   this.opacitySlider.slider.setRange(0, 100);
   this.opacitySlider.setValue(0.5);
   this.opacitySlider.enabled = false;
   this.opacitySlider.onValueUpdated = this.sliderChanged;
   this.opacitySlider.onValueUpdated = function(k) {
      OrtonParameters.opacity = k;
   }

   //Opacity Setting Pane
   this.opacitySizer = new VerticalSizer;
   this.opacitySizer.add(this.opacitySlider);
   this.opacitySizer.addSpacing(2);
   this.opacityGroup = new GroupBox( this );
   this.opacityGroup.title = "Set the Orton Opacity Percentage";
   this.opacityGroup.sizer = this.opacitySizer;
   this.leftSizer.add(this.opacityGroup);

   //Apply Orton Glow Button
   this.ortonButton = new PushButton(this);
   this.ortonButton.text = "Apply the Orton Effect";
   this.ortonButton.width = 40;
   this.ortonButton.enabled = false;
   this.ortonButton.onClick = () => {
      ApplyOrton();
   }

   //Apply the Orton Effect Pane
   this.ortonSizer = new VerticalSizer;
   this.ortonSizer.add(this.ortonButton);
   this.ortonSizer.addSpacing(2);
   this.ortonGroup = new GroupBox( this );
   this.ortonGroup.title = "Apply the Orton Effect to the Image";
   this.ortonGroup.sizer = this.ortonSizer;
   this.leftSizer.add(this.ortonGroup);

    //VERSION and BUILD Numbers
   this.vBuild = new Label(this);
   this.vBuild.text = "Version - " + VERSION + " Build: " + BUILD;

    // Footer with authorship and website information
    this.authorshipLabel = new Label(this);
    this.authorshipLabel.text = "Written by Paul Hancock";
    this.authorshipLabel.textAlignment = TextAlignment.Center;
    this.leftSizer.add(this.authorshipLabel);

    this.websiteLabel = new Label(this);
    this.websiteLabel.text = "https://paulymanastro.photography";
    this.websiteLabel.textAlignment = TextAlignment.Center;
    this.leftSizer.add(this.websiteLabel);


    // Preview Refresh button
    this.previewButton = new PushButton(this);
    this.previewButton.text = "Preview Refresh";
    this.previewButton.onClick = () => {
        if (this.imageList.currentItem !== 0) { // Ensure an image is selected
            var window = ImageWindow.windowById(this.imageList.itemText(this.imageList.currentItem));
            if (window && !window.isNull) {
                var selectedImage = window.mainView.image;
                if (selectedImage) {
                    Console.writeln("Processing image with ID: " + window.mainView.id);
                    this.processPreview(selectedImage); // Ensure selectedImage is not undefined here
                } else {
                    Console.error("selectedImage is undefined.");
                }
            }
        } else {
            Console.writeln("No image selected for preview!");
        }
    };
    //this.leftSizer.add(this.previewButton);

    // Add the left column to the main sizer
    this.mainSizer.add(this.leftSizer);

    // Add the right column to the main sizer
    this.mainSizer.add(this.rightSizer);

    // Add the preview control to the main layout ensuring it expands
    this.rightSizer.add(this.previewControl, 1, 8); // Align_Expand
    this.rightSizer.add(this.previewButton);

    //Bottom Buttons
    this.newInstanceButton = new ToolButton( this );
    this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
    this.newInstanceButton.setScaledFixedSize( 24, 24 );
    this.newInstanceButton.toolTip = "New Instance \u2014 drag to workspace to save current settings.";
    this.newInstanceButton.onMousePress = () => {
       OrtonParameters.save();
       this.newInstance();
    };

    this.bottomSizer = new HorizontalSizer;
    this.bottomSizer.margin = 8;
    this.bottomSizer.add( this.newInstanceButton );
    this.bottomSizer.addStretch();
    this.bottomSizer.add(this.vBuild);
    this.bottomSizer.addStretch();

    this.finalSizer = new VerticalSizer;
    this.finalSizer.margin = 8;
    this.finalSizer.add(this.mainSizer);
    this.finalSizer.addSpacing(8);
    this.finalSizer.add(this.bottomSizer);
    this.finalSizer.addStretch();

    this.sizer = this.finalSizer;

    // Setup the window title and adjust dialog contents to fit
    this.windowTitle = TITLE;
    this.adjustToContents();

    // After all setups are done, check for the initial image and refresh the preview automatically
    this.onShow = () => {
        if (this.imageList.currentItem > 0) {  // Checks if there's an initially selected image
            var window = ImageWindow.windowById(this.imageList.itemText(this.imageList.currentItem));
            if (window && !window.isNull) {
                var selectedImage = window.mainView.image;
                if (selectedImage) {
                    Console.writeln("Displaying the initial image in the preview.");
                    // Instead of processing the preview, just display the image
                    var tmpImage = this.createTemporaryImage(selectedImage);
                    this.previewControl.displayImage = tmpImage;
                    this.previewControl.initScrollBars();
                    this.previewControl.viewport.update();
                }
            }
        } else {
            Console.writeln("No initial image selected.");
        }
    };
}

executeAlgorithm( numIterations ) {
    if (this.imageList.currentItem < 0) {
        new MessageBox("No image selected for processing.", TITLE, StdIcon.Error, StdButton.Ok).execute();
        return;
    }

    let targetView = ImageWindow.windowById(this.imageList.itemText(this.imageList.currentItem)).mainView;
    Console.writeln("Target View ID:", targetView.id);


} // executeAlgorithm
} // class MyDialog


// Standalone executeAlgorithm for OrtonParameters context
OrtonParameters.executeAlgorithm = function() {
    if (!this.targetView) {
        Console.writeln("No target view specified.");
        return;
    }
};


// Update the main function to ensure it is properly set
function main() {
    Console.show();
    OrtonParameters.load();  // Ensure parameters are loaded

    if (Parameters.isGlobalTarget) {
        // Running from a dragged process icon - open dialog with saved parameters
        let dialog = new MyDialog();
        if (dialog.execute()) {
            dialog.executeAlgorithm(OrtonParameters.numIterations);
        }
        return;
    }

    if (OrtonParameters.openDialogbox) {
        let dialog = new MyDialog();
        if (dialog.execute()) {
            dialog.executeAlgorithm(OrtonParameters.numIterations);
        } else {
            Console.noteln("Orton Glow Utility Dialog Closed.");
        }
    } else {
        if (OrtonParameters.targetView) {
            Console.writeln("Executing immediately with stored parameters.");
            OrtonParameters.executeAlgorithm(OrtonParameters.numIterations);
        } else {
            Console.noteln("No target view specified.");
            // Optionally, fall back to opening the dialog if no target view is set
            OrtonParameters.openDialogbox = true;  // Change to true to ensure dialog opens next time
            main();  // Recursively call main to handle dialog opening
        }
    }
}

function GlowImage()
{
   var P = new PixelMath;
   P.expression = OrtonParameters.targetViewId;
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.symbols = "";
   P.clearImageCacheAndExit = false;
   P.cacheGeneratedImages = false;
   P.generateOutput = true;
   P.singleThreaded = false;
   P.optimization = true;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = true;
   P.showNewImage = true;
   P.newImageId = OrtonParameters.targetViewId + "_glow";
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.SameAsTarget;
   P.newImageSampleFormat = PixelMath.SameAsTarget;

   P.newImageSampleFormat = PixelMath.SameAsTarget;
   P.executeOn(View.viewById(OrtonParameters.targetViewId));
}

function Blur()
{
   var P = new Convolution;
   P.mode = Convolution.Parametric;
   P.sigma = OrtonParameters.blur;
   P.shape = 2.00;
   P.aspectRatio = 1.00;
   P.rotationAngle = 0.00;
   P.filterSource = "";
   P.rescaleHighPass = false;
   P.viewId = "glow";
   P.executeOn(View.viewById(OrtonParameters.targetViewId + "_glow"));
}

function ApplyOrton()
{
   var P = new PixelMath;
   var k = OrtonParameters.opacity;
   var image = OrtonParameters.targetViewId;
   var glow = OrtonParameters.targetViewId+"_glow";
   if (OrtonParameters.softlight)
   {
      P.expression = k + "*iif(" + glow + ">0.5,~(~" + image + "*~(" + glow + "-0.5))," + image + "*(" + glow + "+0.5))+~" + k + "*" + image;
   }
   if (OrtonParameters.screen)
   {
      P.expression = k + "*~(~" + image + "*~" + glow + ")+~" + k + "*" + image;
   }
   if (OrtonParameters.overlay)
   {
      P.expression = k + "*iif(" + image + "> 0.5, ~(~(2*(" + image + "- 0.5)) * ~" + glow + "), 2*" + image + "*" + glow + ")+~" + k + "*" + image;
   }
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.clearImageCacheAndExit = false;
   P.cacheGeneratedImages = false;
   P.generateOutput = true;
   P.singleThreaded = false;
   P.optimization = true;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = false;
   P.showNewImage = true;
   P.newImageId = "";
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.SameAsTarget;
   P.newImageSampleFormat = PixelMath.SameAsTarget;

   P.newImageSampleFormat = PixelMath.SameAsTarget;
   P.executeOn(View.viewById(OrtonParameters.targetViewId));

}

function ApplyOrtonPreview(view)
{
   var P = new PixelMath;
   var k = OrtonParameters.opacity;
   var glow = OrtonParameters.targetViewId+"_glow";
   if (OrtonParameters.softlight)
   {
      P.expression = k + "*iif(" + glow + ">0.5,~(~$T" + "*~(" + glow + "-0.5)), $T*(" + glow + "+0.5))+~" + k + "*$T";
   }
   if (OrtonParameters.screen)
   {
      P.expression = k + "*~(~$T*~" + glow + ")+~" + k + "*$T";
   }
   if (OrtonParameters.overlay)
   {
      P.expression = k + "*iif( $T > 0.5, ~(~(2*($T - 0.5)) * ~" + glow + "), 2*$T*" + glow + ")+~" + k + "*$T";
   }
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.clearImageCacheAndExit = false;
   P.cacheGeneratedImages = false;
   P.generateOutput = true;
   P.singleThreaded = false;
   P.optimization = true;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = false;
   P.showNewImage = true;
   P.newImageId = "";
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.SameAsTarget;
   P.newImageSampleFormat = PixelMath.SameAsTarget;

   P.newImageSampleFormat = PixelMath.SameAsTarget;
   P.executeOn(view);

}

main();

