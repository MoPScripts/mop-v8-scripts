#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Hartmut V. Bornemann.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; removed #include
// directives; converted showDialog to class extends Dialog and PreviewControl
// to class extends Frame; expanded all with() statements; replaced
// VectorGraphics with Graphics; replaced processEvents() with
// CoreApplication.processEvents(); replaced underscore constants.
// ----------------------------------------------------------------------------

/*
   SKill.js

   Purpose:

      - black paint satellite trails
      or
      - replace satellite tracks with pixels from a reference frame


   Copyright (C) 2022, Hartmut V. Bornemann

   mailto: hvb356@hotmail.de


   Acknowledgements

   Andres del Pozo for his PreviewControl.js

   stackoverflow for a nice curve interpolation function

   Herbert Walter and Gerald Wechselberger for testing and tips
*/


#feature-id    SKill : MoP V8 > SKill


#define VERSION "1.0.15"
#define DEFAULT_AUTOSTRETCH_SCLIP -2.80
// Target mean background in the [0,1] range.
#define DEFAULT_AUTOSTRETCH_TBGND   0.25
#define DEFAULT_AUTOSTRETCH_CLINK   false


#define ID        "SKill"
#define TITLE     ID + " " + VERSION



// *****************************************************************************
//
// object to hold track points and methods for one track
//
function Track(index, bounds, trackStateCallback, trackCollection)
{
   //
   // add new point
   //
   this.addPoint = function (x, y)
   {
      this.trackPoints.push(new Point(x, y));
      this.x0 = x;
      this.y0 = y;
      this.reorder();

      for (var i = 0; i < this.trackPoints.length; i++)
      {
         var p = this.trackPoints[i];
         if (p.x == x & p.y == y)
         {
            this.pointIndex = i;
         }
      }
      this.callback(this.trackCollection, false);
   }
   //
   // remove the currently clicked point
   //
   this.removePoint = function ()
   {
      if (this.pointIndex < 0 | this.pointIndex >= this.trackPoints.length) return;
      this.trackPoints.splice(this.pointIndex, 1);
      this.callback(this.trackCollection, false);
   }
   //
   //
   //
   this.reorder = function ()
   {
      if (this.trackPoints.length > 2)
      {
         var u = -1;
         var v = -1;
         var m = 0;
         for (var i = 0; i < this.trackPoints.length; i++)
         {
            for (var j = 0; j < this.trackPoints.length; j++)
            {
               if (i == j) continue;
               var d = dist(this.trackPoints[i], this.trackPoints[j]);
               if (d > m)
               {
                  m = d;
                  u = i;
                  v = j;
               }
            }
         }
         //
         // get points in ascending diff from point[i]
         //
         var points = [];
         points.push(this.trackPoints[u]);
         for (var i = 0; i < this.trackPoints.length; i++)
         {
            if (i != u & i != v) points.push(this.trackPoints[i]);
         }
         points.push(this.trackPoints[v]);
         //
         // now 1st and last are in their position
         //
         this.trackPoints = [...points];
         //
         var pIndex = [];
         for (var i = 0; i < this.trackPoints.length; i++)
         {
            var d = dist(this.trackPoints[0], this.trackPoints[i]);
            pIndex.push(new Point(d, i));
         }
         //
         pIndex.sort(function(a,b) {
            if( a.x == b.x) return a.y-b.y;
            return a.x-b.x;
         });
         //
         points = [];
         //
         for (var i = 0; i < pIndex.length; i++)
            points.push(this.trackPoints[pIndex[i].y]);
         this.trackPoints = [...points];
      }
   }

   function dist(tp1, tp2)
   {
      return Math.sqrt(Math.pow(tp1.x - tp2.x, 2) + Math.pow(tp1.y - tp2.y, 2));
   }

   // paint black line

   this.paintMask = function (g, lineWidth)
   {
      if (this.trackPoints.length == 0) return;

      var pen = new Pen(0xff000000, lineWidth, PenStyle.Solid, PenCap.Round);

      g.pen = pen;

      var curve = getCurvePoints(this.trackPoints);

      g.drawPolyline(curve);
   }

   this.paintPreview = function (g)
   {
      if (this.trackPoints.length == 0) return;

      g.pen = new Pen(this.penColor);

      for (var i = 0; i < this.trackPoints.length; i++)
      {
         var x = this.trackPoints[i].x;
         var y = this.trackPoints[i].y;
         g.drawLine(x - this.tick, y, x + this.tick, y);
         g.drawLine(x, y - this.tick, x, y + this.tick);
         g.drawEllipse(x - this.radius, y - this.radius, x + this.radius, y + this.radius);
      }

      var pen = new Pen(this.penColor, this.lineWidth, PenStyle.Solid, PenCap.Round);

      g.pen = pen;

      var curve = getCurvePoints(this.trackPoints);

      g.drawPolyline(curve);
   }
   //
   // check, if mouse clicked a circle
   //
   this.isPointSelected = function (x, y)
   {
      for (var i = 0; i < this.trackPoints.length; i++)
      {
         var dist = Math.sqrt(Math.pow(x - this.trackPoints[i].x, 2) +
                              Math.pow(y - this.trackPoints[i].y, 2));
         if (dist <= this.radius)
         {
            this.pointIndex = i;
            return true;
         }
      }
      return false;
   }


   this.mouseDown = function (x, y)
   {
      this.x0 = x;
      this.y0 = y;
   }


   this.mouseMove = function (x, y)
   {
      var dx = x - this.x0;
      var dy = y - this.y0;
      var p = this.trackPoints[this.pointIndex];

      if (!this.bounds.includes(p))
      {
         if (p.x < this.bounds.x0) p = new Point (this.bounds.x0, p.y);
         if (p.y < this.bounds.y0) p = new Point (p.x, this.bounds.y0);
         if (p.x > this.bounds.x1) p = new Point (this.bounds.x1, p.y);
         if (p.y > this.bounds.y1) p = new Point (p.x, this.bounds.y1);
      }

      this.trackPoints[this.pointIndex] = new Point(p.x + dx, p.y + dy);

      this.x0 = x;
      this.y0 = y;
   }


   this.mouseUp = function (x, y)
   {
      this.reorder();
   }

   this.count = function ()
   {
      return this.trackPoints.length;
   }

   this.x0 = 0;
   this.y0 = 0;

   this.lineWidth = 1;

   this.penColor = 0;

   this.tick = 28;

   this.radius = 24;

   this.bounds = bounds;

   this.selected = false;

   this.pointIndex = -1;

   this.trackIndex = index;

   this.trackPoints = [];

   this.callback = trackStateCallback;

   this.trackCollection = trackCollection;

   this.trackID = Math.random();
}

// *****************************************************************************

function TrackCollection(bounds)
{
   this.addTrack = function ()
   {
      var index = this.tracks.length;
      this.tracks.push(new Track(index, this.bounds, setTrackState, this));
      this.selectTrack(index);
      this.saved = false
   }


   this.removeTrack = function()
   {
      if (this.selectedTrack != null)
      {
         var index = this.selectedTrack.trackIndex;
         var temp = [];
         for (var i = 0; i < this.tracks.length; i++)
         {
            if (this.tracks[i].trackIndex != index) temp.push(this.tracks[i]);
         }
         this.tracks = temp;
         for (var i = 0; i < this.tracks.length; i++)
         {
            this.tracks[i].trackIndex = i;
         }
         if (index >= this.tracks.length) index = this.tracks.length - 1;
         if (this.tracks.length > 0) this.selectTrack(index);
         setTrackState(this, this.tracks.length == 0);
      }
   }
   //
   // find a track by x, y, set selected track and pointIndex
   //
   this.detectTrack = function (x, y)
   {
      for (var i = 0; i < this.tracks.length; i++)
      {
         if (this.tracks[i].isPointSelected (x, y))
         {
            for (var j = 0; j < this.tracks.length; j++)
            {
               this.tracks[j].selected = j == i;
            }
            this.tracks[i].selected = true;
            this.selectedTrack = this.tracks[i];
            this.selectedTrack.penColor = this.SelectedColor;
            this.selectedTrack.mouseDown(x, y);
            return true;
         }
      }
      return false;
   }

   this.paintMask = function (graphics, lineWidth)
   {

      for (var i = 0; i < this.tracks.length; i++)
      {
         this.tracks[i].paintMask(graphics, lineWidth);
      }
   }

   // preview paint, tracks & markers

   this.paintPreview = function (graphics)
   {
      for (var i = 0; i < this.tracks.length; i++)
      {
         if (this.tracks[i].selected)
            this.tracks[i].penColor = this.SelectedColor;
         else
            this.tracks[i].penColor = this.DeSelectedColor;
         //
         // paint with choosen colors
         //
         this.tracks[i].paintPreview(graphics);
      }
   }

   this.selectTrack = function (index)
   {
      //
      // de-select all
      //
      for (var i = 0; i < this.tracks.length; i++)
      {
         this.tracks[i].selected = false;
      }
      //
      if (index > -1 && this.tracks.length > 0)
      {
         this.tracks[index].selected = true;
         this.selectedTrack = this.tracks[index];
         this.selectedTrack.lineWidth = this.lineWidth;

         return true;
      }
      else
      {
         this.selectedTrack = null;
      }
      return false;
   }

   this.setLineWidth = function (width)
   {
      this.lineWidth = width;

      for (var i = 0; i < this.tracks.length; i++)
      {
         this.tracks[i].lineWidth = width;
      }
   }

   this.count = function ()
   {
      return this.tracks.length;
   }

   this.lineWidth = 1;

   this.tracks = [];     // collection of tracks

   this.bounds = bounds;

   this.selectedTrack = null;

   this.SelectedColor = 0xffff0000;
   this.DeSelectedColor = 0xffffff00;

   this.saved = false;

   // save track points as json string
   //
   this.setTracksToView = function (view)
   {
      var strings = [];
      for (var i = 0; i < this.tracks.length; i++)
      {
         var T = this.tracks[i];

         var points = [];

         for (var j = 0; j < T.trackPoints.length; j++)
         {
            points.push(new TPoint(T.trackPoints[j]));
         }

         strings.push(JSON.stringify(points));
      }

      view.setPropertyValue('Tracks', strings.join('\n'));
   }
}

function TPoint(point)
{
   this.x = point.x;
   this.y = point.y;
}

function setTrackState(trackCollection, state)
{
   trackCollection.saved = state;
}
// *****************************************************************************


class showDialog extends Dialog
{
constructor()
{
   super();
   //
   // Add all properties and methods of the core Dialog object to this object.
   //
   this.userResizable = true;
   var dialog = this;
   this.backgroundColor = 0xff242424;
   this.foregroundColor = 0xffffffff;

   var formsScaling = this.displayPixelRatio ;

   var Screen = GetPrimaryScreenDimensions(dialog);

   var normalSize;

   var isNormalSize = true;

   this.font = new Font("Helvetica", 9);

   var drawTracksSized = false;

   var offset = 12;

   var selectedTrack = null;


   this.previewControl = new PreviewControl(this);
      this.previewControl.onCustomMouseDown = function (x, y, button, buttonState, modifiers)
      {
         if (button != MouseButton.Left) return;

         if (dialog.t.Tracks.detectTrack(x, y))
         {
            selectedTrack = dialog.t.Tracks.selectedTrack;
            if (modifiers == KeyModifier.Control)
            {
               selectedTrack.removePoint();
               if (selectedTrack.count() == 0)
               {
                  dialog.t.Tracks.removeTrack();

                  if (dialog.t.Tracks.count() == 0)
                  {
                     selectedTrack = null;
                     dialog.lblSelectedTrack.text = 'No track';
                  }
                  else
                  {
                     dialog.lblSelectedTrack.text = 'Track# ' +
                        (selectedTrack.trackIndex + 1).toString();
                  }
               }
               dialog.previewControl.forceRedraw();
            }
            else
            {
               dialog.previewControl.forceRedraw();
               dialog.lblSelectedTrack.text = 'Track# ' +
                  (selectedTrack.trackIndex + 1).toString();
            }
            return;
         }

         if (selectedTrack != null)
         {
            //
            // add a new point
            //
            selectedTrack.addPoint(x,y);
            dialog.previewControl.forceRedraw();
            dialog.btnRemove.enabled = true;
            dialog.btnApply.enabled = dialog.btnRemove.enabled;
         }
      }

      this.previewControl.onCustomMouseMove = function( x, y, buttonState, modifiers )
      {
         if (buttonState != MouseButton.Left) return;
         if (selectedTrack != null)
         {
            selectedTrack.mouseMove(x, y);
            dialog.previewControl.forceRedraw();
         }
      }

      this.previewControl.onMouseRelease = function( x, y, button, buttonState, modifiers )
      {
         if (button != MouseButton.Left) return;
         if (selectedTrack != null)
         {
            selectedTrack.mouseUp(x, y);
         }
      }

      this.previewControl.onCustomPaint = function (graphics, x0, y0, x1, y1 )
      {
         graphics.antialiasing = true;
         dialog.t.Tracks.paintPreview(graphics);
      }

   // display

   this.richTextBox = new Label(this);
      this.richTextBox.backgroundColor = this.backgroundColor;
      this.richTextBox.foregroundColor = this.foregroundColor;
      this.richTextBox.useRichText = true;
      this.richTextBox.visible = false;

   // assemble GUI elements

   // my ©

   this.lblCopyright = new Label(this)
      this.lblCopyright.backgroundColor = this.backgroundColor;
      this.lblCopyright.foregroundColor = this.foregroundColor;
      this.lblCopyright.font = this.font;
      this.lblCopyright.text = "© 2020, Hartmut V. Bornemann";

   this.btnHelp = new ToolButton(this);
      this.btnHelp.icon = this.scaledResource( ":/icons/help.png" );
      this.btnHelp.setScaledFixedSize( 24, 24 );
      this.btnHelp.toolTip = '<p><b><font size="5">Satellite track removal</font></b><br></p>' +

      '<p><font size="4"><b>' + ID + '</b> usage summary: </font><br></p>' +

      '<p>- <b>Add</b> inserts ne new empty line in a collection of tracks</p>' +
      '<p>- <b>Remove</b> takes the current selected line off from the collection</p>' +
      '<p>- <b>Select a reference view (opt.)</b> Selection of a reference view(s).</p>' +
      '<p>..The reference view is to replace tracks with good pixels.</p>' +
      '<p>- <b>Line width</b> determines the thickness of the painted tracks</p>' +
      '<p>- <b>Preview</b> checkBox toggles painting of tracks in the preview pane</p>' +
      '<p>- <b>Apply</b> paints the tracks on the current view<br></p>' +

      '<p><u><font size="4">Mouse operations:</font></u></p>' +
      '<p>- Click anywhere adds a new anker point to a selected track</p>' +
      '<p>- Keep mouse down inside an anker point moves the point</p>' +
      '<p>- CTRL + mouse down inside an anker point removes the point from the track<br></p>' +

      '<p><u><font size="4">General remarks:</font></u></p>' +
      '<p>- Use optimal view when setting the anker points.</p>' +
      '<p>- Enlarge the view to at least 1:1 scale for precise positioning.</p>';

   this.toolNormal = new ToolButton(this);
      this.toolNormal.icon = this.scaledResource(':/icons/window-small.png');
      this.toolNormal.setScaledFixedSize( 24, 24 );
      this.toolNormal.toolTip = 'Restore this dialog window';

      this.toolNormal.onPress = function ()
      {
         if (!isNormalSize)
         {
            dialog.move(normalSize.x0, normalSize.y0);
            dialog.resize(normalSize.width, normalSize.height);
            isNormalSize = true;
         }
      }

   this.toolMax = new ToolButton(this);
      this.toolMax.icon = this.scaledResource(':/icons/window.png');
      this.toolMax.setScaledFixedSize( 24, 24 );
      this.toolMax.toolTip = 'Maximize this dialog window';

      this.toolMax.onPress = function ()
      {
         if (isNormalSize)
         {
            var x0 = dialog.position.x;
            var y0 = dialog.position.y;
            var x1 = dialog.position.x + dialog.width;
            var y1 = dialog.position.y + dialog.height;
            normalSize = new Rect(x0, y0, x1, y1);
            dialog.move(0, 0);
            dialog.resize(Screen.width, Screen.height - 36 * formsScaling);
            isNormalSize = false;
         }
      }

   this.workspaceViewList = new ComboBox(this);// ViewList(this);
      var current = -1;
      var windows = ImageWindow.windows;
      for (var i = 0; i < windows.length;i++)
      {
         var v = windows[i].mainView;

         if (!v.image.isColor)
         {
            this.workspaceViewList.addItem(v.id);
            if (v.id == ImageWindow.activeWindow.currentView.id) current = this.workspaceViewList.numberOfItems -1;
         }
      }

      if (current > -1) this.workspaceViewList.currentItem = current;

      this.workspaceViewList.onItemSelected = function (index)
      {
         var id = dialog.workspaceViewList.itemText(index);
         var view = null;
         var windows = ImageWindow.windows;
         for (var i=0; i < windows.length;i++)
         {
            if (windows[i].mainView.id == id)
            {
               view = windows[i].mainView;
               break;
            }
         }

         if (dialog.t.Tracks.count() > 0 & !dialog.t.Tracks.saved)
         {
            var msg = new MessageBox("Save now ?",'The view has changes',
               StdIcon.Question, StdButton.Yes, StdButton.Yes);
            var res = msg.execute();
            if (res == StdButton.Yes)
            {
               this.workspaceViewList.save (dialog);
            }
         }
         //
         if (dialog.t != null)
         {
            // check equal view id
            if (dialog.t.hasReference())
            {
               if (id == dialog.t.reference.id)
               {
                  new MessageBox('View and reference must be different.',
                        'No view selected',
                        StdIcon.Information, StdButton.Ok).execute();
                  return;
               }

               var refImg = dialog.t.reference.image;
               if (view.image.width != refImg.width |
                   view.image.height != refImg.height)
               {
                  dialog.t.clearReference();
                  new MessageBox('View and reference have different geometry.',
                        'No view selected',
                        StdIcon.Information, StdButton.Ok).execute();
                  return;
               }
            }
         }
         //
         dialog.t = new viewsSetup(dialog, view.window, dialog.previewControl);
         checkReference();
         dialog.windowTitle = TITLE + ' - ' + view.id;
      }


   this.btnAdd = new PushButton(this);
      this.btnAdd.backgroundColor = this.backgroundColor;
      this.btnAdd.foregroundColor = this.foregroundColor;
      this.btnAdd.font = this.font;
      this.btnAdd.icon = this.scaledResource(':/icons/add.png');
      this.btnAdd.text = 'Add';
      this.btnAdd.toolTip = '<b>Start with a new tracking line.</b><p>' +
                'Click at track start and track end. If the track is curved, add one ore more points.<p>' +
                'Each point marks a movable anker point. Precision can be improved by clicking inside the circle and moving the cursor.';

      this.btnAdd.onClick = function ( checked )
      {
         if (selectedTrack != null && selectedTrack.count() < 2) return;
         dialog.t.Tracks.addTrack();
         selectedTrack = dialog.t.Tracks.selectedTrack;

         dialog.lblSelectedTrack.text = 'Track# ' + (selectedTrack.trackIndex + 1).toString();
      }


   this.numLineWidth = new NumericEdit(this);
      this.numLineWidth.backgroundColor = this.backgroundColor;
      this.numLineWidth.foregroundColor = this.foregroundColor;
      this.numLineWidth.label.foregroundColor = this.foregroundColor;
      this.numLineWidth.label.font = this.font;
      this.numLineWidth.label.text = 'Line width';
      this.numLineWidth.setPrecision(0);
      this.numLineWidth.setRange(1, 1024);
      this.numLineWidth.setValue(10);
      this.numLineWidth.toolTip = '<b>Set the track width.</b><p>' +
          'The width in pixels must cover the track.';

      this.numLineWidth.onValueUpdated = function ( value )
      {
         if (drawTracksSized)
            dialog.t.Tracks.setLineWidth (value);
         else
            dialog.t.Tracks.setLineWidth (1);
         dialog.previewControl.forceRedraw();
      }


   this.lblSelectedTrack = new Label(this);
      this.lblSelectedTrack.backgroundColor = this.backgroundColor;
      this.lblSelectedTrack.foregroundColor = this.foregroundColor;
      this.lblSelectedTrack.font = this.font;
      this.lblSelectedTrack.text = 'No track';


   this.btnRemove = new PushButton(this);
      this.btnRemove.backgroundColor = this.backgroundColor;
      this.btnRemove.enabled = false;
      this.btnRemove.foregroundColor = this.foregroundColor;
      this.btnRemove.font = this.font;
      this.btnRemove.icon = this.scaledResource(':/icons/remove.png');
      this.btnRemove.text = 'Remove';
      this.btnRemove.toolTip = '<b>Remove the seleted track from the preview.</b><p>' +
         'Remove a single anker point by CTRL + mouse click inside the circle.';

      this.btnRemove.onClick = function ( checked )
      {
         dialog.t.Tracks.removeTrack();
         dialog.btnRemove.enabled = dialog.t.Tracks.tracks.length > 0;
         dialog.btnApply.enabled = dialog.btnRemove.enabled;
         dialog.previewControl.forceRedraw();
         if (dialog.t.Tracks.count() > 0)
         {
            selectedTrack = dialog.t.Tracks.selectedTrack;
            dialog.lblSelectedTrack.text = 'Track# ' +
               (selectedTrack.trackIndex + 1).toString();
         }
         else
         {
            selectedTrack = null;
            dialog.lblSelectedTrack.text = 'No track';
         }
      }


   this.lblAddReference = new Label(this);
      this.lblAddReference.backgroundColor = this.backgroundColor;
      this.lblAddReference.foregroundColor = this.foregroundColor;
      this.lblAddReference.font = this.font;
      this.lblAddReference.text = 'Select a reference view';

   this.cmbReferences = new ComboBox(this);
      this.cmbReferences.addItem('no reference');
      var windows = ImageWindow.windows;
      for (var i=0; i < windows.length;i++)
      {
         var v = windows[i].mainView;

         if (!v.image.isColor) this.cmbReferences.addItem(v.id);
      }

      this.cmbReferences.visible = this.cmbReferences.numberOfItems > 1;
      dialog.lblAddReference.visible = this.cmbReferences.numberOfItems > 1;
      //
      this.cmbReferences.onItemSelected = function (index)
      {
         checkReference();

         /*
         var id = dialog.cmbReferences.itemText(index);

         if (index == 0)
         {
            dialog.t.reference = null;
            return;
         }
         else
         {
            var view = null;
            var windows = ImageWindow.windows;
            for (var i=0; i < windows.length;i++)
            {
               if (windows[i].mainView.id == id)
               {
                  view = windows[i].mainView;
                  Console.writeln('View id ' + id);
                  break;
               }
            }

            if (view.id == dialog.t.view.id)
            {
               new MessageBox('The reference view must be different.',
               'No reference selected',
               StdIcon.Information, StdButton.Ok).execute();

               dialog.cmbReferences.currentItem = 0;

               return;
            }

            if (dialog.t.view.image.width == view.image.width &
                dialog.t.view.image.height == view.image.height)
            {
               dialog.t.setReference( view );
               dialog.previewControl.forceRedraw();
               selectedTrack = null;
               dialog.btnApply.enabled = true;// save(dialog);
               return;
            }
            else
            {
               new MessageBox('The reference view incompatible.' +
                     ' Must be another grayscale with same size.',
                     'No reference selected',
                     StdIcon.Information, StdButton.Ok).execute();

               dialog.cmbReferences.currentItem = 0;

               return;
            }
         }*/
      }

   function checkReference()
   {
      var index = dialog.cmbReferences.currentItem;
      if (index == 0)
      {
         Console.writeln('No reference image');
         dialog.t.reference = null;
         return;
      }
      //
      var view = null;
      var id = dialog.cmbReferences.itemText(index);
      var windows = ImageWindow.windows;
      for (var i=0; i < windows.length;i++)
      {
         if (windows[i].mainView.id == id)
         {
            view = windows[i].mainView;
            Console.writeln('View id ' + id);
            break;
         }
      }

      if (view.id == dialog.t.view.id)
      {
         new MessageBox('The reference view must be different.',
         'No reference selected',
         StdIcon.Information, StdButton.Ok).execute();

         dialog.cmbReferences.currentItem = 0;

         return;
      }

      if (dialog.t.view.image.width == view.image.width &
          dialog.t.view.image.height == view.image.height)
      {
         dialog.t.setReference( view );
         dialog.previewControl.forceRedraw();
         selectedTrack = null;
         dialog.btnApply.enabled = true;
         return;
      }
      else
      {
         new MessageBox('The reference view incompatible.' +
               ' Must be another grayscale with same size.',
               'No reference selected',
               StdIcon.Information, StdButton.Ok).execute();

         dialog.cmbReferences.currentItem = 0;

         return;
      }
   }

   this.cbDrawMode = new CheckBox(this)
      this.cbDrawMode.backgroundColor = this.backgroundColor;
      this.cbDrawMode.foregroundColor = this.foregroundColor;
      this.cbDrawMode.font = this.font;
      this.cbDrawMode.text  = 'Preview';
      this.cbDrawMode.toolTip = '<b>Preview painting option.</b><p>' +
          'If checked, the preview lines are painted with defined width.';

      this.cbDrawMode.onCheck = function (checked)
      {
         drawTracksSized = checked;
         if (drawTracksSized)
            dialog.t.Tracks.setLineWidth (dialog.numLineWidth.value);
         else
            dialog.t.Tracks.setLineWidth (1);
         dialog.previewControl.forceRedraw();
      }


   this.btnApply = new PushButton(this);
      this.btnApply.backgroundColor = this.backgroundColor;
      this.btnApply.foregroundColor = this.foregroundColor;
      this.btnApply.enabled = false;
      this.btnApply.font = this.font;
      this.btnApply.icon = this.scaledResource(':/icons/ok.png');
      this.btnApply.text = '   Apply';
      this.btnApply.toolTip = '<b>Process track paintings on view.</b><p>' +
          'This will result in either a black line or a merge with a reference view.';

      this.btnApply.onClick = function ( checked )
      {
         selectedTrack = null;
         //dialog.btnSetReference.enabled = dialog.t.Tracks.count() > 0;
         save(dialog);
      }

   this.lblProcessing = new Label(this);
      this.lblProcessing.backgroundColor = this.backgroundColor;
      this.lblProcessing.foregroundColor = 0xff00f0ff;
      this.lblProcessing.font = new Font("Helvetica", 10);
      this.lblProcessing.font.bold = true;
      this.lblProcessing.text = '*** Processing ***';
      this.lblProcessing.visible = false;


   this.btnExit = new PushButton(this);
      this.btnExit.backgroundColor = this.backgroundColor;
      this.btnExit.foregroundColor = this.foregroundColor;
      this.btnExit.font = this.font;
      this.btnExit.icon = this.scaledResource(':/toolbar/file-exit.png');
      this.btnExit.text = '   Exit';
      this.btnExit.toolTip = '<b>Terminate the script.</b><p>';
      this.btnExit.onClick = function ( checked )
      {
         dialog.t.Tracks.setTracksToView(dialog.t.view);
         dialog.t.clearReference();
         dialog.done(0);
      }
   //
   // Frames
   //
   this.frame0 = new Frame(this);
      this.frame0.backgroundColor = 0xff0080ff;

      this.frame0.sizer = new HorizontalSizer();
         this.frame0.sizer.margin = 4;
         this.frame0.sizer.addSpacing(offset);
         this.frame0.sizer.add(this.btnHelp);
         this.frame0.sizer.addStretch();
         this.frame0.sizer.add(this.toolNormal);
         this.frame0.sizer.addSpacing(8);
         this.frame0.sizer.add(this.toolMax);
   //
   this.frame1 = new Frame(this);
      this.frame1.sizer = new HorizontalSizer();
         //margin = 4;
         this.frame1.sizer.add(this.workspaceViewList);
   //
   this.frame2 = new Frame(this);
      this.frame2.sizer = new HorizontalSizer();
         this.frame2.sizer.margin = 8;
         this.frame2.sizer.addSpacing(offset);
         this.frame2.sizer.add(this.btnAdd);
         this.frame2.sizer.addStretch();
   //
   this.frame3 = new Frame(this);
      this.frame3.sizer = new HorizontalSizer();
         this.frame3.sizer.margin = 8;
         this.frame3.sizer.addSpacing(offset);
         this.frame3.sizer.add(this.lblSelectedTrack);
         this.frame3.sizer.addStretch();
   //
   this.frame4 = new Frame(this);
      this.frame4.sizer = new HorizontalSizer();
         this.frame4.sizer.margin = 8;
         this.frame4.sizer.addSpacing(offset);
         this.frame4.sizer.add(this.btnRemove);
         this.frame4.sizer.addStretch();
   //
   this.frame5 = new Frame(this);
      this.frame5.sizer = new VerticalSizer();
         this.frame5.sizer.addSpacing(8);
        // add(this.cbAddReference);
         this.frame5.sizer.add( this.lblAddReference);
         this.frame5.sizer.addSpacing(8);
         this.frame5.sizer.add(this.cmbReferences);

   //
   this.frame6 = new Frame(this);
      this.frame6.sizer = new HorizontalSizer();
         this.frame6.sizer.margin = 8;
         this.frame6.sizer.addSpacing(offset);
         this.frame6.sizer.add(this.numLineWidth);
         this.frame6.sizer.addStretch();
   //
   this.frame7 = new Frame(this);
      this.frame7.sizer = new HorizontalSizer();
         this.frame7.sizer.margin = 8;
         this.frame7.sizer.addSpacing(offset);
         this.frame7.sizer.add(this.cbDrawMode);
         this.frame7.sizer.addStretch();
   //
   this.frame8 = new Frame(this);
      this.frame8.sizer = new HorizontalSizer();
         this.frame8.sizer.margin = 8;
         this.frame8.sizer.addSpacing(offset);
         this.frame8.sizer.add(this.btnApply);
         this.frame8.sizer.addSpacing(offset);
         this.frame8.sizer.add(this.lblProcessing);
         this.frame8.sizer.addStretch();

   //
   this.frame9 = new Frame(this);
      this.frame9.sizer = new HorizontalSizer();
         this.frame9.sizer.margin = 8;
         this.frame9.sizer.addSpacing(offset);
         this.frame9.sizer.add(this.btnExit);
         this.frame9.sizer.addStretch();
   //
   this.frame10 = new Frame(this);
      this.frame10.sizer = new VerticalSizer();
         this.frame10.sizer.margin = 4;
         this.frame10.sizer.add(this.frame0);
         this.frame10.sizer.addSpacing(8);
         this.frame10.sizer.add(this.frame1);
         this.frame10.sizer.addSpacing(28);
         this.frame10.sizer.add(this.frame5);
         this.frame10.sizer.addSpacing(46);
         this.frame10.sizer.add(this.frame2);
         this.frame10.sizer.addSpacing(16);
         this.frame10.sizer.add(this.frame3);
         this.frame10.sizer.addSpacing(16);
         this.frame10.sizer.add(this.frame4);
         this.frame10.sizer.addSpacing(16);
         this.frame10.sizer.add(this.frame6);
         this.frame10.sizer.addSpacing(16);
         this.frame10.sizer.add(this.frame7);
         this.frame10.sizer.addSpacing(16);
         this.frame10.sizer.add(this.frame8);
         this.frame10.sizer.addStretch();
         this.frame10.sizer.add(this.frame9);
         this.frame10.sizer.addSpacing(16);
         this.frame10.sizer.add(this.lblCopyright);
   //
   this.leftFrame = new Frame(this);
      this.leftFrame.setScaledFixedWidth(200);

      this.leftFrame.sizer = new VerticalSizer();
         this.leftFrame.sizer.add(this.frame0);
         this.leftFrame.sizer.add(this.frame10);
   //
   this.rightFrame = new Frame(this);
      this.rightFrame.backgroundColor = 0xff000000;
      this.rightFrame.sizer = new VerticalSizer();
      this.rightFrame.sizer.margin = 0;
      this.rightFrame.sizer.spacing = 0;
      this.rightFrame.sizer.add(this.previewControl)
      this.rightFrame.sizer.add(this.richTextBox);
   //
   this.fullFrame = new Frame(this);
      this.fullFrame.setScaledMinWidth(1200);
      this.fullFrame.setScaledMinHeight(800);
      this.fullFrame.sizer = new HorizontalSizer();
      this.fullFrame.sizer.add(this.leftFrame);
      this.fullFrame.sizer.add(this.rightFrame);
   //
   this.sizer = new Sizer();
   this.sizer.add(this.fullFrame);

   this.userResizable = true;

   this.t = new viewsSetup(dialog, ImageWindow.activeWindow, this.previewControl);

	this.adjustToContents();

   CoreApplication.processEvents();
} // constructor
} // class showDialog


function save(dialog)
{
   try
   {
      dialog.btnApply.visible = false;
      dialog.lblProcessing.visible = true;
      CoreApplication.processEvents();

      var mask = createMask(dialog);
      //
      //
      //
      if (dialog.t.hasReference())
      {
         Console.writeln('\nFill track(s) with pixels from a reference frame');
         Console.writeln( '=================================================\n');
         //
         var fittedReference = dialog.t.getFittedReference();
         //
         mergeReference(dialog.t.view, fittedReference, mask);
         //
         dialog.t.clearFittedReference();
         Console.writeln( 'Pixel from reference image merged');
      }
      else
      {
         Console.writeln('\nFill track(s) with black color');
         Console.writeln(  '==============================\n');
         //
         mergeReference(dialog.t.view, null, mask);
         Console.writeln( 'Black pixel merged');
      }
      //
      //
      Console.writeln( 'Close mask ' + mask.id);

      mask.window.forceClose();
      //
      setTrackState(dialog.t.Tracks, true);
      dialog.lblSelectedTrack.text = 'No track selected';
      dialog.btnApply.visible = true;
      dialog.lblProcessing.visible = false;
      CoreApplication.processEvents();
   }
   catch (ex)
   {
      Console.writeln('Save failed\n' +ex);
   }
}
//
// create a view with black track(s) on a white background
//
function createMask(dialog)
{
   // graphics
   //
   var maskBitmap = new Bitmap(dialog.t.bitmap.width, dialog.t.bitmap.height);
   var g = new Graphics(maskBitmap);
   g.fillRect(new Rect(0, 0, maskBitmap.width, maskBitmap. height),
      new Brush(0xffffffff));
   dialog.t.Tracks.paintMask(g, dialog.numLineWidth.value);
   g.end();
   //
   var image = new Image(maskBitmap.width, maskBitmap.height);
   image.blend(maskBitmap);
   //
   var maskWin = new ImageWindow(dialog.t.bitmap.width, dialog.t.bitmap.height,
      1, 32, true, false, dialog.t.maskId);
   maskWin.mainView.beginProcess(UndoFlag.NoSwapFile);
   maskWin.mainView.image.apply(image);
   maskWin.mainView.endProcess();
   //
   return maskWin.mainView;
}

function viewsSetup(dialog, Window, previewControl)
{
   this.editView = Window.mainView;

   var savedTracks = this.editView.propertyValue('Tracks');

   Console.writeln(savedTracks);

   this.meanOfMain = this.editView.image.mean();

   this.view = this.editView;

   var window = copyWindow(Window, Window.mainView.id + "_tracks");

   this.maskId = this.view.id + "_trackMask"

   var copyOfview = window.mainView;

   ApplyAutoSTF(copyOfview, DEFAULT_AUTOSTRETCH_SCLIP,
      DEFAULT_AUTOSTRETCH_TBGND );

   ApplyHistogram (copyOfview);

   this.bitmap = copyOfview.image.render();

   this.metadata = new Size(this.bitmap);

   window.forceClose();

   this.setReference = function (view)
   {
      this.clearReference();
      this.reference = view;
      Console.writeln('Reference is ' + this.reference.id);
   }

   this.getFittedReference = function ()
   {
      if (this.reference == null) return null;

      if (fittedReference == null)
      {
         fittedReference = copyView(this.reference, '_reference');

         Console.writeln("Fitted reference is " + fittedReference.id);

         Console.writeln('LinearFit on ' + fittedReference.id + '\n');

         try
         {
            var P = new LinearFit;
            P.referenceViewId = this.editView.id;
            P.rejectLow = 0.000000;
            P.rejectHigh = 0.999;
            P.executeOn(fittedReference);
         }
         catch (ex)
         {
            Console.writeln('LinearFit failed on ' + fittedReference.id + '\n' + ex);
         }
      }
      return fittedReference;
   }

   this.clearReference = function ()
   {
      if (fittedReference != null)
      {
         fittedReference.window.forceClose();
         fittedReference = null;
      }
      if (this.reference != null)
      {
         //this.reference.window.forceClose();
         this.reference = null;
      }
   }

   this.clearFittedReference = function ()
   {
      if (fittedReference != null)
      {
         fittedReference.window.forceClose();
         fittedReference = null;
      }
   }

   this.hasReference = function ()
   {
      return this.reference != null;
   }

   this.reference = null;

   var fittedReference = null;

   // collection of tracks
   this.Tracks = new TrackCollection(new Rect(0, 0, this.bitmap.width, this.bitmap.height));

  // this.Tracks.getTracksFromView(this.view);

   previewControl.SetImage(this.bitmap, this.metadata);

   dialog.windowTitle = TITLE + ' - ' + Window.mainView.id;
}

function mergeReference(view, reference, mask)
{
   // view is the target with sat tracks
   // reference is a registered view w/o tracks or null
   // mask is white with black tracks
   //
   var w = view.image.width;
   var h = view.image.height;
   //
   var v = new Float32Array(w * h);
   view.image.getSamples(v);
   //
   var m = new Float32Array(w * h);
   mask.image.getSamples (m);
   //
   if (reference != null)
   {
      var r = new Float32Array(w * h);
      reference.image.getSamples (r);
      for (var i = 0; i < v.length; i++)
      {
         if (m[i] == 0) v[i] = r[i];
      }
   }
   else
   {
      for (var i = 0; i < v.length; i++)
      {
         if (m[i] == 0) v[i] = 0;
      }
   }
   //
   // update view
   //
   var image = new Image(v, w, h);
   //
   view.beginProcess();
   view.image.apply(image);
   view.endProcess();
}

function copyView(view, newName)
{
   var win = new ImageWindow(view.image.width, view.image.height,
                             view.image.numberOfChannels,
                             view.image.bitsPerSample, view.image.isReal,
                             view.image.isColor,
                             newName);
   win.hide();
   win.mainView.beginProcess(UndoFlag.NoSwapFile);
   win.mainView.image.apply(view.image);
   win.mainView.endProcess();
   return win.mainView;
}

function copyWindow( window, newName)
{
   var view = window.mainView;

   var win = new ImageWindow(view.image.width, view.image.height,
                             view.image.numberOfChannels,
                             view.image.bitsPerSample, view.image.isReal,
                             view.image.isColor,
                             newName);
   win.hide();
   win.mainView.beginProcess(UndoFlag.NoSwapFile);
   win.mainView.image.apply(view.image);
   win.mainView.endProcess();
   return win;
}

function GetPrimaryScreenDimensions(dialog)
{
   //
   // get MainWindow\Geometry width & height
   //
   var roamingDir = File.homeDirectory + '/AppData/Roaming/Pleiades';
   var ini = roamingDir + '/PixInsight.ini';
   var x = 0;
   var y = 0;
   var w = 1920;
   var h = 1080;

   if (File.exists(ini))
   {
      var n = 0;
      var iniStrings = File.readLines(ini);
      for (var i = 0; i < iniStrings.length; i++)
      {
         var s = iniStrings[i];
         var a = s.split('=');
         var j = s.indexOf('=');

         var k = a[0];
         var v = a[1];

         if (k == 'MainWindow\\Geometry\\Top')
         {
            y = v.toInt();
            n++;
         }
         if (k == 'MainWindow\\Geometry\\Left')
         {
            x = v.toInt();
            n++;
         }
         if (k == 'MainWindow\\Geometry\\DesktopWidth')
         {
            w = v.toInt();
            n++;
         }
         if (k == 'MainWindow\\Geometry\\DesktopHeight')
         {
            h = v.toInt();
            n++;
         }

         if (n == 4) break;
      }
   }

   var scale = dialog.logicalPixelsToPhysical;
   return {left:x,top:y,width:w,height:h};
}

function Size(bitmap)
{
   this.width = bitmap.width;
   this.height = bitmap.height;
}

//
// modified source:
// https://stackoverflow.com/questions/7054272/how-to-draw-smooth-curve-through-n-points-using-javascript-html5-canvas
//
function getCurvePoints(points, tension, isClosed, numOfSegments) {

   var pts = [];
   for (var i = 0; i < points.length; i++)
   {
      pts.push(points[i].x);
      pts.push(points[i].y);
   }
   // use input value if provided, or use a default value
   tension = (typeof tension != 'undefined') ? tension : 0.5;
   isClosed = isClosed ? isClosed : false;
   numOfSegments = numOfSegments ? numOfSegments : 16;

   var _pts = [], res = [],    // clone array
     x, y,           // our x,y coords
     t1x, t2x, t1y, t2y, // tension vectors
     c1, c2, c3, c4,     // cardinal points
     st, t, i;       // steps based on num. of segments

   // clone array so we don't change the original
   //
   _pts = pts.slice(0);

   // The algorithm require a previous and next point to the actual point array.
   // Check if we will draw closed or open curve.
   // If closed, copy end points to beginning and first points to end
   // If open, duplicate first points to befinning, end points to end
   if (isClosed) {
     _pts.unshift(pts[pts.length - 1]);
     _pts.unshift(pts[pts.length - 2]);
     _pts.unshift(pts[pts.length - 1]);
     _pts.unshift(pts[pts.length - 2]);
     _pts.push(pts[0]);
     _pts.push(pts[1]);
   }
   else {
     _pts.unshift(pts[1]);   //copy 1. point and insert at beginning
     _pts.unshift(pts[0]);
     _pts.push(pts[pts.length - 2]); //copy last point and append
     _pts.push(pts[pts.length - 1]);
   }

   // ok, lets start..

   // 1. loop goes through point array
   // 2. loop goes through each segment between the 2 pts + 1e point before and after
   for (i=2; i < (_pts.length - 4); i+=2)
   {
      for (t=0; t <= numOfSegments; t++)
      {
         // calc tension vectors
         t1x = (_pts[i+2] - _pts[i-2]) * tension;
         t2x = (_pts[i+4] - _pts[i]) * tension;

         t1y = (_pts[i+3] - _pts[i-1]) * tension;
         t2y = (_pts[i+5] - _pts[i+1]) * tension;

         // calc step
         st = t / numOfSegments;

         // calc cardinals
         c1 =   2 * Math.pow(st, 3)  - 3 * Math.pow(st, 2) + 1;
         c2 = -(2 * Math.pow(st, 3)) + 3 * Math.pow(st, 2);
         c3 =       Math.pow(st, 3)  - 2 * Math.pow(st, 2) + st;
         c4 =       Math.pow(st, 3)  -     Math.pow(st, 2);

         // calc x and y cords with common control vectors
         x = c1 * _pts[i]    + c2 * _pts[i+2] + c3 * t1x + c4 * t2x;
         y = c1 * _pts[i+1]  + c2 * _pts[i+3] + c3 * t1y + c4 * t2y;

         //store points in array
         res.push(new Point(x, y));
      }
   }

   return res;
}


// ========================================================================
//      STF Auto Stretch routine
// ========================================================================
//
function ApplyAutoSTF( view, shadowsClipping, targetBackground, rgbLinked )
{
   var stf = new ScreenTransferFunction;

   var n = view.image.isColor ? 3 : 1;

   var median = view.computeOrFetchProperty( "Median" );

   var mad = view.computeOrFetchProperty( "MAD" );
   mad.mul( 1.4826 ); // coherent with a normal distribution

   if ( rgbLinked )
   {
      /*
       * Try to find how many channels look as channels of an inverted image.
       * We know a channel has been inverted because the main histogram peak is
       * located over the right-hand half of the histogram. Seems simplistic
       * but this is consistent with astronomical images.
       */
      var invertedChannels = 0;
      for ( var c = 0; c < n; ++c )
         if ( median.at( c ) > 0.5 )
            ++invertedChannels;

      if ( invertedChannels < n )
      {
         /*
          * Noninverted image
          */
         var c0 = 0, m = 0;
         for ( var c = 0; c < n; ++c )
         {
            if ( 1 + mad.at( c ) != 1 )
               c0 += median.at( c ) + shadowsClipping * mad.at( c );
            m  += median.at( c );
         }
         c0 = Math.range( c0/n, 0.0, 1.0 );
         m = Math.mtf( targetBackground, m/n - c0 );

         stf.STF = [ // c0, c1, m, r0, r1
                     [c0, 1, m, 0, 1],
                     [c0, 1, m, 0, 1],
                     [c0, 1, m, 0, 1],
                     [0, 1, 0.5, 0, 1] ];
      }
      else
      {
         /*
          * Inverted image
          */
         var c1 = 0, m = 0;
         for ( var c = 0; c < n; ++c )
         {
            m  += median.at( c );
            if ( 1 + mad.at( c ) != 1 )
               c1 += median.at( c ) - shadowsClipping * mad.at( c );
            else
               c1 += 1;
         }
         c1 = Math.range( c1/n, 0.0, 1.0 );
         m = Math.mtf( c1 - m/n, targetBackground );

         stf.STF = [ // c0, c1, m, r0, r1
                     [0, c1, m, 0, 1],
                     [0, c1, m, 0, 1],
                     [0, c1, m, 0, 1],
                     [0, 1, 0.5, 0, 1] ];
      }
   }
   else
   {
      /*
       * Unlinked RGB channnels: Compute automatic stretch functions for
       * individual RGB channels separately.
       */
      var A = [ // c0, c1, m, r0, r1
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1] ];

      for ( var c = 0; c < n; ++c )
      {
         if ( median.at( c ) < 0.5 )
         {
            /*
             * Noninverted channel
             */
            var c0 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) + shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 0.0;
            var m  = Math.mtf( targetBackground, median.at( c ) - c0 );
            A[c] = [c0, 1, m, 0, 1];
         }
         else
         {
            /*
             * Inverted channel
             */
            var c1 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) - shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 1.0;
            var m  = Math.mtf( c1 - median.at( c ), targetBackground );
            A[c] = [0, c1, m, 0, 1];
         }
      }

      stf.STF = A;
   }

   stf.executeOn( view );
}

function ApplyHistogram(view)
{
   var stf = view.stf;

   var H = [[  0, 0.0, 1.0, 0, 1.0],
            [  0, 0.5, 1.0, 0, 1.0],
            [  0, 0.5, 1.0, 0, 1.0],
            [  0, 0.5, 1.0, 0, 1.0],
            [  0, 0.5, 1.0, 0, 1.0]];

   if (view.image.isColor)
   {
      for (var c = 0; c < 3; c++)
      {
         H[c][0] = stf[c][1];
         H[c][1] = stf[c][0];
      }
   }
   else
   {
      H[3][0] = stf[0][1];
      H[3][1] = stf[0][0];
   }

   var STF = new ScreenTransferFunction;

   view.stf =  [ // c0, c1, m, r0, r1
   [0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
   [0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
   [0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
   [0.00000, 1.00000, 0.50000, 0.00000, 1.00000]
   ];

   STF.executeOn(view)

   var HT = new HistogramTransformation;
   HT.H = H;
   HT.executeOn(view)
}

/*
 * Preview Control
 *
 * This file is part of the AnnotateImage script
 *
 * Copyright (C) 2013-2020, Andres del Pozo
 * Contributions (C) 2019-2020, Juan Conejero (PTeam)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

class PreviewControl extends Frame
{
constructor( parent )
{
   super( parent );
  // this.mouseMode = lineMode;    //


   this.SetImage = function( image, metadata, zoom )
   {
      this.image = image;
      this.imageRect = new Rect(0, 0, image.width, image.height);
      this.metadata = metadata;
      this.scaledImage = null;
      this.SetZoomOutLimit();
      if (zoom === undefined) zoom = -100;
      this.UpdateZoom( zoom );
   };

   this.UpdateZoom = function( newZoom, refPoint )
   {
      newZoom = Math.max( this.zoomOutLimit, Math.min( 4, newZoom ) );
      if ( newZoom == this.zoom && this.scaledImage )
         return;

      if ( refPoint == null )
         refPoint = new Point( this.scrollbox.viewport.width/2, this.scrollbox.viewport.height/2 );

      let imgx = null;
      if ( this.scrollbox.maxHorizontalScrollPosition > 0 )
         imgx = (refPoint.x + this.scrollbox.horizontalScrollPosition)/this.scale;

      let imgy = null;
      if ( this.scrollbox.maxVerticalScrollPosition > 0 )
         imgy = (refPoint.y + this.scrollbox.verticalScrollPosition)/this.scale;

      this.zoom = newZoom;
      this.scaledImage = null;

      if ( this.zoom > 0 )
      {
         this.scale = this.zoom;
         this.zoomVal_Label.text = format( "%d:1", this.zoom );
      }
      else
      {
         this.scale = 1/(-this.zoom + 2);
         this.zoomVal_Label.text = format( "1:%d", -this.zoom + 2 );
      }

      if ( this.image )
         this.scaledImage = this.image.scaled( this.scale );
      else
         this.scaledImage = {
            width: this.metadata.width * this.scale,
            height: this.metadata.height * this.scale
         };

      this.scrollbox.maxHorizontalScrollPosition = Math.max( 0, this.scaledImage.width - this.scrollbox.viewport.width );
      this.scrollbox.maxVerticalScrollPosition = Math.max( 0, this.scaledImage.height - this.scrollbox.viewport.height );

      if ( this.scrollbox.maxHorizontalScrollPosition > 0 && imgx != null )
         this.scrollbox.horizontalScrollPosition = imgx*this.scale - refPoint.x;
      if ( this.scrollbox.maxVerticalScrollPosition > 0 && imgy != null )
         this.scrollbox.verticalScrollPosition = imgy*this.scale - refPoint.y;

      this.scrollbox.viewport.update();
   };

   this.zoomIn_Button = new ToolButton( this );
   this.zoomIn_Button.icon = this.scaledResource( ":/icons/zoom-in.png" );
   this.zoomIn_Button.setScaledFixedSize( 24, 24 );
   this.zoomIn_Button.toolTip = "Zoom In";
   this.zoomIn_Button.onMousePress = function()
   {
      this.parent.parent.UpdateZoom( this.parent.parent.zoom + 1 );
   };

   this.zoomOut_Button = new ToolButton( this );
   this.zoomOut_Button.icon = this.scaledResource( ":/icons/zoom-out.png" );
   this.zoomOut_Button.setScaledFixedSize( 24, 24 );
   this.zoomOut_Button.toolTip = "Zoom Out";
   this.zoomOut_Button.onMousePress = function()
   {
      this.parent.parent.UpdateZoom( this.parent.parent.zoom - 1 );
   };

   this.zoom11_Button = new ToolButton( this );
   this.zoom11_Button.icon = this.scaledResource( ":/icons/zoom-1-1.png" );
   this.zoom11_Button.setScaledFixedSize( 24, 24 );
   this.zoom11_Button.toolTip = "Zoom 1:1";
   this.zoom11_Button.onMousePress = function()
   {
      this.parent.parent.UpdateZoom( 1 );
   };

   this.buttons_Box   = new Frame(this);
      this.buttons_Box.backgroundColor = 0xff0080ff;
      this.buttons_Box.sizer = new HorizontalSizer;
      this.buttons_Box.sizer.margin = 4;
      this.buttons_Box.sizer.spacing = 8;
      this.buttons_Box.sizer.add( this.zoomIn_Button );
      this.buttons_Box.sizer.add( this.zoomOut_Button );
      this.buttons_Box.sizer.add( this.zoom11_Button );
      this.buttons_Box.sizer.addStretch();

   this.setScaledMinSize( 600, 400 );
   this.zoom = 1;
   this.scale = 1;
   this.zoomOutLimit = -5;
   this.scrollbox = new ScrollBox( this );
   this.scrollbox.autoScroll = true;
   this.scrollbox.tracking = true;
   //this.scrollbox.cursor = new Cursor( StdCursor.UpArrow );
   this.scrollbox.cursor = new Cursor( StdCursor.Arrow );


   this.scroll_Sizer = new HorizontalSizer;
   this.scroll_Sizer.add( this.scrollbox );

   this.SetZoomOutLimit = function()
   {
      let scaleX = Math.ceil( this.metadata.width / this.scrollbox.viewport.width );
      let scaleY = Math.ceil( this.metadata.height / this.scrollbox.viewport.height );
      let scale = Math.max( scaleX, scaleY );
      this.zoomOutLimit = -scale + 2;
   };

   this.scrollbox.onHorizontalScrollPosUpdated = function( newPos )
   {
      this.viewport.update();
   };

   this.scrollbox.onVerticalScrollPosUpdated = function( newPos )
   {
      this.viewport.update();
   };

   this.forceRedraw = function()
   {
      this.scrollbox.viewport.update();
   };

   this.scrollbox.viewport.onMouseWheel = function( x, y, delta, buttonState, modifiers )
   {
      let preview = this.parent.parent;
      preview.UpdateZoom( preview.zoom + ((delta > 0) ? -1 : 1), new Point( x, y ) );
   };

   this.scrollbox.viewport.onMousePress = function( x, y, button, buttonState, modifiers )
   {
      let preview = this.parent.parent;

      /*  if (preview.mouseMode == panMode)
      {
         if ( preview.scrolling || button != MouseButton.Left )
            return;
         preview.scrolling = {
            orgCursor: new Point( x, y ),
            orgScroll: new Point( preview.scrollbox.horizontalScrollPosition, preview.scrollbox.verticalScrollPosition )
         };
      }
      else*/
      {
         if(preview.onCustomMouseDown)
         {
            var p =  preview.transform(x, y, preview);
            preview.onCustomMouseDown.call(this, p.x, p.y, button, buttonState, modifiers )
         }
      }

      this.cursor = new Cursor( StdCursor.ClosedHand );
   };

   this.transform = function(x, y, preview)
   {
      var scrollbox = preview.scrollbox;
      var ox = 0;
      var oy = 0;
      ox = scrollbox.maxHorizontalScrollPosition>0 ? -scrollbox.horizontalScrollPosition : (scrollbox.viewport.width-preview.scaledImage.width)/2;
      oy = scrollbox.maxVerticalScrollPosition>0 ? -scrollbox.verticalScrollPosition: (scrollbox.viewport.height-preview.scaledImage.height)/2;
      var coordPx = new Point((x - ox) / preview.scale, (y - oy) / preview.scale);
      return new Point(coordPx.x, coordPx.y);
   }


   this.scrollbox.viewport.onMouseMove = function( x, y, buttonState, modifiers )
   {
      let preview = this.parent.parent;
      if ( preview.scrolling )
      {
         preview.scrollbox.horizontalScrollPosition = preview.scrolling.orgScroll.x - (x - preview.scrolling.orgCursor.x);
         preview.scrollbox.verticalScrollPosition = preview.scrolling.orgScroll.y - (y - preview.scrolling.orgCursor.y);
      }

      let ox = (this.parent.maxHorizontalScrollPosition > 0) ?
                  -this.parent.horizontalScrollPosition : (this.width - preview.scaledImage.width)/2;
      let oy = (this.parent.maxVerticalScrollPosition > 0) ?
                  -this.parent.verticalScrollPosition : (this.height - preview.scaledImage.height)/2;
      let coordPx = new Point( (x - ox)/preview.scale, (y - oy)/preview.scale );
      if ( coordPx.x < 0 ||
           coordPx.x > preview.metadata.width ||
           coordPx.y < 0 ||
           coordPx.y > preview.metadata.height ||
           !preview.metadata.projection )
      if (preview.imageRect.includes(coordPx))
      {
         preview.Xval_Label.text = coordPx.x.toFixed(0);// "---";
         preview.Yval_Label.text = coordPx.y.toFixed(0);// "---";
         //preview.RAval_Label.text = "---";
         //preview.Decval_Label.text = "---";

         if(preview.onCustomMouseMove)
         {
            //preview.cursor = new Cursor(StdCursor.NoCursor);
            var p =  preview.transform(x, y, preview);
            //  Console.writeln('Call onCustomMouseMove  ' + p.x + '  ' +p.y + '      ' +buttonState);
            preview.onCustomMouseMove.call(this, p.x, p.y, buttonState, modifiers );
         }
      }
      else
      {
         try
         {
            if(preview.onCustomMouseMove)
            {
               var p =  preview.transform(x, y, preview);
               preview.onCustomMouseMove.call(this, -1, -1, MouseButton.Unknown, KeyModifier.Control );
            }
            preview.Xval_Label.text = format( "%8.2f", coordPx.x );
            preview.Yval_Label.text = format( "%8.2f", coordPx.y );
            /*
            let coordRD = preview.metadata.Convert_I_RD( coordPx );
            if ( coordRD.x < 0 )
               coordRD.x += 360;
            preview.RAval_Label.text = DMSangle.FromAngle( coordRD.x*24/360 ).ToString( true );
            preview.Decval_Label.text = DMSangle.FromAngle( coordRD.y ).ToString( false );
            */
         }
         catch ( ex )
         {
            preview.Xval_Label.text = "---";
            preview.Yval_Label.text = "---";
            //preview.RAval_Label.text = "---";
            //preview.Decval_Label.text = "---";
         }
      }
   };

   this.scrollbox.viewport.onMouseRelease = function( x, y, button, buttonState, modifiers )
   {
      let preview = this.parent.parent;
      if ( preview.scrolling && button == MouseButton.Left )
      {
         preview.scrollbox.horizontalScrollPosition = preview.scrolling.orgScroll.x - (x - preview.scrolling.orgCursor.x);
         preview.scrollbox.verticalScrollPosition = preview.scrolling.orgScroll.y - (y - preview.scrolling.orgCursor.y);
         preview.scrolling = null;
         if (preview.mouseMode == lineMode || preview.mouseMode == starMode)
            this.cursor = new Cursor( StdCursor.Arrow  );
         else
            this.cursor = new Cursor( StdCursor.UpArrow );
      }
      else
      {
         this.cursor = new Cursor( StdCursor.Arrow  );
      }

      if ( preview.onCustomMouseRelease )
      {
         var p =  preview.transform(x, y, preview);
         preview.onCustomMouseRelease.call(this, p.x, p.y, buttonState, modifiers );
      }
   };

   this.scrollbox.viewport.onResize = function( wNew, hNew, wOld, hOld )
   {
      let preview = this.parent.parent;
      if ( preview.metadata && preview.scaledImage )
      {
         this.parent.maxHorizontalScrollPosition = Math.max( 0, preview.scaledImage.width - wNew );
         this.parent.maxVerticalScrollPosition = Math.max( 0, preview.scaledImage.height - hNew );
         preview.SetZoomOutLimit();
         preview.UpdateZoom( preview.zoom );
      }
      this.update();
   };

   this.scrollbox.viewport.onPaint = function( x0, y0, x1, y1 )
   {
      let preview = this.parent.parent;
      let graphics = new Graphics( this );

      graphics.fillRect( x0, y0, x1, y1, new Brush( 0xff202020 ) );

      let offsetX = (this.parent.maxHorizontalScrollPosition > 0) ?
            -this.parent.horizontalScrollPosition : ( this.width - preview.scaledImage.width ) / 2;
      let offsetY = (this.parent.maxVerticalScrollPosition > 0) ?
            -this.parent.verticalScrollPosition : ( this.height - preview.scaledImage.height ) / 2;
      graphics.translateTransformation( offsetX, offsetY );


      preview.offsetX = offsetX;
      preview.offsetY = offsetY;

      if ( preview.image )
         graphics.drawBitmap( 0, 0, preview.scaledImage );
      else
         graphics.fillRect( 0, 0, preview.scaledImage.width, preview.scaledImage.height, new Brush( 0xff000000 ) );

      graphics.pen = new Pen( 0x80ffffff, 0 );
      graphics.drawRect( -1, -1, preview.scaledImage.width + 1, preview.scaledImage.height + 1 );

      if ( preview.onCustomPaint )
      {
         graphics.scaleTransformation( preview.scale, preview.scale );
         preview.onCustomPaint.call( preview.onCustomPaint,
            graphics, 0, 0, preview.scaledImage.width, preview.scaledImage.height );
      }

      graphics.end();
   };

   this.offsetX = 0;
   this.offsetY = 0;

   this.getOffset = function()
   {
      return new Point(this.offsetX, this.offsetY);
   }

   this.zoomLabel_Label = new Label( this );
   this.zoomLabel_Label.text = "Zoom:";
   this.zoomVal_Label = new Label( this );
   this.zoomVal_Label.text = "1:1";
   this.zoomLabel_Label.foregroundColor = this.parent.foregroundColor;
   this.zoomLabel_Label.backgroundColor = this.parent.backgroundColor;
   this.zoomVal_Label.foregroundColor = this.parent.foregroundColor;
   this.zoomVal_Label.backgroundColor = this.parent.backgroundColor;


   this.Xlabel_Label = new Label( this );
   this.Xlabel_Label.text = "X:";
   this.Xval_Label = new Label( this );
   this.Xval_Label.text = "---";
   this.Xlabel_Label.foregroundColor = this.parent.foregroundColor;
   this.Xlabel_Label.backgroundColor = this.parent.backgroundColor;
   this.Xval_Label.foregroundColor = this.parent.foregroundColor;
   this.Xval_Label.backgroundColor = this.parent.backgroundColor;

   this.Ylabel_Label = new Label( this );
   this.Ylabel_Label.text = "Y:";
   this.Yval_Label = new Label( this );
   this.Yval_Label.text = "---";
   this.Ylabel_Label.foregroundColor = this.parent.foregroundColor;
   this.Ylabel_Label.backgroundColor = this.parent.backgroundColor;
   this.Yval_Label.foregroundColor = this.parent.foregroundColor;
   this.Yval_Label.backgroundColor = this.parent.backgroundColor;


   this.coords_Frame = new Frame( this );

   this.coords_Frame.foregroundColor = this.parent.foregroundColor;
   this.coords_Frame.font = this.parent.font;

   this.coords_Frame.styleSheet = this.scaledStyleSheet(
      "QLabel { font-family: Hack; background: white; }" );
   this.coords_Frame.backgroundColor = this.parent.backgroundColor;// 0xffffffff;
   this.coords_Frame.sizer = new HorizontalSizer;
   this.coords_Frame.sizer.margin = 4;
   this.coords_Frame.sizer.spacing = 8;
   this.coords_Frame.sizer.add( this.zoomLabel_Label );
   this.coords_Frame.sizer.add( this.zoomVal_Label );
   this.coords_Frame.sizer.addSpacing( 20 );
   this.coords_Frame.sizer.add( this.Xlabel_Label );
   this.coords_Frame.sizer.add( this.Xval_Label );
   this.coords_Frame.sizer.addSpacing( 20 );
   this.coords_Frame.sizer.add( this.Ylabel_Label );
   this.coords_Frame.sizer.add( this.Yval_Label );
   this.coords_Frame.sizer.addStretch();


   this.sizer = new VerticalSizer;
   this.sizer.add( this.buttons_Box);// this.buttons_Sizer );
   this.sizer.add( this.scroll_Sizer );
   this.sizer.add( this.coords_Frame );
} // constructor
} // class PreviewControl



/* ****************************************************************************

   Main script entry point

 * ****************************************************************************
 */
function main()
{
   //
   // start with active image window.
   //
  // Console.hide();
   var windows = ImageWindow.windows;
   if (windows.length > 0)
   {
      var window = ImageWindow.activeWindow;
      var view = window.currentView;
      if (view.isMainView & view.image.numberOfChannels == 1)
      {
         var test = view.propertyValue("Tracks");

         var dialog = new showDialog();
         dialog.execute();
      }
      else
      {
         new MessageBox("Please take a grayscaled main view and restart again",
                  "No image",
                  StdIcon.Information, StdButton.Ok).execute();
      }
   }
   else
   {
       new MessageBox("Please open an image and restart again", "No image",
                  StdIcon.Information, StdButton.Ok).execute();
   }
}

main();
