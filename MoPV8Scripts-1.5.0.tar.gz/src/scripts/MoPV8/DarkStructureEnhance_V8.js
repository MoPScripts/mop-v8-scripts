#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/*
   DarkStructureEnhance v1.1

   A script for enhancement of dark structures.

   Copyright (C) 2009 Carlos Sonnenstein (PTeam) & Oriol Lehmkuhl (PTeam)

   This program is free software: you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation, version 3 of the License.

   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.

   You should have received a copy of the GNU General Public License along with
   this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// This script has been ported to the PixInsight 1.9.4 V8 JavaScript engine
// by Peter Proulx (peterproulx@gmail.com), Masters of PixInsight
// (www.mastersofpixinsight.com), June 2026.
//
// This is NOT an original work. All credit for the original script, its
// design, algorithms, and functionality belongs solely to the original
// author(s) as identified in the copyright notice above.
//
// The V8 port involved the following technical changes:
//   - Added #engine v8 directive for PixInsight 1.9.4+ compatibility
//   - Converted ES5 constructor/prototype patterns to ES6 class syntax
//   - Expanded with() statements (prohibited in V8 strict mode)
//   - Updated PJSR constant naming conventions (underscore to dot notation)
//   - Removed deprecated #include directives
//   - Additional fixes as required for V8 engine compatibility
//
// Beyond the mechanical V8 port, the following NEW functionality was added
// and is not part of the original author's design:
//   - A live before/after preview panel (downsamples the full image for
//     algorithmic correctness, displays a zoomed crop of the result,
//     resizable along with the dialog)
//   - A "New Instance" drag-to-icon button for saving/recalling settings
//
// This ported version is offered freely to the PixInsight community.
// No rights to the original work are claimed or implied.
// ----------------------------------------------------------------------------

#feature-id    MoP V8> DarkStructureEnhance

#feature-info  A script for enhancement of dark structures.<br/>\
   <br/>\
   Based on an original algorithm created by Carlos Sonnenstein (PTeam). \
   JavaScript/PixInsight implementation by Oriol Lehmkuhl (PTeam).<br/> \
   <br/> \
   Copyright &copy; 2009 Carlos Sonnenstein (PTeam) & Oriol Lehmkuhl (PTeam)

#feature-icon  DarkStructureEnhance.xpm

#define nStarMask 6

#define VERSION "1.1"

#define TITLE "DarkStructureEnhance Script"

function ScalingFunction( kernel, name , size )
{
    this.kernel = kernel;
    this.name = name;
    this.size = size;
}

function GetWindowBmp( view )
{
   var image = view.image;
   image.firstSelectedChannel = 0;
   image.lastSelectedChannel  = image.numberOfChannels - 1;
   return image.render();
}

function processEventsAndRepaint( dlg )
{
   dlg.previewButton.repaint();
   CoreApplication.processEvents();
}

var window = ImageWindow.activeWindow;
if ( window.isNull )
   throw Error( "There is no active image window!" );

var scalingFunctions = new Array;

scalingFunctions[0] = new ScalingFunction(
   [ 0.29289322, 0.5, 0.29289322,
     0.5,        1.0, 0.5,
     0.29289322, 0.5, 0.29289322 ],
   "3x3 Linear Interpolation", 3 );

scalingFunctions[1] = new ScalingFunction(
   [ 1/256, 1/64, 3/128, 1/64, 1/256,
     1/64,  1/16, 3/32,  1/16, 1/64,
     3/128, 3/32, 9/64,  3/32, 3/128,
     1/64,  1/16, 3/32,  1/16, 1/64,
     1/256, 1/64, 3/128, 1/64, 1/256 ],
   "5x5 B3 Spline", 5 );

function doAuxiliarImage(data, applyView) {

    var view = applyView || data.targetView;
    var mask = new ImageWindow(view.image.width,
            view.image.height,
            view.image.numberOfChannels,
            view.window.bitsPerSample,
            view.window.isFloatSample,
            view.image.colorSpace != ColorSpace.Gray,
            "Mask");
    var maskView = mask.mainView;

    // copy data
    maskView.beginProcess(UndoFlag.NoSwapFile);
    maskView.image.apply(view.image);
    maskView.endProcess();

    // do awt

    var auxLayers = new Array(nStarMask);
    for(var i=0;i<nStarMask;++i) {
        auxLayers[i] = [true, true, 1.00, 3.00, 0.000, false, 0, 0.50, 2, 5, false, true, 1.0, 0.02000];
    }
    auxLayers[nStarMask] = [false, true, 1.00, 3.00, 0.000, false, 0, 0.50, 2, 5, false, false, 0.50, 0.02000];

    var wavlets = new ATrousWaveletTransformV1;
    wavlets.version = 257;
    wavlets.layers = auxLayers;
    wavlets.scaleDelta = 0;
    wavlets.scalingFunctionData = scalingFunctions[data.scalingFunction].kernel;
    wavlets.scalingFunctionKernelSize = scalingFunctions[data.scalingFunction].size;
    wavlets.scalingFunctionName = scalingFunctions[data.scalingFunction].name;
    wavlets.largeScaleFunction = 0; // NoFunction
    wavlets.curveBreakPoint = 0.75;
    wavlets.noiseThresholdingAmount = 0.00;
    wavlets.noiseThreshold = 3.00;
    wavlets.lowRange = 0.000;
    wavlets.highRange = 0.000;
    wavlets.previewMode = 0; // Disabled
    wavlets.previewLayer = 0;
    wavlets.toLuminance = true;
    wavlets.toChrominance = true;
    wavlets.linear = false;
    wavlets.executeOn(maskView, false/*swapFile*/ );

    return mask;
};

function doMask( data, applyView ) {
    var view = applyView || data.targetView;
    var mask = new ImageWindow(view.image.width,
            view.image.height,
            view.image.numberOfChannels,
            view.window.bitsPerSample,
            view.window.isFloatSample,
            view.image.colorSpace != ColorSpace.Gray,
            "Mask");
    var maskView = mask.mainView;

    // copy data
    maskView.beginProcess(UndoFlag.NoSwapFile);
    maskView.image.apply(view.image);
    maskView.endProcess();

    // RBGWorking space

    var rgb = new RGBWorkingSpace;
    rgb.channels = // Y, x, y
        [
        [0.333333, 0.648431, 0.330856],
        [0.333333, 0.321152, 0.597871],
        [0.333333, 0.155886, 0.066044]];
    rgb.gamma = 2.20;
    rgb.sRGBGamma = true;
    rgb.applyGlobalRGBWS = false;
    rgb.executeOn(maskView, false/*swapFile*/ );

    // Anti deringing: Carlos Paranoia :D

    var auxMask = doAuxiliarImage(data, view);

    var pm = new PixelMath;

    var id = auxMask.mainView.id;

    pm.expression  = "$T -"+id;
    pm.useSingleExpression = true;
    pm.use64BitWorkingImage = false;
    pm.rescale = false;
    pm.rescaleLower = 0.0000000000;
    pm.rescaleUpper = 1.0000000000;
    pm.truncate = true;
    pm.truncateLower = 0.0000000000;
    pm.truncateUpper = 1.0000000000;
    pm.createNewImage = false;

    pm.executeOn( maskView, false/*swapFile*/ );

    //auxMask.show();

    auxMask.forceClose();

    // wavlets

    var auxLayers = new Array(data.numberOfLayers);
    for(var i=0;i<data.numberOfLayers;++i) {
        auxLayers[i] = [false, true, 1.00, 3.00, 0.000, false, 0, 0.50, 2, 5, false, false, 0.50, 0.02000];
    }
    auxLayers[data.numberOfLayers] = [true, true, 1.00, 3.00, 0.000, false, 0, 0.50, 2, 5, false, false, 0.50, 0.02000];

    var wavlets = new ATrousWaveletTransformV1;
    wavlets.version = 257;
    wavlets.layers = auxLayers;
    wavlets.scaleDelta = 0;
    wavlets.scalingFunctionData = scalingFunctions[data.scalingFunction].kernel;
    wavlets.scalingFunctionKernelSize = scalingFunctions[data.scalingFunction].size;
    wavlets.scalingFunctionName = scalingFunctions[data.scalingFunction].name;
    wavlets.largeScaleFunction = 0; // NoFunction
    wavlets.curveBreakPoint = 0.75;
    wavlets.noiseThresholdingAmount = 0.00;
    wavlets.noiseThreshold = 3.00;
    wavlets.lowRange = 0.000;
    wavlets.highRange = 0.000;
    wavlets.previewMode = 0; // Disabled
    wavlets.previewLayer = 0;
    wavlets.toLuminance = true;
    wavlets.toChrominance = true;
    wavlets.linear = false;
    wavlets.executeOn( maskView, false/*swapFile*/ );

    // Pixel Math

    var pm = new PixelMath;
    pm.expression = maskView.id+"-"+view.id;
    pm.expression1 = "";
    pm.expression2 = "";
    pm.useSingleExpression = true;
    pm.variables = "";
    pm.use64BitWorkingImage = false;
    pm.rescale = false;
    pm.rescaleLower = 0.0000000000;
    pm.rescaleUpper = 1.0000000000;
    pm.truncate = true;
    pm.truncateLower = 0.0000000000;
    pm.truncateUpper = 1.0000000000;
    pm.createNewImage = false;
    pm.newImageId = "";
    pm.newImageWidth = 0;
    pm.newImageHeight = 0;
    pm.newImageColorSpace = PixelMath.SameAsTarget;
    pm.newImageSampleFormat = PixelMath.SameAsTarget;
    pm.executeOn( maskView, false/*swapFile*/ );

    // Convert to gray

    if(view.image.colorSpace != ColorSpace.Gray) {
        var toGray = new ConvertToGrayscale;
        toGray.executeOn( maskView, false/*swapFile*/ );
    }

    // Rescale

    var rescale = new Rescale;
    rescale.mode = Rescale.RGBK;
    rescale.executeOn( maskView, false/*swapFile*/ );

    // Noise reduction

    var nr = new ATrousWaveletTransformV1;
    nr.version = 257;
    nr.layers = // enabled, biasEnabled, structureDetectionThreshold, structureDetectionRange, bias, noiseReductionEnabled, noiseReductionFilter, noiseReductionAmount, noiseReductionIterations, noiseReductionKernelSize, noiseReductionProtectSignificant, deringingEnabled, deringingAmount, deringingThreshold
        [
        [false, true, 1.00, 3.00, 0.000, false, 0, // Recursive
         1.00, 5, 5, false, false, 0.50, 0.02000],
        [true, true, 1.00, 3.00, 0.000, true, 0, // Recursive
         1.00, 5, 5, false, false, 0.50, 0.02000],
        [true, true, 1.00, 3.00, 0.000, false, 0, // Recursive
         0.50, 2, 5, false, false, 0.50, 0.02000]];
    nr.scaleDelta = 0;
    nr.scalingFunctionData = [
        0.292893,0.5,0.292893,
        0.5,1,0.5,
        0.292893,0.5,0.292893];
    nr.scalingFunctionKernelSize = 3;
    nr.scalingFunctionName = "3x3 Linear Interpolation";
    nr.largeScaleFunction = 0; // NoFunction
    nr.toLuminance = true;
    nr.toChrominance = false;
    nr.linear = false;
    nr.executeOn( maskView, false/*swapFile*/ );

    return mask;
}

function doDark(data, applyView) {
    var view = applyView || data.targetView;

    var hist = new HistogramTransformation;

    hist.H = [
        [0, 0.5,        1, 0, 1], // R
        [0, 0.5,        1, 0, 1], // G
        [0, 0.5,        1, 0, 1], // B
        [0, data.median,1, 0, 1], // RGB
        [0, 0.5,        1, 0, 1], // Alpha
        ];

    var mask = doMask(data, view);

    var pc = new ProcessContainer;

    for(var i=0;i<data.iterations;++i) {
        pc.add(hist);
        pc.setMask(i,mask,false/*invert*/);
    }

    view.beginProcess();
    pc.executeOn( view, false/*swapFile*/ );
    view.endProcess();

   mask.removeMaskReferences();

   if ( data.viewMask )
      mask.show();
   else
      mask.forceClose();
}

function generatePreview(data) {
    var srcView = data.targetView;
    if ( srcView.isNull )
        return null;

    var srcImage = srcView.image;
    var win = srcView.window;

    var previewWin = new ImageWindow(
        srcImage.width,
        srcImage.height,
        srcImage.numberOfChannels,
        win.bitsPerSample,
        win.isFloatSample,
        srcImage.colorSpace != ColorSpace.Gray,
        "DSE_Preview_" + Date.now()
    );

    var previewView = previewWin.mainView;
    previewView.beginProcess( UndoFlag.NoSwapFile );
    previewView.image.assign( srcImage );
    previewView.endProcess();

    // Downsample the WHOLE image (never crop before processing). Each a
    // trous wavelet layer roughly doubles its effective support radius,
    // so at the higher layer counts this script allows (7-12), processing
    // only a small crop starves the mask of real surrounding structure
    // and the before/after preview comes out looking identical even
    // though doDark() did run. Downsampling keeps the image's real edges
    // and large-scale structure intact while staying fast.
    var maxDim = 1536;
    var longSide = Math.max( srcImage.width, srcImage.height );
    if ( longSide > maxDim )
    {
        var factor = maxDim / longSide;
        var rs = new Resample;
        rs.xSize = factor;
        rs.ySize = factor;
        rs.mode = Resample.RelativeDimensions;
        rs.interpolation = Resample.Lanczos3;
        rs.noGUIMessages = true;
        rs.executeOn( previewView, false/*swapFile*/ );
    }

    // No crop here anymore. The preview control has real zoom (1:10 in,
    // fit-to-window out) and drag-to-pan, so cropping before processing
    // would permanently wall off the rest of the frame -- no amount of
    // panning could ever reach it, since that image data was discarded
    // before doDark() even ran. Hand over the whole downsampled frame and
    // let the zoom/pan controls handle visibility instead.
    var beforeBmp = GetWindowBmp( previewView );

    // Run the real algorithm on the full downsampled frame -- the same
    // doDark() the OK button calls, just targeting the preview window.
    // Force viewMask off for the duration so a "Mask" window doesn't pop
    // onto the desktop every time Preview is clicked while "Extract mask"
    // is checked. Console output is forced on (even though main() hides
    // it at startup) so there's a persistent, unambiguous record that the
    // full pipeline executed -- not just a button-text flash that's easy
    // to miss if processing finishes quickly.
    var savedViewMask = data.viewMask;
    data.viewMask = false;
    Console.show();
    Console.writeln( "<b>DarkStructureEnhance preview:</b> running on downsampled frame "
        + previewView.image.width + "x" + previewView.image.height
        + " (" + data.numberOfLayers + " layers, amount " + data.median.toFixed(2)
        + ", " + data.iterations + " iteration(s))..." );
    doDark( data, previewView );
    Console.writeln( "Preview render complete." );

    data.viewMask = savedViewMask;

    var afterBmp = GetWindowBmp( previewView );

    previewWin.forceClose();

    return { before: beforeBmp, after: afterBmp };
}

function DarkMaskLayersData()
{
    this.targetView = window.currentView;
    this.numberOfLayers = 8;
    this.scalingFunction = 1;
    this.extractResidual = true;
    this.toLumi = false;
    this.median = 0.7;
    this.iterations = 1;
    this.viewMask = false;
}

var data = new DarkMaskLayersData;

function exportParameters()
{
   Parameters.set( "numberOfLayers", data.numberOfLayers );
   Parameters.set( "scalingFunction", data.scalingFunction );
   Parameters.set( "median", data.median );
   Parameters.set( "iterations", data.iterations );
   Parameters.set( "viewMask", data.viewMask );
}

function importParameters()
{
   if ( Parameters.has( "numberOfLayers" ) )
      data.numberOfLayers = Parameters.getInteger( "numberOfLayers" );
   if ( Parameters.has( "scalingFunction" ) )
      data.scalingFunction = Parameters.getInteger( "scalingFunction" );
   if ( Parameters.has( "median" ) )
      data.median = Parameters.getReal( "median" );
   if ( Parameters.has( "iterations" ) )
      data.iterations = Parameters.getInteger( "iterations" );
   if ( Parameters.has( "viewMask" ) )
      data.viewMask = Parameters.getBoolean( "viewMask" );
}

// ----------------------------------------------------------------------------
// PreviewControl
// ----------------------------------------------------------------------------
// Ported from the PreviewControl used in Pete's GAME script (originally by
// Andres del Pozo, "PreviewControl.js"). Zoom in/out/1:1 buttons, mouse-wheel
// zoom centered on the cursor, scrollbox-based pan, live X/Y/zoom readout,
// and resize handling. The ellipsoid-dragging hooks (onCustomMouseDown/Up)
// and the AutoSTF checkbox from the original GAME usage are dropped here --
// neither applies to a before/after DSE preview -- everything else is kept
// as-is, including the UpdateZoom math and the null-scaledImage guards that
// were specifically needed for the V8 engine.
class PreviewControl extends Frame
{
constructor(parent)
{
   super(parent);

   // Initialize all properties to safe defaults before any event can fire
   this.image       = null;
   this.metadata    = null;
   this.scaledImage = null;
   this.zoom        = -4;
   this.scale       = 1;
   this.zoomOutLimit = -4;
   this.refPoint    = null;

   this.SetImage = function(image, metadata)
   {
      this.image = image;
      this.metadata = metadata;
      this.scaledImage = null;
      this.SetZoomOutLimit();
      this.UpdateZoom(-100);
   }

   this.UpdateZoom = function (newZoom, refPoint)
   {
      newZoom = Math.max(this.zoomOutLimit, Math.min(10, newZoom));
      if (newZoom == this.zoom && this.scaledImage)
         return;

      if(refPoint==null)
         refPoint=new Point(this.scrollbox.viewport.width/2, this.scrollbox.viewport.height/2);
      var imgx=null;
      if(this.scrollbox.maxHorizontalScrollPosition>0)
         imgx=(refPoint.x+this.scrollbox.horizontalScrollPosition)/this.scale;
      var imgy=null;
      if(this.scrollbox.maxVerticalScrollPosition>0)
         imgy=(refPoint.y+this.scrollbox.verticalScrollPosition)/this.scale;

      this.zoom = newZoom;
      this.scaledImage = null;
      this.refPoint = refPoint;
      if (this.zoom > 0)
      {
         this.scale = this.zoom;
         this.zoomVal_Label.text = format("%d:1", this.zoom);
      }
      else
      {
         this.scale = 1 / (-this.zoom + 2);
         this.zoomVal_Label.text = format("1:%d", -this.zoom + 2);
      }
      if (this.image)
         this.scaledImage = this.image.scaled(this.scale);
      else
         this.scaledImage = {width:this.metadata.width * this.scale, height:this.metadata.height * this.scale};
      this.scrollbox.maxHorizontalScrollPosition = Math.max(0, this.scaledImage.width - this.scrollbox.viewport.width);
      this.scrollbox.maxVerticalScrollPosition = Math.max(0, this.scaledImage.height - this.scrollbox.viewport.height);

      if(this.scrollbox.maxHorizontalScrollPosition>0 && imgx!=null)
         this.scrollbox.horizontalScrollPosition = (imgx*this.scale)-refPoint.x;
      if(this.scrollbox.maxVerticalScrollPosition>0 && imgy!=null)
         this.scrollbox.verticalScrollPosition = (imgy*this.scale)-refPoint.y;

      this.scrollbox.viewport.update();
   }

   this.zoomIn_Button = new ToolButton( this );
   this.zoomIn_Button.icon = this.scaledResource( ":/icons/zoom-in.png" );
   this.zoomIn_Button.setScaledFixedSize( 20, 20 );
   this.zoomIn_Button.toolTip = "Zoom in";
   this.zoomIn_Button.onMousePress = function()
   {
      this.parent.parent.UpdateZoom(this.parent.parent.zoom+1);
   };

   this.zoomOut_Button = new ToolButton( this );
   this.zoomOut_Button.icon = this.scaledResource( ":/icons/zoom-out.png" );
   this.zoomOut_Button.setScaledFixedSize( 20, 20 );
   this.zoomOut_Button.toolTip = "Zoom out";
   this.zoomOut_Button.onMousePress = function()
   {
      this.parent.parent.UpdateZoom(this.parent.parent.zoom-1);
   };

   this.zoom11_Button = new ToolButton( this );
   this.zoom11_Button.icon = this.scaledResource( ":/icons/zoom-1-1.png" );
   this.zoom11_Button.setScaledFixedSize( 20, 20 );
   this.zoom11_Button.toolTip = "Zoom 1:1";
   this.zoom11_Button.onMousePress = function()
   {
      this.parent.parent.UpdateZoom(1);
   };

   this.zoomLabel_Label = new Label(this);
   this.zoomLabel_Label.text = "Zoom:";
   this.zoomVal_Label = new Label(this);
   this.zoomVal_Label.text = "1:1";

   this.buttons_Box = new Frame(this);
   this.buttons_Box.backgroundColor = 0xff0078d7;
   this.buttons_Box.sizer = new HorizontalSizer;
   this.buttons_Box.sizer.margin = 4;
   this.buttons_Box.sizer.spacing = 4;
   this.buttons_Box.sizer.add( this.zoomIn_Button );
   this.buttons_Box.sizer.add( this.zoomOut_Button );
   this.buttons_Box.sizer.add( this.zoom11_Button );
   this.buttons_Box.sizer.addSpacing(8);
   this.buttons_Box.sizer.add( this.zoomLabel_Label );
   this.buttons_Box.sizer.add( this.zoomVal_Label );
   this.buttons_Box.sizer.addStretch();

   this.setScaledMinSize(400,400);
   this.zoom = 1;
   this.scale = 1;
   this.zoomOutLimit = -5;
   this.scrollbox = new ScrollBox(this);
   this.scrollbox.autoScroll = true;
   this.scrollbox.tracking = true;
   this.scrollbox.cursor = new Cursor(StdCursor.Arrow);

   this.scroll_Sizer = new HorizontalSizer;
   this.scroll_Sizer.add( this.scrollbox );

   this.SetZoomOutLimit = function()
   {
      if ( !this.metadata )
         return;
      var scaleX = Math.ceil(this.metadata.width/this.scrollbox.viewport.width);
      var scaleY = Math.ceil(this.metadata.height/this.scrollbox.viewport.height);
      var scale = Math.max(scaleX,scaleY);
      this.zoomOutLimit = -scale+2;
   }

   this.scrollbox.onHorizontalScrollPosUpdated = function (newPos)
   {
      this.viewport.update();
   }
   this.scrollbox.onVerticalScrollPosUpdated = function (newPos)
   {
      this.viewport.update();
   }

   this.forceRedraw = function()
   {
      this.scrollbox.viewport.update();
   };

   this.scrollbox.viewport.onMouseWheel = function (x, y, delta, buttonState, modifiers)
   {
      var preview = this.parent.parent;
      preview.UpdateZoom(preview.zoom + (delta > 0 ? -1 : 1), new Point(x,y));
   }

   this.scrollbox.viewport.onMouseMove = function ( x, y, buttonState, modifiers )
   {
      var preview = this.parent.parent;
      var p = preview.transform(x, y, preview);
      preview.Xval_Label.text = Math.round(p.x).toString();
      preview.Yval_Label.text = Math.round(p.y).toString();
   }

   this.scrollbox.viewport.onResize = function (wNew, hNew, wOld, hOld)
   {
      var preview = this.parent.parent;
      if(preview.metadata && preview.scaledImage)
      {
         this.parent.maxHorizontalScrollPosition = Math.max(0, preview.scaledImage.width - wNew);
         this.parent.maxVerticalScrollPosition = Math.max(0, preview.scaledImage.height - hNew);
         preview.SetZoomOutLimit();
         preview.UpdateZoom(preview.zoom);
      }
      this.update();
   }

   this.scrollbox.viewport.onPaint = function (x0, y0, x1, y1)
   {
      var preview = this.parent.parent;
      var graphics = new Graphics(this);

      graphics.fillRect(x0,y0, x1, y1, new Brush(0xff202020));

      if (!preview.scaledImage)
      {
         graphics.pen = new Pen(0xff808080);
         graphics.drawTextRect(new Rect(x0,y0,x1,y1), "Click Preview to render", TextAlignment.Center);
         graphics.end();
         return;
      }

      var offsetX = this.parent.maxHorizontalScrollPosition>0 ? -this.parent.horizontalScrollPosition : (this.width-preview.scaledImage.width)/2;
      var offsetY = this.parent.maxVerticalScrollPosition>0 ? -this.parent.verticalScrollPosition: (this.height-preview.scaledImage.height)/2;
      graphics.translateTransformation(offsetX, offsetY);
      graphics.drawBitmap(0, 0, preview.scaledImage);

      graphics.pen = new Pen(0xffffffff,0);
      graphics.drawRect(-1, -1, preview.scaledImage.width + 1, preview.scaledImage.height + 1);

      graphics.end();
   }

   this.transform = function(x, y, preview)
   {
      if (!preview.scaledImage) return new Point(0, 0);
      var scrollbox = preview.scrollbox;
      var ox = scrollbox.maxHorizontalScrollPosition>0 ? -scrollbox.horizontalScrollPosition : (scrollbox.viewport.width-preview.scaledImage.width)/2;
      var oy = scrollbox.maxVerticalScrollPosition>0 ? -scrollbox.verticalScrollPosition: (scrollbox.viewport.height-preview.scaledImage.height)/2;
      return new Point((x - ox) / preview.scale, (y - oy) / preview.scale);
   }

   this.Xlabel_Label = new Label(this);
   this.Xlabel_Label.text = "X:";
   this.Xval_Label = new Label(this);
   this.Xval_Label.text = "---";
   this.Ylabel_Label = new Label(this);
   this.Ylabel_Label.text = "Y:";
   this.Yval_Label = new Label(this);
   this.Yval_Label.text = "---";

   this.coords_Frame = new Frame(this);
   this.coords_Frame.sizer = new HorizontalSizer;
   this.coords_Frame.sizer.margin = 2;
   this.coords_Frame.sizer.spacing = 4;
   this.coords_Frame.sizer.add(this.Xlabel_Label);
   this.coords_Frame.sizer.add(this.Xval_Label);
   this.coords_Frame.sizer.addSpacing(6);
   this.coords_Frame.sizer.add(this.Ylabel_Label);
   this.coords_Frame.sizer.add(this.Yval_Label);
   this.coords_Frame.sizer.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.add( this.buttons_Box );
   this.sizer.add( this.scroll_Sizer, 100 );
   this.sizer.add( this.coords_Frame );
}
}

class DarkMaskLayersDialog extends Dialog
{
   constructor()
   {
      super();


   var emWidth = this.font.width( 'M' );
   var labelWidth1 = this.font.width( "Layers to remove:" + 'T' );

   //

   this.helpLabel = new Label( this );
   this.helpLabel.frameStyle = FrameStyle.Box;
   this.helpLabel.margin = 4;
   this.helpLabel.wordWrapping = true;
   this.helpLabel.useRichText = true;
   this.helpLabel.text =
      "<p><b>DarkStructureEnhance v" + VERSION + "</b> &mdash; A script for "
      + "enhancement of dark image structures.</p>"
      + "<p>The script can also provide the mask used in the DSE process. To include "
      + "larger structures in the mask, increase the number of layers to remove. "
      + "To increase enhancement of dark structures, increase the value of the "
      + "<i>Amount</i> parameter.</p>"
      + "<p>Copyright &copy; 2009 Carlos Sonnenstein and Oriol Lehmkuhl (Pteam)</p>";

   this.targetImage_Label = new Label( this );
   this.targetImage_Label.minWidth = labelWidth1 + this.logicalPixelsToPhysical( 6+1 ); // align with labels inside group boxes below
   this.targetImage_Label.text = "Target image:";
   this.targetImage_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.targetImage_ViewList = new ViewList( this );
   this.targetImage_ViewList.scaledMinWidth = 200;
   this.targetImage_ViewList.getAll(); // include main views as well as previews
   this.targetImage_ViewList.currentView = data.targetView;
   this.targetImage_ViewList.toolTip = "Select the image to perform the Dark Structure Enhancement.";
   this.targetImage_ViewList.onViewSelected = function( view )
   {
      data.targetView = view;
   };

   this.targetImage_Sizer = new HorizontalSizer;
   this.targetImage_Sizer.spacing = 4;
   this.targetImage_Sizer.add( this.targetImage_Label );
   this.targetImage_Sizer.add( this.targetImage_ViewList, 100 );

   // Dark Mask parameters
   this.numberOfLayers_Label = new Label( this );
   this.numberOfLayers_Label.minWidth = labelWidth1;
   this.numberOfLayers_Label.text = "Layers to remove:";
   this.numberOfLayers_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.numberOfLayers_SpinBox = new SpinBox( this );
   this.numberOfLayers_SpinBox.minValue = 7;
   this.numberOfLayers_SpinBox.maxValue = 12;
   this.numberOfLayers_SpinBox.value = data.numberOfLayers;
   this.numberOfLayers_SpinBox.toolTip = this.numberOfLayers_Label.toolTip =
      "<b>Number of wavelet layers that will be removed to build an enhancement mask.</b>";
   this.numberOfLayers_SpinBox.onValueUpdated = function( value )
   {
      data.numberOfLayers = value;
   };

   this.extractResidual_CheckBox = new CheckBox( this );
   this.extractResidual_CheckBox.text = "Extract mask";
   this.extractResidual_CheckBox.checked = data.viewMask;
   this.extractResidual_CheckBox.toolTip =
      "<p>If this option is selected, the script will create an image window "
      + "with the mask used to perform dark structure enhancement.</p>";
   this.extractResidual_CheckBox.onCheck = function( checked )
   {
      data.viewMask = checked;
   };

   this.numberOfLayers_Sizer = new HorizontalSizer;
   this.numberOfLayers_Sizer.spacing = 4;
   this.numberOfLayers_Sizer.add( this.numberOfLayers_Label );
   this.numberOfLayers_Sizer.add( this.numberOfLayers_SpinBox );
   this.numberOfLayers_Sizer.addSpacing( 12 );
   this.numberOfLayers_Sizer.add( this.extractResidual_CheckBox );
   this.numberOfLayers_Sizer.addStretch();

   this.scalingFunction_Label = new Label( this );
   this.scalingFunction_Label.minWidth = labelWidth1;
   this.scalingFunction_Label.text = "Scaling function:";
   this.scalingFunction_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.scalingFunction_ComboBox = new ComboBox( this );
   for ( var i = 0; i < scalingFunctions.length; ++i )
      this.scalingFunction_ComboBox.addItem( scalingFunctions[i].name );
   this.scalingFunction_ComboBox.currentItem = data.scalingFunction;
   this.scalingFunction_ComboBox.toolTip = this.scalingFunction_Label.toolTip =
      "<p>Select a scaling function to perform the wavelet decomposition.</p>";
   this.scalingFunction_ComboBox.onItemSelected = function( index )
   {
      data.scalingFunction = index;
   };

   this.scalingFunction_Sizer = new HorizontalSizer;
   this.scalingFunction_Sizer.spacing = 4;
   this.scalingFunction_Sizer.add( this.scalingFunction_Label );
   this.scalingFunction_Sizer.add( this.scalingFunction_ComboBox );
   this.scalingFunction_Sizer.addStretch();

   this.dmParGroupBox = new GroupBox( this );
   this.dmParGroupBox.title = "Mask Parameters";
   this.dmParGroupBox.sizer = new VerticalSizer;
   this.dmParGroupBox.sizer.margin = 6;
   this.dmParGroupBox.sizer.spacing = 4;
   this.dmParGroupBox.sizer.add( this.numberOfLayers_Sizer );
   this.dmParGroupBox.sizer.add( this.scalingFunction_Sizer );

   // DSE parameters
   this.median_NC = new NumericControl (this);

   this.median_NC.label.text = "Amount:";
   this.median_NC.label.minWidth = labelWidth1;
   this.median_NC.setRange( 0.0, 0.99 );
   this.median_NC.slider.setRange( 0, 1000 );
   this.median_NC.slider.scaledMinWidth = 250;
   this.median_NC.setPrecision( 2 );
   this.median_NC.setValue( (data.median-0.5)*2 );
   this.median_NC.toolTip = "<p>DSE intensity for each iteration.</p>";
   this.median_NC.onValueUpdated = function( value )
   {
      data.median = (0.5*value)+0.5;
   };


   this.iter_Label = new Label( this );
   this.iter_Label.minWidth = labelWidth1;
   this.iter_Label.text = "Iterations:";
   this.iter_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.iter_SpinBox = new SpinBox( this );
   this.iter_SpinBox.minValue = 1;
   this.iter_SpinBox.maxValue = 10;
   this.iter_SpinBox.value = data.iterations;
   this.iter_SpinBox.toolTip = "<p>Number of midtones balance transformations.</p>";
   this.iter_SpinBox.onValueUpdated = function( value )
   {
      data.iterations = value;
   };

   this.iter_Sizer = new HorizontalSizer;
   this.iter_Sizer.spacing = 4;
   this.iter_Sizer.add( this.iter_Label );
   this.iter_Sizer.add( this.iter_SpinBox );
   this.iter_Sizer.addStretch();

   this.dseParGroupBox = new GroupBox( this );
   this.dseParGroupBox.title = "DSE Parameters";
   this.dseParGroupBox.sizer = new VerticalSizer;
   this.dseParGroupBox.sizer.margin = 6;
   this.dseParGroupBox.sizer.spacing = 4;
   this.dseParGroupBox.sizer.add( this.median_NC );
   this.dseParGroupBox.sizer.add( this.iter_Sizer );

   // ---- Preview panel --------------------------------------------------
   var dlg = this;
   this.previewBefore  = null;
   this.previewAfter   = null;
   this.previewShowing = "after";

   this.previewControl = new PreviewControl( this );

   // Shows a bitmap in the preview control, preserving the current zoom
   // level and scroll position if something was already being shown (same
   // save-zoom / SetImage / restore-zoom pattern used for the AutoSTF
   // toggle in GAME.js) -- so toggling Before/After or re-rendering after
   // a parameter change doesn't keep snapping the view back to fit.
   this.showPreviewImage = function( bmp )
   {
      var pc = this.previewControl;
      var hadImage = !!pc.scaledImage;
      var zoom = pc.zoom;
      var hPos = pc.scrollbox.horizontalScrollPosition;
      var vPos = pc.scrollbox.verticalScrollPosition;

      pc.SetImage( bmp, { width: bmp.width, height: bmp.height } );

      if ( hadImage )
      {
         pc.UpdateZoom( zoom );
         pc.scrollbox.horizontalScrollPosition = hPos;
         pc.scrollbox.verticalScrollPosition = vPos;
      }
   };

   this.previewLabel = new Label( this );
   this.previewLabel.text = "Preview (real algorithm, full-frame context -- scroll to zoom, drag to pan)";
   this.previewLabel.textAlignment = TextAlignment.Center;

   this.previewButton = new PushButton( this );
   this.previewButton.text = "Preview";
   this.previewButton.toolTip = "<p>Runs the actual Dark Structure Enhance algorithm on a "
      + "downsampled copy of the full image (long side capped at 1536 px), so every "
      + "wavelet layer keeps the image's real edges and large-scale structure. The "
      + "whole frame is shown here -- use the zoom buttons, mouse wheel, or drag to "
      + "pan/inspect it. The process console will show a message confirming the "
      + "pipeline ran.</p>";
   this.previewButton.onClick = function()
   {
      this.enabled = false;
      this.text = "Rendering...";
      processEventsAndRepaint( dlg );

      try
      {
         var result = generatePreview( data );
         if ( result )
         {
            dlg.previewBefore  = result.before;
            dlg.previewAfter   = result.after;
            dlg.previewShowing = "after";
            dlg.toggleButton.text    = "Show Before";
            dlg.toggleButton.enabled = true;
            dlg.showPreviewImage( dlg.previewAfter );
         }
      }
      catch ( e )
      {
         (new MessageBox( "Preview failed:\n" + e.message,
            TITLE, StdIcon.Error, StdButton.Ok )).execute();
      }

      this.text = "Preview";
      this.enabled = true;
   };

   this.toggleButton = new PushButton( this );
   this.toggleButton.text = "Show Before";
   this.toggleButton.enabled = false;
   this.toggleButton.onClick = function()
   {
      if ( dlg.previewShowing == "after" )
      {
         dlg.previewShowing = "before";
         this.text = "Show After";
      }
      else
      {
         dlg.previewShowing = "after";
         this.text = "Show Before";
      }
      dlg.showPreviewImage( dlg.previewShowing == "before" ? dlg.previewBefore : dlg.previewAfter );
   };

   this.previewButtons_Sizer = new HorizontalSizer;
   this.previewButtons_Sizer.spacing = 4;
   this.previewButtons_Sizer.add( this.previewButton );
   this.previewButtons_Sizer.add( this.toggleButton );
   this.previewButtons_Sizer.addStretch();

   this.previewGroupBox = new GroupBox( this );
   this.previewGroupBox.title = "Preview";
   this.previewGroupBox.sizer = new VerticalSizer;
   this.previewGroupBox.sizer.margin = 6;
   this.previewGroupBox.sizer.spacing = 4;
   this.previewGroupBox.sizer.add( this.previewLabel );
   this.previewGroupBox.sizer.add( this.previewControl, 100 );
   this.previewGroupBox.sizer.add( this.previewButtons_Sizer );

    // usual control buttons
    this.newInstanceButton = new ToolButton( this );
    this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
    this.newInstanceButton.setScaledFixedSize( 24, 24 );
    this.newInstanceButton.toolTip = "New Instance: drag this icon to the desktop to save the "
        + "current settings, then drop it onto an image to re-run the script with those "
        + "settings without showing this dialog.";
    this.newInstanceButton.onMousePress = function()
    {
        this.hasFocus = true;
        exportParameters();
        this.pushed = false;
        this.dialog.newInstance();
    };

    this.ok_Button = new PushButton( this );
    this.ok_Button.text = "OK";
    this.ok_Button.icon = this.scaledResource( ":/icons/ok.png" );
    this.ok_Button.onClick = function()
    {
        this.dialog.ok();
    };

    this.cancel_Button = new PushButton( this );
    this.cancel_Button.text = "Cancel";
    this.cancel_Button.icon = this.scaledResource( ":/icons/cancel.png" );
    this.cancel_Button.onClick = function()
    {
        this.dialog.cancel();
    };

    this.buttons_Sizer = new HorizontalSizer;
    this.buttons_Sizer.spacing = 4;
    this.buttons_Sizer.add( this.newInstanceButton );
    this.buttons_Sizer.addStretch();
    this.buttons_Sizer.add( this.ok_Button );
    this.buttons_Sizer.add( this.cancel_Button );

    this.sizer = new VerticalSizer;
    this.sizer.margin = 8;
    this.sizer.spacing = 6;
    this.sizer.add( this.helpLabel );
    this.sizer.addSpacing( 4 );
    this.sizer.add( this.targetImage_Sizer );
    this.sizer.add( this.dmParGroupBox);
    this.sizer.add( this.dseParGroupBox);
    this.sizer.add( this.previewGroupBox, 100 );
    this.sizer.addSpacing( 4 );
    this.sizer.add( this.buttons_Sizer );

    this.windowTitle = TITLE;
    this.adjustToContents();
    this.setMinSize( this.width, this.height );
    this.userResizable = true;
   }
}





/*
 * Script entry point.
 */
function main()
{
   Console.hide();

   importParameters();

   // If a previously saved instance icon was dropped directly onto an
   // image (rather than dragged from the dialog onto the desktop first),
   // run immediately with the saved settings and skip the dialog.
   if ( Parameters.isViewTarget )
   {
      data.targetView = Parameters.targetView;
      Console.show();
      doDark( data );
      return;
   }

   if ( !data.targetView )
   {
      var msg = new MessageBox( "There is no active image window!",
                                "DarkMaskLayers Script",
                                StdIcon.Error, StdButton.Ok );
      msg.execute();
      return;
   }

   var dialog = new DarkMaskLayersDialog();
   for ( ;; )
   {
      if ( !dialog.execute() )
         break;

      // A view must be selected.
      if ( data.targetView.isNull )
      {
         var msg = new MessageBox( "You must select a view to apply this script.",
                                   "DarkMaskLayers Script", StdIcon.Error, StdButton.Ok );
         msg.execute();
         continue;
      }

      Console.show();
      doDark( data );
      break;
   }
}

main();
