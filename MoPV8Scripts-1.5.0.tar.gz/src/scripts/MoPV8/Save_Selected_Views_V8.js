#engine v8

////////////////////////////////////////////////////////////////////////////
//
// Save Selected Views - Masters of PixInsight
// V8 / PixInsight 1.9.4+ rebuild
//
// Based on Pete Proulx's Save Selected Views script.
// Rebuilt for the PixInsight V8 JavaScript engine.
//
////////////////////////////////////////////////////////////////////////////

#define TITLE "Save Selected Views - Masters of PixInsight"
#define VERSION "V8 Checkbox Rebuild v1"

#feature-id SaveSelectedViews : MoP V8> Save Selected Views
#feature-info Enhanced tool for saving selected Views with modern UI and advanced options - www.mastersofpixinsight.com

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

let parameters = {
   outputDir: "",
   fileFormatIndex: 0,
   conflictIndex: 0,
   save: function()
   {
      Parameters.set( "outputDir", this.outputDir );
      Parameters.set( "fileFormatIndex", this.fileFormatIndex );
      Parameters.set( "conflictIndex", this.conflictIndex );
   },
   load: function()
   {
      if ( Parameters.has( "outputDir" ) )        this.outputDir = Parameters.getString( "outputDir" );
      if ( Parameters.has( "fileFormatIndex" ) )  this.fileFormatIndex = Parameters.getInteger( "fileFormatIndex" );
      if ( Parameters.has( "conflictIndex" ) )    this.conflictIndex = Parameters.getInteger( "conflictIndex" );
   }
};

function safeString( v )
{
   return v === undefined || v === null ? "" : String( v );
}

function sanitizeFileName( name )
{
   let s = safeString( name );
   let out = "";
   for ( let i = 0; i < s.length; ++i )
   {
      let c = s.charAt( i );
      if ( (c >= "A" && c <= "Z") ||
           (c >= "a" && c <= "z") ||
           (c >= "0" && c <= "9") ||
           c === "_" || c === "-" || c === "." )
         out += c;
      else
         out += "_";
   }
   return out.length > 0 ? out : "UnnamedView";
}

function joinPath( dir, fileName )
{
   if ( dir.length === 0 ) return fileName;
   let last = dir.charAt( dir.length - 1 );
   return (last === "/" || last === "\\") ? dir + fileName : dir + "/" + fileName;
}

function fileExists( path )
{
   try { return File.exists( path ); }
   catch ( e ) { return false; }
}

function autoRenamedPath( filePath )
{
   let dot = filePath.lastIndexOf( "." );
   let base = dot >= 0 ? filePath.substring( 0, dot ) : filePath;
   let ext  = dot >= 0 ? filePath.substring( dot ) : "";

   let n = 1;
   let candidate = base + "_" + n + ext;
   while ( fileExists( candidate ) )
   {
      ++n;
      candidate = base + "_" + n + ext;
   }
   return candidate;
}

class ProgressTracker
{
   constructor( total )
   {
      this.total = total;
      this.current = 0;
      this.errors = [];
   }

   step( message )
   {
      ++this.current;
      let percent = this.total > 0 ? Math.round( (this.current / this.total) * 100 ) : 100;
      Console.writeln( "Progress [" + percent + "%] (" + this.current + "/" + this.total + ") " + message );
   }

   addError( message )
   {
      this.errors.push( message );
      Console.warningln( "ERROR: " + message );
   }
}

class SaveSelectedViewsDialog extends Dialog
{
   constructor()
   {
      super();

      parameters.load();

      this.windowTitle = "Save Selected Views - Masters of PixInsight";
      this.viewRows = [];

      this.titleLabel = new Label( this );
      this.titleLabel.text = "Save Selected Views";
      this.titleLabel.textAlignment = TextAlignment.Center;
      this.titleLabel.styleSheet = "font-weight: bold; font-size: 16px; padding: 8px;";

      this.websiteLabel = new Label( this );
      this.websiteLabel.text = "www.mastersofpixinsight.com";
      this.websiteLabel.textAlignment = TextAlignment.Center;
      this.websiteLabel.styleSheet = "font-size: 12px; padding: 4px;";

      this.instructionsGroupBox = new GroupBox( this );
      this.instructionsGroupBox.title = "Instructions";
      this.instructionsGroupBox.titleCheckBox = false;

      this.instructionsText = new Label( this );
      this.instructionsText.text =
         "Enhanced batch saving tool for opened image Views:\n\n" +
         "• Select Views to save by checking the boxes in the list below\n" +
         "• Choose output folder and file format\n" +
         "• Configure file conflict handling options\n" +
         "• Supports XISF, FITS, JPEG, TIFF, BMP, and PNG formats\n\n" +
         "Tip: Use XISF for astronomical data, JPEG/PNG for previews.";
      this.instructionsText.wordWrap = true;
      this.instructionsText.textAlignment = TextAlignment.Left;
      this.instructionsText.styleSheet = "line-height: 1.4; padding: 8px;";

      let instructionsSizer = new VerticalSizer;
      instructionsSizer.margin = 8;
      instructionsSizer.add( this.instructionsText );
      this.instructionsGroupBox.sizer = instructionsSizer;

      this.viewSelectionGroupBox = new GroupBox( this );
      this.viewSelectionGroupBox.title = "View Selection";
      this.viewSelectionGroupBox.titleCheckBox = false;

      this.selectAllButton = new PushButton( this );
      this.selectAllButton.text = "Select All";
      this.selectAllButton.icon = this.scaledResource( ":/icons/checked.png" );
      this.selectAllButton.toolTip = "Select all Views for saving";
      this.selectAllButton.onClick = () => {
         this.viewRows.forEach( row => { row.checkBox.checked = true; } );
         this.updateViewCount();
      };

      this.selectNoneButton = new PushButton( this );
      this.selectNoneButton.text = "Select None";
      this.selectNoneButton.icon = this.scaledResource( ":/icons/unchecked.png" );
      this.selectNoneButton.toolTip = "Deselect all Views";
      this.selectNoneButton.onClick = () => {
         this.viewRows.forEach( row => { row.checkBox.checked = false; } );
         this.updateViewCount();
      };

      this.refreshViewsButton = new PushButton( this );
      this.refreshViewsButton.text = "Refresh Views";
      this.refreshViewsButton.toolTip = "Refresh the list of opened Views";
      this.refreshViewsButton.onClick = () => {
         Console.writeln( "Refresh is disabled in this V8 build. Close and reopen the script to rescan open views." );
      };

      this.viewCountLabel = new Label( this );
      this.viewCountLabel.text = "Views selected: 0";
      this.viewCountLabel.styleSheet = "font-weight: bold;";

      this.viewControlsSizer = new HorizontalSizer;
      this.viewControlsSizer.spacing = 8;
      this.viewControlsSizer.add( this.selectAllButton );
      this.viewControlsSizer.add( this.selectNoneButton );
      this.viewControlsSizer.add( this.refreshViewsButton );
      this.viewControlsSizer.addStretch();
      this.viewControlsSizer.add( this.viewCountLabel );

      this.viewListFrame = new Frame( this );
      this.viewListFrame.frameStyle = FrameStyle.Box;
      this.viewListFrame.setScaledMinSize( 650, 220 );

      this.viewListSizer = new VerticalSizer;
      this.viewListSizer.margin = 6;
      this.viewListSizer.spacing = 4;
      this.viewListFrame.sizer = this.viewListSizer;

      let viewSelectionSizer = new VerticalSizer;
      viewSelectionSizer.margin = 8;
      viewSelectionSizer.spacing = 8;
      viewSelectionSizer.add( this.viewControlsSizer );
      viewSelectionSizer.add( this.viewListFrame, 100 );
      this.viewSelectionGroupBox.sizer = viewSelectionSizer;

      this.settingsGroupBox = new GroupBox( this );
      this.settingsGroupBox.title = "Save Settings";
      this.settingsGroupBox.titleCheckBox = false;

      this.outputDirLabel = new Label( this );
      this.outputDirLabel.text = "Output Folder:";
      this.outputDirLabel.setFixedWidth( 120 );
      this.outputDirLabel.styleSheet = "font-weight: bold;";

      this.outputDirEdit = new Edit( this );
      this.outputDirEdit.readOnly = true;
      this.outputDirEdit.text = parameters.outputDir;

      this.outputDirButton = new ToolButton( this );
      this.outputDirButton.icon = this.scaledResource( ":/icons/select-file.png" );
      this.outputDirButton.toolTip = "Select output folder";
      this.outputDirButton.onClick = () => {
         let gdd = new GetDirectoryDialog;
         gdd.initialPath = this.outputDirEdit.text;
         gdd.caption = "Select Output Folder";
         if ( gdd.execute() )
         {
            this.outputDirEdit.text = gdd.directory;
            parameters.outputDir = gdd.directory;
         }
      };

      this.outputDirSizer = new HorizontalSizer;
      this.outputDirSizer.spacing = 6;
      this.outputDirSizer.add( this.outputDirLabel );
      this.outputDirSizer.add( this.outputDirEdit, 100 );
      this.outputDirSizer.add( this.outputDirButton );

      this.fileFormatLabel = new Label( this );
      this.fileFormatLabel.text = "File Format:";
      this.fileFormatLabel.setFixedWidth( 120 );
      this.fileFormatLabel.styleSheet = "font-weight: bold;";

      this.fileFormatComboBox = new ComboBox( this );
      [
         "XISF - PixInsight Image Format (Recommended)",
         "FITS - Flexible Image Transport System",
         "JPEG - Joint Photographic Experts Group",
         "TIFF - Tagged Image File Format",
         "BMP - Windows Bitmap",
         "PNG - Portable Network Graphics"
      ].forEach( item => this.fileFormatComboBox.addItem( item ) );
      this.fileFormatComboBox.currentItem = Math.max( 0, Math.min( 5, parameters.fileFormatIndex ) );
      this.fileFormatComboBox.onItemSelected = index => { parameters.fileFormatIndex = index; };

      this.fileFormatSizer = new HorizontalSizer;
      this.fileFormatSizer.spacing = 6;
      this.fileFormatSizer.add( this.fileFormatLabel );
      this.fileFormatSizer.add( this.fileFormatComboBox, 100 );

      this.conflictLabel = new Label( this );
      this.conflictLabel.text = "File Conflicts:";
      this.conflictLabel.setFixedWidth( 120 );
      this.conflictLabel.styleSheet = "font-weight: bold;";

      this.conflictComboBox = new ComboBox( this );
      [
         "Ask each time",
         "Overwrite existing files",
         "Skip existing files",
         "Auto-rename with suffix"
      ].forEach( item => this.conflictComboBox.addItem( item ) );
      this.conflictComboBox.currentItem = Math.max( 0, Math.min( 3, parameters.conflictIndex ) );
      this.conflictComboBox.onItemSelected = index => { parameters.conflictIndex = index; };

      this.conflictSizer = new HorizontalSizer;
      this.conflictSizer.spacing = 6;
      this.conflictSizer.add( this.conflictLabel );
      this.conflictSizer.add( this.conflictComboBox, 100 );

      let settingsSizer = new VerticalSizer;
      settingsSizer.margin = 8;
      settingsSizer.spacing = 8;
      settingsSizer.add( this.outputDirSizer );
      settingsSizer.add( this.fileFormatSizer );
      settingsSizer.add( this.conflictSizer );
      this.settingsGroupBox.sizer = settingsSizer;

      this.newInstanceButton = new ToolButton( this );
      this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
      this.newInstanceButton.setScaledFixedSize( 24, 24 );
      this.newInstanceButton.toolTip = "Create Process Icon - Drag to save current settings";
      this.newInstanceButton.onMousePress = () => {
         parameters.outputDir = this.outputDirEdit.text;
         parameters.fileFormatIndex = this.fileFormatComboBox.currentItem;
         parameters.conflictIndex = this.conflictComboBox.currentItem;
         parameters.save();
         this.newInstance();
      };

      this.saveButton = new PushButton( this );
      this.saveButton.text = "Save Selected Views";
      this.saveButton.icon = this.scaledResource( ":/icons/ok.png" );
      this.saveButton.styleSheet = "font-weight: bold; padding: 8px 16px;";
      this.saveButton.defaultButton = true;
      this.saveButton.onClick = () => { this.ok(); };

      this.cancelButton = new PushButton( this );
      this.cancelButton.text = "Cancel";
      this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
      this.cancelButton.onClick = () => { this.cancel(); };

      this.buttonsSizer = new HorizontalSizer;
      this.buttonsSizer.spacing = 10;
      this.buttonsSizer.add( this.newInstanceButton );
      this.buttonsSizer.addStretch();
      this.buttonsSizer.add( this.saveButton );
      this.buttonsSizer.add( this.cancelButton );

      this.mainSizer = new VerticalSizer;
      this.mainSizer.margin = 12;
      this.mainSizer.spacing = 12;
      this.mainSizer.add( this.titleLabel );
      this.mainSizer.add( this.websiteLabel );
      this.mainSizer.add( this.instructionsGroupBox );
      this.mainSizer.add( this.viewSelectionGroupBox, 100 );
      this.mainSizer.add( this.settingsGroupBox );
      this.mainSizer.add( this.buttonsSizer );

      this.sizer = this.mainSizer;
      this.refreshViewList();
      this.adjustToContents();
      this.setMinWidth( Math.max( this.width, 700 ) );
      this.setMinHeight( Math.max( this.height, 600 ) );
   }

   clearViewList()
   {
      // PixInsight V8 sizers cannot be cleared or replaced once assigned.
      // This method is only used during initial construction when the sizer is empty.
      this.viewRows = [];
   }

   addHeaderRow()
   {
      let header = new HorizontalSizer;
      header.spacing = 8;

      let name = new Label( this );
      name.text = "View Name";
      name.styleSheet = "font-weight: bold;";
      name.setFixedWidth( 330 );

      let dim = new Label( this );
      dim.text = "Dimensions";
      dim.styleSheet = "font-weight: bold;";
      dim.setFixedWidth( 150 );

      let cs = new Label( this );
      cs.text = "Color Space";
      cs.styleSheet = "font-weight: bold;";
      cs.setFixedWidth( 120 );

      header.add( name );
      header.add( dim );
      header.add( cs );
      header.addStretch();
      this.viewListSizer.add( header );
   }

   refreshViewList()
   {
      this.clearViewList();
      this.addHeaderRow();

      let windows = ImageWindow.windows;
      if ( windows.length === 0 )
      {
         let label = new Label( this );
         label.text = "No Views currently open";
         label.styleSheet = "font-style: italic; padding: 8px;";
         this.viewListSizer.add( label );
         this.updateViewCount();
         return;
      }

      for ( let i = 0; i < windows.length; ++i )
      {
         let win = windows[i];
         if ( !win || win.isNull ) continue;

         let view = win.mainView;
         let image = view.image;
         let rowSizer = new HorizontalSizer;
         rowSizer.spacing = 8;

         let cb = new CheckBox( this );
         cb.text = view.id;
         cb.setFixedWidth( 330 );
         cb.checked = false;
         cb.onCheck = () => { this.updateViewCount(); };

         let dimLabel = new Label( this );
         dimLabel.text = image.width + " × " + image.height;
         dimLabel.setFixedWidth( 150 );

         let colorLabel = new Label( this );
         colorLabel.text = image.isColor ? "RGB" : "Grayscale";
         colorLabel.setFixedWidth( 120 );

         rowSizer.add( cb );
         rowSizer.add( dimLabel );
         rowSizer.add( colorLabel );
         rowSizer.addStretch();

         this.viewListSizer.add( rowSizer );
         this.viewRows.push( { checkBox: cb, window: win, id: view.id } );
      }

      this.updateViewCount();
      this.adjustToContents();
   }

   updateViewCount()
   {
      let count = 0;
      this.viewRows.forEach( row => { if ( row.checkBox.checked ) ++count; } );
      this.viewCountLabel.text = "Views selected: " + count;
   }

   selectedViews()
   {
      let out = [];
      this.viewRows.forEach( row => {
         if ( row.checkBox.checked )
            out.push( { id: row.id, window: row.window } );
      } );
      return out;
   }
}

function processSelectedViews( dialog )
{
   let outputDir = safeString( dialog.outputDirEdit.text );
   let fileFormatIndex = dialog.fileFormatComboBox.currentItem;
   let conflictMode = ["ask", "overwrite", "skip", "rename"][dialog.conflictComboBox.currentItem];

   parameters.outputDir = outputDir;
   parameters.fileFormatIndex = fileFormatIndex;
   parameters.conflictIndex = dialog.conflictComboBox.currentItem;
   parameters.save();

   if ( outputDir.length === 0 )
   {
      new MessageBox( "Please select an output folder.", TITLE, StdIcon.Error, StdButton.Ok ).execute();
      return false;
   }

   if ( !File.directoryExists( outputDir ) )
   {
      new MessageBox( "The selected output folder does not exist.", TITLE, StdIcon.Error, StdButton.Ok ).execute();
      return false;
   }

   let selectedViews = dialog.selectedViews();
   if ( selectedViews.length === 0 )
   {
      new MessageBox( "Please select at least one view to save.", TITLE, StdIcon.Error, StdButton.Ok ).execute();
      return false;
   }

   let formatNames = ["XISF", "FITS", "JPEG", "TIFF", "BMP", "PNG"];
   let formatExtensions = ["xisf", "fits", "jpg", "tif", "bmp", "png"];

   let confirmMessage = "Ready to save " + selectedViews.length + " view(s):\n\n" +
      "Output Folder: " + outputDir + "\n" +
      "File Format: " + formatNames[fileFormatIndex] + "\n" +
      "File Conflicts: " + ["Ask each time", "Overwrite", "Skip", "Auto-rename"][dialog.conflictComboBox.currentItem] + "\n\n" +
      "Continue with saving?";

   let confirm = new MessageBox( confirmMessage, TITLE, StdIcon.Question, StdButton.Yes, StdButton.No ).execute();
   if ( confirm !== StdButton.Yes )
      return false;

   Console.show();
   Console.writeln( "═══════════════════════════════════════" );
   Console.writeln( "SAVE SELECTED VIEWS PROCESSING STARTED - MASTERS OF PIXINSIGHT" );
   Console.writeln( "═══════════════════════════════════════" );
   Console.writeln( "Output folder: " + outputDir );
   Console.writeln( "File format: " + formatNames[fileFormatIndex] );
   Console.writeln( "Views to save: " + selectedViews.length );
   Console.writeln( "───────────────────────────────────────" );

   let progress = new ProgressTracker( selectedViews.length );
   let results = { success: 0, errors: 0, skipped: 0 };

   for ( let i = 0; i < selectedViews.length; ++i )
   {
      let viewData = selectedViews[i];
      let win = viewData.window;
      let viewId = viewData.id;

      if ( !win || win.isNull )
      {
         progress.addError( "View not found: " + viewId );
         ++results.errors;
         continue;
      }

      let fileName = sanitizeFileName( viewId ) + "." + formatExtensions[fileFormatIndex];
      let finalPath = joinPath( outputDir, fileName );

      progress.step( "Processing: " + viewId );

      try
      {
         let shouldSave = true;

         if ( fileExists( finalPath ) )
         {
            if ( conflictMode === "ask" )
            {
               let r = new MessageBox( "File already exists:\n\n" + finalPath + "\n\nOverwrite it?",
                                       TITLE, StdIcon.Question, StdButton.Yes, StdButton.No ).execute();
               shouldSave = (r === StdButton.Yes);
               if ( !shouldSave )
               {
                  ++results.skipped;
                  Console.writeln( "Skipped existing file: " + fileName );
               }
            }
            else if ( conflictMode === "skip" )
            {
               shouldSave = false;
               ++results.skipped;
               Console.writeln( "Skipped existing file: " + fileName );
            }
            else if ( conflictMode === "rename" )
            {
               finalPath = autoRenamedPath( finalPath );
               Console.writeln( "Renamed to: " + finalPath );
            }
            // overwrite mode falls through
         }

         if ( shouldSave )
         {
            Console.writeln( "Saving: " + viewId + " -> " + finalPath );
            win.saveAs( finalPath, false, false, false, false );
            ++results.success;
            Console.writeln( "Successfully saved: " + finalPath );
         }
      }
      catch ( e )
      {
         progress.addError( "Failed to save " + viewId + ": " + e.toString() );
         ++results.errors;
      }
   }

   Console.writeln( "───────────────────────────────────────" );
   Console.writeln( "PROCESSING SUMMARY:" );
   Console.writeln( "Successfully saved: " + results.success );
   Console.writeln( "Skipped: " + results.skipped );
   Console.writeln( "Errors: " + results.errors );
   Console.writeln( "═══════════════════════════════════════" );

   new MessageBox( "Save operation completed!\n\n" +
                   "Successfully saved: " + results.success + " files\n" +
                   "Skipped: " + results.skipped + " files\n" +
                   "Errors: " + results.errors + " files\n\n" +
                   "Check the console for detailed results.",
                   TITLE, StdIcon.Information, StdButton.Ok ).execute();
   return true;
}

function main()
{
   let dialog = new SaveSelectedViewsDialog();

   while ( true )
   {
      if ( !dialog.execute() )
         break;

      if ( processSelectedViews( dialog ) )
         break;
   }
}

main();
