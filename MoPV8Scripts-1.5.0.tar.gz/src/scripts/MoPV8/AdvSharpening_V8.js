#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Hartmut V. Bornemann.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; removed #include
// directives; converted sstDialog to class extends Dialog; expanded all
// with() statements; replaced all .prototype. enum references; replaced
// #define StdCursor macros with StdCursor.X dot notation.
// ----------------------------------------------------------------------------

/*

AdvSharpening.js: Advanced image sharpen using the MLT process
================================================================================

Bilder schärfen durch Maskierung.
Durch eine differenzierte Anhebung der Bias-Werte in den Wavelet-Layers ist eine
Schärfung und Verbesserung im Kontrast möglich. Das Script erzeugt dazu die
Masken und führt den Prozess mit MultiscaleLinearTransform durch.
Die Masken und der Prozess können optional exportiert werden, womit eine
schnellere Veränderung durchgeführt werden kann.

Advanced image sharpen using the MultiscaleLinearTransform process
Input:
1. Active window
2. Some ideas, how to raise or lower the bias in 4 layers
================================================================================
 *
 *
 * Copyright Hartmut V. Bornemann, 2016, 2017
 *
 * Based on a method by Vicent Peris
 *
 * mailTo:hvb356@hotmail.de
 */

#feature-id    AdvSharpening : MoP V8 > AdvSharpening


#define TITLE "Advanced image sharpen"
#define VERSION "1.2.1"
#define closeViews true


class sstDialog extends Dialog
{
constructor(view)
{
   super();

   var dlg = this;

   var bias = [0.0, 0.4, 0.1, 0.0];
   this.biasCtl = [null, null, null, null];
   var currentView = view;// ImageWindow.activeWindow.currentView;
   var exportMasks = false;
   var keepMaskOnView = false;
   var launchMLTprocess = false

   // ------------------------------------------------------------------------
   // GUI
   // ------------------------------------------------------------------------

   this.lblHeadLine = new Label(this)
      this.lblHeadLine.useRichText = true;
      this.lblHeadLine.text ="<b>Advanced sharpening using MultiscaleLinearTransform</b>";
      this.lblHeadLine.toolTip = "<p>change bias values to strengthen or weaken the effect" +
            "</p>";

   // my ©

   this.lblCopyright = new Label(this)
   this.lblCopyright.text      = "© 2016, Hartmut V. Bornemann";

   // execute button

   this.execButton = new PushButton( this );
   this.execButton.text = "Sharpen";
   this.execButton.enabled = true;
   this.execButton.onPress = function()
      {
         dlg.execButton.enabled = false;
         // copy bias values to array
         for (var i = 0; i < 4; i++)
         {
            bias[i] = dlg.biasCtl[i].value;
            Console.writeln("Layer " + (i+1).toString() + "   Bias: " + bias[i].toString());
         }

         var lightMaskName = getNewName("lightness_mask", "_2");
         Advanced_generate_lightness_mask_2(currentView, lightMaskName);
         var lightMaskView = ImageWindow.windowById(lightMaskName).mainView;
         lightMaskView.window.visible = exportMasks;
         Advanced_process_lightness_mask(lightMaskView);

         var starMaskName = getNewName("star_mask", "_2");
         Advanced_generate_star_mask(currentView, starMaskName);
         var starMaskView = ImageWindow.windowById(starMaskName).mainView;
         starMaskView.window.visible = exportMasks;
         Advanced_process_star_mask(starMaskView);

         var combinedName = getNewName("sharpening", "_2");
         Advanced_combine_masks(lightMaskView, starMaskView, combinedName, exportMasks);

         Console.writeln(combinedName + " ready");
         Console.flush();


         // delete lightMask and starMask

         if (!exportMasks)
         {
            lightMaskView.window.forceClose();
            starMaskView.window.forceClose();
         }

         var combinedMask = View.viewById(combinedName);

         // mask the view

         currentView.window.mask = combinedMask.window;
         currentView.window.maskEnabled = true;

         var mlt = sharpen(currentView, bias);

         if (!keepMaskOnView)
         {
            currentView.window.removeMask();
         }

         if (!exportMasks)
         {
            combinedMask.window.forceClose();
         }

         if (launchMLTprocess) mlt.launch();

         dlg.cursor = new Cursor(StdCursor.Arrow);
         dlg.done(1);
      }

   this.buttonSizer = new HorizontalSizer;
      this.buttonSizer.spacing = 4;
      this.buttonSizer.add( this.execButton );

   // ------------------------------------------------------------------------
   // BIAS
   // ------------------------------------------------------------------------

   for (var i = 0; i < 4; i++)
   {
      this.biasCtl[i] = new NumericControl (this);
         this.biasCtl[i].label.text = "Layer " + (i+1).toString() + " Bias:";
         this.biasCtl[i].setRange (-1, 5);
         this.biasCtl[i].slider.scaledMinWidth = 250;
         this.biasCtl[i].setPrecision (2);
         this.biasCtl[i].setValue (bias[i]);
   }

   this.dseParGroupBox = new GroupBox( this );
      this.dseParGroupBox.title = "Multiscale Linear Transform Bias Settings";
      this.dseParGroupBox.sizer = new VerticalSizer;
      this.dseParGroupBox.sizer.margin = 6;
      this.dseParGroupBox.sizer.spacing = 4;
      for (var i = 0; i < 4; i++)
      {
         this.dseParGroupBox.sizer.add( this.biasCtl[i] );
      }

   // object disposition controls

   this.exportMasks = new CheckBox( this )
      this.exportMasks.checked = false;
      this.exportMasks.text = "Export masks";
      this.exportMasks.onCheck = function (checked)
      {
         dlg.keepMask.enabled = checked;
         dlg.launchMLT.enabled = checked;
         exportMasks = checked;
         keepMaskOnView = keepMaskOnView && checked;
         launchMLTprocess = launchMLTprocess && checked;
      }

   this.keepMask = new CheckBox( this )
      this.keepMask.checked = false;
      this.keepMask.enabled = false;
      this.keepMask.text = "Keep mask on view";
      this.keepMask.onCheck = function (checked)
      {
         keepMaskOnView = checked;
      }

   this.launchMLT = new CheckBox( this )
      this.launchMLT.checked = false;
      this.launchMLT.enabled = false;
      this.launchMLT.text = "Launch MLT process";
      this.launchMLT.onCheck = function (checked)
      {
         launchMLTprocess = checked;
      }


   this.objectDispGroup =  new GroupBox( this );
      this.objectDispGroup.title = "Object disposition";
      this.objectDispGroup.sizer = new VerticalSizer;
      this.objectDispGroup.sizer.margin = 6;
      this.objectDispGroup.sizer.spacing = 4;
      this.objectDispGroup.sizer.add(this.exportMasks);
      this.objectDispGroup.sizer.add( this.keepMask );
      this.objectDispGroup.sizer.add( this.launchMLT );

   // ------------------------------------------------------------------------

   this.input_GroupBox = new GroupBox( this );
      this.input_GroupBox.title = "";
      this.input_GroupBox.sizer = new VerticalSizer;
      this.input_GroupBox.sizer.margin = 6;
      this.input_GroupBox.sizer.spacing = 4;
      this.input_GroupBox.sizer.add( this.dseParGroupBox);
      this.input_GroupBox.sizer.add( this.objectDispGroup);
      this.input_GroupBox.sizer.add( this.buttonSizer );

   // ------------------------------------------------------------------------
   // finally arrange all sizing elements and ajust the dialog frame
   // ------------------------------------------------------------------------

   this.sizer = new VerticalSizer(this);
   this.sizer.margin = 6;
   this.sizer.spacing = 6;
   this.sizer.add( this.lblHeadLine );
   this.sizer.add( this.lblCopyright );
   this.sizer.add( this.input_GroupBox );
   this.windowTitle = "AdvSharpen " + VERSION;

   this.adjustToContents();
}
} // class sstDialog

function sharpen(view, bias)
{
   //
   var P = new MultiscaleLinearTransform;
   P.layers = [ // enabled, biasEnabled, bias, noiseReductionEnabled, noiseReductionThreshold, noiseReductionAmount, noiseReductionIterations
      [true, true, bias[0], false, 3.000, 1.00, 1],
      [true, true, bias[1], false, 3.000, 1.00, 1],
      [true, true, bias[2], false, 3.000, 1.00, 1],
      [true, true, bias[3], false, 3.000, 1.00, 1],
      [true, true, 0.00000, false, 3.000, 1.00, 1]
   ];
   P.transform = MultiscaleLinearTransform.StarletTransform;
   P.scaleDelta = 0;
   P.scalingFunctionData = [
      0.25,0.5,0.25,
      0.5,1,0.5,
      0.25,0.5,0.25
   ];
   P.scalingFunctionRowFilter = [
      0.5,
      1,
      0.5
   ];
   P.scalingFunctionColFilter = [
      0.5,
      1,
      0.5
   ];
   P.scalingFunctionNoiseSigma = [
      0.8003,0.2729,0.1198,
      0.0578,0.0287,0.0143,
      0.0072,0.0036,0.0019,
      0.001
   ];
   P.scalingFunctionName = "Linear Interpolation (3)";
   P.linearMask = false;
   P.linearMaskAmpFactor = 100;
   P.linearMaskSmoothness = 1.00;
   P.linearMaskInverted = true;
   P.linearMaskPreview = false;
   P.largeScaleFunction = MultiscaleLinearTransform.NoFunction;
   P.curveBreakPoint = 0.75;
   P.noiseThresholding = false;
   P.noiseThresholdingAmount = 1.00;
   P.noiseThreshold = 3.00;
   P.softThresholding = true;
   P.useMultiresolutionSupport = false;
   P.deringing = false;
   P.deringingDark = 0.1000;
   P.deringingBright = 0.0000;
   P.outputDeringingMaps = false;
   P.lowRange = 0.0000;
   P.highRange = 0.0000;
   P.previewMode = MultiscaleLinearTransform.Disabled;
   P.previewLayer = 0;
   P.toLuminance = true;
   P.toChrominance = true;
   P.linear = false;
   P.executeOn(view);
   return P;
}


// Advanced_generate_lightness_mask_2

function Advanced_generate_lightness_mask_2(view, name)
{
   var P = new ChannelExtraction;
   P.colorSpace = ChannelExtraction.CIELch;
   P.channels = [ // enabled, id
      [true, name],
      [false, "RGB_c"],
      [false, ""]
   ];
   P.sampleFormat = ChannelExtraction.SameAsSource;
   P.executeOn(view);
}

// Advanced_process_lightness_mask

function Advanced_process_lightness_mask(view)
{
   var P = new CurvesTransformation;
   P.R = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Rt = CurvesTransformation.AkimaSubsplines;
   P.G = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Gt = CurvesTransformation.AkimaSubsplines;
   P.B = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Bt = CurvesTransformation.AkimaSubsplines;
   P.K = [ // x, y
      [0.00000, 0.00000],
      [0.24605, 0.07792],
      [1.00000, 1.00000]
   ];
   P.Kt = CurvesTransformation.AkimaSubsplines;
   P.A = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.At = CurvesTransformation.AkimaSubsplines;
   P.L = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Lt = CurvesTransformation.AkimaSubsplines;
   P.a = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.at = CurvesTransformation.AkimaSubsplines;
   P.b = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.bt = CurvesTransformation.AkimaSubsplines;
   P.c = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.ct = CurvesTransformation.AkimaSubsplines;
   P.H = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Ht = CurvesTransformation.AkimaSubsplines;
   P.S = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.St = CurvesTransformation.AkimaSubsplines;
   P.executeOn(view);
}

// Advanced_generate_star_mask

function Advanced_generate_star_mask(view, name)
{
   var P = new ChannelExtraction;
   P.colorSpace = ChannelExtraction.CIELch;
   P.channels = [ // enabled, id
      [true, name],
      [false, "RGB_c"],
      [false, ""]
   ];
   P.sampleFormat = ChannelExtraction.SameAsSource;
   P.executeOn(view);
}

// Advanced_process_star_mask

function Advanced_process_star_mask(view)
{
   var P = new MultiscaleLinearTransform;
   P.layers = [ // enabled, biasEnabled, bias, noiseReductionEnabled, noiseReductionThreshold, noiseReductionAmount, noiseReductionIterations
      [false, true, 0.000, false, 3.000, 1.00, 1],
      [true, true, 0.000, false, 3.000, 1.00, 1],
      [true, true, 0.000, false, 40.000, 1.00, 1],
      [true, true, 0.500, true, 40.000, 1.00, 1],
      [false, true, 0.000, false, 3.000, 1.00, 1]
   ];
   P.transform = MultiscaleLinearTransform.StarletTransform;
   P.scaleDelta = 0;
   P.scalingFunctionData = [
      0.25,0.5,0.25,
      0.5,1,0.5,
      0.25,0.5,0.25
   ];
   P.scalingFunctionRowFilter = [
      0.5,
      1,
      0.5
   ];
   P.scalingFunctionColFilter = [
      0.5,
      1,
      0.5
   ];
   P.scalingFunctionNoiseSigma = [
      0.8003,0.2729,0.1198,
      0.0578,0.0287,0.0143,
      0.0072,0.0036,0.0019,
      0.001
   ];
   P.scalingFunctionName = "Linear Interpolation (3)";
   P.linearMask = false;
   P.linearMaskAmpFactor = 100;
   P.linearMaskSmoothness = 1.00;
   P.linearMaskInverted = true;
   P.linearMaskPreview = false;
   P.largeScaleFunction = MultiscaleLinearTransform.NoFunction;
   P.curveBreakPoint = 0.75;
   P.noiseThresholding = true;
   P.noiseThresholdingAmount = 1.00;
   P.noiseThreshold = 10.00;
   P.softThresholding = true;
   P.useMultiresolutionSupport = false;
   P.deringing = false;
   P.deringingDark = 0.1000;
   P.deringingBright = 0.0000;
   P.outputDeringingMaps = false;
   P.lowRange = 0.0000;
   P.highRange = 0.0000;
   P.previewMode = MultiscaleLinearTransform.Disabled;
   P.previewLayer = 0;
   P.toLuminance = true;
   P.toChrominance = true;
   P.linear = false;
   P.executeOn(view);


   P = new CurvesTransformation;
   P.R = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Rt = CurvesTransformation.AkimaSubsplines;
   P.G = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Gt = CurvesTransformation.AkimaSubsplines;
   P.B = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Bt = CurvesTransformation.AkimaSubsplines;
   P.K = [ // x, y
      [0.00000, 0.00000],
      [0.32957, 0.25195],
      [0.55079, 0.72987],
      [1.00000, 1.00000]
   ];
   P.Kt = CurvesTransformation.AkimaSubsplines;
   P.A = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.At = CurvesTransformation.AkimaSubsplines;
   P.L = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Lt = CurvesTransformation.AkimaSubsplines;
   P.a = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.at = CurvesTransformation.AkimaSubsplines;
   P.b = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.bt = CurvesTransformation.AkimaSubsplines;
   P.c = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.ct = CurvesTransformation.AkimaSubsplines;
   P.H = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Ht = CurvesTransformation.AkimaSubsplines;
   P.S = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.St = CurvesTransformation.AkimaSubsplines;
   P.executeOn(view);


   P = new MorphologicalTransformation;
   P.operator = MorphologicalTransformation.Dilation;
   P.interlacingDistance = 1;
   P.lowThreshold = 0.000000;
   P.highThreshold = 0.000000;
   P.numberOfIterations = 1;
   P.amount = 1.00;
   P.selectionPoint = 0.50;
   P.structureName = "";
   P.structureSize = 7;
   P.structureWayTable = [ // mask
      [[
         0x00,0x00,0x01,0x01,0x01,0x00,0x00,
         0x00,0x01,0x01,0x01,0x01,0x01,0x00,
         0x01,0x01,0x01,0x01,0x01,0x01,0x01,
         0x01,0x01,0x01,0x01,0x01,0x01,0x01,
         0x01,0x01,0x01,0x01,0x01,0x01,0x01,
         0x00,0x01,0x01,0x01,0x01,0x01,0x00,
         0x00,0x00,0x01,0x01,0x01,0x00,0x00
      ]]
   ];
   P.executeOn(view);


   P = new Convolution;
   P.mode = Convolution.Parametric;
   P.sigma = 2.00;
   P.shape = 2.00;
   P.aspectRatio = 1.00;
   P.rotationAngle = 0.00;
   P.filterSource = "";
   P.rescaleHighPass = false;
   P.viewId = "";
   P.executeOn(view);
}

// Advanced_combine_masks

function Advanced_combine_masks(lightness_mask, star_mask, combinedMaskName, shownew)
{
   var P = new PixelMath;
   P.expression = lightness_mask.id + " - " + star_mask.id + " * 0.7";
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.symbols = "";
   P.generateOutput = true;
   P.singleThreaded = false;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = true;
   P.showNewImage = shownew;
   P.newImageId = combinedMaskName;
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.Gray;
   P.newImageSampleFormat = PixelMath.i32;
   P.executeOn(lightness_mask);
}

function launchMLT()
{
   var P = new MultiscaleLinearTransform;
   P.layers = [ // enabled, biasEnabled, bias, noiseReductionEnabled, noiseReductionThreshold, noiseReductionAmount, noiseReductionIterations
      [true, true, 0.000, false, 3.000, 1.00, 1],
      [true, true, 0.400, false, 3.000, 1.00, 1],
      [true, true, 0.100, false, 3.000, 1.00, 1],
      [true, true, 0.000, false, 3.000, 1.00, 1],
      [true, true, 0.000, false, 3.000, 1.00, 1]
   ];
   P.transform = MultiscaleLinearTransform.StarletTransform;
   P.scaleDelta = 0;
   P.scalingFunctionData = [
      0.25,0.5,0.25,
      0.5,1,0.5,
      0.25,0.5,0.25
   ];
   P.scalingFunctionRowFilter = [
      0.5,
      1,
      0.5
   ];
   P.scalingFunctionColFilter = [
      0.5,
      1,
      0.5
   ];
   P.scalingFunctionNoiseSigma = [
      0.8003,0.2729,0.1198,
      0.0578,0.0287,0.0143,
      0.0072,0.0036,0.0019,
      0.001
   ];
   P.scalingFunctionName = "Linear Interpolation (3)";
   P.linearMask = false;
   P.linearMaskAmpFactor = 100;
   P.linearMaskSmoothness = 1.00;
   P.linearMaskInverted = true;
   P.linearMaskPreview = false;
   P.largeScaleFunction = MultiscaleLinearTransform.NoFunction;
   P.curveBreakPoint = 0.75;
   P.noiseThresholding = false;
   P.noiseThresholdingAmount = 1.00;
   P.noiseThreshold = 3.00;
   P.softThresholding = true;
   P.useMultiresolutionSupport = false;
   P.deringing = false;
   P.deringingDark = 0.1000;
   P.deringingBright = 0.0000;
   P.outputDeringingMaps = false;
   P.lowRange = 0.0000;
   P.highRange = 0.0000;
   P.previewMode = MultiscaleLinearTransform.Disabled;
   P.previewLayer = 0;
   P.toLuminance = true;
   P.toChrominance = true;
   P.linear = false;
   P.launch();
}

function replaceView(view, replacement)
{
   var P = new PixelMath;
   P.expression = replacement.id;
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.symbols = "";
   P.generateOutput = true;
   P.singleThreaded = false;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = false;
   P.newImageColorSpace = PixelMath.SameAsTarget;
   P.newImageSampleFormat = PixelMath.SameAsTarget;
   P.executeOn(view);
}

function toRGB(view, name)
{
   var P = new PixelMath;
   P.expression = view.id;
   P.expression1 = view.id;
   P.expression2 = view.id;
   P.expression3 = "";
   P.useSingleExpression = false;
   P.symbols = "";
   P.generateOutput = true;
   P.singleThreaded = false;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = true;
   P.showNewImage = false;
   P.newImageId = name;
   P.newImageWidth = view.image.width;
   P.newImageHeight = view.image.height;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.RGB;
   P.newImageSampleFormat = PixelMath.i32;
   if (P.executeGlobal())
   {
      return View.viewById(name);
   }
   else
   {
      message("Grayscale to RGB failed", "Error");
      return null;
   }
}

function extractLuminance(view, id)
{
   var P = new ChannelExtraction;
   P.colorSpace = ChannelExtraction.CIELab;
   P.channels = [ // enabled, id
      [true, id],
      [false, ""],
      [false, ""]
   ];
   P.sampleFormat = ChannelExtraction.SameAsSource;
   if (P.executeOn(view))
      return View.viewById(id);
   {
      message("extractLuminance ", "Error");
      return null;
   }
}

// Helper function
function getNewName(name, suffix)
{
   name += suffix;
   let n = 1;
   while (!ImageWindow.windowById(name).isNull)
   {  // if there are 99 windows with matching names then throw!!!
      ++n;
      name += n;
   }
   return name;
}


function message(txt)
{
   var bx = new MessageBox(txt, "Error");
   bx.execute();
}


//////////////////////////////////////////////////////////////////////////////
//
// Main script entry point
//
function main()
{
   // Get access to the current active image window.
   Console.hide();
   var window = ImageWindow.activeWindow;
   if ( window.isNull )
   {
      message( "No active image" );
   }
   else
   {
      Console.writeln(TITLE + " started");
      var dialog = null;
      var view = window.currentView;
      if (!window.currentView.image.isColor)
      {
         var rgbName = getNewName(window.currentView.id, "_tmp")
         var tempRGB = toRGB(window.currentView, rgbName);
         dialog = new sstDialog(tempRGB);
         var result = dialog.execute();
         if (result == 1)
         {
            var lumName = getNewName(window.currentView.id, "_lum")
            var lumOfRGB = extractLuminance(tempRGB, lumName);
            replaceView(view, lumOfRGB);
            lumOfRGB.window.forceClose();
         }
         tempRGB.window.forceClose();
      }
      else
      {
         dialog = new sstDialog(window.currentView);
         dialog.execute();
      }
   }

   Console.writeln("\n" + TITLE + " ended");
}

main();
