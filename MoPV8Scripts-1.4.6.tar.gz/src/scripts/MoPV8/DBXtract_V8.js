#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/******************************************************************************
 * DBXtract.js version 1.5 (Dic 2025)
 *
 * This script allows you to extract the Sulfur II, Hydrogen Alpha and Oxygen III
 * signal from dual band filters to compose a SHO image
 *
 * This script was developed by Raúl Hussein.
 * Inspired in videos of  Dark Sky Geek youtube channel
 *
 * Changelog:
 * 0.1 - Core version
 * 0.2 - Combination OIII and SHO, HSO, HOO palettes
 * 0.3 - Minor bugs
 * 0.4 - Sensor imx410, imx178 and minor bugs
 * 0.5 - Sensor imx094, imx455, imx662, imx462
 * 0.6 - Manual QE sensor
 * 0.7 - Astrometic copy
 * 0.8 - Mean/Max OIII integration
 * 0.9 - IMX 294 clipping bug
 * 1.0 - Pedestal normalization
 * 1.1 - New methods OIII SO and HO integraion
 * 1.2 - Instance properties and container execution of HO images
 * 1.3 - New calculation of QE sensor (Relative Response transformation)
 *     - New sensors imx193 (Nikon D5300, QHY 247C), imx366, imx676, imx678
 * 1.4 – Improved OIII extraction
 *     - Added physical correction factor to avoid over-subtraction of R in G/B channels.
 *     – Greatly reduces black clipping in low-OIII regions while keeping physical consistency.
 * 1.5 - Improved OIII extraction pipeline
 *     - Band-specific background offset removal
 *     - HBeta (Hβ) extraction added
 *     - SII combination for SO and SH filters added
 *     - Improved OIII combination for HO and SO filters
 *     - Refined pixelMath engine and strict output range enforcement
 *     - Internal clean-up and stability improvements
 *
 *****************************************************************************/

// Script developed and tested on PixInsight 1.8.9-1 Ripley
// DBXtract.js
//
// This file is part of DBXtract Script
//
// Copyright (C) 2024 Raúl Hussein
// All Rights Reserved
//
// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Raúl Hussein.
// No rights to the original work are claimed or implied.
// ----------------------------------------------------------------------------

#feature-id DBXtract : MoP V8> DBXtract
#feature-info DualBand Channel Extraction<br/><br/>This script allows you to extract the SII, Ha, Hb and OIII signal from OSC cameras and dual band filters.
#feature-icon icons/DBXtract-icon.svg


#define VERSION "1.5"
#define TITLE "DBXtract"

#define R_NAME "_R"
#define B_NAME "_B"
#define G_NAME "_G"
#define OIII_HO_NAME "OIII_HO"
#define OIII_SO_NAME "OIII_SO"
#define SII_SO_NAME "SII_SO"
#define SII_SH_NAME "SII_SH"
#define HA_NAME "_HA"
#define SII_NAME "_SII"
#define OIII_NAME "_OIII"
#define HB_NAME "_HB"

#define KO3_FACTOR 0.9
#define KSII_SH_FACTOR 0.05
#define KHB_FACTOR 0.6
#define COTA_FACTOR 0.12
#define BRIGHTNESS_FACTOR 0.60
#define KHB_TO_SII_FACTOR 0.0
#define IS_HO 0
#define IS_SO 1
#define IS_SH 2

function DBXtractStart(data){
   Console.show();
   var result = false;

   // HO Processing
   if (data.referenceHO != null && !data.referenceHO.isNull){
      RGBChannelExtraction(data.referenceHO);
      HOcreateOIII(data);
      HOcreateHA(data);
      closeRGB();
      result = true;

      if (data.referenceSO == null  || data.referenceSO.isNull){
         var viewO3_HO = View.viewById(OIII_HO_NAME);
         if (!viewO3_HO.isNull) viewO3_HO.id = OIII_NAME;
      }
   }

   // SO Processing
   if (data.referenceSO != null  && !data.referenceSO.isNull){
      RGBChannelExtraction(data.referenceSO);
      SOcreateOIII(data);
      SOcreateSII(data);
      closeRGB();
      result = true;

      if (data.referenceHO != null && !data.referenceHO.isNull){
         OIIIcombine(data.referenceSO, data.integracion);
         closeOIII();
      }

      if (data.referenceSH == null  || data.referenceSH.isNull){
         var viewS2_SO = View.viewById(SII_SO_NAME);
         if (!viewS2_SO.isNull) viewS2_SO.id = SII_NAME;
      }

      if (data.referenceHO == null  || data.referenceHO.isNull){
         var viewO3_SO = View.viewById(OIII_SO_NAME);
         if (!viewO3_SO.isNull) viewO3_SO.id = OIII_NAME;
      }

   }

   // SH Processing
   if (data.referenceSH != null  && !data.referenceSH.isNull){
      RGBChannelExtraction(data.referenceSH);
      SHcreateHB(data);
      SHcreateSII(data);
      closeRGB();
      result = true;

      if (data.referenceSO != null && !data.referenceSO.isNull){
         SIIcombine(data.referenceSO, data.integracion);
         closeSII();
      }

      if (data.referenceSO == null  || data.referenceSO.isNull){
         var viewS2_SH = View.viewById(SII_SH_NAME);
         if (!viewS2_SH.isNull) viewS2_SH.id = SII_NAME;
      }

   }

   if (!result) {
       (new MessageBox("You must select at least one valid HO, SO, or SH image.", TITLE, StdIcon.Error, StdButton.Ok)).execute();
       return;
   }

   Console.writeln("DBXtract processing complete.");
   return;
}

function closeRGB(){
   var R = ImageWindow.windowById(R_NAME);
   var R_c = ImageWindow.windowById(R_NAME + "_copy");
   var G = ImageWindow.windowById(G_NAME);
   var B = ImageWindow.windowById(B_NAME);
   if (R && !R.isNull) R.forceClose();
   if (R_c && !R_c.isNull) R_c.forceClose();
   if (G && !G.isNull) G.forceClose();
   if (B && !B.isNull) B.forceClose();
}

function closeOIII(){
   var OIII_HO = ImageWindow.windowById(OIII_HO_NAME);
   var OIII_SO = ImageWindow.windowById(OIII_SO_NAME);

   if (OIII_HO != null && !OIII_HO.isNull) OIII_HO.forceClose();
   if (OIII_SO != null && !OIII_SO.isNull) OIII_SO.forceClose();
}

function closeSII(){
   var SII_SO = ImageWindow.windowById(SII_SO_NAME);
   var SII_SH = ImageWindow.windowById(SII_SH_NAME);

   if (SII_SO != null && !SII_SO.isNull) SII_SO.forceClose();
   if (SII_SH != null && !SII_SH.isNull) SII_SH.forceClose();
}

function copyAstrometricSolution(origenId, destinoId){
   var origen = View.viewById(origenId);

   if (origen != null && !origen.isNull && origen.window.hasAstrometricSolution){
      var destino = View.viewById(destinoId);

      if (destino != null && !destino.isNull){
         var iw = origen.image;
         var ow = destino.image;

         if (iw.width == ow.width && iw.height == ow.height){
            destino.window.copyAstrometricSolution(origen.window);
            Console.noteln("Astrometric solution copied to: ", destino.id);
         } else {
            Console.warningln(
               "Astrometric copy skipped: incompatible image dimensions between ",
               origen.id, " (", iw.width, "x", iw.height, ") and ",
               destino.id, " (", ow.width, "x", ow.height, ")."
            );
         }
      }
   }
}

// Parámetros B
function get_b1(sensor){
   switch(sensor){
      case 0: default: return 0.50; //IMX 571
      case 1: return 0.50; // IMX 533
      case 2: return 0.40; // IMX 585
      case 3: return 0.48; // IMX 294
      case 4: return 0.47; // IMX 183
      case 5: return 0.50; // IMX 071
      case 6: return 0.45; // IMX 410
      case 7: return 0.47; // IMX 178
      case 8: return 0.40; // IMX 455
      case 9: return 0.45; // IMX 094
      case 10: return 0.45; // IMX 462
      case 11: return 0.40; // IMX 662
	  case 12: return 0.45; // IMX 678
	  case 13: return 0.45; // IMX 676
	  case 14: return 0.47; // IMX 366
      case 15: return 0.50; // IMX 193
	  case 16: return 0.33; // KAF-8300
   }
}

function get_b2(sensor){
   switch(sensor){
      case 0: default: return 0.04; // IMX 571
      case 1: return 0.04; // IMX 533
      case 2: return 0.05; // IMX 585
      case 3: return 0.04; // IMX 294
      case 4: return 0.04; // IMX 183
      case 5: return 0.03; // IMX 071
      case 6: return 0.04; // IMX 410
      case 7: return 0.05; // IMX 178
      case 8: return 0.02; // IMX 455
      case 9: return 0.02; // IMX 094
      case 10: return 0.09; // IMX 462
      case 11: return 0.06; // IMX 662
	  case 12: return 0.09; // IMX 678
	  case 13: return 0.10; // IMX 676
	  case 14: return 0.04; // IMX 366
      case 15: return 0.01; // IMX 193
	  case 16: return 0.03; // KAF-8300
   }
}

function get_b3(sensor){
   switch(sensor){
      case 0: default: return 0.05; // IMX 571
      case 1: return 0.06; // IMX 533
      case 2: return 0.06; // IMX 585
      case 3: return 0.06; // IMX 294
      case 4: return 0.06; // IMX 183
      case 5: return 0.04; // IMX 071
      case 6: return 0.05; // IMX 410
      case 7: return 0.05; // IMX 178
      case 8: return 0.03; // IMX 455
      case 9: return 0.03; // IMX 094
      case 10: return 0.12; // IMX 462
      case 11: return 0.07; // IMX 662
      case 12: return 0.12; // IMX 678
	  case 13: return 0.13; // IMX 676
	  case 14: return 0.05; // IMX 366
      case 15: return 0.01; // IMX 193
	  case 16: return 0.04; // KAF-8300
   }
}

function get_b4(sensor){
   switch(sensor){
      case 0: default: return 0.70; // IMX 571
      case 1: return 0.67; // IMX 533
      case 2: return 0.52; // IMX 585
      case 3: return 0.62; // IMX 294
      case 4: return 0.64; // IMX 183
      case 5: return 0.65; // IMX 071
      case 6: return 0.64; // IMX 410
      case 7: return 0.64; // IMX 178
      case 8: return 0.47; // IMX 455
      case 9: return 0.62; // IMX 094
      case 10: return 0.64; // IMX 462
      case 11: return 0.65; // IMX 662
      case 12: return 0.62; // IMX 678
	  case 13: return 0.60; // IMX 676
	  case 14: return 0.67; // IMX 366
      case 15: return 0.72; // IMX 193
	  case 16: return 0.33; // KAF-8300
   }
}

// Parámetros G
function get_g1(sensor){
   switch(sensor){
      case 0: default: return 0.93; // IMX 571
      case 1: return 0.92; // IMX 533
      case 2: return 0.80; // IMX 585
      case 3: return 0.92; // IMX 294
      case 4: return 0.92; // IMX 183
      case 5: return 0.65; // IMX 071
      case 6: return 0.92; // IMX 410
      case 7: return 0.92; // IMX 178
      case 8: return 0.68; // IMX 455
      case 9: return 0.66; // IMX 094
      case 10: return 0.78; // IMX 462
      case 11: return 0.92; // IMX 662
      case 12: return 0.85; // IMX 678
	  case 13: return 0.85; // IMX 676
	  case 14: return 0.88; // IMX 366
      case 15: return 0.60; // IMX 193
	  case 16: return 0.22; // KAF-8300
   }
}

function get_g2(sensor){
   switch(sensor){
      case 0: default: return 0.11; // IMX 571
      case 1: return 0.12; // IMX 533
      case 2: return 0.14; // IMX 585
      case 3: return 0.12; // IMX 294
      case 4: return 0.11; // IMX 183
      case 5: return 0.09; // IMX 071
      case 6: return 0.11; // IMX 410
      case 7: return 0.11; // IMX 178
      case 8: return 0.06; // IMX 455
      case 9: return 0.09; // IMX 094
      case 10: return 0.20; // IMX 462
      case 11: return 0.36; // IMX 662
      case 12: return 0.28; // IMX 678
	  case 13: return 0.28; // IMX 676
	  case 14: return 0.13; // IMX 366
      case 15: return 0.02; // IMX 193
	  case 16: return 0.13; // KAF-8300
   }
}

function get_g3(sensor){
   switch(sensor){
      case 0: default: return 0.13; // IMX 571
      case 1: return 0.13; // IMX 533
      case 2: return 0.17; // IMX 585
      case 3: return 0.13; // IMX 294
      case 4: return 0.13; // IMX 183
      case 5: return 0.13; // IMX 071
      case 6: return 0.13; // IMX 410
      case 7: return 0.13; // IMX 178
      case 8: return 0.08; // IMX 455
      case 9: return 0.11; // IMX 094
      case 10: return 0.23; // IMX 462
      case 11: return 0.34; // IMX 662
      case 12: return 0.32; // IMX 678
	  case 13: return 0.40; // IMX 676
	  case 14: return 0.14; // IMX 366
      case 15: return 0.01; // IMX 193
	  case 16: return 0.08; // KAF-8300
   }
}

function get_g4(sensor){
   switch(sensor){
      case 0: default: return 0.67; // IMX 571
      case 1: return 0.82; // IMX 533
      case 2: return 0.72; // IMX 585
      case 3: return 0.85; // IMX 294
      case 4: return 0.77; // IMX 183
      case 5: return 0.50; // IMX 071
      case 6: return 0.77; // IMX 410
      case 7: return 0.77; // IMX 178
      case 8: return 0.57; // IMX 455
      case 9: return 0.46; // IMX 094
      case 10: return 0.77; // IMX 462
      case 11: return 0.85; // IMX 662
      case 12: return 0.72; // IMX 678
	  case 13: return 0.69; // IMX 676
	  case 14: return 0.75; // IMX 366
      case 15: return 0.48; // IMX 193
	  case 16: return 0.16; // KAF-8300
   }
}

// Parámetros R
function get_r1(sensor){
   switch(sensor){
      case 0: default: return 0.04; //IMX 571
      case 1: return 0.04; // IMX 533
      case 2: return 0.07; // IMX 585
      case 3: return 0.05; // IMX 294
      case 4: return 0.05; // IMX 183
      case 5: return 0.04; // IMX 071
      case 6: return 0.04; // IMX 410
      case 7: return 0.05; // IMX 178
      case 8: return 0.03; // IMX 455
      case 9: return 0.04; // IMX 094
      case 10: return 0.05; // IMX 462
      case 11: return 0.05; // IMX 662
      case 12: return 0.07; // IMX 678
	  case 13: return 0.05; // IMX 676
	  case 14: return 0.08; // IMX 366
      case 15: return 0.07; // IMX 193
	  case 16: return 0.04; // KAF-8300
   }
}

function get_r2(sensor){
   switch(sensor){
      case 0: default: return 0.80; // IMX 571
      case 1: return 0.80; // IMX 533
      case 2: return 0.98; // IMX 585
      case 3: return 0.90; // IMX 294
      case 4: return 0.77; // IMX 183
      case 5: return 0.75; // IMX 071
      case 6: return 0.80; // IMX 410
      case 7: return 0.78; // IMX 178
      case 8: return 0.66; // IMX 455
      case 9: return 0.79; // IMX 094
      case 10: return 0.81; // IMX 462
      case 11: return 0.87; // IMX 662
      case 12: return 0.93; // IMX 678
	  case 13: return 0.93; // IMX 676
	  case 14: return 0.80; // IMX 366
      case 15: return 0.15; // IMX 193
	  case 16: return 0.23; // KAF-8300
   }
}

function get_r3(sensor){
   switch(sensor){
      case 0: default: return 0.74; // IMX 571
      case 1: return 0.71; // IMX 533
      case 2: return 0.93; // IMX 585
      case 3: return 0.78; // IMX 294
      case 4: return 0.66; // IMX 183
      case 5: return 0.68; // IMX 071
      case 6: return 0.72; // IMX 410
      case 7: return 0.66; // IMX 178
      case 8: return 0.57; // IMX 455
      case 9: return 0.77; // IMX 094
      case 10: return 0.76; // IMX 462
      case 11: return 0.82; // IMX 662
      case 12: return 0.85; // IMX 678
	  case 13: return 0.85; // IMX 676
	  case 14: return 0.67; // IMX 366
      case 15: return 0.05; // IMX 193
	  case 16: return 0.23; // KAF-8300
   }
}

function get_r4(sensor){
   switch(sensor){
      case 0: default: return 0.04; // IMX 571
      case 1: return 0.04; // IMX 533
      case 2: return 0.04; // IMX 585
      case 3: return 0.04; // IMX 294
      case 4: return 0.04; // IMX 183
      case 5: return 0.04; // IMX 071
      case 6: return 0.04; // IMX 410
      case 7: return 0.04; // IMX 178
      case 8: return 0.02; // IMX 455
      case 9: return 0.04; // IMX 094
      case 10: return 0.04; // IMX 462
      case 11: return 0.03; // IMX 662
      case 12: return 0.05; // IMX 678
	  case 13: return 0.04; // IMX 676
	  case 14: return 0.08; // IMX 366
      case 15: return 0.07; // IMX 193
	  case 16: return 0.04; // KAF-8300
   }
}

function computeImageMode(view) {
    const img = view.image;
    const width = img.width;
    const height = img.height;
    const nChannels = img.numberOfChannels;
    const histBins = 1024;

    let hist = [];
    for (let i = 0; i < nChannels; i++) {
        hist[i] = [];
        for (let j = 0; j < histBins; ++j)
            hist[i][j] = 0;
    }

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            for (let c = 0; c < nChannels; c++) {
                let val = img.sample(x, y, c);
                if (val > 1e-6) {
                    let bin = Math.min(histBins - 1, Math.floor(val * (histBins - 1)));
                    hist[c][bin]++;
                }
            }
        }
    }

    function findPeak(h) {
        let max = 0;
        let index = 0;
        for (let i = 0; i < h.length; i++) {
            if (h[i] > max) {
                max = h[i];
                index = i;
            }
        }
        return index / (histBins - 1);
    }

    let result = [];
    for (let c = 0; c < nChannels; c++) {
        result.push(findPeak(hist[c]));
    }
    return result;
}

function subtractBackground(view, backgroundValues) {
    if (!view || view.isNull) return;

    let expr = "(" + view.id + ") - " + backgroundValues[0];

    view.beginProcess();
    let P = new PixelMath;
    P.expression = expr;
    P.useSingleExpression = true;
    P.generateOutput = true;
    P.createNewImage = false;
    P.truncate = false;
    P.executeOn(view, false);
    view.endProcess();
}

function applyChannelBackgroundCorrection(channelIds) {
    let pedestals = {};
    for (let i = 0; i < channelIds.length; i++) {
        let id = channelIds[i];
        let view = View.viewById(id);
        if (view && !view.isNull) {
            let pedestal = computeImageMode(view)[0];
            subtractBackground(view, [pedestal]);
            pedestals[id] = pedestal;
        }
    }
    Console.writeln("Pedestales aplicados:");
    for (let id in pedestals)
        Console.writeln(id, " = ", pedestals[id]);
    return pedestals;
}

function getOIIIScales(sensor){
   // QE in OIII (index 1) for this sensor
   var g1 = get_g1(sensor);
   var b1 = get_b1(sensor);

   // Reference Sensor: 0 = IMX571
   var g1_ref = get_g1(0);
   var b1_ref = get_b1(0);

   // Base scale for IMX571
   var scale_g = 1.5 * (g1 / g1_ref);
   var scale_b = 0.5 * (b1 / b1_ref);

   // Initial clamps
   if (scale_g < 0.5)  scale_g = 0.5;
   if (scale_g > 2.0)  scale_g = 2.0;
   if (scale_b < 0.25) scale_b = 0.25;
   if (scale_b > 1.0)  scale_b = 1.0;

   Console.writeln(
      format("OIII scales (sensor %d): scale_g = %.3f, scale_b = %.3f",
             sensor, scale_g, scale_b)
   );

   return { scale_g: scale_g, scale_b: scale_b };
}

function buildOIIIExpression(data, isHOB, O3_b){
   // Global factor OIII
   var kO3 = KO3_FACTOR;

   // QE in OIII (line 1 = OIII) each channel
   var b1 = data.b1;  // B @ OIII
   var r1 = data.r1;  // R @ OIII
   var g1 = data.g1;  // G @ OIII

   // "Mixed" coefficients HO or SO
   var bScaled = data.b2;
   var rScaled = data.r2;
   var gScaled = data.g2;

   switch (isHOB) {
      case IS_SO:
         bScaled = data.b3;
         rScaled = data.r3;
         gScaled = data.g3;
         break;
      case IS_SH:
         bScaled = data.b4;
         rScaled = data.r4;
         gScaled = data.g4;
         break;
   }

   // Subtraction basis coefficients of R
   var betaBase = bScaled / rScaled;   // B
   var cotaBase = gScaled / rScaled;   // G

   // Reasonable limit for bound and beta
   var cotaMax = COTA_FACTOR;   // 0.12
   var betaMax = 1.0;           // limit 1

   if (cotaBase > cotaMax)
      cotaBase = cotaMax;

   if (betaBase > betaMax)
      betaBase = betaMax;

   // Applying kO3
   var beta = kO3 * betaBase;
   var cota = kO3 * cotaBase;


   // Mixture weights according to sensor QE
   var scales  = getOIIIScales(data.sensor);
   var scale_b = scales.scale_b;
   var scale_g = scales.scale_g;

   // g_mix * r1 / r_mix (G “contaminated” with R)
   var gMix = data.g2;
   var rMix = data.r2;

   switch (isHOB) {
      case IS_SO:
         gMix = data.g3;
         rMix = data.r3;
         break;
      case IS_SH:
         gMix = data.g4;
         rMix = data.r4;
         break;
   }

   // Threshold of a bright star
   var brightThresh = BRIGHTNESS_FACTOR;

   // OIII in B: with bypass in saturated stars
   var O3_B =
      "iif(" + R_NAME + " > " + brightThresh.toFixed(3) + ", " +
         "(" + B_NAME + " / " + b1 + ") * " + scale_b + ", " +
         "((" + B_NAME + " - " + beta.toFixed(4) + " * " + R_NAME + ") / (" +
              b1 + " - (" + beta.toFixed(4) + " * " + r1 + "))) * " +
              scale_b +
      ")";

   // OIII in G
   var O3_G =
      "iif(" + R_NAME + " > " + brightThresh.toFixed(3) + ", " +
         "(" + G_NAME + " / " + g1 + ") * " + scale_g + ", " +
         "((" + G_NAME + " - " + cota.toFixed(4) + " * " + R_NAME + ") / (" +
              g1 + " - ((" + gMix + " * " + r1 + ") / " + rMix + "))) * " +
              scale_g +
      ")";

   // Weighted mix G/B + pedestal
   var exp1 =
      "(((2 * " + g1 + " * (" + O3_G + ")) + (" + b1 + " * (" + O3_B + "))) / " +
       "(2 * " + g1 + " + " + b1 + ")) + " + O3_b;

   return exp1;
}

function HOcreateOIII(data) {
   Console.noteln("HOcreateOIII (normalized)");

   // Background correction per channel and common pedestal
   const bg = applyChannelBackgroundCorrection([R_NAME, G_NAME, B_NAME]);
   var O3_b = Math.max(bg[B_NAME], bg[G_NAME]);

   // We construct the OIII expression for the HO case
   var exp1 = buildOIIIExpression(data, IS_HO, O3_b);

   // We run PixelMath (with standard truncation to [0,1])
   pixelMathFcn(data.referenceHO, exp1, "", "", "", OIII_HO_NAME);
   copyAstrometricSolution(data.referenceHO.id, OIII_HO_NAME);
}

function SOcreateOIII(data) {
   Console.noteln("SOcreateOIII (normalized)");

   const bg = applyChannelBackgroundCorrection([R_NAME, G_NAME, B_NAME]);
   var O3_b = Math.max(bg[B_NAME], bg[G_NAME]);

   // Now we generate the expression for the SO case
   var exp1 = buildOIIIExpression(data, IS_SO, O3_b);

   pixelMathFcn(data.referenceSO, exp1, "", "", "", OIII_SO_NAME);
   copyAstrometricSolution(data.referenceSO.id, OIII_SO_NAME);
}

function buildHBExpression_SH(data, HB_b) {
   var g1 = data.g1;
   var b1 = data.b1;

   var scales  = getOIIIScales(data.sensor);
   var scale_g = scales.scale_g;
   var scale_b = scales.scale_b;

   // G y B
   var expG = "(" + G_NAME + " / " + g1 + ") * " + scale_g;
   var expB = "(" + B_NAME + " / " + b1 + ") * " + scale_b;

   // Mixed weighted OIII (simplified)
   var exp =
      "(((2 * " + g1 + " * " + expG + ") + (" + b1 + " * " + expB + ")) / " +
      "(2 * " + g1 + " + " + b1 + ")) + " + HB_b;

   return exp;
}

function SHcreateHB(data) {
   Console.noteln("SHcreateHB (normalized)");

   const bg = applyChannelBackgroundCorrection([R_NAME, G_NAME, B_NAME]);
   var HB_b = Math.max(bg[B_NAME], bg[G_NAME]);

   var baseExp = buildHBExpression_SH(data, HB_b);

   // Global scale Hbeta
   baseExp = "(" + baseExp + ") * " + KHB_FACTOR;  // KHB_FACTOR = 0.6

   // Satured stars clamp
   var hbBrightThresh = 0.98;

   var exp1 =
      "iif(" + R_NAME + " > " + hbBrightThresh.toFixed(3) + ", " +
         "min(" + R_NAME + ", " + baseExp + "), " +
         baseExp +
      ")";

   pixelMathFcn(data.referenceSH, exp1, "", "", "", HB_NAME);
   copyAstrometricSolution(data.referenceSH.id, HB_NAME);
}

function HOcreateHA(data){
   Console.noteln("HOcreateHA");

   const R_b = computeImageMode(View.viewById(R_NAME))[0];
   const O3_b = computeImageMode(View.viewById(OIII_HO_NAME))[0];
   const correctedO3 = "(" + OIII_HO_NAME + ") - " + O3_b;

   // HA = (R-r1*O3) / r2
   var exp1 = "((" + R_NAME + ") - "+data.r1+" * (" + correctedO3 + ")) / "+data.r2+" + " + (O3_b+R_b);
   pixelMathFcn(data.referenceHO, exp1, "", "", "", HA_NAME);
   copyAstrometricSolution(data.referenceHO.id, HA_NAME);
}

function SOcreateSII(data){
   Console.noteln("SOcreateSII");

   const R_b = computeImageMode(View.viewById(R_NAME))[0];
   const O3_b = computeImageMode(View.viewById(OIII_SO_NAME))[0];
   const correctedO3 = "(" + OIII_SO_NAME + ") - " + O3_b;

   // SII = (R-r1*O3) / r3
   var exp1 = "("+R_NAME+" - "+data.r1+" * ("+correctedO3+")) / "+data.r3+" + " + (O3_b+R_b);
   pixelMathFcn(data.referenceSO, exp1, "", "", "", SII_SO_NAME);
   copyAstrometricSolution(data.referenceSO.id, SII_SO_NAME);
}

function SHcreateSII(data){
   Console.noteln("SHcreateSII");

   const R_b  = computeImageMode(View.viewById(R_NAME))[0];
   const HB_b = computeImageMode(View.viewById(HB_NAME))[0];
   const correctedHB = "(" + HB_NAME + ") - " + HB_b;

   // Effective Hbeta leakage in R (for SH should be very low)
   var kHB = data.r1 * KHB_TO_SII_FACTOR;

   // Núcleo de la fórmula SII
   var coreExp =
      "(" + R_NAME + " - " + kHB.toFixed(4) + " * (" + correctedHB + ")) / " +
      data.r4 + " + " + (HB_b + R_b);

   // Global scale to prevent SII_SH from triggering
   var exp1 = "(" + coreExp + ") * " + KSII_SH_FACTOR;

   pixelMathFcn(data.referenceSH, exp1, "", "", "", SII_SH_NAME);
   copyAstrometricSolution(data.referenceSH.id, SII_SH_NAME);
}

function computeChannelMean(view, channel = 0) {
    const img = view.image;
    const w = img.width, h = img.height;
    let sum = 0;
    for (let y = 0; y < h; y++)
        for (let x = 0; x < w; x++)
            sum += img.sample(x, y, channel);
    return sum / (w * h);
}

function computeChannelStats(view, channel = 0) {
    const img = view.image;
    const w = img.width, h = img.height;
    let sum = 0, sum2 = 0, N = w * h;

    for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
            let val = img.sample(x, y, channel);
            sum += val;
            sum2 += val * val;
        }
    }

    const mean = sum / N;
    const variance = (sum2 / N) - (mean * mean);
    const sigma = Math.sqrt(Math.max(variance, 0));

    return { mean: mean, sigma: sigma };
}

function sameGeometry(v1, v2) {
   if (!v1 || v1.isNull || !v2 || v2.isNull)
      return false;

   var i1 = v1.image;
   var i2 = v2.image;

   return i1.width == i2.width && i1.height == i2.height;
}

function OIIIcombine(referenceView, integracion) {
    Console.noteln("OIIIcombine: " + integracion);

    var exp1;

    // Vistas OIII
    let ho = View.viewById(OIII_HO_NAME);
    let so = View.viewById(OIII_SO_NAME);

    if ((!ho || ho.isNull) && (!so || so.isNull)) {
        Console.warningln("OIIIcombine: There are no OIII_HO or OIII_SO views. The combination is omitted.");
        return;
    }

    // We checked geometric compatibility with the reference
    let ref = referenceView;
    let hoOK = ho && sameGeometry(ref, ho);
    let soOK = so && sameGeometry(ref, so);

    let combineOK = hoOK && soOK && sameGeometry(ho, so);

    if (!combineOK) {
        // No podemos combinar con seguridad
        if (hoOK && !soOK) {
            Console.warningln("OIIIcombine: OIII_SO incompatible with the reference. Using only OIII_HO.");
            exp1 = OIII_HO_NAME;
        } else if (!hoOK && soOK) {
            Console.warningln("OIIIcombine: OIII_HO incompatible with the reference. Using only OIII_SO.");
            exp1 = OIII_SO_NAME;
        } else if (hoOK && soOK) {
            Console.warningln("OIIIcombine: OIII_HO and OIII_SO have different dimensions. Using only OIII_HO.");
            exp1 = OIII_HO_NAME;
        } else {
            Console.warningln("OIIIcombine: No OIII view is compatible with the reference. No OIII is generated.");
            return;
        }
    } else {
        // Geometry OK: we can apply the selected blending mode
        switch (integracion) {
        case 0:
        default: // Adaptative with scaling
            {
                let statsHO = computeChannelStats(ho);
                let statsSO = computeChannelStats(so);

                Console.writeln("Stats OIII_HO → mean: ", statsHO.mean, ", sigma: ", statsHO.sigma);
                Console.writeln("Stats OIII_SO → mean: ", statsSO.mean, ", sigma: ", statsSO.sigma);

                let HO_expr = "((" + OIII_HO_NAME + ") - " +
                               statsHO.mean.toFixed(6) + ") / " +
                               statsHO.sigma.toFixed(6);
                let SO_expr = "((" + OIII_SO_NAME + ") - " +
                               statsSO.mean.toFixed(6) + ") / " +
                               statsSO.sigma.toFixed(6);

                let sigmaMean = ((statsHO.sigma + statsSO.sigma) / 2).toFixed(6);
                let meanMean  = ((statsHO.mean + statsSO.mean) / 2).toFixed(6);

                exp1 = "avg(" + HO_expr + ", " + SO_expr + ") * " +
                        sigmaMean + " + " + meanMean;
            }
            break;

        case 1: // Weighted median (SNR-like)
            {
                let meanHO = computeChannelMean(ho);
                let meanSO = computeChannelMean(so);
                let sum = meanHO + meanSO;
                let k = sum > 0 ? meanHO / sum : 0.5;
                exp1 = k.toFixed(3) + " * " + OIII_HO_NAME +
                       " + " + (1 - k).toFixed(3) + " * " + OIII_SO_NAME;
                Console.writeln("Weighted combination by average: k = ", k.toFixed(3));
            }
            break;

        case 2: // Simple average
            exp1 = "avg(" + OIII_HO_NAME + ", " + OIII_SO_NAME + ")";
            break;
        }
    }

    // If we have arrived here, we have a valid expression for OIII
    pixelMathFcn(referenceView, exp1, OIII_SO_NAME, OIII_HO_NAME, "", OIII_NAME);
    copyAstrometricSolution(referenceView.id, OIII_NAME);
}

function SIIcombine(referenceView, integracion) {
    Console.noteln("SIIcombine: " + integracion);

    var exp1;

    // SII views
    let so = View.viewById(SII_SO_NAME);
    let sh = View.viewById(SII_SH_NAME);

    if ((!so || so.isNull) && (!sh || sh.isNull)) {
        Console.warningln("SIIcombine: There are no SII_SO or SII_SH views. The merge is omitted.");
        return;
    }

    // We checked geometric compatibility with the reference
    let ref = referenceView;
    let soOK = so && sameGeometry(ref, so);
    let shOK = sh && sameGeometry(ref, sh);

    let combineOK = soOK && shOK && sameGeometry(so, sh);

    if (!combineOK) {
        // No podemos combinar con seguridad
        if (soOK && !shOK) {
            Console.warningln("SIIcombine: SII_SO is incompatible with the reference. Only using SII_SH.");
            exp1 = SII_SO_NAME;
        } else if (!soOK && shOK) {
            Console.warningln("SIIcombine: SII_SH is incompatible with the reference. Only SII_SO is being used.");
            exp1 = SII_SH_NAME;
        } else if (soOK && shOK) {
            Console.warningln("SIIcombine: SII_SO and SII_SH have different dimensions. Using only SII_SO.");
            exp1 = SII_SO_NAME;
        } else {
            Console.warningln("SIIcombine: No SII view is compatible with the reference. No SII is generated.");
            return;
        }
    } else {
        // Geometry OK: we can apply the selected blending mode
        switch (integracion) {
        case 0:
        default: // Adaptative with scaling
            {
                let statsSO = computeChannelStats(so);
                let statsSH = computeChannelStats(sh);
                Console.writeln("Stats SII_HO → mean: ", statsSO.mean, ", sigma: ", statsSO.sigma);
                Console.writeln("Stats SII_SO → mean: ", statsSH.mean, ", sigma: ", statsSH.sigma);

                let SO_expr = "((" + SII_SO_NAME + ") - " +
                               statsSO.mean.toFixed(6) + ") / " +
                               statsSO.sigma.toFixed(6);
                let SH_expr = "((" + SII_SH_NAME + ") - " +
                               statsSH.mean.toFixed(6) + ") / " +
                               statsSH.sigma.toFixed(6);

                let sigmaMean = ((statsSO.sigma + statsSH.sigma) / 2).toFixed(6);
                let meanMean  = ((statsSO.mean + statsSH.mean) / 2).toFixed(6);

                exp1 = "avg(" + SO_expr + ", " + SH_expr + ") * " +
                        sigmaMean + " + " + meanMean;
            }
            break;

        case 1: // Weighted average (SNR-like)
            {
                let meanSO = computeChannelMean(so);
                let meanSH = computeChannelMean(sh);
                let sum = meanSO + meanSH;
                let k = sum > 0 ? meanSO / sum : 0.5;
                exp1 = k.toFixed(3) + " * " + SII_SO_NAME +
                       " + " + (1 - k).toFixed(3) + " * " + SII_SH_NAME;
                Console.writeln("Weighted combination by average: k = ", k.toFixed(3));
            }
            break;

        case 2: // Simple average
            exp1 = "avg(" + SII_SO_NAME + ", " + SII_SH_NAME + ")";
            break;
        }
    }

    // If we have arrived here, we have a valid expression for SII
    pixelMathFcn(referenceView, exp1, SII_SH_NAME, SII_SO_NAME, "", SII_NAME);
    copyAstrometricSolution(referenceView.id, SII_NAME);
}

function pixelMathFcn(vista, exp1, exp2, exp3, exp4, name, noTruncate){
    var m = vista;
	 m.beginProcess();

    var P = new PixelMath;
    P.expression = exp1;
    P.expression1 = exp2;
    P.expression2 = exp3;
    P.expression3 = exp4;
    P.useSingleExpression = true;
    P.symbols = "";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.createNewImage = true;
    P.showNewImage = true;
    P.newImageId = name;
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.newImageColorSpace = PixelMath.Gray;
    P.newImageSampleFormat = PixelMath.SameAsTarget;

    P.executeOn(m, false /*swapFile */);
	 m.endProcess();
}

function RGBChannelExtraction(vista){
   Console.noteln("RGBChannelExtraction");

   var m = vista && vista.id ? vista : ImageWindow.activeWindow.currentView;
   m.beginProcess();

   var P = new ChannelExtraction;
   P.colorSpace = ChannelExtraction.RGB;
   P.channels = [
      [true, R_NAME],
      [true, G_NAME],
      [true, B_NAME]
   ];
   P.sampleFormat = ChannelExtraction.SameAsSource;
   P.inheritAstrometricSolution = true;

   P.executeOn(m, false);
   m.endProcess();
}


/*
 * DIALOGO
 *
 */

// The script's parameters prototype.
function parametersPrototype()
{
   this.setDefaults = function()
   {
      this.referenceHO = null;
      this.referenceSO = null;
      this.referenceSH = null;
      this.sensor = 0;
      this.integracion = 0;
      this.rgbCustomize = false;
      this.r1 = get_r1(this.sensor);
      this.r2 = get_r2(this.sensor);
      this.r3 = get_r3(this.sensor);
      this.r4 = get_r4(this.sensor);
      this.g1 = get_g1(this.sensor);
      this.g2 = get_g2(this.sensor);
      this.g3 = get_g3(this.sensor);
      this.g4 = get_g4(this.sensor);
      this.b1 = get_b1(this.sensor);
      this.b2 = get_b2(this.sensor);
      this.b3 = get_b3(this.sensor);
      this.b4 = get_b4(this.sensor);
   };

   this.setParameters = function()
   {
      Parameters.clear();
      if(this.referenceHO != null && !this.referenceHO.isNull) Parameters.set( "referenceHO", this.referenceHO.id );
      if(this.referenceSO != null && !this.referenceSO.isNull) Parameters.set( "referenceSO", this.referenceSO.id );
      if(this.referenceSH != null && !this.referenceSH.isNull) Parameters.set( "referenceSH", this.referenceSH.id );
      Parameters.set( "sensor", this.sensor );
      Parameters.set( "rgbCustomize", this.rgbCustomize );
      Parameters.set( "integracion", this.integracion );
      Parameters.set( "r1", this.r1 );
      Parameters.set( "r2", this.r2 );
      Parameters.set( "r3", this.r3 );
      Parameters.set( "r4", this.r4 );
      Parameters.set( "g1", this.g1 );
      Parameters.set( "g2", this.g2 );
      Parameters.set( "g3", this.g3 );
      Parameters.set( "g4", this.g4 );
      Parameters.set( "b1", this.b1 );
      Parameters.set( "b2", this.b2 );
      Parameters.set( "b3", this.b3 );
      Parameters.set( "b4", this.b4 );
   };

   this.getParameters = function()
   {
      if (Parameters.has("referenceHO"))
         this.referenceHO = View.viewById(Parameters.getString("referenceHO"));

      if (this.referenceHO == null && Parameters.isViewTarget) {
         var targetViewId = Parameters.getString("targetView");
         if (targetViewId)
            this.referenceHO = View.viewById(targetViewId);
         Console.writeln("Vista objetivo recibida como referenceHO: ",
                         this.referenceHO ? this.referenceHO.id : "undefined");
      }

      if (Parameters.has("referenceSO"))
         this.referenceSO = View.viewById(Parameters.getString("referenceSO"));

      if (Parameters.has("referenceSH"))
         this.referenceSH = View.viewById(Parameters.getString("referenceSH"));

      if (Parameters.has("sensor"))
         this.sensor = Parameters.getInteger("sensor");

      if (Parameters.has("rgbCustomize"))
         this.rgbCustomize = Parameters.getBoolean("rgbCustomize");

      if (Parameters.has("integracion"))
         this.integracion = Parameters.getInteger("integracion");

      if (Parameters.has("r1")) this.r1 = Parameters.getReal("r1");
      if (Parameters.has("r2")) this.r2 = Parameters.getReal("r2");
      if (Parameters.has("r3")) this.r3 = Parameters.getReal("r3");
      if (Parameters.has("r4")) this.r4 = Parameters.getReal("r4");
      if (Parameters.has("g1")) this.g1 = Parameters.getReal("g1");
      if (Parameters.has("g2")) this.g2 = Parameters.getReal("g2");
      if (Parameters.has("g3")) this.g3 = Parameters.getReal("g3");
      if (Parameters.has("g4")) this.g4 = Parameters.getReal("g4");
      if (Parameters.has("b1")) this.b1 = Parameters.getReal("b1");
      if (Parameters.has("b2")) this.b2 = Parameters.getReal("b2");
      if (Parameters.has("b3")) this.b3 = Parameters.getReal("b3");
      if (Parameters.has("b4")) this.b4 = Parameters.getReal("b4");
   };
}

var data = new parametersPrototype();
data.setDefaults();
data.getParameters();


// ============================================================================
// V8-native compact dialog
// Replaces legacy SpiderMonkey/PJSR dialog while preserving the DBXtract engine.
// ============================================================================

function isValidView( v )
{
   return v !== null && v !== undefined && !v.isNull;
}

function setSensorDefaultsFromIndex( sensorIndex )
{
   data.sensor = sensorIndex;

   data.r1 = get_r1(sensorIndex);
   data.r2 = get_r2(sensorIndex);
   data.r3 = get_r3(sensorIndex);
   data.r4 = get_r4(sensorIndex);

   data.g1 = get_g1(sensorIndex);
   data.g2 = get_g2(sensorIndex);
   data.g3 = get_g3(sensorIndex);
   data.g4 = get_g4(sensorIndex);

   data.b1 = get_b1(sensorIndex);
   data.b2 = get_b2(sensorIndex);
   data.b3 = get_b3(sensorIndex);
   data.b4 = get_b4(sensorIndex);
}

var scriptMain = class extends Dialog
{
   constructor()
   {
      super();

      this.windowTitle = TITLE + " " + VERSION + " - V8";
      this.userResizable = true;

      let labelWidth = this.font.width("SII + Hbeta filter:") + 20;

      this.headerLabel = new Label(this);
      this.headerLabel.text = "<p><b>" + TITLE + " - Version " + VERSION + " V8</b></p>";
      this.headerLabel.useRichText = true;
      this.headerLabel.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;
      this.headerLabel.margin = 6;
      this.headerLabel.styleSheet = "font-size: 14px; font-weight: bold;";

      this.helpLabel = new Label(this);
      this.helpLabel.frameStyle = FrameStyle.Box;
      this.helpLabel.margin = 6;
      this.helpLabel.wordWrapping = true;
      this.helpLabel.useRichText = true;
      this.helpLabel.text =
         "Extract SII, Ha, Hβ, and OIII signal from OSC dual-band data.<br><br>" +
         "<b>V8 compatibility rebuild:</b> This version keeps the original extraction engine " +
         "but replaces the legacy dialog with a V8-native interface.";

      // Camera sensor
      this.cameraLabel = new Label(this);
      this.cameraLabel.text = "Camera sensor:";
      this.cameraLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.cameraLabel.minWidth = labelWidth;

      this.cameraCombo = new ComboBox(this);
      this.cameraCombo.editEnabled = false;
      [
         "IMX 571", "IMX 533", "IMX 585", "IMX 294", "IMX 183", "IMX 071",
         "IMX 410", "IMX 178", "IMX 455", "IMX 094", "IMX 462", "IMX 662",
         "IMX 678", "IMX 676", "IMX 366", "IMX 193", "KAF 8300"
      ].forEach( name => this.cameraCombo.addItem(name) );
      this.cameraCombo.currentItem = data.sensor;
      this.cameraCombo.toolTip = "Select the camera sensor used for the OSC dual-band data.";
      this.cameraCombo.onItemSelected = index =>
      {
         setSensorDefaultsFromIndex(index);
      };

      this.cameraSizer = new HorizontalSizer;
      this.cameraSizer.spacing = 6;
      this.cameraSizer.add(this.cameraLabel);
      this.cameraSizer.add(this.cameraCombo, 100);

      // View helpers
      const makeViewRow = (labelText, tooltip) =>
      {
         let label = new Label(this);
         label.text = labelText;
         label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
         label.minWidth = labelWidth;

         let list = new ViewList(this);
         list.getAll();
         list.minWidth = 320;
         list.toolTip = tooltip;

         let sizer = new HorizontalSizer;
         sizer.spacing = 6;
         sizer.add(label);
         sizer.add(list, 100);

         return { label: label, list: list, sizer: sizer };
      };

      let ho = makeViewRow("Ha + OIII filter:", "Select the HO / Ha+OIII reference image.");
      this.referenceHO_Label = ho.label;
      this.referenceHO_ViewList = ho.list;
      this.referenceHO_Sizer = ho.sizer;
      this.referenceHO_ViewList.onViewSelected = view => { data.referenceHO = view; };
      if ( isValidView(data.referenceHO) )
         this.referenceHO_ViewList.currentView = data.referenceHO;

      let so = makeViewRow("SII + OIII filter:", "Select the SO / SII+OIII reference image.");
      this.referenceSO_Label = so.label;
      this.referenceSO_ViewList = so.list;
      this.referenceSO_Sizer = so.sizer;
      this.referenceSO_ViewList.onViewSelected = view => { data.referenceSO = view; };
      if ( isValidView(data.referenceSO) )
         this.referenceSO_ViewList.currentView = data.referenceSO;

      let sh = makeViewRow("SII + Hbeta filter:", "Select the SH / SII+Hbeta reference image.");
      this.referenceSH_Label = sh.label;
      this.referenceSH_ViewList = sh.list;
      this.referenceSH_Sizer = sh.sizer;
      this.referenceSH_ViewList.onViewSelected = view => { data.referenceSH = view; };
      if ( isValidView(data.referenceSH) )
         this.referenceSH_ViewList.currentView = data.referenceSH;

      this.imageGroupBox = new GroupBox(this);
      this.imageGroupBox.title = "Input Images";
      this.imageGroupBox.sizer = new VerticalSizer;
      this.imageGroupBox.sizer.margin = 8;
      this.imageGroupBox.sizer.spacing = 6;
      this.imageGroupBox.sizer.add(this.cameraSizer);
      this.imageGroupBox.sizer.add(this.referenceHO_Sizer);
      this.imageGroupBox.sizer.add(this.referenceSO_Sizer);
      this.imageGroupBox.sizer.add(this.referenceSH_Sizer);

      // Integration
      this.integrationLabel = new Label(this);
      this.integrationLabel.text = "Integration Method:";
      this.integrationLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.integrationLabel.minWidth = labelWidth;

      this.integrationCombo = new ComboBox(this);
      this.integrationCombo.editEnabled = false;
      this.integrationCombo.addItem("Adaptive with scaling");
      this.integrationCombo.addItem("SNR-weighted average");
      this.integrationCombo.addItem("Average");
      this.integrationCombo.currentItem = data.integracion;
      this.integrationCombo.toolTip =
         "Method used when combining matching OIII or SII extractions from multiple filters.";
      this.integrationCombo.onItemSelected = index =>
      {
         data.integracion = index;
      };

      this.integrationSizer = new HorizontalSizer;
      this.integrationSizer.spacing = 6;
      this.integrationSizer.add(this.integrationLabel);
      this.integrationSizer.add(this.integrationCombo);
      this.integrationSizer.addStretch();

      this.optionsGroupBox = new GroupBox(this);
      this.optionsGroupBox.title = "Options";
      this.optionsGroupBox.sizer = new VerticalSizer;
      this.optionsGroupBox.sizer.margin = 8;
      this.optionsGroupBox.sizer.spacing = 6;
      this.optionsGroupBox.sizer.add(this.integrationSizer);

      this.noteLabel = new Label(this);
      this.noteLabel.wordWrapping = true;
      this.noteLabel.useRichText = true;
      this.noteLabel.text =
         "<b>Note:</b> This V8 build uses the selected sensor's default coefficients. " +
         "Manual coefficient customization from the legacy dialog can be added back after the core V8 workflow is confirmed.";
      this.noteLabel.margin = 4;

      // Buttons
      this.newInstanceButton = new ToolButton(this);
      this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
      this.newInstanceButton.setScaledFixedSize(24, 24);
      this.newInstanceButton.toolTip = "Create Process Icon";
      this.newInstanceButton.onMousePress = () =>
      {
         data.setParameters();
         this.newInstance();
      };

      this.processButton = new PushButton(this);
      this.processButton.text = "Run DBXtract";
      this.processButton.icon = this.scaledResource(":/icons/ok.png");
      this.processButton.onClick = () =>
      {
         this.ok();
      };

      this.cancelButton = new PushButton(this);
      this.cancelButton.text = "Cancel";
      this.cancelButton.icon = this.scaledResource(":/icons/cancel.png");
      this.cancelButton.onClick = () =>
      {
         this.cancel();
      };

      this.buttonSizer = new HorizontalSizer;
      this.buttonSizer.spacing = 8;
      this.buttonSizer.add(this.newInstanceButton);
      this.buttonSizer.addStretch();
      this.buttonSizer.add(this.processButton);
      this.buttonSizer.add(this.cancelButton);

      this.sizer = new VerticalSizer;
      this.sizer.margin = 10;
      this.sizer.spacing = 10;
      this.sizer.add(this.headerLabel);
      this.sizer.add(this.helpLabel);
      this.sizer.add(this.imageGroupBox);
      this.sizer.add(this.optionsGroupBox);
      this.sizer.add(this.noteLabel);
      this.sizer.add(this.buttonSizer);

      this.adjustToContents();
      this.setMinWidth(560);
   }
};

function pullDialogSelections( dialog )
{
   if ( dialog.cameraCombo )
      setSensorDefaultsFromIndex(dialog.cameraCombo.currentItem);

   if ( dialog.integrationCombo )
      data.integracion = dialog.integrationCombo.currentItem;

   if ( dialog.referenceHO_ViewList && isValidView(dialog.referenceHO_ViewList.currentView) )
      data.referenceHO = dialog.referenceHO_ViewList.currentView;

   if ( dialog.referenceSO_ViewList && isValidView(dialog.referenceSO_ViewList.currentView) )
      data.referenceSO = dialog.referenceSO_ViewList.currentView;

   if ( dialog.referenceSH_ViewList && isValidView(dialog.referenceSH_ViewList.currentView) )
      data.referenceSH = dialog.referenceSH_ViewList.currentView;
}

function main()
{
   Console.writeln("");
   Console.noteln("<b>", TITLE, " ", VERSION, " V8</b>:");

   data.getParameters();

   // Process icons or view-target launches can run directly if a valid reference was persisted.
   if ( isValidView(data.referenceHO) || isValidView(data.referenceSO) || isValidView(data.referenceSH) )
   {
      Console.show();
      DBXtractStart(data);
      return;
   }

   let dialog = new scriptMain();

   for ( ;; )
   {
      if ( !dialog.execute() )
      {
         Console.writeln("DBXtract cancelled.");
         return;
      }

      pullDialogSelections(dialog);
      data.setParameters();

      Console.show();
      Console.writeln("Selected HO: ", isValidView(data.referenceHO) ? data.referenceHO.id : "none");
      Console.writeln("Selected SO: ", isValidView(data.referenceSO) ? data.referenceSO.id : "none");
      Console.writeln("Selected SH: ", isValidView(data.referenceSH) ? data.referenceSH.id : "none");
      Console.writeln("Sensor index: ", data.sensor);
      Console.writeln("Integration mode: ", data.integracion);

      if ( !isValidView(data.referenceHO) && !isValidView(data.referenceSO) && !isValidView(data.referenceSH) )
      {
         new MessageBox("Select at least one HO, SO, or SH reference image.", TITLE, StdIcon.Warning, StdButton.Ok).execute();
         continue;
      }

      DBXtractStart(data);
      return;
   }
}

main();
