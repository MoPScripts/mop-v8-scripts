#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// PixInsight JavaScript Runtime API - PJSR Version 1.0
// ----------------------------------------------------------------------------
// NBRGBCombination.js - Released 2025-04-07T09:32:51Z
// ----------------------------------------------------------------------------
//
//
// Copyright (c) 2003-2025 Pleiades Astrophoto S.L. All Rights Reserved.
//
// Use of this source code is governed by the PixInsight Class Library License
// version 2.0, which can be found in the LICENSE file as well as at:
// https://pixinsight.com/license/PCL-License-2.0.html
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Pleiades Astrophoto S.L.
// No rights to the original work are claimed or implied.
// ----------------------------------------------------------------------------

/*
 * ### FIXME ###
 *
 * PTeam revision - 2013 December 05 - This script has been revised to keep it
 * running on version 1.8.0 of PixInsight.
 *
 * - The code needs refactoring, especially to get rid of with{} constructs.
 *
 * - Several UI bugs still have to be fixed.
 */

#feature-id    NBRGBCombination : MoP V8> NBRGBCombination

#feature-info  Script to combine any narrowband image (Ha,O3 etc) with RGB \
               originaly made by Silvercup \
            heavily modified by roryt (Ioannis Ioannou) \
            see http://pixinsight.com/forum/index.php?topic=3446.0

// Version 1.7  2013-11-30 roryt (Ioannis Ioannou)


// Largest dimension of the image preview in pixels.
#define PREVIEW_SIZE 400

// Shadows clipping point in (normalized) MAD units from the median.
#define SHADOWS_CLIP -2.80
// Target mean background in the [0,1] range.
#define TARGET_BKG    0.25

// Whether to apply the same STF to all channels, or treat each channel separately.
// roryt, made this a parameter data.CSTF_Linked not a hardcoded define #define RGB_LINK      true

// names for the temporary views
#define R_NAME                "NBRGBCombination_R"
#define G_NAME                "NBRGBCombination_G"
#define B_NAME                "NBRGBCombination_B"
#define NBr_NAME              "NBRGBCombination_NBr"
#define NBg_NAME              "NBRGBCombination_NBg"
#define NBb_NAME              "NBRGBCombination_NBb"
#define NBRGBCombination_NAME "NBRGBCombination"
#define Preview_NAME          "NBRGBCombination_Preview"

function NBRGBCombinationData()	{
   this.RGBView= ImageWindow.activeWindow.mainView;
   if ( this.RGBView.isNull ) {
      var msg = new MessageBox( "You must select an RGB view to apply this script.", "NBRGB Combination Script", StdIcon.Error, StdButton.Ok );
      console.hide();
      msg.execute();
      throw new Error( "You must select an RGB view to apply this script." );
   }

   this.Preview= new ImageWindow(this.RGBView.image.width,
                                 this.RGBView.image.height,
                                 3,
                                 32,
                                 true,
                                 true,
                                 Preview_NAME);

   this.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
   this.Preview.mainView.image.fill( 0 );
   this.Preview.mainView.endProcess();
   this.Preview.show();
   this.Preview.zoomToOptimalFit();


   this.NBRGBView= new ImageWindow(this.RGBView.image.width,
                                 this.RGBView.image.height,
                                 3,
                                 32,
                                 true,
                                 true,
                                 NBRGBCombination_NAME);

   this.NBRGBView.mainView.beginProcess(UndoFlag.NoSwapFile);
   this.NBRGBView.mainView.image.fill( 0 );
   this.NBRGBView.mainView.endProcess();


   this.NBrView= new ImageWindow(this.RGBView.image.width,
                                 this.RGBView.image.height,
                                 1,
                                 32,
                                 true,
                                 false, /* ### */
                                 NBr_NAME);

   this.NBrView.mainView.beginProcess(UndoFlag.NoSwapFile);
   this.NBrView.mainView.image.fill( 0 );
   this.NBrView.mainView.endProcess();

   this.NBgView= new ImageWindow(this.RGBView.image.width,
                                 this.RGBView.image.height,
                                 1,
                                 32,
                                 true,
                                 false, /* ### */
                                 NBg_NAME);

   this.NBgView.mainView.beginProcess(UndoFlag.NoSwapFile);
   this.NBgView.mainView.image.fill( 0 );
   this.NBgView.mainView.endProcess();

   this.NBbView= new ImageWindow(this.RGBView.image.width,
                                 this.RGBView.image.height,
                                 1,
                                 32,
                                 true,
                                 false, /* ### */
                                 NBb_NAME);

   this.NBbView.mainView.beginProcess(UndoFlag.NoSwapFile);
   this.NBbView.mainView.image.fill( 0 );
   this.NBbView.mainView.endProcess();


   this.RView= new ImageWindow(this.RGBView.image.width,
                                 this.RGBView.image.height,
                                 1,
                                 32,
                                 true,
                                 false,
                                 R_NAME);

   this.RView.mainView.beginProcess(UndoFlag.NoSwapFile);
   this.RView.mainView.image.fill( 0 );
   this.RView.mainView.endProcess();

   this.GView= new ImageWindow(this.RGBView.image.width,
                                 this.RGBView.image.height,
                                 1,
                                 32,
                                 true,
                                 false,
                                 G_NAME);
   this.GView.mainView.beginProcess(UndoFlag.NoSwapFile);
   this.GView.mainView.image.fill( 0 );
   this.GView.mainView.endProcess();

   this.BView= new ImageWindow(this.RGBView.image.width,
                                 this.RGBView.image.height,
                                 1,
                                 32,
                                 true,
                                 false,
                                 B_NAME);

   this.BView.mainView.beginProcess(UndoFlag.NoSwapFile);
   this.BView.mainView.image.fill( 0 );
   this.BView.mainView.endProcess();



   this.sourceNBrView=null;
   this.sourceNBrBandwidth=7;
   this.sourceNBrMultiplication=1.20;
   this.sourceNBgView=null;
   this.sourceNBgBandwidth=8.5;
   this.sourceNBgMultiplication=1.20;
   this.sourceNBbView=null;
   this.sourceNBbBandwidth=8.5;
   this.sourceNBbMultiplication=1.20;

   this.sourceRGBView=null;
   this.sourceRGBBandwidth=100;

   this.RGBImageSTF=null;
   this.NBRGBImageSTF=null;
   this.NBrImageSTF=null;
   this.NBgImageSTF=null;
   this.NBbImageSTF=null;

   this.CSTF=true;
   this.CSTF_Linked=false;

   this.Changed=true;

   this.CRescale=false;

   this.abort = false;
   this.busy = false;
   this.terminate = false;

}

class MyDialog extends Dialog
{
constructor()
{
   super();

   this.onHide = function() {
      // onHide is called in any case that the Dialog closes, cleanup
      data.Preview.forceClose();
      data.RView.forceClose();
      data.GView.forceClose();
      data.BView.forceClose();
      data.NBrView.forceClose();
      data.NBgView.forceClose();
      data.NBbView.forceClose();
      if (! data.NBRGBView.isNull) { // null will be at Cancel
         data.NBRGBView.show();  // do not know if OK was pressed or the form was closed by [X], better show it than close it
      }
   };

   /*
    * STF Auto Stretch routine
    */
   this.ApplyAutoSTF = function( view, shadowsClipping, targetBackground, rgbLinked )
   {
      var stf = new ScreenTransferFunction;

      var n = view.image.isColor ? 3 : 1;

      var median = view.computeOrFetchProperty( "Median" );

      var mad = view.computeOrFetchProperty( "MAD" );
      mad.mul( 1.4826 ); // coherent with a normal distribution

      if ( rgbLinked )
      {
         /*
          * Try to find how many channels look as channels of an inverted image.
          * We know a channel has been inverted because the main histogram peak is
          * located over the right-hand half of the histogram. Seems simplistic
          * but this is consistent with astronomical images.
          */
         var invertedChannels = 0;
         for ( var c = 0; c < n; ++c )
            if ( median.at( c ) > 0.5 )
               ++invertedChannels;

         if ( invertedChannels < n )
         {
            /*
             * Noninverted image
             */
            var c0 = 0, m = 0;
            for ( var c = 0; c < n; ++c )
            {
               if ( 1 + mad.at( c ) != 1 )
                  c0 += median.at( c ) + shadowsClipping * mad.at( c );
               m  += median.at( c );
            }
            c0 = Math.range( c0/n, 0.0, 1.0 );
            m = Math.mtf( targetBackground, m/n - c0 );

            stf.STF = [ // c0, c1, m, r0, r1
                        [c0, 1, m, 0, 1],
                        [c0, 1, m, 0, 1],
                        [c0, 1, m, 0, 1],
                        [0, 1, 0.5, 0, 1] ];
         }
         else
         {
            /*
             * Inverted image
             */
            var c1 = 0, m = 0;
            for ( var c = 0; c < n; ++c )
            {
               m  += median.at( c );
               if ( 1 + mad.at( c ) != 1 )
                  c1 += median.at( c ) - shadowsClipping * mad.at( c );
               else
                  c1 += 1;
            }
            c1 = Math.range( c1/n, 0.0, 1.0 );
            m = Math.mtf( c1 - m/n, targetBackground );

            stf.STF = [ // c0, c1, m, r0, r1
                        [0, c1, m, 0, 1],
                        [0, c1, m, 0, 1],
                        [0, c1, m, 0, 1],
                        [0, 1, 0.5, 0, 1] ];
         }
      }
      else
      {
         /*
          * Unlinked RGB channnels: Compute automatic stretch functions for
          * individual RGB channels separately.
          */
         var A = [ // c0, c1, m, r0, r1
                  [0, 1, 0.5, 0, 1],
                  [0, 1, 0.5, 0, 1],
                  [0, 1, 0.5, 0, 1],
                  [0, 1, 0.5, 0, 1] ];

         for ( var c = 0; c < n; ++c )
         {
            if ( median.at( c ) < 0.5 )
            {
               /*
                * Noninverted channel
                */
               var c0 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) + shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 0.0;
               var m  = Math.mtf( targetBackground, median.at( c ) - c0 );
               A[c] = [c0, 1, m, 0, 1];
            }
            else
            {
               /*
                * Inverted channel
                */
               var c1 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) - shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 1.0;
               var m  = Math.mtf( c1 - median.at( c ), targetBackground );
               A[c] = [0, c1, m, 0, 1];
            }
         }

         stf.STF = A;
      }

      console.writeln( "<end><cbr/><br/><b>", view.fullId, "</b>:" );
      for ( var c = 0; c < n; ++c )
      {
         console.writeln( "channel #", c );
         console.writeln( format( "c0 = %.6f", stf.STF[c][0] ) );
         console.writeln( format( "m  = %.6f", stf.STF[c][2] ) );
         console.writeln( format( "c1 = %.6f", stf.STF[c][1] ) );
      }

      stf.executeOn( view );

      console.writeln( "<end><cbr/><br/>" );
   };

   this.applySTF=function( img, stf ) {
      var HT = new HistogramTransformation;
      if (img.isColor) {
         HT.H =	[	[stf[0][1], stf[0][0], stf[0][2], stf[0][3], stf[0][4]],
                  [stf[1][1], stf[1][0], stf[1][2], stf[1][3], stf[1][4]],
                  [stf[2][1], stf[2][0], stf[2][2], stf[2][3], stf[2][4]],
                  [ 0, 0.5, 1, 0, 1]
               ];
      } else {
         HT.H =	[	[ 0, 0.5, 1, 0, 1],
                  [ 0, 0.5, 1, 0, 1],
                  [ 0, 0.5, 1, 0, 1],
                  [stf[0][1], stf[0][0], stf[0][2], stf[0][3], stf[0][4]]
               ];
      }

      //console.writeln("R/K: ",  stf[0][0], ",", stf[0][1], ",", stf[0][2], ",", stf[0][3], ",", stf[0][4]);
      //console.writeln("G  : ",  stf[1][0], ",", stf[1][1], ",", stf[1][2], ",", stf[1][3], ",", stf[1][4]);
      //console.writeln("B  : ",  stf[2][0], ",", stf[2][1], ",", stf[2][2], ",", stf[2][3], ",", stf[2][4]);
      //console.writeln("L  : ",  stf[3][0], ",", stf[3][1], ",", stf[3][2], ",", stf[3][3], ",", stf[3][4]);
      //console.writeln("width: ", img.width, " height: ", img.height, " , channels: " , img.numberOfChannels, " , bitsperpixel: ", img.bitsPerSample, " , sample: ", img.sampleType, " ,is color: ", img.isColor);

      var wtmp = new ImageWindow( img.width, img.height, img.numberOfChannels, img.bitsPerSample, img.sampleType == PixelSampleType.Real, img.isColor, "tmpSTFWindow" );
      var v = wtmp.mainView;
      v.beginProcess( UndoFlag.NoSwapFile );
      v.image.assign( img );
      v.endProcess();
      HT.executeOn( v, false ); // no swap file
      var image=v.image;
      var result=new Image(	image.width, image.height, image.numberOfChannels, image.colorSpace, image.bitsPerSample, image.sampleType);
      result.assign(v.image);
      wtmp.forceClose();
      return result;
   };

   this.Calculate_NBRGB = function() {

      if (data.Changed){
         console.show();

         //---------------------------------------------------
         var P = new PixelMath;
         // Ha = (Ha*RGB_bandwith-RGB*Ha_bandwith )/(RGB_bandwith-Ha_bandwith)
         P.expression = "";
         P.expression1 = "";
         P.expression2 = "";
         P.expression3 = "";
         P.useSingleExpression = true;
         P.symbols = "";
         P.use64BitWorkingImage = false;
         P.rescale = data.CRescale;
         P.rescaleLower = 0.0000000000;
         P.rescaleUpper = 1.0000000000;
         P.truncate = true;
         P.truncateLower = 0.0000000000;
         P.truncateUpper = 1.0000000000;
         P.createNewImage = false;
         P.newImageId = "";
         P.newImageWidth = 0;
         P.newImageHeight = 0;
         P.newImageAlpha = false;
         P.newImageColorSpace = PixelMath.SameAsTarget;
         P.newImageSampleFormat = PixelMath.SameAsTarget;

         if (data.sourceNBrView != null) {
            P.expression = "(("+data.sourceNBrView.id+"*"+data.sourceRGBBandwidth+")-("+data.sourceRGBView.id+"*"+data.sourceNBrBandwidth+"))/("+data.sourceRGBBandwidth+"-"+data.sourceNBrBandwidth+")";
            data.NBrView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.NBrView.mainView);
            data.NBrView.mainView.endProcess();
            console.writeln("NBrView P.expression=",P.expression);
         }
         if (data.sourceNBgView != null) {
            P.expression = "(("+data.sourceNBgView.id+"*"+data.sourceRGBBandwidth+")-("+data.sourceRGBView.id+"*"+data.sourceNBgBandwidth+"))/("+data.sourceRGBBandwidth+"-"+data.sourceNBgBandwidth+")";
            data.NBgView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.NBgView.mainView);
            data.NBgView.mainView.endProcess();
            console.writeln("NBgView P.expression=",P.expression);
         }
         if (data.sourceNBbView != null) {
            P.expression = "(("+data.sourceNBbView.id+"*"+data.sourceRGBBandwidth+")-("+data.sourceRGBView.id+"*"+data.sourceNBbBandwidth+"))/("+data.sourceRGBBandwidth+"-"+data.sourceNBbBandwidth+")";
            data.NBbView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.NBbView.mainView);
            data.NBbView.mainView.endProcess();
            console.writeln("NBbView P.expression=",P.expression);
         }

         data.NBRGBView.mainView.beginProcess(UndoFlag.NoSwapFile);
         data.NBRGBView.mainView.image.assign(data.sourceRGBView.image);
         data.NBRGBView.mainView.endProcess();
         // --------------------------------------------------------------------------
         var P = new PixelMath;
         // R=R+(Ha-med(Ha))*HaMultiplier
         P.expression = "";
         P.expression1 = "";
         P.expression2 = "";
         P.expression3 = "";
         P.useSingleExpression = true;
         P.symbols = "";
         P.use64BitWorkingImage = false;
         P.rescale = data.CRescale;
         P.rescaleLower = 0.0000000000;
         P.rescaleUpper = 1.0000000000;
         P.truncate = true;
         P.truncateLower = 0.0000000000;
         P.truncateUpper = 1.0000000000;
         P.createNewImage = false;
         P.newImageId = "";
         P.newImageWidth = 0;
         P.newImageHeight = 0;
         P.newImageAlpha = false;
         P.newImageColorSpace = PixelMath.SameAsTarget;
         P.newImageSampleFormat = PixelMath.SameAsTarget;

         if (data.sourceNBrView != null) {
            P.expression = data.sourceRGBView.id+"[0]+("+NBr_NAME+"-med("+NBr_NAME+"))*"+data.sourceNBrMultiplication;
            data.RView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.RView.mainView);
            data.RView.mainView.endProcess();
            console.writeln("RView P.expression=",P.expression);
         }
         if (data.sourceNBgView != null) {
            P.expression = data.sourceRGBView.id+"[1]+("+NBg_NAME+"-med("+NBg_NAME+"))*"+data.sourceNBgMultiplication;
            data.GView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.GView.mainView);
            data.GView.mainView.endProcess();
            console.writeln("GView P.expression=",P.expression);
         }
         if (data.sourceNBbView != null) {
            P.expression = data.sourceRGBView.id+"[2]+("+NBb_NAME+"-med("+NBb_NAME+"))*"+data.sourceNBbMultiplication;
            data.BView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.BView.mainView);
            data.BView.mainView.endProcess();
            console.writeln("BView P.expression=",P.expression);
         }
         //-----------------------------------------------------
         // linearfit Ha with R
         var P = new LinearFit;
         P.rejectLow = 0.000000;
         P.rejectHigh = 0.920000;
         if (data.sourceNBrView != null) {
            P.referenceViewId = R_NAME;
            data.NBrView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.NBrView.mainView);
            data.NBrView.mainView.endProcess();
            console.writeln("Linear Fit NBrView with ",R_NAME);
         }
         if (data.sourceNBgView != null) {
            P.referenceViewId = G_NAME;
            data.NBgView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.NBgView.mainView);
            data.NBgView.mainView.endProcess();
            console.writeln("Linear Fit NBgView with ",G_NAME);
         }
         if (data.sourceNBbView != null) {
            P.referenceViewId = B_NAME;
            data.NBbView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.NBbView.mainView);
            data.NBbView.mainView.endProcess();
            console.writeln("Linear Fit NBbView with ",B_NAME);
         }
         //-------------------------------------------------------------------

         var P = new PixelMath;
         //max(Ha,R)
         P.expression1 = "";
         P.expression2 = "";
         P.expression3 = "";
         P.useSingleExpression = true;
         P.symbols = "";
         P.use64BitWorkingImage = false;
         P.rescale = data.CRescale;
         P.rescaleLower = 0.0000000000;
         P.rescaleUpper = 1.0000000000;
         P.truncate = true;
         P.truncateLower = 0.0000000000;
         P.truncateUpper = 1.0000000000;
         P.createNewImage = false;
         P.newImageId = "";
         P.newImageWidth = 0;
         P.newImageHeight = 0;
         P.newImageAlpha = false;
         P.newImageColorSpace = PixelMath.SameAsTarget;
         P.newImageSampleFormat = PixelMath.SameAsTarget;
         if (data.sourceNBrView != null) {
            P.expression = "max("+NBr_NAME+","+R_NAME+")";
            data.RView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.RView.mainView);
            data.RView.mainView.endProcess();
            console.writeln("RView P.expression=",P.expression);
         }
         if (data.sourceNBgView != null) {
            P.expression = "max("+NBg_NAME+","+G_NAME+")";
            data.GView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.GView.mainView);
            data.GView.mainView.endProcess();
            console.writeln("GView P.expression=",P.expression);
         }
         if (data.sourceNBbView != null) {
            P.expression = "max("+NBb_NAME+","+B_NAME+")";
            data.BView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.BView.mainView);
            data.BView.mainView.endProcess();
            console.writeln("BView P.expression=",P.expression);
         }
         //----------------------------------------------------

         var P = new PixelMath;
         // remaining R,G,or B

         P.expression1 = "";
         P.expression2 = "";
         P.expression3 = "";
         P.useSingleExpression = true;
         P.symbols = "";
         P.use64BitWorkingImage = false;
         P.rescale = false;
         P.rescaleLower = 0.0000000000;
         P.rescaleUpper = 1.0000000000;
         P.truncate = true;
         P.truncateLower = 0.0000000000;
         P.truncateUpper = 1.0000000000;
         P.createNewImage = false;
         P.newImageId = "";
         P.newImageWidth = 0;
         P.newImageHeight = 0;
         P.newImageAlpha = false;
         P.newImageColorSpace = PixelMath.SameAsTarget;
         P.newImageSampleFormat = PixelMath.SameAsTarget;

         if (data.sourceNBrView == null) {
            P.expression = data.sourceRGBView.id+"[0]";
            data.RView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.RView.mainView);
            data.RView.mainView.endProcess();
            console.writeln("RView P.expression=",P.expression);
         }
         if (data.sourceNBgView == null) {
            P.expression = data.sourceRGBView.id+"[1]";
            data.GView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.GView.mainView);
            data.GView.mainView.endProcess();
            console.writeln("GView P.expression=",P.expression);
         }
         if (data.sourceNBbView == null) {
            P.expression = data.sourceRGBView.id+"[2]";
            data.BView.mainView.beginProcess(UndoFlag.NoSwapFile);
            P.executeOn(data.BView.mainView);
            data.BView.mainView.endProcess();
            console.writeln("BView P.expression=",P.expression);
         }
         //--------------------------------------------------------------
         var P = new ChannelCombination;
         P.colorSpace = ChannelCombination.RGB;
         P.channels = [ // enabled, id
                     [true, R_NAME],
                     [true, G_NAME],
                     [true, B_NAME]
                  ];

         data.NBRGBView.mainView.beginProcess(UndoFlag.NoSwapFile);
         P.executeOn(data.NBRGBView.mainView);
         data.NBRGBView.mainView.endProcess();

         if (data.CSTF) {
            this.ApplyAutoSTF( data.NBRGBView.mainView, SHADOWS_CLIP, TARGET_BKG, data.CSTF_Linked );
            data.NBRGBImageSTF = this.applySTF(data.NBRGBView.mainView.image,data.NBRGBView.mainView.stf);
         }
         console.hide();
         data.Changed=false;
      }
   }

   this.showNBRGB = function() {

      if ((data.sourceRGBView==null || data.sourceRGBView.isNull ) ||
         (	(data.sourceNBrView==null || data.sourceNBrView.isNull ) &&
            (data.sourceNBgView==null || data.sourceNBgView.isNull ) &&
            (data.sourceNBbView==null || data.sourceNBbView.isNull) ) ) {
         var msg = new MessageBox( 	"Please select at least one source narrowband and an RGB image.",
                              "NBRGB Combination Script", StdIcon.Error, StdButton.Ok );
         msg.execute();
         return;
      }

      data.NBRGBView.mainView.stf=[[0.5,1,0,0,1],[0.5,1,0,0,1],[0.5,1,0,0,1],[0.5,1,0,0,1]];

      this.Calculate_NBRGB();

      if (data.CSTF){
         data.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         data.Preview.mainView.image.assign(data.NBRGBImageSTF);
         data.Preview.mainView.endProcess();
         this.ScrollControl.updateView();
      } else {
         data.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         data.Preview.mainView.image.assign(data.NBRGBView.mainView.image);
         data.Preview.mainView.endProcess();
         this.ScrollControl.updateView();
      }
   }


   this.showNBr = function() {
      if (data.sourceNBrView==null || data.sourceNBrView.isNull){
         var msg = new MessageBox( 	"Please select a source N/B image to merge with R (eg Ha).",
                              "NBRGB Combination Script", StdIcon.Error, StdButton.Ok );
         msg.execute();
         return;
      }

      if (data.CSTF) {
         if (data.NBrImageSTF==null){
            console.show();
            data.NBrView.mainView.beginProcess(UndoFlag.NoSwapFile);
            data.NBrView.mainView.image.assign(data.sourceNBrView.image);
            data.NBrView.mainView.endProcess();
         }
         this.ApplyAutoSTF( data.NBrView.mainView, SHADOWS_CLIP, TARGET_BKG, data.CSTF_Linked );
         data.NBrImageSTF = this.applySTF(data.NBrView.mainView.image,data.NBrView.mainView.stf);

         data.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         data.Preview.mainView.image.assign(data.NBrImageSTF);
         data.Preview.mainView.endProcess();
         this.ScrollControl.updateView();
         console.hide();
      } else {
         data.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         data.Preview.mainView.image.assign(data.NBrView.mainView.image);
         data.Preview.mainView.endProcess();
         this.ScrollControl.updateView();
         console.hide();
      }
   }

   this.showNBg = function() {
      if (data.sourceNBgView==null || data.sourceNBgView.isNull){
         var msg = new MessageBox( 	"Please select a source N/B image to merge with G (eg O3).",
                              "NBRGB Combination Script", StdIcon.Error, StdButton.Ok );
         msg.execute();
         return;
      }

      if (data.CSTF) {
         if (data.NBgImageSTF==null){
            console.show();
            data.NBgView.mainView.beginProcess(UndoFlag.NoSwapFile);
            data.NBgView.mainView.image.assign(data.sourceNBgView.image);
            data.NBgView.mainView.endProcess();
         }
         this.ApplyAutoSTF( data.NBgView.mainView, SHADOWS_CLIP, TARGET_BKG, data.CSTF_Linked );
         data.NBgImageSTF = this.applySTF(data.NBgView.mainView.image,data.NBgView.mainView.stf);

         data.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         data.Preview.mainView.image.assign(data.NBgImageSTF);
         data.Preview.mainView.endProcess();
         this.ScrollControl.updateView();
         console.hide();
      } else {
         data.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         data.Preview.mainView.image.assign(data.NBgView.mainView.image);
         data.Preview.mainView.endProcess();
         this.ScrollControl.updateView();
         console.hide();
      }
   }


   this.showNBb = function() {
      if (data.sourceNBbView==null || data.sourceNBbView.isNull){
         var msg = new MessageBox( 	"Please select a source N/B image to merge with B (eg O3).",
                              "NBRGB Combination Script", StdIcon.Error, StdButton.Ok );
         msg.execute();
         return;
      }

      if (data.CSTF) {
         if (data.NBbImageSTF==null){
            console.show();
            data.NBbView.mainView.beginProcess(UndoFlag.NoSwapFile);
            data.NBbView.mainView.image.assign(data.sourceNBbView.image);
            data.NBbView.mainView.endProcess();
         }
         this.ApplyAutoSTF( data.NBbView.mainView, SHADOWS_CLIP, TARGET_BKG, data.CSTF_Linked );
         data.NBbImageSTF = this.applySTF(data.NBbView.mainView.image,data.NBbView.mainView.stf);

         data.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         data.Preview.mainView.image.assign(data.NBbImageSTF);
         data.Preview.mainView.endProcess();
         this.ScrollControl.updateView();
         console.hide();
      } else {
         data.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         data.Preview.mainView.image.assign(data.NBbView.mainView.image);
         data.Preview.mainView.endProcess();
         this.ScrollControl.updateView();
         console.hide();
      }
   }

   this.showRGB = function() {
      if (data.sourceRGBView==null || data.sourceRGBView.isNull){
         var msg = new MessageBox( 	"Please select a source RGB image.",
                              "NBRGB Combination Script", StdIcon.Error, StdButton.Ok );
         msg.execute();
         return;
      }

      if (data.CSTF) {
         if (data.RGBImageSTF==null){
            console.show();
            this.ApplyAutoSTF( data.sourceRGBView, SHADOWS_CLIP, TARGET_BKG, data.CSTF_Linked );
            data.RGBImageSTF = this.applySTF(data.sourceRGBView.image,data.sourceRGBView.stf);
         }
         data.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         data.Preview.mainView.image.assign(data.RGBImageSTF);
         data.Preview.mainView.endProcess();
         this.ScrollControl.updateView();
         console.hide();
      } else {
         data.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         data.Preview.mainView.image.assign(data.sourceRGBView.image);
         data.Preview.mainView.endProcess();
         this.ScrollControl.updateView();
         console.hide();
      }
   }


   this.onMouseWheel = function(Dx,Dy, MouseWheel) {
      if (MouseWheel >0) {
         if (data.NBrView.visible ) {
            data.NBrView.zoomOut();
         } else {
            if (data.NBgView.visible ) {
               data.NBgView.zoomOut();
            } else {
               if (data.NBbView.visible ) {
                  data.NBbView.zoomOut();
               } else {
                  data.Preview.zoomOut();
               }
            }
         }
      } else {
         if (data.NBrView.visible ) {
            data.NBrView.zoomIn();
         } else {
            if (data.NBgView.visible ) {
               data.NBgView.zoomIn();
            } else {
               if (data.NBbView.visible ) {
                  data.NBbView.zoomIn();
               } else {
                  data.Preview.zoomIn();
               }
            }
         }
      }
      this.ScrollControl.updateView();
   }

   this.ScrollControl = new Control( this );

   this.ScrollControl.updateView = function()
   {
      var imageWidth = data.Preview.mainView.image.width;
      var imageHeight = data.Preview.mainView.image.height;
      var width, height;
      if ( imageWidth > imageHeight )
      {
         width = PREVIEW_SIZE;
         height = PREVIEW_SIZE*imageHeight/imageWidth;
      }
      else
      {
         width = PREVIEW_SIZE*imageWidth/imageHeight;
         height = PREVIEW_SIZE;
      }
      this.setFixedSize( width, height );
      this.kw = 1/imageWidth*width;
      this.kh = 1/imageHeight*height;
      this.update();
   };

   this.ScrollControl.scalingFactor = function()
   {
      return Math.sqrt( this.boundsRect.area/data.Preview.mainView.image.bounds.area );
   };

   this.ScrollControl.imageRect = function()
   {
      try {
         var rect = data.Preview.viewportToImage( data.Preview.visibleViewportRect );
         rect.mul( this.scalingFactor() );
         return rect;
      } catch(e) {
         return this.boundsRect;
      }
   };

   this.ScrollControl.toolTip = "<p>Control the Preview window (zoom/scroll) using this image</p>";
   this.ScrollControl.cursor = new Cursor( StdCursor.CirclePlus );

   this.ScrollControl.dragging = false;
   this.ScrollControl.dragOffset = null;

   this.ScrollControl.onPaint = function()
   {
      var G = new Graphics( this );
      G.drawScaledBitmap( this.boundsRect, data.Preview.mainView.image.render() );
      G.pen = new Pen( 0xFF00FF00 ); //Green
      G.drawRect( this.imageRect() );
      G.end();
   };

   this.ScrollControl.onMousePress = function( x, y )
   {
      this.dragging = true;
      this.dragOffset = new Point( x, y );
      this.dragOffset.sub( this.imageRect().center );
   };

   this.ScrollControl.onMouseRelease = function()
   {
      this.dragging = false;
      this.dragOffset = null;
   };

   this.ScrollControl.onMouseMove = function( x, y )
   {
      if ( this.dragging )
      {
         var scale = this.scalingFactor();
         data.Preview.setViewport( (x - this.dragOffset.x)/scale, (y - this.dragOffset.y)/scale );
         this.update();
      }
   };

   this.ScrollControl.updateView( data.Preview.mainView );

   //---------------------------------------------------------------------------------------
   // Zoom buttons
   var labelWidth1 = this.font.width( "----------------------" + 'T' );


   this.ZoomToFit_Button = new PushButton( this );
      this.ZoomToFit_Button.text = "ZoomToFit";
      this.ZoomToFit_Button.onClick = function() {
         if (data.NBrView.visible ) {
            data.NBrView.zoomToFit();
         } else {
            if (data.NBgView.visible ) {
               data.NBgView.zoomToFit();
            } else {
               if (data.NBbView.visible ) {
                  data.NBbView.zoomToFit();
               } else {
                  data.Preview.zoomToFit();
               }
            }
         }
         this.dialog.ScrollControl.repaint();
      }

   this.fitWindow_Button = new PushButton( this );
      this.fitWindow_Button.text = "FitView";
      this.fitWindow_Button.onClick = function() {
         if (data.NBrView.visible ) {
            data.NBrView.fitWindow();
         } else {
            if (data.NBgView.visible ) {
               data.NBgView.fitWindow();
            } else {
               if (data.NBbView.visible ) {
                  data.NBbView.fitWindow();
               } else {
                  data.Preview.fitWindow();
               }
            }
         }
         this.dialog.ScrollControl.repaint();
      }
   this.zoomToOptimalFit_Button = new PushButton( this );
      this.zoomToOptimalFit_Button.text = "OptimalFit";
      this.zoomToOptimalFit_Button.onClick = function() {
         if (data.NBrView.visible ) {
            data.NBrView.zoomToOptimalFit();
         } else {
            if (data.NBgView.visible ) {
               data.NBgView.zoomToOptimalFit();
            } else {
               if (data.NBbView.visible ) {
                  data.NBbView.zoomToOptimalFit();
               } else {
                  data.Preview.zoomToOptimalFit();
               }
            }
         }
         this.dialog.ScrollControl.repaint();
      }


   // Preview buttons
   this.showNBRGB_Button = new PushButton( this );
      this.showNBRGB_Button.text = "NBRGB";
      this.showNBRGB_Button.toolTip = "<p>Show the final image at the preview window</p>";
      this.showNBRGB_Button.onClick = function() {
         this.dialog.showNBRGB();
      }

   this.showRGB_Button = new PushButton( this );
      this.showRGB_Button.text = "RGB";
      this.showRGB_Button.toolTip = "<p>Show the source RGB image at the preview window</p>";
      this.showRGB_Button.onClick = function() {
         this.dialog.showRGB();
      }
   this.showNBr_Button = new PushButton( this );
      this.showNBr_Button.text = "R channel";
      this.showNBr_Button.toolTip = "<p>Show the narrowband image that will be merged with R, at the preview window</p>";
      this.showNBr_Button.onClick = function() {
         this.dialog.showNBr();
      }
   this.showNBg_Button = new PushButton( this );
      this.showNBg_Button.text = "G channel";
      this.showNBg_Button.toolTip = "<p>Show the narrowband image that will be merged with G, at the preview window</p>";
      this.showNBg_Button.onClick = function() {
         this.dialog.showNBg();
      }
   this.showNBb_Button = new PushButton( this );
      this.showNBb_Button.text = "B channel";
      this.showNBb_Button.toolTip = "<p>Show the narrowband image that will be merged with B, at the preview window</p>";
      this.showNBb_Button.onClick = function() {
         this.dialog.showNBb();
      }

   this.STF_CheckBox = new CheckBox( this );
      this.STF_CheckBox.text = "AutoSTF";
      this.STF_CheckBox.checked = data.CSTF;
      this.STF_CheckBox.toolTip = "<p>If this option is selected, the script will perfom an AutoSTF "	+ "to the final image.</p>";
      this.STF_CheckBox.onCheck = function( checked ) {
         //data.Changed=true;
         data.CSTF = checked;
      }

   this.STF_LinkCheckBox = new CheckBox( this );
      this.STF_LinkCheckBox.text = "Linked STF";
      this.STF_LinkCheckBox.checked = data.CSTF_Linked;
      this.STF_LinkCheckBox.toolTip = "<p>During STF, should the RGB channels be linked ?</p>";
      this.STF_LinkCheckBox.onCheck = function( checked ) {
         data.CSTF_Linked = checked;
      }


   this.Rescale_CheckBox = new CheckBox( this );
      this.Rescale_CheckBox.text = "Non Linear";
      this.Rescale_CheckBox.checked = data.CRescale;
      this.Rescale_CheckBox.toolTip = "<p>If this option is selected, the script will rescale " + "pixelmath expressions for non linear images.</p>";
      this.Rescale_CheckBox.onCheck = function( checked ) {
         data.Changed=true;
         data.CRescale = checked;
      }



   this.applyButton = new PushButton( this );
   this.applyButton.text = "Apply";
   this.applyButton.icon = this.scaledResource( ":/icons/gears.png" );
   this.applyButton.onClick = function() {
      data.Changed=true;
      this.this.dialog.showNBRGB();
   };

   this.okButton = new PushButton( this );
   this.okButton.text = "OK";
   this.okButton.icon = this.scaledResource( ":/icons/ok.png" );
   this.okButton.onClick = function() {
      data.NBRGBView.deletePreviews();
      data.NBRGBView.show();
      this.dialog.ok();
   };

   this.cancelButton = new PushButton( this );
   this.cancelButton.text = "Cancel";
   this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
   this.cancelButton.onClick = function() {
      data.NBRGBView.deletePreviews();
      data.NBRGBView.forceClose();
      this.dialog.cancel();
   };



   //--------------------------
   // RGB selector and sliders
   this.sourceRGBImage_Label = new Label( this );
   this.sourceRGBImage_Label.minWidth = labelWidth1; // align with labels inside group boxes below
   this.sourceRGBImage_Label.text = "Source image:";
   this.sourceRGBImage_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.sourceRGBImage_ViewList = new ViewList( this );
   this.sourceRGBImage_ViewList.excludeIdentifiersPattern = "^NBRGBCombination*";
   this.sourceRGBImage_ViewList.getAll();
      this.sourceRGBImage_ViewList.scaledMinWidth = 200;
      this.sourceRGBImage_ViewList.toolTip = "Select the source RGB image.";
      this.sourceRGBImage_ViewList.onViewSelected = function( view ) {
         data.Changed=true;
         data.sourceRGBView = view;
         if (view.isNull) {
            data.sourceRGBControl.enabled = false;
         } else {
            data.sourceRGBControl.enabled = true;
         }
      };

   this.sourceRGBImage_Sizer = new HorizontalSizer;
   this.sourceRGBImage_Sizer.spacing = 4;
   this.sourceRGBImage_Sizer.add( this.sourceRGBImage_Label );
   this.sourceRGBImage_Sizer.add( this.sourceRGBImage_ViewList, 100 );

   data.sourceRGBControl = new NumericControl( this );
      data.sourceRGBControl.enabled = false;
      data.sourceRGBControl.setRange( 0, 200 );
      data.sourceRGBControl.label.text = "Bandwidth (nm):";
      data.sourceRGBControl.label.minWidth = labelWidth1;
      data.sourceRGBControl.slider.setRange( 0.0, 900.0 );
      data.sourceRGBControl.slider.scaledMinWidth = 200;
      data.sourceRGBControl.setPrecision (2);
      data.sourceRGBControl.setValue( data.sourceRGBBandwidth);
      data.sourceRGBControl.toolTip = "<p>RGB's total Bandwidth</p>";
      data.sourceRGBControl.onValueUpdated = function( value ) {
         data.Changed=true;
         data.sourceRGBBandwidth = value;
      };


   //---------------------------------------
   // NBr (eg Ha) selector and sliders

   this.sourceNBrImage_Label = new Label( this );
   this.sourceNBrImage_Label.minWidth = labelWidth1; // align with labels inside group boxes below
   this.sourceNBrImage_Label.text = "Source image:";
   this.sourceNBrImage_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.sourceNBrImage_ViewList = new ViewList( this );
   this.sourceNBrImage_ViewList.excludeIdentifiersPattern = "^NBRGBCombination*";
   this.sourceNBrImage_ViewList.getAll();
      this.sourceNBrImage_ViewList.scaledMinWidth = 200;
      this.sourceNBrImage_ViewList.toolTip = "Select the narrowband image to be merged with R (eg Ha).";
      this.sourceNBrImage_ViewList.onViewSelected = function( view ) {
         data.Changed=true;
         data.sourceNBrView = view;
         if (view.isNull) {
            data.sourceNBrControl.enabled = false;
            data.sourceNBrMultiplicationControl.enabled = false;
         } else {
            data.sourceNBrControl.enabled = true;
            data.sourceNBrMultiplicationControl.enabled = true;
         }
      }


   this.sourceNBrImage_Sizer = new HorizontalSizer;
   this.sourceNBrImage_Sizer.spacing = 4;
   this.sourceNBrImage_Sizer.add( this.sourceNBrImage_Label );
   this.sourceNBrImage_Sizer.add( this.sourceNBrImage_ViewList, 100 );

   data.sourceNBrControl = new NumericControl( this );
      data.sourceNBrControl.enabled = false;
      data.sourceNBrControl.setRange( 0.0, 100.0 );
      data.sourceNBrControl.label.text = "Bandwidth (nm):";
      data.sourceNBrControl.label.minWidth = labelWidth1;
      data.sourceNBrControl.slider.setRange( 0.0, 100.0 );
      data.sourceNBrControl.slider.scaledMinWidth = 200;
      data.sourceNBrControl.setPrecision (2);
      data.sourceNBrControl.setValue( data.sourceNBrBandwidth);
      data.sourceNBrControl.toolTip = "<p>Narrowband filter's bandwidth (nm).</p>";
      data.sourceNBrControl.onValueUpdated = function( value ) {
         data.Changed=true;
         data.sourceNBrBandwidth = value;
         console.writeln("DEBUG value=",value);
      };
   data.sourceNBrMultiplicationControl = new NumericControl( this );
      data.sourceNBrMultiplicationControl.enabled = false;
      data.sourceNBrMultiplicationControl.setRange( 0.0, 10.0 );
      data.sourceNBrMultiplicationControl.label.text = "Scale :";
      data.sourceNBrMultiplicationControl.label.minWidth = labelWidth1;
      data.sourceNBrMultiplicationControl.slider.setRange( 0.0, 100.0 );
      data.sourceNBrMultiplicationControl.slider.scaledMinWidth = 200;
      data.sourceNBrMultiplicationControl.setValue( data.sourceNBrMultiplication);
      data.sourceNBrMultiplicationControl.setPrecision (2);
      data.sourceNBrMultiplicationControl.toolTip = "<p>R channel's multiplication factor.</p>";
      data.sourceNBrMultiplicationControl.onValueUpdated = function( value ) {
         data.Changed=true;
         data.sourceNBrMultiplication = value;
      };


   //---------------------------------------
   // NBg (eg O3) selector and sliders

   this.sourceNBgImage_Label = new Label( this );
   this.sourceNBgImage_Label.minWidth = labelWidth1; // align with labels inside group boxes below
   this.sourceNBgImage_Label.text = "Source image:";
   this.sourceNBgImage_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.sourceNBgImage_ViewList = new ViewList( this );
   this.sourceNBgImage_ViewList.excludeIdentifiersPattern = "^NBRGBCombination*";
   this.sourceNBgImage_ViewList.getAll();
      this.sourceNBgImage_ViewList.scaledMinWidth = 200;
      this.sourceNBgImage_ViewList.toolTip = "Select the narrowband image to be merged with G (eg O3).";
      this.sourceNBgImage_ViewList.onViewSelected = function( view ) {
         data.Changed=true;
         data.sourceNBgView = view;
         if (view.isNull) {
            data.sourceNBgControl.enabled = false;
            data.sourceNBgMultiplicationControl.enabled = false;
         } else {
            data.sourceNBgControl.enabled = true;
            data.sourceNBgMultiplicationControl.enabled = true;
         }
      }

   this.sourceNBgImage_Sizer = new HorizontalSizer;
   this.sourceNBgImage_Sizer.spacing = 4;
   this.sourceNBgImage_Sizer.add( this.sourceNBgImage_Label );
   this.sourceNBgImage_Sizer.add( this.sourceNBgImage_ViewList, 100 );

   data.sourceNBgControl = new NumericControl( this );
      data.sourceNBgControl.enabled = false;
      data.sourceNBgControl.setRange( 0.0, 100.0 );
      data.sourceNBgControl.label.text = "Bandwidth (nm):";
      data.sourceNBgControl.label.minWidth = labelWidth1;
      data.sourceNBgControl.slider.setRange( 0.0, 100.0 );
      data.sourceNBgControl.slider.scaledMinWidth = 200;
      data.sourceNBgControl.setPrecision (2);
      data.sourceNBgControl.setValue( data.sourceNBgBandwidth);
      data.sourceNBgControl.toolTip = "<p>Narrowband filter's bandwidth (nm).</p>";
      data.sourceNBgControl.onValueUpdated = function( value ) {
         data.Changed=true;
         data.sourceNBgBandwidth = value;
      };
   data.sourceNBgMultiplicationControl = new NumericControl( this );
      data.sourceNBgMultiplicationControl.enabled = false;
      data.sourceNBgMultiplicationControl.setRange( 0.0, 10.0 );
      data.sourceNBgMultiplicationControl.label.text = "Scale:";
      data.sourceNBgMultiplicationControl.label.minWidth = labelWidth1;
      data.sourceNBgMultiplicationControl.slider.setRange( 0.0, 100.0 );
      data.sourceNBgMultiplicationControl.slider.scaledMinWidth = 200;
      data.sourceNBgMultiplicationControl.setValue( data.sourceNBgMultiplication);
      data.sourceNBgMultiplicationControl.setPrecision (2);
      data.sourceNBgMultiplicationControl.toolTip = "<p>G channel's multiplication factor.</p>";
      data.sourceNBgMultiplicationControl.onValueUpdated = function( value ) {
         data.Changed=true;
         data.sourceNBgMultiplication = value;
      };

   //---------------------------------------
   // NBb (eg O3) selector and sliders

   this.sourceNBbImage_Label = new Label( this );
   this.sourceNBbImage_Label.minWidth = labelWidth1; // align with labels inside group boxes below
   this.sourceNBbImage_Label.text = "Source image:";
   this.sourceNBbImage_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.sourceNBbImage_ViewList = new ViewList( this );
   this.sourceNBbImage_ViewList.excludeIdentifiersPattern = "^NBRGBCombination*";
   this.sourceNBbImage_ViewList.getAll();
      this.sourceNBbImage_ViewList.scaledMinWidth = 200;
      this.sourceNBbImage_ViewList.toolTip = "Select the narrowband image to be merged with B (eg O3).";
      this.sourceNBbImage_ViewList.onViewSelected = function( view ) {
         data.Changed=true;
         data.sourceNBbView = view;
         if (view.isNull) {
            data.sourceNBbControl.enabled = false;
            data.sourceNBbMultiplicationControl.enabled = false;
         } else {
            data.sourceNBbControl.enabled = true;
            data.sourceNBbMultiplicationControl.enabled = true;
         }

      }

   this.sourceNBbImage_Sizer = new HorizontalSizer;
   this.sourceNBbImage_Sizer.spacing = 4;
   this.sourceNBbImage_Sizer.add( this.sourceNBbImage_Label );
   this.sourceNBbImage_Sizer.add( this.sourceNBbImage_ViewList, 100 );

   data.sourceNBbControl = new NumericControl( this );
      data.sourceNBbControl.enabled = false;
      data.sourceNBbControl.setRange( 0.0, 100.0 );
      data.sourceNBbControl.label.text = "Bandwidth (nm):";
      data.sourceNBbControl.label.minWidth = labelWidth1;
      data.sourceNBbControl.slider.setRange( 0.0, 100.0 );
      data.sourceNBbControl.slider.scaledMinWidth = 200;
      data.sourceNBbControl.setPrecision (2);
      data.sourceNBbControl.setValue( data.sourceNBbBandwidth);
      data.sourceNBbControl.toolTip = "<p>Narrowband filter's bandwidth (nm).</p>";
      data.sourceNBbControl.onValueUpdated = function( value ) {
         data.Changed=true;
         data.sourceNBbBandwidth = value;
      };
   data.sourceNBbMultiplicationControl = new NumericControl( this );
      data.sourceNBbMultiplicationControl.enabled = false;
      data.sourceNBbMultiplicationControl.setRange( 0.0, 10.0 );
      data.sourceNBbMultiplicationControl.label.text = "Scale :";
      data.sourceNBbMultiplicationControl.label.minWidth = labelWidth1;
      data.sourceNBbMultiplicationControl.slider.setRange( 0.0, 100.0 );
      data.sourceNBbMultiplicationControl.slider.scaledMinWidth = 200;
      data.sourceNBbMultiplicationControl.setValue( data.sourceNBbMultiplication);
      data.sourceNBbMultiplicationControl.setPrecision (2);
      data.sourceNBbMultiplicationControl.toolTip = "<p>B channel's multiplication factor.</p>";
      data.sourceNBbMultiplicationControl.onValueUpdated = function( value ) {
         data.Changed=true;
         data.sourceNBbMultiplication = value;
      };



   // --------------- Arrange on Screen


   this.zoombuttonssizer = new VerticalSizer;
      this.zoombuttonssizer.margin = 0;
      this.zoombuttonssizer.spacing = 6;
      this.zoombuttonssizer.add( this.ZoomToFit_Button );
      this.zoombuttonssizer.add( this.fitWindow_Button );
      this.zoombuttonssizer.add( this.zoomToOptimalFit_Button );
      this.zoombuttonssizer.add( this.STF_CheckBox);
      this.zoombuttonssizer.add( this.STF_LinkCheckBox);
      this.zoombuttonssizer.add( this.Rescale_CheckBox);
      this.zoombuttonssizer.addStretch();


   this.showbuttonssizer = new VerticalSizer;
      this.showbuttonssizer.margin = 0;
      this.showbuttonssizer.spacing = 6;
      this.showbuttonssizer.add( this.showNBr_Button);
      this.showbuttonssizer.add( this.showNBg_Button);
      this.showbuttonssizer.add( this.showNBb_Button);
      this.showbuttonssizer.add( this.showRGB_Button);
      this.showbuttonssizer.add( this.showNBRGB_Button);
      this.showbuttonssizer.addStretch();

   this.PWButtonsSizer = new HorizontalSizer;
      this.PWButtonsSizer.margin = 0;
      this.PWButtonsSizer.spacing = 8;
      this.PWButtonsSizer.add( this.ScrollControl, 100 );
      this.PWButtonsSizer.add( this.showbuttonssizer );
      this.PWButtonsSizer.add( this.zoombuttonssizer );
      this.PWButtonsSizer.addStretch();


   this.RGBGroupBox = new GroupBox( this );
      this.RGBGroupBox.title = "RGB source Image";
      this.RGBGroupBox.sizer = new VerticalSizer;
      this.RGBGroupBox.sizer.margin = 6;
      this.RGBGroupBox.sizer.spacing = 6;
      this.RGBGroupBox.sizer.add( this.sourceRGBImage_Sizer);
      this.RGBGroupBox.sizer.add( data.sourceRGBControl );

   this.NBrGroupBox = new GroupBox( this );
      this.NBrGroupBox.title = "Narrowband for R channel (eg Ha)";
      this.NBrGroupBox.sizer = new VerticalSizer;
      this.NBrGroupBox.sizer.margin = 6;
      this.NBrGroupBox.sizer.spacing = 6;
      this.NBrGroupBox.sizer.add( this.sourceNBrImage_Sizer);
      this.NBrGroupBox.sizer.add( data.sourceNBrControl );
      this.NBrGroupBox.sizer.add( data.sourceNBrMultiplicationControl );


   this.NBgGroupBox = new GroupBox( this );
      this.NBgGroupBox.title = "Narrowband for G channel (eg O3)";
      this.NBgGroupBox.sizer = new VerticalSizer;
      this.NBgGroupBox.sizer.margin = 6;
      this.NBgGroupBox.sizer.spacing = 6;
      this.NBgGroupBox.sizer.add( this.sourceNBgImage_Sizer);
      this.NBgGroupBox.sizer.add( data.sourceNBgControl );
      this.NBgGroupBox.sizer.add( data.sourceNBgMultiplicationControl );

   this.NBbGroupBox = new GroupBox( this );
      this.NBbGroupBox.title = "Narrowband for B channel (eg O3)";
      this.NBbGroupBox.sizer = new VerticalSizer;
      this.NBbGroupBox.sizer.margin = 6;
      this.NBbGroupBox.sizer.spacing = 6;
      this.NBbGroupBox.sizer.add( this.sourceNBbImage_Sizer);
      this.NBbGroupBox.sizer.add( data.sourceNBbControl );
      this.NBbGroupBox.sizer.add( data.sourceNBbMultiplicationControl );


   // -------------OK,Apply,Cancel buttons
   this.buttons = new HorizontalSizer;
      this.buttons.spacing = 8;
      this.buttons.add( this.applyButton );
      this.buttons.addStretch();
      this.buttons.add( this.cancelButton );
      this.buttons.add( this.okButton );

   // channels and ok buttons
   this.tabsbuttons = new VerticalSizer;
      this.tabsbuttons.margin = 6;
      this.tabsbuttons.spacing = 6;
      this.tabsbuttons.addStretch();
      this.tabsbuttons.add( this.RGBGroupBox);
      this.tabsbuttons.add( this.NBrGroupBox );
      this.tabsbuttons.add( this.NBgGroupBox );
      this.tabsbuttons.add( this.NBbGroupBox );
      this.tabsbuttons.addSpacing( 8 );
      this.tabsbuttons.add( this.buttons);


   // all together
   this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 8;
      this.sizer.add( this.PWButtonsSizer );
      this.sizer.add( this.tabsbuttons );

   // window
   this.windowTitle = "NBRGB Combination Script";
   this.adjustToContents();
   this.setFixedSize();
}
}


var window = ImageWindow.activeWindow;
var data = new NBRGBCombinationData;

function main () {

   var dlg = new MyDialog;
   dlg.userResizable=false;
   console.hide();
   dlg.execute();
}

main();

// ----------------------------------------------------------------------------
// EOF NBRGBCombination.js - Released 2025-04-07T09:32:51Z
