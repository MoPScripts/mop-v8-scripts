#engine v8

////////////////////////////////////////////////////////////////////////////
//
// Create Synthetic Luminance from RGB
// V8 / PixInsight 1.9.4+ rebuild
//
// Extracts R, G, B channels from a color image into separate views
// Creates synthetic luminance with multiple methods and configuration options
//
// Features:
// - Multiple luminance calculation methods
// - Robust error handling and window tracking
// - User configuration dialog
// - Cleanup options
// - Working new instance icon support
// - Progress feedback
//
// Pete Proulx, Enhanced May 2025
// Masters of PixInsight V3.0 - V8 Rebuild
//
////////////////////////////////////////////////////////////////////////////

#define TITLE   "Create Synthetic Luminance from RGB - Masters of PixInsight"
#define VERSION "V8 Rebuild 2026-05-15"

#feature-id SyntheticLuminance : MoP V8> Create Synthetic Luminance from RGB
#feature-info RGB channel extraction with multiple luminance methods and configuration options - www.mastersofpixinsight.com

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ============================================================================
// Parameters
// ============================================================================

let P = {
   luminanceMethod:            1,                    // 0=Average, 1=Weighted, 2=Max, 3=Custom
   customWeights:              [ 0.3, 0.59, 0.11 ],  // Custom RGB weights
   extractIndividualChannels:  true,                 // Extract R, G, B channels
   createLuminance:            true,                 // Create synthetic luminance
   cleanupChannels:            true,                 // Close R,G,B after luminance creation
   customSuffix:               "",                   // Custom suffix for output names
   showProgress:               true,                 // Show progress messages

   save: function()
   {
      Parameters.set( "luminanceMethod",           this.luminanceMethod );
      Parameters.set( "customWeightR",             this.customWeights[0] );
      Parameters.set( "customWeightG",             this.customWeights[1] );
      Parameters.set( "customWeightB",             this.customWeights[2] );
      Parameters.set( "extractIndividualChannels", this.extractIndividualChannels );
      Parameters.set( "createLuminance",           this.createLuminance );
      Parameters.set( "cleanupChannels",           this.cleanupChannels );
      Parameters.set( "customSuffix",              this.customSuffix );
      Parameters.set( "showProgress",              this.showProgress );
   },

   load: function()
   {
      if ( Parameters.has( "luminanceMethod" ) )           this.luminanceMethod           = Parameters.getInteger( "luminanceMethod" );
      if ( Parameters.has( "customWeightR" ) )             this.customWeights[0]          = Parameters.getReal( "customWeightR" );
      if ( Parameters.has( "customWeightG" ) )             this.customWeights[1]          = Parameters.getReal( "customWeightG" );
      if ( Parameters.has( "customWeightB" ) )             this.customWeights[2]          = Parameters.getReal( "customWeightB" );
      if ( Parameters.has( "extractIndividualChannels" ) ) this.extractIndividualChannels = Parameters.getBoolean( "extractIndividualChannels" );
      if ( Parameters.has( "createLuminance" ) )           this.createLuminance           = Parameters.getBoolean( "createLuminance" );
      if ( Parameters.has( "cleanupChannels" ) )           this.cleanupChannels           = Parameters.getBoolean( "cleanupChannels" );
      if ( Parameters.has( "customSuffix" ) )              this.customSuffix              = Parameters.getString( "customSuffix" );
      if ( Parameters.has( "showProgress" ) )              this.showProgress              = Parameters.getBoolean( "showProgress" );
   }
};

// ============================================================================
// Progress Tracker
// ============================================================================

class ProgressTracker
{
   constructor( totalSteps )
   {
      this.total   = totalSteps;
      this.current = 0;
      this.errors  = [];
   }

   step( message )
   {
      this.current++;
      if ( P.showProgress )
      {
         let percent = Math.round( (this.current / this.total) * 100 );
         console.writeln( "📊 Progress [" + percent + "%] (" + this.current + "/" + this.total + ") " + message );
      }
   }

   addError( error )
   {
      this.errors.push( error );
      console.criticalln( "❌ ERROR: " + error );
   }

   hasErrors()
   {
      return this.errors.length > 0;
   }
}

// ============================================================================
// Processing functions
// ============================================================================

function extractChannelRobust( sourceWindow, channelIndex, channelName, progress )
{
   try
   {
      progress.step( "Extracting " + channelName + " channel" );

      // Snapshot existing window IDs before extraction
      let existingIds = {};
      for ( let win of ImageWindow.windows )
         existingIds[win.mainView.id] = true;

      // Set up channel extraction
      let CE = new ChannelExtraction;
      CE.colorSpace = ChannelExtraction.RGB;
      CE.channels = [
         [ channelIndex === 0, "" ],
         [ channelIndex === 1, "" ],
         [ channelIndex === 2, "" ]
      ];
      CE.sampleFormat = ChannelExtraction.SameAsSource;
      CE.executeOn( sourceWindow.mainView );

      // Find the newly created window
      let newWindow = null;
      for ( let win of ImageWindow.windows )
      {
         if ( !existingIds[win.mainView.id] )
         {
            newWindow = win;
            break;
         }
      }

      if ( newWindow )
      {
         let suffix = P.customSuffix ? "_" + P.customSuffix : "";
         let newId = sourceWindow.mainView.id + "_" + channelName + suffix;
         newWindow.mainView.id = newId;
         console.writeln( "✅ Created: " + newId );
         return newWindow;
      }
      else
      {
         throw new Error( "Could not identify newly created " + channelName + " channel window" );
      }
   }
   catch ( error )
   {
      progress.addError( "Failed to extract " + channelName + " channel: " + error.toString() );
      return null;
   }
}

function createSyntheticLuminance( redWindow, greenWindow, blueWindow, sourceWindow, progress )
{
   try
   {
      progress.step( "Creating synthetic luminance" );

      let pm = new PixelMath;
      let expression = "";
      let methodName = "";

      switch ( P.luminanceMethod )
      {
         case 0: // Simple Average
            expression = "(" + redWindow.mainView.id + " + " + greenWindow.mainView.id + " + " + blueWindow.mainView.id + ") / 3";
            methodName = "Average";
            break;

         case 1: // Weighted (standard luminance)
            expression = "0.3*" + redWindow.mainView.id + " + 0.59*" + greenWindow.mainView.id + " + 0.11*" + blueWindow.mainView.id;
            methodName = "Weighted";
            break;

         case 2: // Maximum
            expression = "max(max(" + redWindow.mainView.id + ", " + greenWindow.mainView.id + "), " + blueWindow.mainView.id + ")";
            methodName = "Maximum";
            break;

         case 3: // Custom weights
         {
            let r = P.customWeights[0];
            let g = P.customWeights[1];
            let b = P.customWeights[2];
            expression = r + "*" + redWindow.mainView.id + " + " + g + "*" + greenWindow.mainView.id + " + " + b + "*" + blueWindow.mainView.id;
            methodName = "Custom";
            break;
         }

         default:
            throw new Error( "Invalid luminance method: " + P.luminanceMethod );
      }

      console.writeln( "🔬 Using " + methodName + " method: " + expression );

      let suffix = P.customSuffix ? "_" + P.customSuffix : "";
      pm.expression           = expression;
      pm.useSingleExpression  = true;
      pm.generateOutput       = true;
      pm.createNewImage       = true;
      pm.newImageColorSpace   = PixelMath.Gray;
      pm.newImageSampleFormat = PixelMath.SameAsTarget;
      pm.newImageId           = sourceWindow.mainView.id + "_" + methodName + "Luminance" + suffix;
      pm.executeOn( redWindow.mainView, false );

      // Find the created luminance window
      let lumWindow = null;
      for ( let win of ImageWindow.windows )
      {
         if ( win.mainView.id === pm.newImageId )
         {
            lumWindow = win;
            break;
         }
      }

      if ( lumWindow )
      {
         console.writeln( "✅ Created synthetic luminance: " + lumWindow.mainView.id );
         return lumWindow;
      }
      else
      {
         throw new Error( "Could not find created luminance window" );
      }
   }
   catch ( error )
   {
      progress.addError( "Failed to create synthetic luminance: " + error.toString() );
      return null;
   }
}

function cleanupChannelWindows( redWindow, greenWindow, blueWindow, progress )
{
   if ( P.cleanupChannels )
   {
      progress.step( "Cleaning up individual channel windows" );
      let closedCount = 0;
      try
      {
         if ( redWindow   && !redWindow.isNull   ) { let id = redWindow.mainView.id;   redWindow.forceClose();   console.writeln( "🧹 Closed: " + id ); closedCount++; }
         if ( greenWindow && !greenWindow.isNull ) { let id = greenWindow.mainView.id; greenWindow.forceClose(); console.writeln( "🧹 Closed: " + id ); closedCount++; }
         if ( blueWindow  && !blueWindow.isNull  ) { let id = blueWindow.mainView.id;  blueWindow.forceClose();  console.writeln( "🧹 Closed: " + id ); closedCount++; }
         console.writeln( "🧹 Cleaned up " + closedCount + " channel window(s)" );
      }
      catch ( error )
      {
         console.warningln( "⚠️ Warning during cleanup: " + error.toString() );
      }
   }
}

// ============================================================================
// Configuration Dialog
// ============================================================================

class ConfigurationDialog extends Dialog
{
   constructor()
   {
      super();

      this.windowTitle = "Create Synthetic Luminance from RGB - Masters of PixInsight";
      this.minWidth    = 550;
      this.minHeight   = 780;

      // ---- Title ----
      this.titleLabel = new Label( this );
      this.titleLabel.text          = "Create Synthetic Luminance from RGB";
      this.titleLabel.textAlignment = TextAlignment.Center;
      this.titleLabel.styleSheet    = "font-weight: bold; font-size: 16px; padding: 8px;";

      this.websiteLabel = new Label( this );
      this.websiteLabel.text          = "www.mastersofpixinsight.com";
      this.websiteLabel.textAlignment = TextAlignment.Center;
      this.websiteLabel.styleSheet    = "font-size: 12px; padding: 4px;";

      // ---- Instructions ----
      this.instructionsGroupBox = new GroupBox( this );
      this.instructionsGroupBox.title         = "📋 How This Script Works";
      this.instructionsGroupBox.titleCheckBox = false;

      this.instructionsText = new Label( this );
      this.instructionsText.text =
         "Create high-quality synthetic luminance from RGB color images:\n\n" +
         "• Select your RGB color image from the dropdown below\n" +
         "• Choose your preferred luminance calculation method\n" +
         "• Script extracts R, G, B channels into separate grayscale views\n" +
         "• Combines channels using your selected method to create synthetic luminance\n" +
         "• Optionally cleans up individual channels to keep workspace organized\n\n" +
         "Why Use Synthetic Luminance?\n" +
         "• Creates detailed luminance data from RGB color information\n" +
         "• Essential for LRGB workflows when you don't have dedicated L data\n" +
         "• Provides high-resolution detail layer for final image processing\n" +
         "• Multiple calculation methods for different imaging scenarios\n\n" +
         "💡 Recommended: Use 'Weighted' method for most astrophotography applications\n" +
         "💡 Tip: Keep individual channels if you plan further color processing";
      this.instructionsText.wordWrap      = true;
      this.instructionsText.textAlignment = TextAlignment.Left;
      this.instructionsText.styleSheet    = "line-height: 1.4; padding: 8px;";

      let instructionsSizer = new VerticalSizer;
      instructionsSizer.margin = 8;
      instructionsSizer.add( this.instructionsText );
      this.instructionsGroupBox.sizer = instructionsSizer;

      // ---- Image Selection ----
      this.viewSelectionGroupBox = new GroupBox( this );
      this.viewSelectionGroupBox.title         = "🖼️ Image Selection";
      this.viewSelectionGroupBox.titleCheckBox = false;

      let viewSelectionSizer = new VerticalSizer;
      viewSelectionSizer.margin  = 8;
      viewSelectionSizer.spacing = 6;

      let viewSizer = new HorizontalSizer;
      viewSizer.spacing = 6;

      this.viewLabel = new Label( this );
      this.viewLabel.text          = "Source RGB Image:";
      this.viewLabel.setFixedWidth( 120 );
      this.viewLabel.styleSheet    = "font-weight: bold;";

      this.viewComboBox = new ComboBox( this );
      this.viewComboBox.setFixedWidth( 350 );
      this.viewComboBox.toolTip = "Select the RGB color image to process for synthetic luminance creation";
      this.viewComboBox.onItemSelected = () =>
      {
         this.updateViewInfo();
         this.updateOkButtonState();
      };

      viewSizer.add( this.viewLabel );
      viewSizer.add( this.viewComboBox );
      viewSizer.addStretch();

      this.viewInfoLabel = new Label( this );
      this.viewInfoLabel.text      = "Select an RGB color image from the dropdown above";
      this.viewInfoLabel.styleSheet = "font-style: italic; font-size: 11px;";

      viewSelectionSizer.add( viewSizer );
      viewSelectionSizer.add( this.viewInfoLabel );
      this.viewSelectionGroupBox.sizer = viewSelectionSizer;

      // ---- Extraction Options ----
      this.extractionGroupBox = new GroupBox( this );
      this.extractionGroupBox.title         = "⚙️ Extraction Options";
      this.extractionGroupBox.titleCheckBox = false;

      this.extractChannelsCheckBox = new CheckBox( this );
      this.extractChannelsCheckBox.text      = "Extract individual R, G, B channels";
      this.extractChannelsCheckBox.checked   = P.extractIndividualChannels;
      this.extractChannelsCheckBox.toolTip   =
         "Create separate grayscale windows for Red, Green, and Blue channels.\n\n" +
         "• Required for luminance creation\n" +
         "• Useful for individual channel processing\n" +
         "• Creates: ImageName_R, ImageName_G, ImageName_B";
      this.extractChannelsCheckBox.styleSheet = "font-weight: bold;";

      this.createLuminanceCheckBox = new CheckBox( this );
      this.createLuminanceCheckBox.text      = "Create synthetic luminance";
      this.createLuminanceCheckBox.checked   = P.createLuminance;
      this.createLuminanceCheckBox.toolTip   =
         "Combine R, G, B channels into a synthetic luminance image.\n\n" +
         "• Uses selected calculation method above\n" +
         "• Creates high-quality grayscale luminance\n" +
         "• Essential for LRGB processing workflows";
      this.createLuminanceCheckBox.styleSheet = "font-weight: bold;";

      this.cleanupCheckBox = new CheckBox( this );
      this.cleanupCheckBox.text      = "Close individual channels after luminance creation";
      this.cleanupCheckBox.checked   = P.cleanupChannels;
      this.cleanupCheckBox.toolTip   =
         "Automatically close R, G, B channel windows after creating luminance.\n\n" +
         "• Keeps workspace clean and organized\n" +
         "• Default: Enabled for cleaner workflow\n" +
         "• Uncheck to keep individual channels open for further processing";
      this.cleanupCheckBox.styleSheet = "font-weight: bold;";

      let extractionSizer = new VerticalSizer;
      extractionSizer.margin  = 8;
      extractionSizer.spacing = 6;
      extractionSizer.add( this.extractChannelsCheckBox );
      extractionSizer.add( this.createLuminanceCheckBox );
      extractionSizer.add( this.cleanupCheckBox );
      this.extractionGroupBox.sizer = extractionSizer;

      // ---- Luminance Method ----
      this.methodGroupBox = new GroupBox( this );
      this.methodGroupBox.title         = "🔬 Luminance Calculation Method";
      this.methodGroupBox.titleCheckBox = false;

      this.averageRadio = new RadioButton( this );
      this.averageRadio.text      = "Simple Average: (R + G + B) / 3";
      this.averageRadio.checked   = P.luminanceMethod === 0;
      this.averageRadio.toolTip   =
         "Simple equal weighting of all channels.\n\n" +
         "• Treats R, G, B channels equally\n" +
         "• Quick and basic luminance calculation\n" +
         "• Good for: Testing and basic applications\n" +
         "• Limitation: Doesn't account for human eye sensitivity";
      this.averageRadio.styleSheet = "font-weight: bold;";

      this.weightedRadio = new RadioButton( this );
      this.weightedRadio.text      = "Weighted: 0.3×R + 0.59×G + 0.11×B (recommended)";
      this.weightedRadio.checked   = P.luminanceMethod === 1;
      this.weightedRadio.toolTip   =
         "Photometrically accurate luminance (CIE Y component).\n\n" +
         "• Based on human eye sensitivity to different colors\n" +
         "• Green gets highest weight (0.59) - eyes most sensitive\n" +
         "• Red gets medium weight (0.30)\n" +
         "• Blue gets lowest weight (0.11) - eyes least sensitive\n" +
         "• Industry standard for digital imaging and astronomy\n" +
         "• Best choice for: Most astrophotography applications";
      this.weightedRadio.styleSheet = "font-weight: bold;";

      this.maximumRadio = new RadioButton( this );
      this.maximumRadio.text      = "Maximum: max(R, G, B)";
      this.maximumRadio.checked   = P.luminanceMethod === 2;
      this.maximumRadio.toolTip   =
         "Uses the brightest channel value at each pixel.\n\n" +
         "• Preserves maximum signal from any color channel\n" +
         "• Captures brightest details across all channels\n" +
         "• Good for: Maximizing detail preservation\n" +
         "• Use case: When you want to retain peak brightness\n" +
         "• Note: May not be perceptually accurate";
      this.maximumRadio.styleSheet = "font-weight: bold;";

      this.customRadio = new RadioButton( this );
      this.customRadio.text      = "Custom weights:";
      this.customRadio.checked   = P.luminanceMethod === 3;
      this.customRadio.toolTip   =
         "User-defined RGB coefficients for specialized applications.\n\n" +
         "• Specify your own R, G, B weighting factors\n" +
         "• Good for: Narrowband imaging with custom filters\n" +
         "• Use case: Emphasizing specific spectral regions\n" +
         "• Advanced: When standard weights don't suit your data\n" +
         "• Note: Weights should typically sum to ~1.0";
      this.customRadio.styleSheet = "font-weight: bold;";

      // Custom weight controls
      this.customWeightsLabel = new Label( this );
      this.customWeightsLabel.text     = "R:";
      this.customWeightsLabel.minWidth = 20;

      this.redWeightEdit = new Edit( this );
      this.redWeightEdit.text     = P.customWeights[0].toString();
      this.redWeightEdit.minWidth = 60;
      this.redWeightEdit.toolTip  = "Red channel weight (typically 0.2-0.4)";

      this.greenWeightLabel = new Label( this );
      this.greenWeightLabel.text     = "G:";
      this.greenWeightLabel.minWidth = 20;

      this.greenWeightEdit = new Edit( this );
      this.greenWeightEdit.text     = P.customWeights[1].toString();
      this.greenWeightEdit.minWidth = 60;
      this.greenWeightEdit.toolTip  = "Green channel weight (typically 0.5-0.7)";

      this.blueWeightLabel = new Label( this );
      this.blueWeightLabel.text     = "B:";
      this.blueWeightLabel.minWidth = 20;

      this.blueWeightEdit = new Edit( this );
      this.blueWeightEdit.text     = P.customWeights[2].toString();
      this.blueWeightEdit.minWidth = 60;
      this.blueWeightEdit.toolTip  = "Blue channel weight (typically 0.1-0.2)";

      let customWeightsSizer = new HorizontalSizer;
      customWeightsSizer.margin  = 0;
      customWeightsSizer.spacing = 4;
      customWeightsSizer.addSpacing( 20 );
      customWeightsSizer.add( this.customWeightsLabel );
      customWeightsSizer.add( this.redWeightEdit );
      customWeightsSizer.add( this.greenWeightLabel );
      customWeightsSizer.add( this.greenWeightEdit );
      customWeightsSizer.add( this.blueWeightLabel );
      customWeightsSizer.add( this.blueWeightEdit );
      customWeightsSizer.addStretch();

      let methodSizer = new VerticalSizer;
      methodSizer.margin  = 8;
      methodSizer.spacing = 6;
      methodSizer.add( this.averageRadio );
      methodSizer.add( this.weightedRadio );
      methodSizer.add( this.maximumRadio );
      methodSizer.add( this.customRadio );
      methodSizer.add( customWeightsSizer );
      this.methodGroupBox.sizer = methodSizer;

      // ---- Output Options ----
      this.outputGroupBox = new GroupBox( this );
      this.outputGroupBox.title         = "📁 Output Options";
      this.outputGroupBox.titleCheckBox = false;

      this.suffixLabel = new Label( this );
      this.suffixLabel.text      = "Custom suffix for output names:";
      this.suffixLabel.styleSheet = "font-weight: bold;";

      let suffixInputSizer = new HorizontalSizer;
      suffixInputSizer.spacing = 6;

      this.suffixEdit = new Edit( this );
      this.suffixEdit.text         = P.customSuffix;
      this.suffixEdit.setFixedWidth( 200 );
      this.suffixEdit.toolTip      =
         "Optional suffix to add to output image names.\n\n" +
         "Valid characters: A-Z, a-z, 0-9, underscore (_)\n" +
         "Examples: v1, test, my_version, final_2024\n" +
         "Invalid: spaces, hyphens, special characters";
      this.suffixEdit.onTextUpdated = () => { this.updateSuffixValidation(); };

      this.suffixStatusLabel = new Label( this );
      this.suffixStatusLabel.text     = "";
      this.suffixStatusLabel.setMinWidth( 250 );

      suffixInputSizer.add( this.suffixEdit );
      suffixInputSizer.add( this.suffixStatusLabel );
      suffixInputSizer.addStretch();

      this.progressCheckBox = new CheckBox( this );
      this.progressCheckBox.text      = "Show detailed progress messages";
      this.progressCheckBox.checked   = P.showProgress;
      this.progressCheckBox.toolTip   = "Display step-by-step progress in the console during processing";
      this.progressCheckBox.styleSheet = "font-weight: bold;";

      let outputSizer = new VerticalSizer;
      outputSizer.margin  = 8;
      outputSizer.spacing = 6;
      outputSizer.add( this.suffixLabel );
      outputSizer.add( suffixInputSizer );
      outputSizer.add( this.progressCheckBox );
      this.outputGroupBox.sizer = outputSizer;

      // ---- Buttons ----
      this.newInstanceButton = new ToolButton( this );
      this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
      this.newInstanceButton.setScaledFixedSize( 24, 24 );
      this.newInstanceButton.toolTip      = "Create Process Icon - Drag to save current settings";
      this.newInstanceButton.onMousePress = () =>
      {
         this.hasFocus = true;
         this.pushed   = false;
         this.updateParameters();
         this.newInstance();
      };

      this.okButton = new PushButton( this );
      this.okButton.text          = "🚀 Process Image";
      this.okButton.icon          = this.scaledResource( ":/icons/ok.png" );
      this.okButton.defaultButton = true;
      this.okButton.styleSheet    = "font-weight: bold; padding: 8px 16px;";
      this.okButton.onClick       = () => { this.ok(); };

      this.cancelButton = new PushButton( this );
      this.cancelButton.text    = "Cancel";
      this.cancelButton.icon    = this.scaledResource( ":/icons/cancel.png" );
      this.cancelButton.onClick = () => { this.cancel(); };

      let buttonsSizer = new HorizontalSizer;
      buttonsSizer.spacing = 8;
      buttonsSizer.add( this.newInstanceButton );
      buttonsSizer.addStretch();
      buttonsSizer.add( this.okButton );
      buttonsSizer.add( this.cancelButton );

      // ---- Main layout ----
      this.sizer = new VerticalSizer;
      this.sizer.margin  = 12;
      this.sizer.spacing = 8;
      this.sizer.add( this.titleLabel );
      this.sizer.add( this.websiteLabel );
      this.sizer.add( this.instructionsGroupBox );
      this.sizer.add( this.viewSelectionGroupBox );
      this.sizer.add( this.extractionGroupBox );
      this.sizer.add( this.methodGroupBox );
      this.sizer.add( this.outputGroupBox );
      this.sizer.add( buttonsSizer );

      // ---- Initialize ----
      this.populateViewSelection();
      this.updateDialog();
      this.updateOkButtonState();
      this.adjustToContents();
   }

   // --------------------------------------------------------------------------

   validateSuffix( suffix )
   {
      if ( !suffix || suffix.trim() === "" )
         return { valid: true, message: "✅ No suffix (optional)" };

      let trimmed = suffix.trim();

      if ( trimmed.length > 30 )
         return { valid: false, message: "❌ Too long (max 30 characters)" };

      if ( /^[0-9]/.test( trimmed ) )
         return { valid: false, message: "❌ Cannot start with number" };

      if ( !/^[A-Za-z_][A-Za-z0-9_]*$/.test( trimmed ) )
      {
         let invalidChars = trimmed.match( /[^A-Za-z0-9_]/g );
         if ( invalidChars )
         {
            let unique = [ ...new Set( invalidChars.map( c => c === ' ' ? 'space' : c ) ) ];
            return { valid: false, message: "❌ Invalid: " + unique.join( ", " ) + " (use A-Z, 0-9, _)" };
         }
      }

      return { valid: true, message: "✅ Valid suffix" };
   }

   updateSuffixValidation()
   {
      let validation = this.validateSuffix( this.suffixEdit.text );
      this.suffixStatusLabel.text = validation.message;

      if ( validation.valid )
      {
         this.suffixStatusLabel.styleSheet = "color: #006600; font-size: 11px;";
         this.suffixEdit.styleSheet        = "";
      }
      else
      {
         this.suffixStatusLabel.styleSheet = "color: #cc0000; font-size: 11px;";
         this.suffixEdit.styleSheet        = "border: 1px solid #cc0000;";
      }

      this.updateOkButtonState();
      return validation.valid;
   }

   updateOkButtonState()
   {
      let suffixValid  = this.validateSuffix( this.suffixEdit.text ).valid;
      let viewSelected = this.getSelectedWindow() !== null;

      this.okButton.enabled = suffixValid && viewSelected;

      if ( !suffixValid )
         this.okButton.toolTip = "Fix the custom suffix validation error before processing";
      else if ( !viewSelected )
         this.okButton.toolTip = "Select a valid RGB image before processing";
      else
         this.okButton.toolTip = "Process the selected RGB image to create synthetic luminance";
   }

   populateViewSelection()
   {
      this.viewComboBox.clear();

      let rgbViews    = [];
      let otherViews  = [];
      let activeWindow = ImageWindow.activeWindow;
      let currentViewIndex = -1;

      for ( let win of ImageWindow.windows )
      {
         let viewId  = win.mainView.id;
         let isColor = win.mainView.image.isColor;

         if ( isColor )
         {
            rgbViews.push( { id: viewId, window: win } );
            if ( activeWindow && !activeWindow.isNull && win.mainView.id === activeWindow.mainView.id )
               currentViewIndex = rgbViews.length - 1;
         }
         else
         {
            otherViews.push( { id: viewId, window: win } );
         }
      }

      for ( let v of rgbViews )
         this.viewComboBox.addItem( "✅ " + v.id + " (RGB)" );

      if ( rgbViews.length > 0 && otherViews.length > 0 )
         this.viewComboBox.addItem( "────────────────────────" );

      for ( let v of otherViews )
         this.viewComboBox.addItem( "⚠️ " + v.id + " (Grayscale - Not suitable)" );

      if ( currentViewIndex >= 0 )
      {
         this.viewComboBox.currentItem = currentViewIndex;
         this.updateViewInfo();
      }
      else if ( rgbViews.length > 0 )
      {
         this.viewComboBox.currentItem = 0;
         this.updateViewInfo();
      }
      else
      {
         this.viewInfoLabel.text       = "⚠️ No RGB color images found. Please open an RGB image first.";
         this.viewInfoLabel.styleSheet = "color: #cc6600; font-style: italic; font-size: 11px;";
      }
   }

   updateViewInfo()
   {
      let selectedText = this.viewComboBox.itemText( this.viewComboBox.currentItem );

      if ( selectedText.indexOf( "✅" ) === 0 )
      {
         let viewId = selectedText.replace( "✅ ", "" ).replace( " (RGB)", "" );
         let view   = View.viewById( viewId );
         if ( !view.isNull )
         {
            let image = view.image;
            this.viewInfoLabel.text =
               "✅ RGB Image • " + image.width + "×" + image.height +
               " pixels • " + image.numberOfChannels + " channels • Ready for processing";
            this.viewInfoLabel.styleSheet = "color: #006600; font-style: italic; font-size: 11px;";
         }
      }
      else if ( selectedText.indexOf( "⚠️" ) === 0 )
      {
         this.viewInfoLabel.text       = "⚠️ Grayscale images cannot be used for RGB channel extraction";
         this.viewInfoLabel.styleSheet = "color: #cc6600; font-style: italic; font-size: 11px;";
      }
      else if ( selectedText.indexOf( "────" ) === 0 )
      {
         // Skip separator — move to nearest valid item
         if ( this.viewComboBox.currentItem > 0 )
            this.viewComboBox.currentItem = this.viewComboBox.currentItem - 1;
         else
            this.viewComboBox.currentItem = this.viewComboBox.currentItem + 1;
         this.updateViewInfo();
      }
   }

   getSelectedWindow()
   {
      let selectedText = this.viewComboBox.itemText( this.viewComboBox.currentItem );
      if ( selectedText.indexOf( "✅" ) === 0 )
      {
         let viewId = selectedText.replace( "✅ ", "" ).replace( " (RGB)", "" );
         let view   = View.viewById( viewId );
         return view.isNull ? null : view.window;
      }
      return null;
   }

   updateDialog()
   {
      this.extractChannelsCheckBox.checked = P.extractIndividualChannels;
      this.createLuminanceCheckBox.checked = P.createLuminance;
      this.cleanupCheckBox.checked         = P.cleanupChannels;

      this.averageRadio.checked  = P.luminanceMethod === 0;
      this.weightedRadio.checked = P.luminanceMethod === 1;
      this.maximumRadio.checked  = P.luminanceMethod === 2;
      this.customRadio.checked   = P.luminanceMethod === 3;

      this.redWeightEdit.text   = P.customWeights[0].toString();
      this.greenWeightEdit.text = P.customWeights[1].toString();
      this.blueWeightEdit.text  = P.customWeights[2].toString();

      this.suffixEdit.text           = P.customSuffix;
      this.progressCheckBox.checked  = P.showProgress;

      this.updateSuffixValidation();
   }

   updateParameters()
   {
      P.extractIndividualChannels = this.extractChannelsCheckBox.checked;
      P.createLuminance           = this.createLuminanceCheckBox.checked;
      P.cleanupChannels           = this.cleanupCheckBox.checked;

      if      ( this.averageRadio.checked  ) P.luminanceMethod = 0;
      else if ( this.weightedRadio.checked ) P.luminanceMethod = 1;
      else if ( this.maximumRadio.checked  ) P.luminanceMethod = 2;
      else if ( this.customRadio.checked   ) P.luminanceMethod = 3;

      try
      {
         P.customWeights[0] = parseFloat( this.redWeightEdit.text );
         P.customWeights[1] = parseFloat( this.greenWeightEdit.text );
         P.customWeights[2] = parseFloat( this.blueWeightEdit.text );
      }
      catch ( e )
      {
         console.warningln( "⚠️ Invalid custom weights, using defaults" );
         P.customWeights = [ 0.3, 0.59, 0.11 ];
      }

      let suffixValidation = this.validateSuffix( this.suffixEdit.text );
      if ( suffixValidation.valid )
         P.customSuffix = this.suffixEdit.text.trim();
      else
      {
         console.warningln( "⚠️ Invalid suffix rejected, using empty suffix" );
         P.customSuffix = "";
      }

      P.showProgress = this.progressCheckBox.checked;

      P.save();
   }
}

// ============================================================================
// Processing
// ============================================================================

function processImage( selectedWindow )
{
   console.show();

   if ( ImageWindow.windows.length === 0 )
      return {
         success: false,
         error:   "No Images Open",
         message: "No images are currently open in PixInsight.\n\n" +
                  "To fix this:\n" +
                  "• Open an RGB color image first\n" +
                  "• The dialog will refresh to show available images\n" +
                  "• Select your RGB image and try again"
      };

   if ( !selectedWindow || selectedWindow.isNull )
      return {
         success: false,
         error:   "No Image Selected",
         message: "Please select a valid RGB color image from the dropdown.\n\n" +
                  "To fix this:\n" +
                  "• Choose an RGB image from the 'Source RGB Image' dropdown\n" +
                  "• Make sure the selected image shows '✅ (RGB)' indicator\n" +
                  "• Grayscale images cannot be used for this process"
      };

   if ( !selectedWindow.mainView.image.isColor )
      return {
         success: false,
         error:   "Not an RGB Image",
         message: "The selected image '" + selectedWindow.mainView.id + "' is not a color image.\n\n" +
                  "This script requires an RGB color image to extract channels and create luminance.\n\n" +
                  "To fix this:\n" +
                  "• Select a different image from the dropdown that shows '✅ (RGB)'\n" +
                  "• Make sure the image has Red, Green, and Blue channels\n" +
                  "• Grayscale images cannot be used for this process"
      };

   let totalSteps = 0;
   if ( P.extractIndividualChannels ) totalSteps += 3;
   if ( P.createLuminance           ) totalSteps += 1;
   if ( P.cleanupChannels           ) totalSteps += 1;

   let progress = new ProgressTracker( totalSteps );

   console.writeln( "═══════════════════════════════════════" );
   console.writeln( "SYNTHETIC LUMINANCE CREATION STARTED - MASTERS OF PIXINSIGHT" );
   console.writeln( "═══════════════════════════════════════" );
   console.writeln( "Source image:      " + selectedWindow.mainView.id );
   console.writeln( "Extract channels:  " + P.extractIndividualChannels );
   console.writeln( "Create luminance:  " + P.createLuminance );
   console.writeln( "Cleanup channels:  " + P.cleanupChannels );
   if ( P.customSuffix ) console.writeln( "Custom suffix: " + P.customSuffix );
   console.writeln( "───────────────────────────────────────" );

   let redWindow       = null;
   let greenWindow     = null;
   let blueWindow      = null;
   let luminanceWindow = null;

   try
   {
      if ( P.extractIndividualChannels )
      {
         redWindow   = extractChannelRobust( selectedWindow, 0, "R", progress );
         greenWindow = extractChannelRobust( selectedWindow, 1, "G", progress );
         blueWindow  = extractChannelRobust( selectedWindow, 2, "B", progress );

         if ( !redWindow || !greenWindow || !blueWindow )
            throw new Error( "Failed to extract one or more channels" );

         console.writeln( "───────────────────────────────────────" );
         console.writeln( "✅ Channel extraction completed!" );
         console.writeln( "  Red:   " + redWindow.mainView.id );
         console.writeln( "  Green: " + greenWindow.mainView.id );
         console.writeln( "  Blue:  " + blueWindow.mainView.id );
      }

      if ( P.createLuminance )
      {
         if ( !redWindow || !greenWindow || !blueWindow )
            throw new Error( "Cannot create luminance without extracted channels" );

         luminanceWindow = createSyntheticLuminance( redWindow, greenWindow, blueWindow, selectedWindow, progress );

         if ( !luminanceWindow )
            throw new Error( "Failed to create synthetic luminance" );
      }

      if ( P.cleanupChannels && P.createLuminance )
         cleanupChannelWindows( redWindow, greenWindow, blueWindow, progress );

      console.writeln( "───────────────────────────────────────" );
      console.writeln( "✅ PROCESSING COMPLETED SUCCESSFULLY!" );
      console.writeln( "───────────────────────────────────────" );
      console.writeln( "📊 Results:" );
      if ( P.extractIndividualChannels && !P.cleanupChannels )
      {
         if ( redWindow   ) console.writeln( "  Red channel:   " + redWindow.mainView.id );
         if ( greenWindow ) console.writeln( "  Green channel: " + greenWindow.mainView.id );
         if ( blueWindow  ) console.writeln( "  Blue channel:  " + blueWindow.mainView.id );
      }
      if ( luminanceWindow )
      {
         console.writeln( "  🌟 Synthetic luminance: " + luminanceWindow.mainView.id );
         luminanceWindow.show();
         luminanceWindow.zoomToFit();
      }
      console.writeln( "═══════════════════════════════════════" );

      return { success: true };
   }
   catch ( error )
   {
      progress.addError( "Processing failed: " + error.toString() );

      console.criticalln( "───────────────────────────────────────" );
      console.criticalln( "❌ PROCESSING FAILED!" );
      if ( progress.hasErrors() )
      {
         console.criticalln( "Errors encountered:" );
         for ( let e of progress.errors )
            console.criticalln( "  • " + e );
      }
      console.criticalln( "───────────────────────────────────────" );
      console.criticalln( "💡 Partial results may be available:" );
      if ( redWindow   ) console.criticalln( "  Red channel:   " + redWindow.mainView.id );
      if ( greenWindow ) console.criticalln( "  Green channel: " + greenWindow.mainView.id );
      if ( blueWindow  ) console.criticalln( "  Blue channel:  " + blueWindow.mainView.id );
      console.criticalln( "═══════════════════════════════════════" );

      return {
         success: false,
         error:   "Processing Error",
         message: "An error occurred during processing:\n\n" + error.toString() +
                  "\n\nCheck the console for detailed information."
      };
   }
}

// ============================================================================
// Main
// ============================================================================

function main()
{
   P.load();

   while ( true )
   {
      let dialog = new ConfigurationDialog();

      if ( dialog.execute() )
      {
         dialog.updateParameters();

         let selectedWindow = dialog.getSelectedWindow();
         let result         = processImage( selectedWindow );

         if ( result.success )
            break;

         // On failure, loop back to dialog
         console.writeln( "════════════════════════════════════════" );
         console.writeln( "PROCESSING ERROR - MASTERS OF PIXINSIGHT" );
         console.writeln( "════════════════════════════════════════" );
         console.writeln( result.message );
         console.writeln( "════════════════════════════════════════" );
      }
      else
      {
         console.writeln( "Operation cancelled by user." );
         break;
      }
   }
}

main();
