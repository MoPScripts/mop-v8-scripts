#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/*
 ****************************************************************************
 * Foraxx Palette Utility
 *
 * ForaxxPalette.js
 * Copyright (C) 2024, Paul Hancock
 *
 * This script provides an environment within which to create a Foraxx Palette
 * image. The script expects stretched starless images along with stretched
 * images of the stars.
 *
 * If you have gathered Sii, Ha and Oiii data then simply provide the script
 * with the corresponding stretched starless and star images in the drop
 * down menus.
 *
 * If you have only gathered Ha and Oiii (eihter via mono imaging or OSC with
 * a dual narrowband filter), then provide the script with the starless Ha and Oiii
 * along with the corresponding starless images, leaving the Sii drop down menus
 * blank.
 *
 * The script will produce the relevant dynamic pixelmath intermediary images. It will
 * then run the appropriate Foraxx expressions depending on the number of filters used.
 *
 * Once Complete, you will have a final Foraxx image along with the colour stars image,
 * named Foraxx and Foraxx_stars respectively.
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 1.0     2023-01-13 first release v1 (Didn't go so well).
 * 1.01    2023-01-14 Hopefully fixed the web host bugs.
 * 1.15    2023-08-19 PI 1.8.9-2 ready.
 * 1.16    2024-12-23 PI 1.9 ready.

 ****************************************************************************
 */

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Roger Pettengell / Paul Hancock.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; inlined all lib/
// files into a single self-contained script; converted ForaxxDialog from
// __base__/prototype to class extends Dialog; expanded all with() statements;
// replaced all .prototype. enum references and underscore constants to dot
// notation.
// ----------------------------------------------------------------------------

#feature-id    ForaxxPalette : MoP V8 > ForaxxPalette
#feature-info  This script provides an environment within which to create a Foraxx Palette \
#define TITLE "Foraxx Palette Utility"
#define VERSION "1.15"
#define BUILD "202412230651"

// ============================================================================
// lib/PixelMathConstructor.js (inlined)
// ============================================================================
/*
 * *****************************************************************************
 *
 * PixelMath Expressions to create Foraxx Image
 * This dialog forms part of the ForaxxPalette.js
 * Version 1.0
 *
 * Copyright (C) 2023 Paul Hancock
 *
 * *****************************************************************************
 */

function PixelMathConstructor(baseimage,newid,type,r,g,b) {
   var P = new PixelMath;
   P.expression = r;
   P.expression1 = g;
   P.expression2 = b;
   P.expression3 = "";
   P.symbols = "";
   P.clearImageCacheAndExit = false;
   P.cacheGeneratedImages = false;
   P.generateOutput = true;
   P.singleThreaded = false;
   P.optimization = true;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = true;
   P.showNewImage = true;
   P.newImageId = newid;
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   if (type == "rgb") {
       P.newImageColorSpace = PixelMath.RGB;
       P.useSingleExpression = false;
   } else {
       P.newImageColorSpace = PixelMath.Gray;
       P.useSingleExpression = true;
   }
   P.newImageSampleFormat = PixelMath.SameAsTarget;
   P.executeOn(baseimage);
}

// ============================================================================
// lib/ImageConstructor.js (inlined)
// ============================================================================
/*
 * *****************************************************************************
 *
 * Constructor for the Foraxx Image
 * This dialog forms part of the ForaxxPalette.js
 * Version 1.0
 *
 * Copyright (C) 2023 Paul Hancock
 *
 * *****************************************************************************
 */

function ImageConstruction()
{
   if (ForaxxParameters.buttonLogic == "0" || ForaxxParameters.buttonLogic == "1")
   {

      var ha = ForaxxParameters.haView.id;
      var oiii = ForaxxParameters.oiiiView.id;
      var hoString = "(" + ha + "*" + oiii + ")^~(" + ha + "*" + oiii + ")";
      var rString = ha;
      var gString = "";
      var bString = oiii;
      var rString_stars = "";
      var gString_stars = "";
      var bString_stars = "";

      Console.writeln("Creating the 'HO' Dynamic PixelMath Factor ...");
      PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.hoFactorView, "gray", hoString, gString, bString);
      Console.noteln("'HO' Dynamic PixelMath Factor created...");

      if (ForaxxParameters.buttonLogic == "1")
      {
         gString = "(" + hoString + ")" + "*" + ha + "+ ~(" + hoString + ")" + "*" + oiii;
         Console.writeln("Creating the Foraxx Image ...");
         PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.foraxxView, "rgb", rString, gString, bString);
         Console.noteln("Foraxx Image created...")
         Console.writeln("Completing Curves Adjustments ...")
         CurvesAdjustments1();
         CurvesAdjustments2();
         SelectiveSaturationBoost();
         SelectiveSaturationBoost();
         Console.noteln("Curves Adjustments Complete...")
      }

      if (ForaxxParameters.buttonLogic == "0")
      {
         gString = "(" + hoString + ")" + "*" + ha + "+ ~(" + hoString + ")" + "*" + oiii;
         var ha_stars = ForaxxParameters.haStarsView.id;
         var oiii_stars = ForaxxParameters.oiiiStarsView.id;
         rString_stars = ha_stars;
         gString_stars = "(" + hoString + ")" + "*" + ha_stars + "+ ~(" + hoString + ")" + "*" + oiii_stars;
         bString_stars = oiii_stars;
         Console.writeln("Creating the Foraxx Image ...");
         PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.foraxxView, "rgb", rString, gString, bString);
         Console.noteln("Foraxx Image created...")
         Console.writeln("Completing Curves Adjustments ...")
         CurvesAdjustments1();
         CurvesAdjustments2();
         SelectiveSaturationBoost();
         SelectiveSaturationBoost();
         Console.noteln("Curves Adjustments Complete...")
         Console.writeln("Creating the Foraxx Stars ...");
         PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.foraxxView+"_stars", "rgb", rString_stars, gString_stars, bString_stars);
         Console.writeln("Completing Curves Adjustments on the Stars...")
         StarAdjustments();
      }

      Console.noteln("Script Complete ...");

   }
   else if (ForaxxParameters.buttonLogic == "2" || ForaxxParameters.buttonLogic == "3")
   {

      var ha = ForaxxParameters.haView.id;
      var oiii = ForaxxParameters.oiiiView.id;
      var sii = ForaxxParameters.siiView.id;

      var oString =  oiii + "^~" + oiii;
      var hoString = "(" + ha + "*" + oiii + ")^~(" + ha + "*" + oiii + ")";
      rString = "";
      gString = "";
      bString = oiii;
      var rString_stars = "";
      var gString_stars = "";
      var bString_stars = "";

      Console.writeln("Creating the 'O' Dynamic PixelMath Factor ...");
      PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.oFactorView, "gray", oString, gString, bString);
      Console.noteln("'O' Dynamic PixelMath Factor created...");
      Console.writeln("Creating the 'HO' Dynamic PixelMath Factor ...");
      PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.hoFactorView, "gray", hoString, gString, bString);
      Console.noteln("'HO' Dynamic PixelMath Factor created...");

      if (ForaxxParameters.buttonLogic == "3")
      {
         rString = "(" + oString + ")" + "*" + sii + "+ ~(" + oString + ")" + "*" + ha;
         gString = "(" + hoString + ")" + "*" + ha + "+ ~(" + hoString + ")" + "*" + oiii;
         Console.writeln("Creating the Foraxx Image ...");
         PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.foraxxView, "rgb", rString, gString, bString);
         Console.noteln("Foraxx Image created...")
         Console.writeln("Completing Curves Adjustments ...")
         CurvesAdjustments1();
         CurvesAdjustments2();
         SelectiveSaturationBoost();
         SelectiveSaturationBoost();
         Console.noteln("Curves Adjustments Complete...")
      }

      if (ForaxxParameters.buttonLogic == "2")
      {
         rString = "(" + oString + ")" + "*" + sii + "+ ~(" + oString + ")" + "*" + ha;
         gString = "(" + hoString + ")" + "*" + ha + "+ ~(" + hoString + ")" + "*" + oiii;
         var ha_stars = ForaxxParameters.haStarsView.id;
         var oiii_stars = ForaxxParameters.oiiiStarsView.id;
         var sii_stars = ForaxxParameters.siiStarsView.id;
         rString_stars = "(" + oString + ")" + "*" + sii_stars + "+ ~(" + oString + ")" + "*" + ha_stars;
         gString_stars = "(" + hoString + ")" + "*" + ha_stars + "+ ~(" + hoString + ")" + "*" + oiii_stars;
         bString_stars = oiii_stars;
         Console.writeln("Creating the Foraxx Image ...");
         PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.foraxxView, "rgb", rString, gString, bString);
         Console.noteln("Foraxx Image created...")
         Console.writeln("Completing Curves Adjustments ...")
         CurvesAdjustments1();
         CurvesAdjustments2();
         SelectiveSaturationBoost();
         SelectiveSaturationBoost();
         Console.noteln("Curves Adjustments Complete...")
         Console.writeln("Creating the Foraxx Stars ...");
         PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.foraxxView+"_stars", "rgb", rString_stars, gString_stars, bString_stars);
         Console.writeln("Completing Curves Adjustments on the Stars...")
         StarAdjustments();
      }
      Console.noteln("Script Complete ...");
   }
}

//function ImageConstructor(sii, ha, oiii) {
function ImageConstructor() {
   ha = ForaxxParameters.haView.id;
   oiii = ForaxxParameters.oiiiView.id;
   var oString =  oiii + "^~" + oiii;
   var hoString = "(" + ha + "*" + oiii + ")^~(" + ha + "*" + oiii + ")";
   var rString = "";
   var gString = "";
   var bString = "";
   var rString_stars = "";
   var gString_stars = "";
   var bString_stars = "";
   //var combine_string = "~(~" + View.viewById("Foraxx") + "*" + View.viewById("Foraxx_stars") + ") - " + View.viewById("Foraxx") + "*" + View.viewById("Foraxx_stars");

   if (ForaxxParameters.twoChannels == true)
   {
      rString = ha;
      gString = "(" + hoString + ")" + "*" + ha + "+ ~(" + hoString + ")" + "*" + oiii;
      bString = oiii;
      if (!ForaxxParameters.onlyForaxx)
      {
         ha_stars = ForaxxParameters.haStarsView.id;
         oiii_stars = ForaxxParameters.oiiiStarsView.id;
         rString_stars = ha_stars;
         gString_stars = "(" + hoString + ")" + "*" + ha_stars + "+ ~(" + hoString + ")" + "*" + oiii_stars;
         bString_stars = oiii_stars;
      }
   }
   else
   {
      sii = ForaxxParameters.siiView.id;
      rString = "(" + oString + ")" + "*" + sii + "+ ~(" + oString + ")" + "*" + ha;
      gString = "(" + hoString + ")" + "*" + ha + "+ ~(" + hoString + ")" + "*" + oiii;
      bString = oiii;
      if (!ForaxxParameters.onlyForaxx)
      {
         ha_stars = ForaxxParameters.haStarsView.id;
         oiii_stars = ForaxxParameters.oiiiStarsView.id;
         sii_stars = ForaxxParameters.siiStarsView.id;
         rString_stars = "(" + oString + ")" + "*" + sii_stars + "+ ~(" + oString + ")" + "*" + ha_stars;
         gString_stars = "(" + hoString + ")" + "*" + ha_stars + "+ ~(" + hoString + ")" + "*" + oiii_stars;
         bString_stars = oiii_stars;
      }
      Console.writeln("Creating the 'O' Dynamic PixelMath Factor ...");
      PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.oFactorView, "gray", oString, gString, bString);
      Console.noteln("'O' Dynamic PixelMath Factor created...");
   }
   Console.writeln("Creating the 'HO' Dynamic PixelMath Factor ...");
   PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.hoFactorView, "gray", hoString, gString, bString);
   gString = "(" + hoString + ")" + "*" + ha + "+ ~(" + hoString + ")" + "*" + oiii;
   if (!ForaxxParameters.onlyForaxx)
   {
      gString_stars = "(" + hoString + ")" + "*" + ha_stars + "+ ~(" + hoString + ")" + "*" + oiii_stars;
   }
   Console.noteln("'HO' Dynamic PixelMath Factor created...");
   Console.writeln("Creating the Foraxx Image ...");
   PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.foraxxView, "rgb", rString, gString, bString);
   Console.noteln("Foraxx Image created...")
   Console.writeln("Completing Curves Adjustments ...")
   CurvesAdjustments1();
   CurvesAdjustments2();
   SelectiveSaturationBoost();
   SelectiveSaturationBoost();
   Console.noteln("Curves Adjustments Complete...")
   if (!ForaxxParameters.onlyForaxx)
   {
      Console.writeln("Creating the Foraxx Stars ...");
      PixelMathConstructor(ForaxxParameters.haView, ForaxxParameters.foraxxView+"_stars", "rgb", rString_stars, gString_stars, bString_stars);
      Console.writeln("Completing Curves Adjustments on the Stars...")
      StarAdjustments();
   }
   Console.noteln("Script Complete ...");
}

// ============================================================================
// lib/CurvesAdjustments.js (inlined)
// ============================================================================
/* *****************************************************************************
 *
 * Curves Adjustments on the Foraxx Image
 * This dialog forms part of the ForaxxPalette.js
 * Version 1.0
 *
 * Copyright (C) 2023 Paul Hancock
 *
 * *****************************************************************************
 */

function CurvesAdjustments1() {
   var P = new CurvesTransformation;

   P.ct = CurvesTransformation.AkimaSubsplines;
   P.H = [ // x, y
      [0.00000, 0.00000],
      [0.02517, 0.05952],
      [0.07323, 0.08571],
      [0.11442, 0.13810],
      [0.62014, 0.67619],
      [1.00000, 1.00000]
   ];
   P.Ht = CurvesTransformation.AkimaSubsplines;
   P.S = [ // x, y
      [0.00000, 0.00000],
      [0.50801, 0.61667],
      [1.00000, 1.00000]
   ];
   P.St = CurvesTransformation.AkimaSubsplines;

   P.executeOn(View.viewById(ForaxxParameters.foraxxView));
}

function CurvesAdjustments2() {
   var P = new CurvesTransformation;

   P.H = [ // x, y
      [0.00000, 0.00000],
      [0.05034, 0.03571],
      [0.08238, 0.10238],
      [0.24943, 0.25000],
      [1.00000, 1.00000]
   ];
   P.Ht = CurvesTransformation.AkimaSubsplines;

   P.executeOn(View.viewById(ForaxxParameters.foraxxView));
}

function SelectiveSaturationBoost() {
   var P = new ColorSaturation;
   P.HS = [ // x, y
      [0.00000, 0.00000],
      [0.04910, 0.00909],
      [0.07235, 0.00909],
      [0.10594, 0.15455],
      [0.19380, 0.00909],
      [0.37726, 0.00000],
      [0.52972, 0.00909],
      [0.60465, 0.13636],
      [0.68475, -0.00909],
      [0.84496, 0.00000], // row 10
      [1.00000, 0.00000]
   ];
   P.HSt = ColorSaturation.AkimaSubsplines;
   P.hueShift = 0.000;
   P.executeOn(View.viewById(ForaxxParameters.foraxxView));
}

function StarAdjustments() {
   var P = new CurvesTransformation;

   P.H = [ // x, y
      [0.00000, 0.05476],
      [0.12815, 0.12857],
      [0.24943, 0.24524],
      [0.37300, 0.37857],
      [0.49886, 0.60000],
      [0.62471, 0.62619],
      [0.75057, 0.74048],
      [0.87872, 0.87381],
      [1.00000, 1.00000]
      ];
      P.Ht = CurvesTransformation.AkimaSubsplines;

      P.executeOn(View.viewById(ForaxxParameters.foraxxView+"_stars"));
}

// ============================================================================
// lib/CheckForExistingDynamicExpressions.js (inlined)
// ============================================================================
function checkForExistingDynamicExpressions( id )
{
   let v = View.viewById( id );
   return v != null && !v.isNull;
}

function uniqueViewId( baseId )
{
   var id = baseId;
   for ( var count = 0;  checkForExistingDynamicExpressions( id ); )
      id = baseId + format( "%02d", ++count );
   return id;
}

function updateFileNames()
{
   var oViewId = uniqueViewId("o");
   var hoViewId = uniqueViewId("ho");
   var foraxxViewId = uniqueViewId("Foraxx");

   ForaxxParameters.oFactorView = oViewId;
   ForaxxParameters.hoFactorView = hoViewId;
   ForaxxParameters.foraxxView = foraxxViewId;

}

// ============================================================================
// lib/CheckForCompleteness.js (inlined)
// ============================================================================
function checkForCompleteness()
{
   if (ForaxxParameters.twoChannels == true && ForaxxParameters.onlyForaxx == false)
   {
      if (ForaxxParameters.haView && ForaxxParameters.haStarsView && ForaxxParameters.oiiiView && ForaxxParameters.oiiiStarsView)
      {
         ForaxxParameters.okToRun = true;
      }
      else
      {
         let warnMessage = "You did not choose the required images to complete a Foraxx expression. Sorry the script cannot continue.";
         let msgReturn = (new MessageBox( warnMessage, "Warning", StdIcon.Warning, StdButton.Ok )).execute();
         return;
      }
   }
   else if (ForaxxParameters.twoChannels == true && ForaxxParameters.onlyForaxx == true)
   {
      if (ForaxxParameters.haView && ForaxxParameters.oiiiView)
      {
         ForaxxParameters.okToRun = true;
      }
      else
      {
         let warnMessage = "You did not choose the required images to complete a Foraxx expression. Sorry the script cannot continue.";
         let msgReturn = (new MessageBox( warnMessage, "Warning", StdIcon.Warning, StdButton.Ok )).execute();
         return;
      }
   }
   else if (ForaxxParameters.twoChannels == false && ForaxxParameters.onlyForaxx == false)
   {
      if (ForaxxParameters.haView && ForaxxParameters.haStarsView && ForaxxParameters.oiiiView && ForaxxParameters.oiiiStarsView && ForaxxParameters.siiView && ForaxxParameters.siiStarsView)
      {
         ForaxxParameters.okToRun = true;
      }
      else
      {
         let warnMessage = "You did not choose the required images to complete a Foraxx expression. Sorry the script cannot continue.";
         let msgReturn = (new MessageBox( warnMessage, "Warning", StdIcon.Warning, StdButton.Ok )).execute();
         return;
      }
   }
    else if (ForaxxParameters.twoChannels == false && ForaxxParameters.onlyForaxx == true)
   {
      if (ForaxxParameters.haView && ForaxxParameters.oiiiView && ForaxxParameters.siiView)
      {
         ForaxxParameters.okToRun = true;
      }
      else
      {
         let warnMessage = "You did not choose the required images to complete a Foraxx expression. Sorry the script cannot continue.";
         let msgReturn = (new MessageBox( warnMessage, "Warning", StdIcon.Warning, StdButton.Ok )).execute();
         return;
      }
   }
}

function checkButtonLogic()
{
   if (ForaxxParameters.twoChannels && !ForaxxParameters.onlyForaxx)
   {
      ForaxxParameters.buttonLogic = "0";
   }
   else if (ForaxxParameters.twoChannels && ForaxxParameters.onlyForaxx)
   {
      ForaxxParameters.buttonLogic = "1";
   }
   else if (!ForaxxParameters.twoChannels && !ForaxxParameters.onlyForaxx)
   {
      ForaxxParameters.buttonLogic = "2";
   }
   else if (!ForaxxParameters.twoChannels && ForaxxParameters.onlyForaxx)
   {
      ForaxxParameters.buttonLogic = "3";
   }
}

// ============================================================================
// lib/DialogForaxxMain.js (inlined)
// ============================================================================
 /*
 * *****************************************************************************
 *
 * MAIN ForaxxPalette DIALOG
 * This dialog forms part of the ForaxxPalette.js
 * Version 1.12
 *
 * Copyright (C) 2023 Paul Hancock
 *
 * *****************************************************************************
 */


class ForaxxDialog extends Dialog
{
constructor()
{
   super();
   var dlg = this;


   //Set Dialog Width and Height
   this.minHeight = 200;
   this.minWidth=660;

   //The Main instructional textbox
   this.title = new TextBox(this);
   this.title.text = "<b>Foraxx Palette Construction " + VERSION + "</b> <br><br>" +
                     "This script provides an environment within which to create a Foraxx Palette image. " +
                     "<br><br>" +
                     "For more in depth information about the Foraxx Palette, you should visit the Coldest Nights website, " +
                     "use the button below (bottom left) to navigate to the website." +
                     "<br><br>" +
                     "The script expects stretched starless images along with, (optionally) stretched images of the stars. " +
                     "<br><br>" +
                     "First select how many channels of data you have in the Number of Channels Tab Box. " +
                     "If you have gathered Sii, Ha and Oiii data then choose 3 Channels, if you have only " +
                     "gathered Ha and Oiii (either via mono imaging or OSC with a dual narrowband filter), " +
                     "then choose 2 Channels, this will grey out the Sii boxes. " +
                     "<br><br>" +
                     "Once you have chosen the appropriate number of channels you need to select each of your " +
                     "starless images, and the respective star images or check the box to disable star images. " +
                     "<br><br>" +
                     "Once you press the Execute button, the script will produce the relevant dynamic pixelmath " +
                     "intermediary images. " +
                     "It will then run the appropriate Foraxx expressions depending on the number of filters used. " +
                     "<br><br>" +
                     "Once Complete, you will have a final Foraxx image along with the colour stars image, " +
                     "named Foraxx and Foraxx_stars respectively. " +
                     "<br><br>" +
                     "Copyright &copy; 2023 Paul Hancock. All Rights Reserved.";

   this.title.readOnly = true;
   this.title.minHeight = 380;
   this.title.maxHeight = 380;
   this.title

   /**********************************************************************************************************
    *
    *  Create options for 2 or 3 channel Foraxx without risk of user adding files to the wrong drop downs.
    *
    * ********************************************************************************************************/

   //Create the Two Channel Radio Button
   this.twoChannel = new RadioButton(this);
   this.twoChannel.text = "Choose this option if you only have two channels.";
   this.twoChannel.toolTip = "Select this option if you have dual narrowband OSC data or only collected Ha and Oiii data.";
   this.twoChannel.onCheck = function ( checked )
      {
         ForaxxParameters.twoChannels = checked;
         checkButtonLogic();
         dlg.viewlistSII.enabled = !checked;
         dlg.viewlistSIIStars.enabled = !checked;

         ForaxxParameters.siiView = undefined;
         ForaxxParameters.siiViewStars = undefined;
         dlg.viewlistHA.enabled = true;
         dlg.viewlistOIII.enabled = true;
         //dlg.onlyForaxx.enabled = true;
         if (ForaxxParameters.buttonLogic == "0")
         {
            dlg.viewlistHAStars.enabled = true;
            dlg.viewlistOIIIStars.enabled = true;
         }
         else if (ForaxxParameters.buttonLogic == "1")
         {
            dlg.viewlistHAStars.enabled = false;
            dlg.viewlistOIIIStars.enabled = false;
         }
         //Console.noteln("The 2 Channel Foraxx Variant has been Selected.");
      }

   //Create the Three Channel Radio Button
   this.threeChannel = new RadioButton(this);
   this.threeChannel.text = "Choose this option if you have three channels.";
   this.threeChannel.toolTip = "Select this option if you collected Sii, Ha and Oiii data.";
   this.threeChannel.onCheck = function ( checked )
      {
         ForaxxParameters.twoChannels = !checked;
         checkButtonLogic();
         dlg.viewlistSII.enabled = true;
         dlg.viewlistHA.enabled = true;
         dlg.viewlistOIII.enabled = true;
         //dlg.viewlistSIIStars.enabled = true;
         //dlg.onlyForaxx.enabled = true;
         if (ForaxxParameters.buttonLogic == "2")
         {
            dlg.viewlistHAStars.enabled = true;
            dlg.viewlistOIIIStars.enabled = true;
            dlg.viewlistSIIStars.enabled = true;
         }
         else if (ForaxxParameters.buttonLogic == "3")
         {
            dlg.viewlistHAStars.enabled = false;
            dlg.viewlistOIIIStars.enabled = false;
            dlg.viewlistSIIStars.enabled = false;
         }
         //Console.noteln("The 3 Channel Foraxx Variant has been Selected.");
      }

   /**********************************************************************************************************
    *
    *  Create an optional checkbox to only create a Foraxx image, no extra stars image.
    *
    * ********************************************************************************************************/

   //Create the optional only Foraxx Button
   this.onlyForaxx = new CheckBox(this);
   //this.onlyForaxx.enabled = false;
   this.onlyForaxx.text = "Check this box if you only want a single Foraxx Image and don't need any stars images created.";
   this.onlyForaxx.toolTip = "If your images have not had the stars removed, or you don't want a Foraxx stars image created then check this box.";
   this.onlyForaxx.onCheck = function ( checked )
      {
         if (checked && !ForaxxParameters.twoChannels)
         {
            ForaxxParameters.onlyForaxx = true;
            dlg.viewlistHAStars.enabled = false;
            dlg.viewlistOIIIStars.enabled = false;
            dlg.viewlistSIIStars.enabled = false;
         }
         else if (checked && ForaxxParameters.twoChannels)
         {
            ForaxxParameters.onlyForaxx = true;
            dlg.viewlistHAStars.enabled = false;
            dlg.viewlistOIIIStars.enabled = false;
            dlg.viewlistSIIStars.enabled = false;
         }
         else if (!checked && !ForaxxParameters.twoChannels)
         {
            ForaxxParameters.onlyForaxx = false;
            dlg.viewlistHAStars.enabled = true;
            dlg.viewlistOIIIStars.enabled = true;
            dlg.viewlistSIIStars.enabled = true;
         }
         else if (!checked && ForaxxParameters.twoChannels)
         {
               ForaxxParameters.onlyForaxx = false;
               dlg.viewlistHAStars.enabled = true;
               dlg.viewlistOIIIStars.enabled = true;
               dlg.viewlistSIIStars.enabled = false;
         }
         checkButtonLogic();
         //Console.noteln("A Foraxx star image will be created.")
      }


  /************************************************************************************************************
   * **********************************************************************************************************
   *
   * The view Lists for the Starless and Star Images
   *
   *
   *
   * **********************************************************************************************************
   * *********************************************************************************************************/

   //Create the Ha list view
   this.textHA = new Label(this);
   this.textHA.text = "Ha: "
   this.viewlistHA = new ViewList(this);
   this.viewlistHA.getMainViews();
   this.viewlistHA.enabled = false;
   this.viewlistHA.onViewSelected = function(view) {
      ForaxxParameters.haView = view;
   }

   //Create the Ha Stars list view
   this.textHAStars = new Label(this);
   this.textHAStars.text = "Ha Stars: "
   this.viewlistHAStars = new ViewList(this);
   this.viewlistHAStars.getMainViews();
   this.viewlistHAStars.enabled = false;
   this.viewlistHAStars.onViewSelected = function(view) {
      ForaxxParameters.haStarsView = view;
   }

   //Create the Oiii list view
   this.textOIII = new Label(this);
   this.textOIII.text = "Oiii: "
   this.viewlistOIII = new ViewList(this);
   this.viewlistOIII.getMainViews();
   this.viewlistOIII.enabled = false;
   this.viewlistOIII.onViewSelected = function(view) {
      ForaxxParameters.oiiiView = view;
   }

    //Create the Oiii Stars list view
   this.textOIIIStars = new Label(this);
   this.textOIIIStars.text = "Oiii Stars: "
   this.viewlistOIIIStars = new ViewList(this);
   this.viewlistOIIIStars.getMainViews();
   this.viewlistOIIIStars.enabled = false;
   this.viewlistOIIIStars.onViewSelected = function(view) {
      ForaxxParameters.oiiiStarsView = view;
   }

   //Create the Sii list view
   this.textSII = new Label(this);
   this.textSII.text = "Sii: "
   this.viewlistSII = new ViewList(this);
   this.viewlistSII.getMainViews();
   this.viewlistSII.enabled = false;
   this.viewlistSII.onViewSelected = function(view) {
      ForaxxParameters.siiView = view;
   }

   //Create the Sii Stars list view
   this.textSIIStars = new Label(this);
   this.textSIIStars.text = "Sii Stars: "
   this.viewlistSIIStars = new ViewList(this);
   this.viewlistSIIStars.getMainViews();
   this.viewlistSIIStars.enabled = false;
   this.viewlistSIIStars.onViewSelected = function(view) {
      ForaxxParameters.siiStarsView = view;
   }


   /*********************************************************************************************************
    * *******************************************************************************************************
    *
    *  The Script Buttons
    *
    *
    * *******************************************************************************************************
    * ******************************************************************************************************/

   //Execute Button
   this.execButton = new PushButton(this);
   this.execButton.text = "Execute";
   this.execButton.width = 40;
   this.execButton.enabled = true;
   this.execButton.onClick = () => {
      this.ok();
   }

   //Browser Button
   this.websiteButton = new ToolButton(this);
   this.websiteButton.icon = this.scaledResource(":/icons/internet.png");
   this.websiteButton.setScaledFixedSize(24, 24);
   this.websiteButton.toolTip = "Opens a browser window pointing to the Coldest Nights - Dynamic Pixelmath Expressions."
   this.websiteButton.onClick = function ()
   {
      Dialog.openBrowser("https://thecoldestnights.com/2020/06/pixinsight-dynamic-narrowband-combinations-with-pixelmath/");
   }

   //VERSION and BUILD Numbers
   this.vBuild = new Label(this);
   this.vBuild.text = "Version - " + VERSION + " Build: " + BUILD;



/*****************************************************************************************************
* * ***************************************************************************************************
* Sizer Arrangement
*
* * ****************************************************************************************************
* ***************************************************************************************************/

   //HA View List
   this.haSizer = new HorizontalSizer;
   this.haSizer.margin = 8;
   this.haSizer.add(this.textHA);
   this.haSizer.addSpacing(2);
   this.haSizer.add(this.viewlistHA);
   this.haSizer.addSpacing(5);
   this.haSizer.addStretch();
   this.haSizer.add(this.textHAStars);
   this.haSizer.addSpacing(2);
   this.haSizer.add(this.viewlistHAStars);

    //oiii View List
   this.oiiiSizer = new HorizontalSizer;
   this.oiiiSizer.margin = 8;
   this.oiiiSizer.add(this.textOIII);
   this.oiiiSizer.addSpacing(2);
   this.oiiiSizer.add(this.viewlistOIII);
   this.oiiiSizer.addSpacing(5);
   this.oiiiSizer.addStretch();
   this.oiiiSizer.add(this.textOIIIStars);
   this.oiiiSizer.addSpacing(2);
   this.oiiiSizer.add(this.viewlistOIIIStars);

    //Sii View List
   this.siiSizer = new HorizontalSizer;
   this.siiSizer.margin = 8;
   this.siiSizer.add(this.textSII);
   this.siiSizer.addSpacing(2);
   this.siiSizer.add(this.viewlistSII);
   this.siiSizer.addSpacing(5);
   this.siiSizer.addStretch();
   this.siiSizer.add(this.textSIIStars);
   this.siiSizer.addSpacing(2);
   this.siiSizer.add(this.viewlistSIIStars);

   //Number of  Channels Selection Pane
   this.channelsHsizer = new HorizontalSizer;
   this.channelsHsizer.add(this.twoChannel);
   this.channelsHsizer.add(this.threeChannel);
   this.channelsVsizer = new VerticalSizer;
   this.channelsVsizer.add(this.channelsHsizer);
   this.channelsVsizer.addSpacing(5);
   this.channelsVsizer.add(this.onlyForaxx);
   this.channelsGroup = new GroupBox( this );
   this.channelsGroup.title = "Number of Channels";
   this.channelsGroup.sizer = this.channelsVsizer;

   //Channel Selection Pane
   this.channelSelectionsizer = new VerticalSizer;
   this.channelSelectionsizer.add(this.siiSizer);
   this.channelSelectionsizer.add(this.haSizer);
   this.channelSelectionsizer.add(this.oiiiSizer);
   this.viewGroup = new GroupBox( this );
   this.viewGroup.title = "Channel Selection";
   this.viewGroup.sizer = this.channelSelectionsizer;

   //Bottom Buttons
   this.bottomSizer = new HorizontalSizer;
   this.bottomSizer.margin = 8;

   this.bottomSizer.add(this.websiteButton);
   this.bottomSizer.addStretch();
   this.bottomSizer.add(this.vBuild);
   this.bottomSizer.addStretch();
   this.bottomSizer.add(this.execButton);


   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.add(this.title);
   this.sizer.addSpacing(8);
   this.sizer.add(this.channelsGroup);
   this.sizer.addSpacing(8);
   this.sizer.add(this.viewGroup);
   this.sizer.addSpacing(8);
   this.sizer.add(this.bottomSizer);
   this.sizer.addStretch();

} // constructor
} // class ForaxxDialog

// ============================================================================
// ForaxxPalette.js (main)
// ============================================================================





/*******************************************************************************
 *******************************************************************************
 *
 * Global Parameters for the Foraxx Script
 *
 * *****************************************************************************
 * ****************************************************************************/

var ForaxxParameters = {
   siiView: undefined,
   siiStarsView: undefined,
   haView: undefined,
   haStarsView: undefined,
   oiiiView: undefined,
   oiiiStarsView: undefined,
   oFactorView: "o",
   hoFactorView: "ho",
   foraxxView: "Foraxx",
   twoChannels: false,
   onlyForaxx: false,
   buttonLogic: undefined,
   okToRun: false
}

/*******************************************************************************
 * *****************************************************************************
 *
 * FUNCTION MAIN
 *
 * Script entry point
 *
 * *****************************************************************************
 *******************************************************************************/

function main() {

   // hide the console
   Console.hide();

/*******************************************************************************
 * View context
 *******************************************************************************/
   if (Parameters.isViewTarget) {
      let warnMessage = "Script cannot execute in View context";
      let msgReturn = (new MessageBox( warnMessage, "Warning", StdIcon.Warning, StdButton.Ok )).execute();
      return;
   }

/*******************************************************************************
 * Global context
 *******************************************************************************/
   if (Parameters.isGlobalTarget) {
      let warnMessage = "Script cannot execute in global context";
      let msgReturn = (new MessageBox( warnMessage, "Warning", StdIcon.Warning, StdButton.Ok )).execute();
      return;
   }

/*******************************************************************************
 * Direct context
 *******************************************************************************/
   jsAutoGC = true;  // let PJSR handle automatic garbage collection - small performance hit is worth it as there could be lots of garbage produced by this script!
   let dialog = new ForaxxDialog;
   let dialogReturn = dialog.execute();

   if (dialogReturn == 1) {
      checkForCompleteness();
      if (ForaxxParameters.okToRun == true)
      {
         //Perform the Foraxx Palette Construction
         updateFileNames();
         ImageConstruction();
         //ImageConstructor(ForaxxParameters.siiView,ForaxxParameters.haView,ForaxxParameters.oiiiView);
      }
   } else {
      //The Dialog was cancelled
   }

   //dialog.previewTimer.stop();   //belt and braces - should be stopped in the dialog onHide event handler but no harm to catch here as well

   Console.writeln("Goodbye from ForaxxPalette");
  //Console.hide();
}

main();
