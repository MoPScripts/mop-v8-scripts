#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Hartmut V. Bornemann.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; replaced all
// .prototype. enum references with direct class access.
// No dialogs, with() statements, or #includes were present.
// ----------------------------------------------------------------------------

/*

AdvStarmask.js: Create a starmask
================================================================================

AdvStarmask ist eine Alternative zum Prozess StarMask und benötigt keine
Parameter.

AdvStarmask is a suitable alternative to the PI-process StarMask.
The script works without any parameter.
================================================================================



 Input

      Active window with non-linear view

 Output

      Starmask

 Copyright Hartmut V. Bornemann, 2017

 mailTo:hvb356@hotmail.de

 Written for and dedicated to the PixInsight User Group and Friends of Austria

 ----------------------------------------------------------------------------
 V8 PORT NOTICE
 ----------------------------------------------------------------------------
 Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
 (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
 July 2026. Original script copyright remains with Hartmut V. Bornemann.
 No rights to the original work are claimed or implied.

 V8 changes: added #engine v8 directive and version guard; replaced all
 .prototype. enum references with direct class access (PixelMath, 
 ChannelExtraction, MultiscaleLinearTransform, CurvesTransformation,
 MorphologicalTransformation). No dialogs, with() statements, or #includes
 were present.
 ----------------------------------------------------------------------------
*/

#feature-id    MoP V8 > AdvStarmask
#define VERSION "1.0.0"


function copyView( view, newName)
{
   var P = new PixelMath;
   P.expression = "$T";
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.symbols = "";
   P.generateOutput = true;
   P.singleThreaded = false;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = true;
   P.showNewImage = true;
   P.newImageId = newName;
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.SameAsTarget;
   P.newImageSampleFormat = PixelMath.SameAsTarget;
   if (P.executeOn(view))
      return View.viewById(newName);
   {
      message("Mask creation failed in function copyView", "Error");
      return null;
   }
}

function extractLuminance(view, id)
{
   var P = new ChannelExtraction;
   P.colorSpace = ChannelExtraction.CIELab;
   P.channels = [ // enabled, id
      [true, id],
      [false, ""],
      [false, ""]
   ];
   P.sampleFormat = ChannelExtraction.SameAsSource;
   if (P.executeOn(view))
      return View.viewById(id);
   {
      message("extractLuminance ", "Error");
      return null;
   }
}

function Advanced_process_star_mask(view)
{
   var P = new MultiscaleLinearTransform;
   P.layers = [ // enabled, biasEnabled, bias, noiseReductionEnabled, noiseReductionThreshold, noiseReductionAmount, noiseReductionIterations
      [false, true, 0.000, false, 3.000, 1.00, 1],
      [true, true, 0.000, false, 3.000, 1.00, 1],
      [true, true, 0.000, false, 40.000, 1.00, 1],
      [true, true, 0.500, true, 40.000, 1.00, 1],
      [false, true, 0.000, false, 3.000, 1.00, 1]
   ];
   P.transform = MultiscaleLinearTransform.StarletTransform;
   P.scaleDelta = 0;
   P.scalingFunctionData = [
      0.25,0.5,0.25,
      0.5,1,0.5,
      0.25,0.5,0.25
   ];
   P.scalingFunctionRowFilter = [
      0.5,
      1,
      0.5
   ];
   P.scalingFunctionColFilter = [
      0.5,
      1,
      0.5
   ];
   P.scalingFunctionNoiseSigma = [
      0.8003,0.2729,0.1198,
      0.0578,0.0287,0.0143,
      0.0072,0.0036,0.0019,
      0.001
   ];
   P.scalingFunctionName = "Linear Interpolation (3)";
   P.linearMask = false;
   P.linearMaskAmpFactor = 100;
   P.linearMaskSmoothness = 1.00;
   P.linearMaskInverted = true;
   P.linearMaskPreview = false;
   P.largeScaleFunction = MultiscaleLinearTransform.NoFunction;
   P.curveBreakPoint = 0.75;
   P.noiseThresholding = true;
   P.noiseThresholdingAmount = 1.00;
   P.noiseThreshold = 10.00;
   P.softThresholding = true;
   P.useMultiresolutionSupport = false;
   P.deringing = false;
   P.deringingDark = 0.1000;
   P.deringingBright = 0.0000;
   P.outputDeringingMaps = false;
   P.lowRange = 0.0000;
   P.highRange = 0.0000;
   P.previewMode = MultiscaleLinearTransform.Disabled;
   P.previewLayer = 0;
   P.toLuminance = true;
   P.toChrominance = true;
   P.linear = false;
   P.executeOn(view);


   P = new CurvesTransformation;
   P.R = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Rt = CurvesTransformation.AkimaSubsplines;
   P.G = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Gt = CurvesTransformation.AkimaSubsplines;
   P.B = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Bt = CurvesTransformation.AkimaSubsplines;
   P.K = [ // x, y
      [0.00000, 0.00000],
      [0.32957, 0.25195],
      [0.55079, 0.72987],
      [1.00000, 1.00000]
   ];
   P.Kt = CurvesTransformation.AkimaSubsplines;
   P.A = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.At = CurvesTransformation.AkimaSubsplines;
   P.L = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Lt = CurvesTransformation.AkimaSubsplines;
   P.a = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.at = CurvesTransformation.AkimaSubsplines;
   P.b = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.bt = CurvesTransformation.AkimaSubsplines;
   P.c = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.ct = CurvesTransformation.AkimaSubsplines;
   P.H = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.Ht = CurvesTransformation.AkimaSubsplines;
   P.S = [ // x, y
      [0.00000, 0.00000],
      [1.00000, 1.00000]
   ];
   P.St = CurvesTransformation.AkimaSubsplines;
   P.executeOn(view);


   P = new MorphologicalTransformation;
   P.operator = MorphologicalTransformation.Dilation;
   P.interlacingDistance = 1;
   P.lowThreshold = 0.000000;
   P.highThreshold = 0.000000;
   P.numberOfIterations = 1;
   P.amount = 1.00;
   P.selectionPoint = 0.50;
   P.structureName = "";
   P.structureSize = 7;
   P.structureWayTable = [ // mask
      [[
         0x00,0x00,0x01,0x01,0x01,0x00,0x00,
         0x00,0x01,0x01,0x01,0x01,0x01,0x00,
         0x01,0x01,0x01,0x01,0x01,0x01,0x01,
         0x01,0x01,0x01,0x01,0x01,0x01,0x01,
         0x01,0x01,0x01,0x01,0x01,0x01,0x01,
         0x00,0x01,0x01,0x01,0x01,0x01,0x00,
         0x00,0x00,0x01,0x01,0x01,0x00,0x00
      ]]
   ];
   P.executeOn(view);


   P = new Convolution;
   P.mode = Convolution.Parametric;
   P.sigma = 2.00;
   P.shape = 2.00;
   P.aspectRatio = 1.00;
   P.rotationAngle = 0.00;
   P.filterSource = "";
   P.rescaleHighPass = false;
   P.viewId = "";
   P.executeOn(view);
}

function getNewName(name, suffix)
{
   var newName = name + suffix;
   let n = 1;
   while (!ImageWindow.windowById(newName).isNull)
   {
      ++n;
      newName = name + suffix + n;
   }
   return newName;
}

function message(txt, caption)
{
   var bx = new MessageBox(txt, caption);
   bx.execute();
}

//////////////////////////////////////////////////////////////////////////////
//
// Main script entry point
//
//////////////////////////////////////////////////////////////////////////////
function main()
{
   //
   // Get access to the current active image window.
   //
   var window = ImageWindow.activeWindow;
   if ( window.isNull )
   {
      message( "No active image", "Error" );
   }
   else if (window.currentView.isPreview)
   {
      message("This script can not work on prewiews", "Error");
   }
   else
   {
      Console.hide();
      var maskName = getNewName(window.currentView.id, "_sm");
      var mask = null;
      if (window.currentView.image.isColor)
         mask = extractLuminance(window.currentView, maskName);
      else
      {
         mask = copyView(window.currentView, maskName)
      }

      Advanced_process_star_mask(mask);
   }
}

main();
