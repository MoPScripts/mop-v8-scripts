#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

//////////////////////////////////////////////////////////////////////////////
//
// Professional FITS Header Keyword Manager with Preview and Validation
//
// Comprehensive tool for managing FITS header keywords with safety features
//
// Pete Proulx March 2023, Enhanced May 2025
// Ron Brecher Technical Reviewer
// Masters of PixInsight V2.1
//
//////////////////////////////////////////////////////////////////////////////

#define TITLE "FITS Header Keyword Manager - Accessible"
#feature-id    MoP V8> Batch FITS Keyword Modifier
#feature-info  FITS header keyword management with preview and validation


// FITS keyword validation and utilities
function validateFITSKeyword(keyword) {
    let errors = [];

    if (!keyword || keyword.trim() === "") {
        errors.push("Keyword cannot be empty");
        return errors;
    }

    keyword = keyword.trim().toUpperCase();

    if (keyword.length > 8) {
        errors.push("FITS keywords must be 8 characters or less");
    }

    if (!/^[A-Z0-9_-]+$/.test(keyword)) {
        errors.push("FITS keywords can only contain letters, numbers, hyphens, and underscores");
    }

    if (/^[0-9]/.test(keyword)) {
        errors.push("FITS keywords cannot start with a number");
    }

    // Check for reserved keywords that shouldn't be modified without warning
    let reservedKeywords = [
        'SIMPLE', 'BITPIX', 'NAXIS', 'NAXIS1', 'NAXIS2', 'NAXIS3',
        'EXTEND', 'BZERO', 'BSCALE', 'END'
    ];

    if (reservedKeywords.indexOf(keyword) !== -1) {
        errors.push("Warning: '" + keyword + "' is a reserved FITS keyword");
    }

    return errors;
}

function validateFITSValue(value, keyword) {
    let warnings = [];

    if (value.length > 68) {
        warnings.push("FITS values longer than 68 characters may be truncated");
    }

    // Special validation for common keywords
    if (keyword === 'DATE-OBS' && !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(value)) {
        warnings.push("DATE-OBS should be in ISO 8601 format (YYYY-MM-DDTHH:MM:SS)");
    }

    return warnings;
}

// Enhanced file selection with FITS/XISF filters
function selectFITSFiles() {
    let ofd = new OpenFileDialog;
    ofd.caption = "Select FITS/XISF Files";
    ofd.multipleSelections = true;
    ofd.filters = [
        ["FITS/XISF Files", "*.fit *.fits *.xisf"],
        ["FITS Files", "*.fit *.fits"],
        ["XISF Files", "*.xisf"],
        ["All Files", "*"]
    ];

    if (ofd.execute()) {
        return ofd.fileNames;
    }
    return [];
}

// Get existing keywords from a file (used in processing)
function getExistingKeywords(filePath) {
    try {
        let window = ImageWindow.open(filePath)[0];
        if (window.isNull) {
            return null;
        }

        let keywords = window.keywords;
        window.forceClose();
        return keywords;
    } catch (error) {
        console.warningln("Error reading keywords from " + File.extractNameAndSuffix(filePath) + ": " + error.message);
        return null;
    }
}

// Process files with comprehensive error handling
function processFiles(fileList, operation, targetKeyword, keywordValue, progress) {
    let results = {
        success: 0,
        errors: 0,
        skipped: 0,
        details: []
    };

    for (let i = 0; i < fileList.numberOfChildren; ++i) {
        let node = fileList.child(i);
        let filePath = node.filePath || "";

        if (!filePath) {
            results.skipped++;
            results.details.push("Skipped: No file path");
            continue;
        }

        progress.step("Processing: " + File.extractNameAndSuffix(filePath));

        try {
            // Open file and get keywords
            let window = ImageWindow.open(filePath)[0];
            if (window.isNull) {
                results.errors++;
                results.details.push("Error: Could not open " + File.extractNameAndSuffix(filePath));
                continue;
            }

            let keywords = window.keywords;
            let originalCount = keywords.length;
            let modified = false;

            // Perform the operation
            if (operation === "insert") {
                // Check if keyword already exists
                let exists = false;
                for (let j = 0; j < keywords.length; j++) {
                    if (keywords[j].name.toUpperCase() === targetKeyword.toUpperCase()) {
                        exists = true;
                        break;
                    }
                }

                if (!exists) {
                    let newKeyword = new FITSKeyword(targetKeyword.toUpperCase(), keywordValue);
                    keywords.push(newKeyword);
                    modified = true;
                    console.writeln("➕ Added keyword: " + targetKeyword + " = " + keywordValue);
                } else {
                    console.writeln("⏭️  Keyword already exists: " + targetKeyword);
                }
            }
            else if (operation === "modify") {
                for (let j = 0; j < keywords.length; j++) {
                    if (keywords[j].name.toUpperCase() === targetKeyword.toUpperCase()) {
                        let oldValue = keywords[j].value;
                        keywords[j].value = keywordValue;
                        modified = true;
                        console.writeln("✏️  Modified keyword: " + targetKeyword + " '" + oldValue + "' → '" + keywordValue + "'");
                        break;
                    }
                }

                if (!modified) {
                    console.writeln("⚠️  Keyword not found for modification: " + targetKeyword);
                }
            }
            else if (operation === "remove") {
                let initialLength = keywords.length;
                keywords = keywords.filter(function(kw) {
                    return kw.name.toUpperCase() !== targetKeyword.toUpperCase();
                });

                if (keywords.length < initialLength) {
                    modified = true;
                    console.writeln("🗑️  Removed keyword: " + targetKeyword);
                } else {
                    console.writeln("⚠️  Keyword not found for removal: " + targetKeyword);
                }
            }

            // Save if modified
            if (modified) {
                window.keywords = keywords;
                window.saveAs(filePath, false, false, true, false);
                results.success++;
                results.details.push("Success: " + File.extractNameAndSuffix(filePath) + " (" + operation + ")");
            } else {
                results.skipped++;
                results.details.push("Skipped: " + File.extractNameAndSuffix(filePath) + " (no changes needed)");
            }

            window.forceClose();

        } catch (error) {
            results.errors++;
            results.details.push("Error: " + File.extractNameAndSuffix(filePath) + " - " + error.message);
            console.warningln("❌ Error processing " + File.extractNameAndSuffix(filePath) + ": " + error.message);
        }
    }

    return results;
}

// Progress tracking (reusing from previous script)
function ProgressTracker(total) {
    this.total = total;
    this.current = 0;
    this.errors = [];
    this.warnings = [];

    this.step = function(message) {
        this.current++;
        let percent = Math.round((this.current / this.total) * 100);
        console.writeln("📊 [" + percent + "%] (" + this.current + "/" + this.total + ") " + message);
    };

    this.addError = function(error) {
        this.errors.push(error);
        console.warningln("❌ ERROR: " + error);
    };

    this.addWarning = function(warning) {
        this.warnings.push(warning);
        console.warningln("⚠️ WARNING: " + warning);
    };

    this.getSummary = function() {
        return {
            processed: this.current,
            total: this.total,
            errors: this.errors.length,
            warnings: this.warnings.length,
            success: this.current - this.errors.length
        };
    };
}

// Main dialog creation
function createFITSHeaderDialog() {
    let dialog = new Dialog;
    dialog.windowTitle = "FITS Header Keyword Manager";

    let labelWidth = 150;
    let editWidth = 300;
    let uiMargin = 8;

    // Main title
    let titleLabel = new Label(dialog);
    titleLabel.text = "FITS Header Keyword Manager";
    titleLabel.textAlignment = TextAlignment.Center;
    titleLabel.styleSheet = "font-weight: bold; font-size: 14px;";

    // Instructions GroupBox
    let instructionsGroupBox = new GroupBox(dialog);
    instructionsGroupBox.title = "📋 How This Script Works";
    instructionsGroupBox.titleCheckBox = false;

    let instructionsText = new Label(dialog);
    instructionsText.text =
        "FITS header keyword management for astronomical images:\n\n" +
        "• INSERT: Add new keywords to FITS headers (enter manually)\n" +
        "• MODIFY: Change values of existing keywords (select from dropdown)\n" +
        "• REMOVE: Delete keywords from headers (select from dropdown)\n" +
        "• Add files first, then keywords are automatically scanned\n" +
        "• Use 'Scan Keywords' button to refresh the dropdown\n" +
        "• Changes are reversible - use this tool to modify keywords back\n\n" +
        "⚠️  BEST PRACTICE: Work on copies of your original files, not the masters!\n" +
        "⚠️  Keywords follow FITS standards (8 chars max, uppercase, A-Z 0-9 _ -)";
    instructionsText.wordWrap = true;
    instructionsText.textAlignment = TextAlignment.Left;
    instructionsText.styleSheet = "line-height: 1.4;";

    let instructionsSizer = new VerticalSizer;
    instructionsSizer.margin = 8;
    instructionsSizer.add(instructionsText);
    instructionsGroupBox.sizer = instructionsSizer;

    // Operation Settings GroupBox
    let operationGroupBox = new GroupBox(dialog);
    operationGroupBox.title = "⚙️ Operation Settings";
    operationGroupBox.titleCheckBox = false;

    let operationSizer = new VerticalSizer;
    operationSizer.margin = 8;
    operationSizer.spacing = 8;

    // Action type selection
    let actionSizer = new HorizontalSizer;
    actionSizer.spacing = 10;

    let actionLabel = new Label(dialog);
    actionLabel.text = "Action Type:";
    actionLabel.setFixedWidth(labelWidth);
    actionLabel.styleSheet = "font-weight: bold;";

    dialog.insertRadio = new RadioButton(dialog);
    dialog.insertRadio.text = "➕ INSERT New Keyword";
    dialog.insertRadio.checked = true;
    dialog.insertRadio.styleSheet = "font-weight: bold;";

    dialog.modifyRadio = new RadioButton(dialog);
    dialog.modifyRadio.text = "✏️ MODIFY Existing";
    dialog.modifyRadio.styleSheet = "font-weight: bold;";

    dialog.removeRadio = new RadioButton(dialog);
    dialog.removeRadio.text = "🗑️ REMOVE Keyword";
    dialog.removeRadio.styleSheet = "font-weight: bold;";

    actionSizer.add(actionLabel);
    actionSizer.add(dialog.insertRadio);
    actionSizer.add(dialog.modifyRadio);
    actionSizer.add(dialog.removeRadio);
    operationSizer.add(actionSizer);

    // Keyword input - dynamic based on operation
    let keywordSizer = new HorizontalSizer;
    keywordSizer.spacing = 6;

    let keywordLabel = new Label(dialog);
    keywordLabel.text = "FITS Keyword:";
    keywordLabel.setFixedWidth(labelWidth);
    keywordLabel.styleSheet = "font-weight: bold;";

    // Text input for Insert operations
    dialog.keywordEdit = new Edit(dialog);
    dialog.keywordEdit.setFixedWidth(editWidth);
    dialog.keywordEdit.toolTip = "Enter new FITS keyword (max 8 chars, uppercase, A-Z 0-9 _ -)";

    // Dropdown for Modify/Remove operations
    dialog.keywordComboBox = new ComboBox(dialog);
    dialog.keywordComboBox.setFixedWidth(editWidth);
    dialog.keywordComboBox.toolTip = "Select existing keyword from loaded files";
    dialog.keywordComboBox.enabled = false; // Initially disabled

    keywordSizer.add(keywordLabel);
    keywordSizer.add(dialog.keywordEdit);
    keywordSizer.add(dialog.keywordComboBox);
    operationSizer.add(keywordSizer);

    // Value input
    let valueSizer = new HorizontalSizer;
    valueSizer.spacing = 6;

    let valueLabel = new Label(dialog);
    valueLabel.text = "Keyword Value:";
    valueLabel.setFixedWidth(labelWidth);
    valueLabel.styleSheet = "font-weight: bold;";

    dialog.valueEdit = new Edit(dialog);
    dialog.valueEdit.setFixedWidth(editWidth);
    dialog.valueEdit.toolTip = "Enter the value for the keyword (not needed for Remove operation)";

    valueSizer.add(valueLabel);
    valueSizer.add(dialog.valueEdit);
    operationSizer.add(valueSizer);

    // Options
    let optionsSizer = new HorizontalSizer;
    optionsSizer.spacing = 15;

    dialog.validateCheckBox = new CheckBox(dialog);
    dialog.validateCheckBox.text = "✅ Validate FITS standards";
    dialog.validateCheckBox.checked = true;
    dialog.validateCheckBox.toolTip = "Enforces FITS keyword naming conventions";
    dialog.validateCheckBox.styleSheet = "font-weight: bold;";

    optionsSizer.add(dialog.validateCheckBox);
    operationSizer.add(optionsSizer);

    // Help text with FITS standards button
    let helpSizer = new HorizontalSizer;
    helpSizer.spacing = 10;

    let helpText = new Label(dialog);
    helpText.text = "💡 TIP: Work on copies of your master files • Use 'Export Report' for detailed keyword reference";
    helpText.styleSheet = "font-style: italic; font-size: 11px;";

    // FITS Standards Help Button
    dialog.fitsStandardsButton = new PushButton(dialog);
    dialog.fitsStandardsButton.text = "📚 FITS Standards";
    dialog.fitsStandardsButton.toolTip = "Open FITS keyword standards reference";
    dialog.fitsStandardsButton.styleSheet = "font-weight: bold; padding: 4px 8px; font-size: 11px;";
    dialog.fitsStandardsButton.onClick = function () {
        let helpMessage = "FITS Keyword Standards Reference\n" +
                         "═══════════════════════════════════════\n\n" +
                         "For complete FITS keyword standards and conventions:\n\n" +
                         "🌐 NASA FITS Support Office (Primary Resource):\n" +
                         "   https://fits.gsfc.nasa.gov/\n\n" +
                         "📄 Official FITS Standard Document:\n" +
                         "   https://fits.gsfc.nasa.gov/standard40/\n\n" +
                         "📖 FITS Primer (Beginner-Friendly):\n" +
                         "   https://heasarc.gsfc.nasa.gov/docs/software/fitsio/quick/\n\n" +
                         "📋 Key FITS Keyword Rules:\n" +
                         "───────────────────────────────────────\n" +
                         "• Keywords: Maximum 8 characters, uppercase\n" +
                         "• Characters: A-Z, 0-9, hyphen (-), underscore (_) only\n" +
                         "• Cannot start with numbers\n" +
                         "• Values: Maximum 68 characters\n" +
                         "• Reserved keywords (SIMPLE, BITPIX, NAXIS, etc.) \n" +
                         "  should not be modified without careful consideration\n\n" +
                         "💡 Common Keywords:\n" +
                         "───────────────────────────────────────\n" +
                         "• OBJECT    - Target object name\n" +
                         "• DATE-OBS  - Observation date (ISO 8601)\n" +
                         "• EXPTIME   - Exposure time in seconds\n" +
                         "• FILTER    - Filter used\n" +
                         "• TELESCOP  - Telescope name\n" +
                         "• INSTRUME  - Instrument name\n" +
                         "• OBSERVER  - Observer name\n" +
                         "• SITE      - Observation site\n\n" +
                         "These resources provide authoritative information\n" +
                         "for proper FITS header keyword usage.";

        new MessageBox(helpMessage, "FITS Standards Reference", StdIcon.Information).execute();
    };

    helpSizer.add(helpText);
    helpSizer.addStretch();
    helpSizer.add(dialog.fitsStandardsButton);
    operationSizer.add(helpSizer);

    operationGroupBox.sizer = operationSizer;

    // File Management GroupBox
    let fileManagementGroupBox = new GroupBox(dialog);
    fileManagementGroupBox.title = "📁 File Selection & Keyword Discovery";
    fileManagementGroupBox.titleCheckBox = false;

    let fileManagementSizer = new VerticalSizer;
    fileManagementSizer.margin = 8;
    fileManagementSizer.spacing = 6;

    // File list with simplified view
    dialog.fileList = new TreeBox(dialog);
    dialog.fileList.setMinSize(800, 300);
    dialog.fileList.multipleSelection = true;
    dialog.fileList.numberOfColumns = 2;
    dialog.fileList.setHeaderText(0, "Filename");
    dialog.fileList.setHeaderText(1, "Keywords Count");
    dialog.fileList.headerVisible = true;
    dialog.fileList.toolTip = "Selected FITS/XISF files for processing";

    // Set column widths
    dialog.fileList.setColumnWidth(0, 500);
    dialog.fileList.setColumnWidth(1, 150);

    fileManagementSizer.add(dialog.fileList);

    // File management buttons
    let fileButtonsSizer = new HorizontalSizer;
    fileButtonsSizer.spacing = 8;

    dialog.addFilesButton = new PushButton(dialog);
    dialog.addFilesButton.text = "📁 Add Files";
    dialog.addFilesButton.icon = dialog.scaledResource(":/icons/add.png");
    dialog.addFilesButton.toolTip = "Select FITS/XISF files to process";
    dialog.addFilesButton.styleSheet = "font-weight: bold; padding: 6px 12px;";
    dialog.addFilesButton.onClick = function () {
        let selectedFiles = selectFITSFiles();
        if (selectedFiles.length === 0) {
            return; // User cancelled file selection
        }

        console.writeln("📁 Adding " + selectedFiles.length + " files...");
        for (let i = 0; i < selectedFiles.length; i++) {
            let filePath = selectedFiles[i];
            let node = new TreeBoxNode(dialog.fileList);
            node.setText(0, File.extractNameAndSuffix(filePath));
            node.setText(1, "Loading...");
            node.filePath = filePath;
        }

        console.writeln("🔍 Scanning files for keywords...");
        dialog.updateKeywordPreview();
    };

    dialog.removeSelectedButton = new PushButton(dialog);
    dialog.removeSelectedButton.text = "🗑️ Remove Selected";
    dialog.removeSelectedButton.icon = dialog.scaledResource(":/icons/remove.png");
    dialog.removeSelectedButton.toolTip = "Remove selected files from the list";
    dialog.removeSelectedButton.onClick = function () {
        let selectedNodes = dialog.fileList.selectedNodes;
        for (let i = selectedNodes.length - 1; i >= 0; i--) {
            dialog.fileList.remove(dialog.fileList.childIndex(selectedNodes[i]));
        }
    };

    // Export keywords report function
    dialog.exportKeywordsReport = function() {
        if (this.fileList.numberOfChildren === 0) {
            new MessageBox("No files loaded. Please add FITS/XISF files first.", "No Files", StdIcon.Warning).execute();
            return;
        }

        console.writeln("📄 Generating FITS keywords report...");

        // Generate timestamp for filename
        let now = new Date();
        let year = now.getFullYear().toString();
        let month = (now.getMonth() + 1).toString();
        let day = now.getDate().toString();
        let hour = now.getHours().toString();
        let minute = now.getMinutes().toString();

        // Pad with zeros manually
        if (month.length < 2) month = "0" + month;
        if (day.length < 2) day = "0" + day;
        if (hour.length < 2) hour = "0" + hour;
        if (minute.length < 2) minute = "0" + minute;

        let timestamp = year + month + day + "_" + hour + minute;
        let defaultFileName = "FITS_Keywords_Report_" + timestamp + ".txt";

        // Let user choose save location
        let saveDialog = new SaveFileDialog;
        saveDialog.caption = "Save FITS Keywords Report";
        saveDialog.overwritePrompt = true;
        // PixInsight V8: SaveFileDialog.fileName is read-only, so we don't preset it here.
        saveDialog.filters = [
            ["Text Files", "*.txt"],
            ["All Files", "*"]
        ];

        if (!saveDialog.execute()) {
            console.writeln("📄 Report export cancelled by user");
            return;
        }

        let reportFilePath = saveDialog.fileName;
        if (reportFilePath && File.extractExtension(reportFilePath) === "")
            reportFilePath += ".txt";

        // Build report content
        let report = [];
        report.push("═══════════════════════════════════════");
        report.push("FITS KEYWORD ANALYSIS REPORT");
        report.push("═══════════════════════════════════════");
        report.push("Generated: " + now.toLocaleString());
        report.push("Tool: FITS Header Keyword Manager v2.1 (Accessible)");
        report.push("Total Files: " + this.fileList.numberOfChildren);
        report.push("");

        let allUniqueKeywords = [];
        let totalKeywordCount = 0;
        let fileCount = 0;

        // Process each file
        for (let i = 0; i < this.fileList.numberOfChildren; ++i) {
            let node = this.fileList.child(i);
            let filePath = node.filePath || "";

            if (filePath) {
                fileCount++;
                let fileName = File.extractNameAndSuffix(filePath);

                report.push("───────────────────────────────────────");
                report.push("FILE " + fileCount + ": " + fileName);
                report.push("Full Path: " + filePath);

                try {
                    let windows = ImageWindow.open(filePath);

                    if (windows && windows.length > 0) {
                        let window = windows[0];
                        let keywords = window.keywords;

                        if (keywords && keywords.length > 0) {
                            report.push("Keywords: " + keywords.length);
                            report.push("");

                            totalKeywordCount += keywords.length;

                            for (let j = 0; j < keywords.length; j++) {
                                if (keywords[j] && keywords[j].name) {
                                    let keywordLine = "  " + keywords[j].name;

                                    // Pad keyword name to 10 characters for alignment
                                    while (keywordLine.length < 12) {
                                        keywordLine += " ";
                                    }

                                    keywordLine += "= " + keywords[j].value;

                                    // Add comment if it exists
                                    if (keywords[j].comment && keywords[j].comment.trim() !== "") {
                                        keywordLine += " / " + keywords[j].comment;
                                    }

                                    report.push(keywordLine);

                                    // Track unique keywords
                                    let keywordName = keywords[j].name;
                                    let alreadyExists = false;
                                    for (let k = 0; k < allUniqueKeywords.length; k++) {
                                        if (allUniqueKeywords[k] === keywordName) {
                                            alreadyExists = true;
                                            break;
                                        }
                                    }
                                    if (!alreadyExists) {
                                        allUniqueKeywords.push(keywordName);
                                    }
                                }
                            }
                        } else {
                            report.push("Keywords: 0 (No FITS keywords found)");
                        }

                        window.forceClose();
                    } else {
                        report.push("ERROR: Could not open file");
                    }
                } catch (error) {
                    report.push("ERROR: " + error.message);
                }

                report.push("");
            }
        }

        // Add summary section
        report.push("═══════════════════════════════════════");
        report.push("SUMMARY");
        report.push("═══════════════════════════════════════");
        report.push("Files Processed: " + fileCount);
        report.push("Total Keywords: " + totalKeywordCount);
        report.push("Unique Keywords: " + allUniqueKeywords.length);
        report.push("");
        report.push("All Unique Keywords Found:");

        // Sort and display unique keywords in columns
        allUniqueKeywords.sort();
        let keywordLine = "";
        for (let i = 0; i < allUniqueKeywords.length; i++) {
            keywordLine += allUniqueKeywords[i];

            // Add spacing
            while (keywordLine.length % 12 !== 0) {
                keywordLine += " ";
            }

            // New line every 6 keywords
            if ((i + 1) % 6 === 0 || i === allUniqueKeywords.length - 1) {
                report.push("  " + keywordLine);
                keywordLine = "";
            }
        }

        report.push("");
        report.push("═══════════════════════════════════════");
        report.push("End of Report");

        // Save report to file
        try {
            let reportContent = report.join("\n");
            let file = new File;
            file.createForWriting(reportFilePath);
            file.outTextLn(reportContent);
            file.close();

            console.writeln("✅ Keywords report saved: " + reportFilePath);

            // Show success message
            let successMessage = "FITS Keywords Report Generated!\n\n" +
                                "File: " + File.extractNameAndSuffix(reportFilePath) + "\n" +
                                "Location: " + File.extractDrive(reportFilePath) + File.extractDirectory(reportFilePath) + "\n" +
                                "Files analyzed: " + fileCount + "\n" +
                                "Total keywords: " + totalKeywordCount + "\n" +
                                "Unique keywords: " + allUniqueKeywords.length + "\n\n" +
                                "The report file has been saved to your chosen location.\n" +
                                "You can open it in any text editor for reference.";

            new MessageBox(successMessage, "Report Generated", StdIcon.Information).execute();

        } catch (error) {
            console.warningln("❌ Error saving report: " + error.message);

            // Offer to try a different location
            let retryMessage = "Error saving report to the selected location:\n\n" +
                             error.message + "\n\n" +
                             "This might be due to file permissions or disk space.\n" +
                             "Would you like to try saving to a different location?";

            let retryResult = new MessageBox(retryMessage, "Save Error",
                                           StdIcon.Error, StdButton.Yes, StdButton.No).execute();

            if (retryResult === StdButton.Yes) {
                // Recursive call to try again
                this.exportKeywordsReport();
            }
        }
    };

    dialog.clearAllButton = new PushButton(dialog);
    dialog.clearAllButton.text = "🧹 Clear All";
    dialog.clearAllButton.toolTip = "Remove all files from the list";
    dialog.clearAllButton.onClick = function () {
        dialog.fileList.clear();
    };

    dialog.refreshKeywordsButton = new PushButton(dialog);
    dialog.refreshKeywordsButton.text = "🔄 Scan Keywords";
    dialog.refreshKeywordsButton.toolTip = "Scan all loaded files and populate the keyword dropdown for Modify/Remove operations";
    dialog.refreshKeywordsButton.styleSheet = "font-weight: bold; padding: 4px 8px;";
    dialog.refreshKeywordsButton.onClick = function () {
        console.writeln("🔍 Manual keyword scan requested...");
        console.show(); // Make sure console is visible
        dialog.updateKeywordPreview();
    };

    dialog.exportReportButton = new PushButton(dialog);
    dialog.exportReportButton.text = "📄 Export Report";
    dialog.exportReportButton.toolTip = "Generate detailed text report of all FITS keywords and values - you'll choose where to save it";
    dialog.exportReportButton.styleSheet = "font-weight: bold; padding: 4px 8px;";
    dialog.exportReportButton.onClick = function () {
        dialog.exportKeywordsReport();
    };

    fileButtonsSizer.add(dialog.addFilesButton);
    fileButtonsSizer.add(dialog.removeSelectedButton);
    fileButtonsSizer.add(dialog.clearAllButton);
    fileButtonsSizer.addStretch();
    fileButtonsSizer.add(dialog.exportReportButton);
    fileButtonsSizer.add(dialog.refreshKeywordsButton);

    fileManagementSizer.add(fileButtonsSizer);
    fileManagementGroupBox.sizer = fileManagementSizer;

    // Main action buttons
    let mainButtonsSizer = new HorizontalSizer;
    mainButtonsSizer.spacing = 10;

    // New Instance button
    dialog.newInstanceButton = new ToolButton(dialog);
    dialog.newInstanceButton.icon = dialog.scaledResource(":/process-interface/new-instance.png");
    dialog.newInstanceButton.setScaledFixedSize(24, 24);
    dialog.newInstanceButton.toolTip = "Create Process Icon - Drag to save current settings";
    dialog.newInstanceButton.onMousePress = function () {
        this.hasFocus = true;
        this.pushed = false;
        this.dialog.newInstance();
    };

    dialog.processButton = new PushButton(dialog);
    dialog.processButton.text = "🚀 Process Files";
    dialog.processButton.icon = dialog.scaledResource(":/icons/ok.png");
    dialog.processButton.styleSheet = "font-weight: bold; padding: 8px 16px;";
    dialog.processButton.onClick = function () {
        this.dialog.ok();
    };

    dialog.cancelButton = new PushButton(dialog);
    dialog.cancelButton.text = "Cancel";
    dialog.cancelButton.icon = dialog.scaledResource(":/icons/cancel.png");
    dialog.cancelButton.onClick = function () {
        this.dialog.cancel();
    };

    mainButtonsSizer.add(dialog.newInstanceButton);
    mainButtonsSizer.addStretch();
    mainButtonsSizer.add(dialog.processButton);
    mainButtonsSizer.add(dialog.cancelButton);

    // Update keyword preview function
    dialog.updateKeywordPreview = function() {
        let allKeywords = []; // Use array instead of Set for better compatibility

        // Check if we have any files loaded
        if (this.fileList.numberOfChildren === 0) {
            this.keywordComboBox.clear();
            this.keywordComboBox.addItem("Add files first");
            return;
        }

        console.writeln("📝 Scanning " + this.fileList.numberOfChildren + " files for keywords...");

        for (let i = 0; i < this.fileList.numberOfChildren; ++i) {
            let node = this.fileList.child(i);
            let filePath = node.filePath || "";

            if (filePath) {
                node.setText(1, "Reading...");

                try {
                    let windows = ImageWindow.open(filePath);

                    if (windows && windows.length > 0) {
                        let window = windows[0];
                        let keywords = window.keywords;

                        if (keywords && keywords.length > 0) {
                            node.setText(1, keywords.length + " keywords");

                            // Collect all unique keyword names (check for duplicates manually)
                            for (let j = 0; j < keywords.length; j++) {
                                if (keywords[j] && keywords[j].name) {
                                    let keywordName = keywords[j].name;

                                    // Check if already in array
                                    let alreadyExists = false;
                                    for (let k = 0; k < allKeywords.length; k++) {
                                        if (allKeywords[k] === keywordName) {
                                            alreadyExists = true;
                                            break;
                                        }
                                    }

                                    if (!alreadyExists) {
                                        allKeywords.push(keywordName);
                                    }
                                }
                            }
                        } else {
                            node.setText(1, "No keywords");
                        }

                        window.forceClose();
                    } else {
                        console.warningln("❌ Failed to open file: " + File.extractNameAndSuffix(filePath));
                        node.setText(1, "Error reading");
                    }
                } catch (error) {
                    console.warningln("❌ Exception reading file: " + error.message);
                    node.setText(1, "Error");
                }
            }
        }

        // Update the dropdown with collected keywords
        this.keywordComboBox.clear();

        if (allKeywords.length > 0) {
            // Sort the array
            allKeywords.sort();
            console.writeln("✅ Found " + allKeywords.length + " unique keywords: " +
                          allKeywords.slice(0, 10).join(", ") +
                          (allKeywords.length > 10 ? "..." : ""));

            for (let k = 0; k < allKeywords.length; k++) {
                this.keywordComboBox.addItem(allKeywords[k]);
            }

            console.writeln("📝 Dropdown populated successfully");
        } else {
            this.keywordComboBox.addItem("No keywords found");
            console.writeln("⚠️ No keywords found in any files");
        }
    };

    // Auto-enable/disable controls based on operation
    dialog.insertRadio.onCheck = function(checked) {
        if (checked) {
            this.dialog.valueEdit.enabled = true;
            this.dialog.keywordEdit.enabled = true;
            this.dialog.keywordComboBox.enabled = false;
            this.dialog.keywordEdit.show();
            this.dialog.keywordComboBox.hide();
        }
    };

    dialog.modifyRadio.onCheck = function(checked) {
        if (checked) {
            this.dialog.valueEdit.enabled = true;
            this.dialog.keywordEdit.enabled = false;
            this.dialog.keywordComboBox.enabled = true;
            this.dialog.keywordEdit.hide();
            this.dialog.keywordComboBox.show();
            // Populate dropdown when switching to modify mode
            console.writeln("🔍 Scanning keywords for MODIFY mode...");
            this.dialog.updateKeywordPreview();
        }
    };

    dialog.removeRadio.onCheck = function(checked) {
        if (checked) {
            this.dialog.valueEdit.enabled = false;
            this.dialog.keywordEdit.enabled = false;
            this.dialog.keywordComboBox.enabled = true;
            this.dialog.keywordEdit.hide();
            this.dialog.keywordComboBox.show();
            // Populate dropdown when switching to remove mode
            console.writeln("🔍 Scanning keywords for REMOVE mode...");
            this.dialog.updateKeywordPreview();
        }
    };

    // Initialize display - Insert mode by default
    dialog.keywordComboBox.hide();

    // Main layout
    let mainSizer = new VerticalSizer;
    mainSizer.margin = 12;
    mainSizer.spacing = 12;
    mainSizer.add(titleLabel);
    mainSizer.add(instructionsGroupBox);
    mainSizer.add(operationGroupBox);
    mainSizer.add(fileManagementGroupBox);
    mainSizer.add(mainButtonsSizer);

    dialog.sizer = mainSizer;
    dialog.adjustToContents();
    dialog.setMinWidth(Math.max(dialog.width, 900));
    dialog.setMinHeight(Math.max(dialog.height, 700));

    return dialog;
}

// Enhanced main function with comprehensive validation
function main() {
    let dialog = createFITSHeaderDialog();

    if (dialog.execute()) {
        // Get keyword from appropriate source
        let keyword = "";
        if (dialog.insertRadio.checked) {
            keyword = dialog.keywordEdit.text.trim().toUpperCase();
        } else {
            keyword = dialog.keywordComboBox.itemText(dialog.keywordComboBox.currentItem).trim().toUpperCase();
        }

        let value = dialog.valueEdit.text.trim();
        let validateStandards = dialog.validateCheckBox.checked;

        // Determine operation
        let operation = "insert";
        if (dialog.modifyRadio.checked) operation = "modify";
        else if (dialog.removeRadio.checked) operation = "remove";

        // Validate inputs
        if (validateStandards) {
            let keywordErrors = validateFITSKeyword(keyword);
            if (keywordErrors.length > 0) {
                let errorMessage = "Keyword validation failed:\n\n" + keywordErrors.join("\n");
                new MessageBox(errorMessage, "Validation Error", StdIcon.Error).execute();
                return;
            }

            if (operation !== "remove") {
                let valueWarnings = validateFITSValue(value, keyword);
                if (valueWarnings.length > 0) {
                    let warningMessage = "Value validation warnings:\n\n" + valueWarnings.join("\n") +
                                      "\n\nDo you want to continue anyway?";
                    let result = new MessageBox(warningMessage, "Validation Warning",
                                               StdIcon.Warning, StdButton.Yes, StdButton.No).execute();
                    if (result !== StdButton.Yes) {
                        return;
                    }
                }
            }
        }

        // Basic input validation
        if (!keyword || keyword === "NO KEYWORDS FOUND" || keyword === "ADD FILES FIRST") {
            let message = "";
            if (dialog.insertRadio.checked) {
                message = "Please enter a keyword name.";
            } else if (keyword === "ADD FILES FIRST") {
                message = "Please add FITS/XISF files first, then click 'Scan Keywords' to populate the dropdown.";
            } else {
                message = "No keywords found in selected files. Please add files with FITS keywords first.";
            }
            new MessageBox(message, "Missing Keyword", StdIcon.Warning).execute();
            return;
        }

        if (operation !== "remove" && !value) {
            new MessageBox("Please enter a keyword value.", "Missing Value", StdIcon.Warning).execute();
            return;
        }

        // Check file count
        if (dialog.fileList.numberOfChildren === 0) {
            new MessageBox("No files selected for processing.", "No Files", StdIcon.Warning).execute();
            return;
        }

        // Final confirmation
        let fileCount = dialog.fileList.numberOfChildren;
        let operationText = (operation === "insert" ? "add" :
                           operation === "modify" ? "modify" : "remove");

        let confirmMessage = "Ready to " + operationText + " FITS keyword in " + fileCount + " file(s):\n\n" +
                           "Keyword: " + keyword + "\n" +
                           (operation !== "remove" ? "Value: " + value + "\n" : "") +
                           "Operation: " + operation.toUpperCase() + "\n\n" +
                           "This will modify the FITS headers directly.\n" +
                           "Make sure you're working on copies of your original files!\n\n" +
                           "Continue?";

        let confirmResult = new MessageBox(confirmMessage, "Confirm FITS Header Modification",
                                         StdIcon.Question, StdButton.Yes, StdButton.No).execute();

        if (confirmResult !== StdButton.Yes) {
            console.writeln("FITS header modification cancelled by user.");
            return;
        }

        // Process files
        console.show();
        console.writeln("═══════════════════════════════════════");
        console.writeln("🚀 FITS HEADER KEYWORD PROCESSING STARTED");
        console.writeln("═══════════════════════════════════════");
        console.writeln("Operation: " + operation.toUpperCase());
        console.writeln("Keyword: " + keyword);
        if (operation !== "remove") console.writeln("Value: " + value);
        console.writeln("Files to process: " + fileCount);
        console.writeln("⚠️  Working directly on files - ensure you have copies!");
        console.writeln("───────────────────────────────────────");

        let progress = new ProgressTracker(fileCount);
        let results = processFiles(dialog.fileList, operation, keyword, value, progress);

        // Show results
        console.writeln("───────────────────────────────────────");
        console.writeln("📊 PROCESSING SUMMARY:");
        console.writeln("✅ Successfully processed: " + results.success);
        console.writeln("⏭️  Skipped (no changes): " + results.skipped);
        if (results.errors > 0) {
            console.writeln("❌ Errors encountered: " + results.errors);
        }
        console.writeln("═══════════════════════════════════════");

        // Show completion dialog
        let summaryMessage = "FITS header processing completed!\n\n" +
                           "Successfully processed: " + results.success + " files\n" +
                           "Skipped: " + results.skipped + " files\n" +
                           (results.errors > 0 ? "Errors: " + results.errors + " files\n" : "") +
                           "\nCheck the console for detailed results.";

        new MessageBox(summaryMessage, "Processing Complete",
                      results.errors > 0 ? StdIcon.Warning : StdIcon.Information).execute();

    } else {
        console.writeln("FITS header keyword processing cancelled by user.");
    }
}

// Execute the main function
main();
