#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Hartmut V. Bornemann.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; removed #include
// directives; added dialog with view selector, quality slider, new instance
// button, and GraXpert-style toolbar button row.
// ----------------------------------------------------------------------------

/*
WriteJPEG.js: Save view as JPEG with STF applied
================================================================================

Applies the active image's ScreenTransferFunction to a temporary copy and
saves it as a JPEG file. If no STF is set, AutoSTF is applied automatically.

Copyright (C) 2016, Hartmut V. Bornemann
mailTo:hvb356@hotmail.de

2026-07-08 V8 port with dialog by Pete Proulx, Masters of PixInsight
================================================================================
*/

#feature-id    WriteJPEG : MoP V8 > WriteJPEG
#define TITLE   "WriteJPEG"
#define VERSION "2.0.0"

#feature-info  Applies the ScreenTransferFunction and saves the result as a JPEG file.<br/>\
   Copyright (C) 2016, Hartmut V. Bornemann. V8 port by Pete Proulx, Masters of PixInsight.

#define DEFAULT_AUTOSTRETCH_SCLIP  -2.80
#define DEFAULT_AUTOSTRETCH_TBGND   0.25

// ============================================================================
// Dialog
// ============================================================================

class WriteJPEGDialog extends Dialog
{
constructor()
{
   super();
   var dlg = this;

   // ---- Title label ----
   this.titleLabel = new Label( this );
   this.titleLabel.useRichText = true;
   this.titleLabel.text =
      "<b>" + TITLE + " v" + VERSION + "</b> \u2014 " +
      "Writes a JPEG of the selected view. If the image is linear, " +
      "an AutoSTF is automatically applied and the stretched result " +
      "is saved as the JPEG.";
   this.titleLabel.wordWrapping = true;
   this.titleLabel.frameStyle  = FrameStyle.Box;
   this.titleLabel.margin       = 6;
   this.titleLabel.styleSheet   = "padding: 4px;";

   // ---- View selection ----
   this.viewLabel = new Label( this );
   this.viewLabel.text = "Image:";
   this.viewLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
   this.viewLabel.setFixedWidth( 80 );

   this.viewList = new ViewList( this );
   this.viewList.getMainViews();
   this.viewList.toolTip = "Select the image to save as JPEG.";
   this.viewList.onViewSelected = ( view ) => {
      dlg.selectedView = view;
      dlg.execButton.enabled = ( view != null && !view.isNull );
   };

   var viewSizer = new HorizontalSizer;
   viewSizer.spacing = 6;
   viewSizer.add( this.viewLabel );
   viewSizer.add( this.viewList );

   // ---- Quality ----
   this.qualityLabel = new Label( this );
   this.qualityLabel.text = "Quality:";
   this.qualityLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
   this.qualityLabel.setFixedWidth( 80 );

   this.qualitySlider = new Slider( this );
   this.qualitySlider.minValue  = 1;
   this.qualitySlider.maxValue  = 100;
   this.qualitySlider.value     = 100;
   this.qualitySlider.minWidth  = 200;
   this.qualitySlider.toolTip   = "JPEG quality 1-100. 100 = maximum quality, minimal compression.";
   this.qualitySlider.onValueUpdated = ( v ) => {
      dlg.qualityEdit.text = String( v );
   };

   this.qualityEdit = new Edit( this );
   this.qualityEdit.text     = "100";
   this.qualityEdit.setFixedWidth( 40 );
   this.qualityEdit.toolTip  = "JPEG quality 1-100.";
   this.qualityEdit.onTextUpdated = ( t ) => {
      let v = parseInt( t );
      if ( !isNaN(v) && v >= 1 && v <= 100 )
         dlg.qualitySlider.value = v;
   };

   var qualitySizer = new HorizontalSizer;
   qualitySizer.spacing = 6;
   qualitySizer.add( this.qualityLabel );
   qualitySizer.add( this.qualitySlider );
   qualitySizer.add( this.qualityEdit );

   // ---- Controls sizer ----
   var controlsSizer = new VerticalSizer;
   controlsSizer.margin  = 8;
   controlsSizer.spacing = 6;
   controlsSizer.add( this.titleLabel );
   controlsSizer.add( viewSizer );
   controlsSizer.add( qualitySizer );

   // ---- Toolbar buttons (GraXpert style) ----
   this.buttonFrame = new Frame( this );
   this.buttonFrame.sizer = new HorizontalSizer;
   this.buttonFrame.sizer.margin  = 6;
   this.buttonFrame.sizer.spacing = 6;

   this.newInstanceButton = new ToolButton( this );
   this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
   this.newInstanceButton.setScaledFixedSize( 24, 24 );
   this.newInstanceButton.toolTip = "New Instance \u2014 drag to workspace to save settings.";
   this.newInstanceButton.onMousePress = () => {
      dlg.saveParameters();
      dlg.newInstance();
   };

   this.execButton = new ToolButton( this );
   this.execButton.icon = this.scaledResource( ":/process-interface/execute.png" );
   this.execButton.setScaledFixedSize( 24, 24 );
   this.execButton.toolTip = "Save as JPEG";
   this.execButton.enabled = false;
   this.execButton.onClick = () => {
      dlg.saveJPEG();
   };

   this.cancelButton = new ToolButton( this );
   this.cancelButton.icon = this.scaledResource( ":/process-interface/cancel.png" );
   this.cancelButton.setScaledFixedSize( 24, 24 );
   this.cancelButton.toolTip = "Close";
   this.cancelButton.onClick = () => {
      dlg.cancel();
   };

   this.buttonFrame.sizer.add( this.newInstanceButton );
   this.buttonFrame.sizer.addSpacing( 8 );
   this.buttonFrame.sizer.add( this.execButton );
   this.buttonFrame.sizer.addSpacing( 8 );
   this.buttonFrame.sizer.add( this.cancelButton );
   this.buttonFrame.sizer.addStretch();

   // ---- Main layout ----
   this.sizer = new VerticalSizer;
   this.sizer.margin  = 8;
   this.sizer.spacing = 6;
   this.sizer.add( controlsSizer );
   this.sizer.add( this.buttonFrame );

   this.windowTitle = TITLE + " Script v" + VERSION;
   this.adjustToContents();
   this.setFixedSize();

   // Initialize
   this.selectedView = this.viewList.currentView;
   if ( this.selectedView != null && !this.selectedView.isNull )
      this.execButton.enabled = true;

   this.loadParameters();
}

saveParameters()
{
   Parameters.set( "quality", this.qualitySlider.value );
}

loadParameters()
{
   if ( Parameters.has( "quality" ) )
   {
      let q = Parameters.getInteger( "quality" );
      this.qualitySlider.value = q;
      this.qualityEdit.text    = String( q );
   }
}

saveJPEG()
{
   let view = this.selectedView;
   if ( view == null || view.isNull )
   {
      new MessageBox( "No image selected.", TITLE, StdIcon.Error, StdButton.Ok ).execute();
      return;
   }

   let quality = this.qualitySlider.value;

   // Determine starting path from image file or last used path
   let currentPath = "";
   if ( view.window.filePath )
      currentPath = File.extractDirectory( view.window.filePath );

   let savedPath = Settings.read( TITLE, DataType.String );
   if ( savedPath != null && currentPath === "" )
      currentPath = savedPath;

   let jpeg_filename = view.id;

   let sfdlg = new SaveFileDialog;
   sfdlg.caption = "Save " + jpeg_filename + " as JPEG";
   sfdlg.initialPath = currentPath;
   if ( !sfdlg.initialPath.endsWith( '/' ) )
      sfdlg.initialPath += '/';
   sfdlg.initialPath += jpeg_filename + ".jpg";
   sfdlg.selectedFileExtension = ".jpg";
   sfdlg.overwritePrompt = true;
   sfdlg.filters = [["JPEG Files", "*.jpg"]];

   if ( sfdlg.execute() )
   {
      let filePath = sfdlg.filePath;

      // Save directory for next time
      Settings.write( TITLE, DataType.String, File.extractDirectory( filePath ) );

      try
      {
         // Create temporary copy and apply STF
         let img = view.image;
         let temp_win = new ImageWindow(
            img.width, img.height, img.numberOfChannels,
            img.bitsPerSample, img.sampleType != 0, img.isColor );

         let tempView = temp_win.mainView;
         tempView.beginProcess( UndoFlag.NoSwapFile );
         tempView.image.apply( img );
         tempView.endProcess();

         // Apply STF from source view (or compute AutoSTF if none set)
         // STF format: [midtones, shadows, highlights, lowClip, highClip]
         // A neutral STF has midtones=0.5, shadows=0
         let stfSet = view.stf[0][0] != 0.5 || view.stf[0][1] != 0.0;

         if ( stfSet )
            ApplySTF( tempView, view.stf );
         else
            ApplyAutoSTF( tempView, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, img.isColor );

         // Save JPEG
         let fileFormat = new FileFormat( ".jpg", false, true );

         let file = new FileFormatInstance( fileFormat );
         if ( !file.create( filePath, format( "quality %d", quality ) ) )
            throw new Error( "Could not create file: " + filePath );

         let desc = new ImageDescription;
         desc.bitsPerSample      = 8;
         desc.ieeefpSampleFormat = false;

         if ( !file.setOptions( desc ) )
            throw new Error( "Could not set file options." );

         if ( !file.writeImage( tempView.image ) )
            throw new Error( "Could not write image." );

         file.close();
         temp_win.forceClose();

         Console.show();
         Console.writeln( "<end><cbr>Saved JPEG: " + filePath );
      }
      catch ( x )
      {
         new MessageBox( "Error saving JPEG:\n" + x.message,
            TITLE, StdIcon.Error, StdButton.Ok ).execute();
      }
   }
}

} // class WriteJPEGDialog

// ============================================================================
// STF functions
// ============================================================================

function ApplySTF( view, stf )
{
   // STF format: [midtones, shadows, highlights, lowClip, highClip]
   // Average across R,G,B channels for a combined stretch
   let low = (stf[0][1] + stf[1][1] + stf[2][1]) / 3;  // shadows
   let mtf = (stf[0][0] + stf[1][0] + stf[2][0]) / 3;  // midtones
   let hgh = (stf[0][2] + stf[1][2] + stf[2][2]) / 3;  // highlights

   Console.writeln( "low " + low );
   Console.writeln( "mtf " + mtf );
   Console.writeln( "hgh " + hgh );

   if ( low > 0 || mtf != 0.5 || hgh != 1 )
   {
      Console.writeln( "Applying STF to '" + view.id + "':" );
      let HT = new HistogramTransformation;
      HT.H = [
         [   0, 0.5,  1, 0, 1 ],
         [   0, 0.5,  1, 0, 1 ],
         [   0, 0.5,  1, 0, 1 ],
         [ low, mtf, hgh, 0, 1 ],
         [   0, 0.5,  1, 0, 1 ]
      ];
      HT.executeOn( view, false );
   }
}

function PrintMat( mat )
{
   for ( let i = 0; i < mat.length; i++ )
   {
      let row = "";
      for ( let j = 0; j < mat[i].length; j++ )
         row += format( "%.8f ", mat[i][j] );
      Console.writeln( row );
   }
}

function ApplyAutoSTF( view, shadowsClipping, targetBackground, isColor )
{
   let P = new ScreenTransferFunction();
   let n = isColor ? 3 : 1;
   let median = view.computeOrFetchProperty( "Median" );
   let mad    = view.computeOrFetchProperty( "MAD" );
   mad.mul( 1.4826 );

   let c0 = 0, m = 0;
   for ( let c = 0; c < n; ++c )
   {
      if ( 1 + mad.at(c) != 1 )
         c0 += median.at(c) + shadowsClipping * mad.at(c);
      m += median.at(c);
   }
   c0 = Math.range( c0/n, 0.0, 1.0 );
   m  = Math.mtf( targetBackground, m/n - c0 );

   P.STF = [ [c0, 1, m, 0, 1], [c0, 1, m, 0, 1], [c0, 1, m, 0, 1], [0, 1, 0.5, 0, 1] ];
   P.executeOn( view );
}

// ============================================================================
// Main
// ============================================================================

function main()
{
   let dialog = new WriteJPEGDialog();
   dialog.execute();
}

main();
