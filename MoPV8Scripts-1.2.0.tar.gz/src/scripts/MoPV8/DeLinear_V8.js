#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Hartmut V. Bornemann.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; replaced all
// .prototype. enum references with direct class access; added dialog with
// view selector, linked/unlinked STF option, explanation panel, and New
// Instance button.
// ----------------------------------------------------------------------------

/*

DeLinear.js: Transform linear image to a non-linear form
================================================================================

A simple script to transform a linear image into a non-linear (stretched) form.
This script makes the following steps:

    * Apply AutoSTF if no STF is already set on the image
    * Transfer the STF to a HistogramTransformation
    * Apply the HistogramTransformation to permanently stretch the image
    * Apply AutoSTF to the result for display

================================================================================
 *
 * Copyright (C) 2016, Hartmut V. Bornemann
 *
 * 28.01.2020 changed to version 2.0.2, skip initial STF, if stf applied before
 * 24.11.2017 changed to version 2.0.0
 * function ApplyAutoSTF taken from the AutoSTF script
 *
 * 2026-07-08 V8 port with dialog by Pete Proulx, Masters of PixInsight
 */

#feature-id    MoP V8 > DeLinear
#define VERSION "2.1.0"

#feature-info  Permanently applies the ScreenTransferFunction to stretch a linear image into non-linear form.<br/>\
   Copyright (C) 2016, Hartmut V. Bornemann. V8 port by Pete Proulx, Masters of PixInsight.

// Shadows clipping point in (normalized) MAD units from the median.
#define DEFAULT_AUTOSTRETCH_SCLIP  -2.80
// Target mean background in the [0,1] range.
#define DEFAULT_AUTOSTRETCH_TBGND   0.25

// ============================================================================
// Dialog
// ============================================================================

class DeLinearDialog extends Dialog
{
constructor()
{
   super();

   var dlg = this;

   // ---- Title ----
   this.titleLabel = new Label( this );
   this.titleLabel.text = "De-Linearize Image";
   this.titleLabel.textAlignment = TextAlignment.Center;
   this.titleLabel.styleSheet = "font-weight: bold; font-size: 15px; padding: 6px;";

   this.websiteLabel = new Label( this );
   this.websiteLabel.text = "www.mastersofpixinsight.com";
   this.websiteLabel.textAlignment = TextAlignment.Center;
   this.websiteLabel.styleSheet = "font-size: 11px; padding: 2px;";

   // ---- Explanation ----
   this.explanationBox = new GroupBox( this );
   this.explanationBox.title = "What This Script Does";
   this.explanationBox.titleCheckBox = false;

   this.explanationText = new Label( this );
   this.explanationText.text =
      "De-Linearize permanently stretches a linear image into a non-linear (display-ready) form.\n\n" +
      "When to use it:\n" +
      "  \u2022  Your image is a calibrated, integrated linear master\n" +
      "  \u2022  You want a quick, one-click stretch using the same algorithm as ScreenTransferFunction\n" +
      "  \u2022  You are working on a mono channel (L, R, G, B, Ha, OIII, SII)\n\n" +
      "What it does:\n" +
      "  1. Detects if a ScreenTransferFunction (STF) is already applied to the image\n" +
      "  2. If not, automatically computes and applies an AutoSTF\n" +
      "  3. Transfers the STF parameters into a HistogramTransformation\n" +
      "  4. Permanently applies the HistogramTransformation to the image";
   this.explanationText.wordWrapping = true;
   this.explanationText.textAlignment = TextAlignment.Left;
   this.explanationText.styleSheet = "padding: 6px; line-height: 1.4;";

   var explanationSizer = new VerticalSizer;
   explanationSizer.margin = 6;
   explanationSizer.add( this.explanationText );
   this.explanationBox.sizer = explanationSizer;

   // ---- View Selection ----
   this.viewGroupBox = new GroupBox( this );
   this.viewGroupBox.title = "Target Image";
   this.viewGroupBox.titleCheckBox = false;

   this.viewLabel = new Label( this );
   this.viewLabel.text = "Image:";
   this.viewLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
   this.viewLabel.setFixedWidth( 60 );

   this.viewList = new ViewList( this );
   this.viewList.getMainViews();
   this.viewList.toolTip = "Select the linear image to stretch.";
   this.viewList.onViewSelected = ( view ) => {
      dlg.selectedView = view;
      dlg.updateInfo();
   };

   this.viewInfoLabel = new Label( this );
   this.viewInfoLabel.text = "";
   this.viewInfoLabel.styleSheet = "font-style: italic; font-size: 11px; padding: 2px;";

   var viewSizer = new HorizontalSizer;
   viewSizer.spacing = 6;
   viewSizer.add( this.viewLabel );
   viewSizer.add( this.viewList );

   var viewMainSizer = new VerticalSizer;
   viewMainSizer.margin = 6;
   viewMainSizer.spacing = 4;
   viewMainSizer.add( viewSizer );
   viewMainSizer.add( this.viewInfoLabel );
   this.viewGroupBox.sizer = viewMainSizer;

   // ---- Options ----
   this.optionsGroupBox = new GroupBox( this );
   this.optionsGroupBox.title = "Options";
   this.optionsGroupBox.titleCheckBox = false;

   this.linkedCheckBox = new CheckBox( this );
   this.linkedCheckBox.text = "Linked RGB channels";
   this.linkedCheckBox.checked = true;
   this.linkedCheckBox.toolTip =
      "<p><b>Checked:</b> All RGB channels are stretched together using a single combined STF. " +
      "Recommended for most color images to maintain color balance.</p>" +
      "<p><b>Unchecked:</b> Each RGB channel gets its own independent stretch. " +
      "Useful for narrowband or images with strong color imbalance.</p>";

   var optionsSizer = new VerticalSizer;
   optionsSizer.margin = 6;
   optionsSizer.spacing = 4;
   optionsSizer.add( this.linkedCheckBox );
   this.optionsGroupBox.sizer = optionsSizer;

   // ---- Buttons ----
   this.newInstanceButton = new ToolButton( this );
   this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
   this.newInstanceButton.setScaledFixedSize( 24, 24 );
   this.newInstanceButton.toolTip = "New Instance — drag to save current settings.";
   this.newInstanceButton.onMousePress = () => {
      dlg.saveParameters();
      dlg.newInstance();
   };

   this.okButton = new PushButton( this );
   this.okButton.text = "Apply";
   this.okButton.icon = this.scaledResource( ":/icons/ok.png" );
   this.okButton.defaultButton = true;
   this.okButton.styleSheet = "font-weight: bold;";
   this.okButton.onClick = () => { dlg.ok(); };

   this.cancelButton = new PushButton( this );
   this.cancelButton.text = "Cancel";
   this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
   this.cancelButton.onClick = () => { dlg.cancel(); };

   var buttonsSizer = new HorizontalSizer;
   buttonsSizer.spacing = 8;
   buttonsSizer.add( this.newInstanceButton );
   buttonsSizer.addStretch();
   buttonsSizer.add( this.okButton );
   buttonsSizer.add( this.cancelButton );

   // ---- Main layout ----
   this.sizer = new VerticalSizer;
   this.sizer.margin  = 10;
   this.sizer.spacing = 8;
   this.sizer.add( this.titleLabel );
   this.sizer.add( this.websiteLabel );
   this.sizer.add( this.explanationBox );
   this.sizer.add( this.viewGroupBox );
   this.sizer.add( this.optionsGroupBox );
   this.sizer.add( buttonsSizer );

   this.windowTitle = "De-Linearize Image — Masters of PixInsight";
   this.adjustToContents();
   this.setFixedWidth();

   // Initialize
   this.selectedView = this.viewList.currentView;
   this.loadParameters();
   this.updateInfo();
}

updateInfo()
{
   if ( this.selectedView == null || this.selectedView.isNull )
   {
      this.viewInfoLabel.text = "No image selected.";
      this.okButton.enabled = false;
      return;
   }

   let img = this.selectedView.image;
   let stfSet = false;
   for ( let i = 0; i < this.selectedView.stf.length; i++ )
      if ( this.selectedView.stf[i].toString() !== this.selectedView.stf[0].toString() )
         stfSet = true;

   let stfStatus = stfSet ? "\u2705 STF already applied \u2014 will use existing STF" :
                            "\u26a0\ufe0f No STF set \u2014 AutoSTF will be computed";

   this.viewInfoLabel.text =
      img.width + " \xd7 " + img.height + " px  \u2022  " +
      ( img.isColor ? "RGB Color" : "Grayscale" ) + "  \u2022  " +
      img.bitsPerSample + "-bit  \u2022  " + stfStatus;

   this.okButton.enabled = true;
}

saveParameters()
{
   Parameters.set( "linkedRGB", this.linkedCheckBox.checked );
}

loadParameters()
{
   if ( Parameters.has( "linkedRGB" ) )
      this.linkedCheckBox.checked = Parameters.getBoolean( "linkedRGB" );
}

} // class DeLinearDialog

// ============================================================================
// Processing
// ============================================================================

function deLinearize( view, linkedRGB )
{
   Console.show();
   Console.writeln( "<end><cbr><br><b>De-Linearize: " + view.fullId + "</b>" );
   Console.flush();

   // Detect if STF already set on the view
   let stfApplied = false;
   for ( let i = 1; i < view.stf.length; i++ )
      if ( view.stf[i].toString() !== view.stf[0].toString() )
         stfApplied = true;

   Console.writeln( "STF already applied: " + stfApplied );

   // Compute AutoSTF if not already set
   if ( !stfApplied )
   {
      Console.writeln( "Computing AutoSTF..." );
      ApplyAutoSTF( view, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, linkedRGB );
   }

   // Read the STF values we need for the histogram
   let c0 = view.stf[0][1];
   let m  = view.stf[0][0];

   Console.writeln( format( "Shadows clipping: %.6f", c0 ) );
   Console.writeln( format( "Midtones balance: %.6f", m ) );

   // Clear the STF so the stretched image displays at its true pixel values
   let neutralSTF = new ScreenTransferFunction();
   neutralSTF.executeOn( view );

   // Apply permanent histogram stretch
   let HT = new HistogramTransformation;
   HT.H = [ [ 0, 0.5, 1.0, 0, 1.0 ],
             [ 0, 0.5, 1.0, 0, 1.0 ],
             [ 0, 0.5, 1.0, 0, 1.0 ],
             [ c0,  m, 1.0, 0, 1.0 ],
             [ 0, 0.5, 1.0, 0, 1.0 ] ];

   view.beginProcess();
   HT.executeOn( view.image );
   view.endProcess();

   Console.writeln( "<b>De-Linearize complete.</b>" );
}

// ============================================================================
// AutoSTF
// ============================================================================

function ApplyAutoSTF( view, shadowsClipping, targetBackground, rgbLinked )
{
   let P = new ScreenTransferFunction();
   let n = view.image.isColor ? 3 : 1;
   let median = view.computeOrFetchProperty( "Median" );
   let mad = view.computeOrFetchProperty( "MAD" );
   mad.mul( 1.4826 );

   if ( rgbLinked )
   {
      let invertedChannels = 0;
      for ( let c = 0; c < n; ++c )
         if ( median.at( c ) > 0.5 )
            ++invertedChannels;

      if ( invertedChannels < n )
      {
         let c0 = 0, m = 0;
         for ( let c = 0; c < n; ++c )
         {
            if ( 1 + mad.at( c ) != 1 )
               c0 += median.at( c ) + shadowsClipping * mad.at( c );
            m += median.at( c );
         }
         c0 = Math.range( c0/n, 0.0, 1.0 );
         m = Math.mtf( targetBackground, m/n - c0 );
         P.STF = [ [c0, 1, m, 0, 1], [c0, 1, m, 0, 1], [c0, 1, m, 0, 1], [0, 1, 0.5, 0, 1] ];
      }
      else
      {
         let c1 = 0, m = 0;
         for ( let c = 0; c < n; ++c )
         {
            m += median.at( c );
            if ( 1 + mad.at( c ) != 1 )
               c1 += median.at( c ) - shadowsClipping * mad.at( c );
            else
               c1 += 1;
         }
         c1 = Math.range( c1/n, 0.0, 1.0 );
         m = Math.mtf( c1 - m/n, targetBackground );
         P.STF = [ [0, c1, m, 0, 1], [0, c1, m, 0, 1], [0, c1, m, 0, 1], [0, 1, 0.5, 0, 1] ];
      }
   }
   else
   {
      let A = [ [0,1,0.5,0,1], [0,1,0.5,0,1], [0,1,0.5,0,1], [0,1,0.5,0,1] ];
      for ( let c = 0; c < n; ++c )
      {
         if ( median.at( c ) < 0.5 )
         {
            let c0 = (1 + mad.at(c) != 1) ? Math.range(median.at(c) + shadowsClipping * mad.at(c), 0.0, 1.0) : 0.0;
            let m  = Math.mtf( targetBackground, median.at(c) - c0 );
            A[c] = [c0, 1, m, 0, 1];
         }
         else
         {
            let c1 = (1 + mad.at(c) != 1) ? Math.range(median.at(c) - shadowsClipping * mad.at(c), 0.0, 1.0) : 1.0;
            let m  = Math.mtf( c1 - median.at(c), targetBackground );
            A[c] = [0, c1, m, 0, 1];
         }
      }
      P.STF = A;
   }

   P.executeOn( view );
}

// ============================================================================
// Main
// ============================================================================

function main()
{
   let dialog = new DeLinearDialog();

   if ( dialog.execute() )
   {
      let view = dialog.selectedView;
      let linkedRGB = dialog.linkedCheckBox.checked;

      if ( view == null || view.isNull )
      {
         new MessageBox( "No image selected.", "DeLinear", StdIcon.Error, StdButton.Ok ).execute();
         return;
      }

      deLinearize( view, linkedRGB );
   }
}

main();
