// ****************************************************************************
// PixInsight JavaScript Runtime API - PJSR Version 1.0
// ****************************************************************************
// SHO-AIP.js - Released 2020/05/27
// ****************************************************************************
//
// This file is part of SHO-AIP Script version 1.2.6
//
// Copyright (C) 2013-2020 Laurent Bourgon, Philippe Bernhard & Dave Watson.
// All Rights Reserved. Website: http://www.felopaul.com/pix.htm
//
// Redistribution and use in both source and binary forms, with or without
// modification, is permitted provided that the following conditions are met:
//
// 1. All redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//
// 2. All redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// 3. Neither the names "PixInsight" and "Pleiades Astrophoto", nor the names
//    of their contributors, may be used to endorse or promote products derived
//    from this software without specific prior written permission. For written
//    permission, please contact info@pixinsight.com.
//
// 4. All products derived from this software, in any form whatsoever, must
//    reproduce the following acknowledgment in the end-user documentation
//    and/or other materials provided with the product:
//
//    "This product is based on software from the PixInsight project, developed
//    by Pleiades Astrophoto and its contributors (http://pixinsight.com/)."
//
//    Alternatively, if that is where third-party acknowledgments normally
//    appear, this acknowledgment must be reproduced in the product itself.
//
// THIS SOFTWARE IS PROVIDED BY PLEIADES ASTROPHOTO AND ITS CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL PLEIADES ASTROPHOTO OR ITS
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, BUSINESS
// INTERRUPTION; PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; AND LOSS OF USE,
// DATA OR PROFITS) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
// ****************************************************************************

/******************************************************************************
 * SHO-AIP.js version 1.2.6 (May 2020)
 *
 * This script allows SHONRVB to be mixed with a L using the optional AIP Method
 *
 * Changelog:
 * 1.2.6	Fix bug
 * 1.2.3  - 1.2.5 Fix Bug Liminance
 * 1.2.1  - 1.2.2 Fix bug restart
 * 1.2.0	Revised GUI layout and operation
 * 1.1.1  - 1.1.4 Development/bug fix releases
 * 1.1.0  - Refactoring to PI current standards
 * 1.0.12 - Bug fixes
 * 1.0.11 - Bug fixes
 * 1.0.10 - PTeam changes for PI core version 1.8.0
 *
 *****************************************************************************/

#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Laurent Bourgon,
// Philippe Bernhard & Dave Watson. No rights to the original work are
// claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; removed all
// #include <pjsr/...> directives (PJSR globals available without them);
// inlined the contents of gbr.jsh directly (it was a local, non-PJSR
// #include "gbr.jsh" for the English UI text -- TEXT1-30, ERROR1,
// VERSION_SHO -- rather than a built-in header, so the script now stands
// on its own instead of depending on a second file. The original file
// also offered a French fra.jsh variant; ask before assuming this is the
// one you want.); converted parametersDialog from __base__/.prototype =
// new Dialog to class extends Dialog / super(); replaced 18 .prototype.
// enum references (ACDNR, BackgroundNeutralization, PixelMath, SCNR) with
// direct class access; replaced underscore constants with dot notation
// (TextAlign_* -> TextAlignment.*, FrameStyle_Box -> FrameStyle.Box,
// StdIcon_Warning -> StdIcon.Warning, StdButton_Ok -> StdButton.Ok,
// UndoFlag_NoSwapFile -> UndoFlag.NoSwapFile, StdCursor_* -> StdCursor.*,
// SampleType_Real -> raw integer 1 (float; SampleType namespace doesn't
// exist in V8 -- fixed a mistake here after user testing caught it, see
// the 2026-07-26 note below), DataType_Float -> DataType.Float);
// replaced 8 uses of standalone Align_Center with the raw integer 4
// (Align namespace doesn't exist in V8) -- note these 8 lines assign to
// `.setAlignment` as a property rather than calling it as a method, so
// they were already dead code in the original script and remain so here;
// removed one deprecated bare gc() call; fixed both OpenFileDialog.fileName
// and SaveFileDialog.fileName (deprecated) to .filePath. No with()
// statements or TreeBoxNode usage were present.
//
// 2026-07-26: three fixes found via user testing. (1) A mistake in the
// initial port: SampleType_Real was converted to SampleType.Real, but
// per the rulebook SampleType doesn't exist as a namespace in V8 -- it
// needed to be the raw integer 1 (float), not a dotted constant; fixed.
// (2) TreeBoxNode-unrelated: 8 sizers assigned to .setAlignment as a
// property rather than calling it as a method -- read-only in V8, so
// this now throws instead of silently doing nothing; removed those 8
// lines rather than making them functional, to keep the dialog's
// appearance identical to the original (unless you'd rather they
// actually centered things -- easy to change either way). (3)
// ImageWindow.viewportToImage() no longer accepts a Rect directly in V8
// ("numeric value expected"); only the (Number x, Number y) point
// overload is exposed, so imageRect() now transforms each corner
// separately and rebuilds the Rect.
// ----------------------------------------------------------------------------

#feature-id    Multichannel Synthesis > SHO-AIP : MoP V8 > SHO-AIP
#feature-info A Multichannel Synthesis utility.<br/>\
	<br/>\
	This script allows the mixing SHO with an L using the optional AIP Method.\
	<br/>\
	Copyright &copy; 2013-2020 Laurent Bourgon, Philippe Bernhard & Dave Watson. All Rights Reserved.

#feature-icon  aip.xpm

// ----------------------------------------------------------------------------
// Inlined from gbr.jsh (English UI text), so this script is self-contained
// ----------------------------------------------------------------------------
#define VERSION_SHO   "v1.2.6"

#define ERROR1 "\n<b>Error:</b> no active layer"
#define TEXT1  "Mix SHONRVB To RGB Channels"
#define TEXT2  "Select Images and Mix"
#define TEXT3  "Window Preview Control"
#define TEXT4  "Blue Channel --- % SII : "
#define TEXT5  "Green Channel -- % SII : "
#define TEXT6  "Red Channel --- % SII : "
#define TEXT7  "Create Luminance Image"
#define TEXT8  "Mixing L-SHONRVB Parameters"
#define TEXT9  "Background Auto Equalise"
#define TEXT10 "Mixing with Rescale"
#define TEXT11 "Chroma Noise Reduction"
#define TEXT12 "Noise It: "
#define TEXT13 "Mixing with AIP Method"
#define TEXT14 "Mix L-SHONRVB"
#define TEXT15 "Mix SHONRVB"
#define TEXT16 ""
#define TEXT17 ""
#define TEXT18 "New Image"
#define TEXT19 "same image selected!"
#define TEXT20 "Frame L (Gray mode)"
#define TEXT21 "Frame RGB (RGB Mode)"
#define TEXT22 "Mixing L with RGB (AIP Method)"
#define TEXT23 "Mixing HA with RGB (AIP Method)"
#define TEXT24 "Image Ha (Gray mode)"
#define TEXT25 "% Ha in R Chanel : "
#define TEXT26 "% R in Ha Chanel : "
#define TEXT27 "Remove Pink Halos"
#define TEXT28 "Zoom To Fit"
#define TEXT29 ""
#define TEXT30 ""

// Run Time Options
#define DEBUG false
#define PRELOAD_SHONRVB_IMAGES true		// If true pre-loads images starting with S,H,O,N,R,V,G or B
#define REMOVE_PINK_HALOS true			// If true enables Remove Pink Halos button

#define TITLE  "SHO-AIP"
#define DEFAULT_TB_MARGIN 10
#define DEFAULT_RL_MARGIN 10
#define DEFAULT_BORDER_WIDTH 1

#define SHADOWS_CLIP -1.25
#define TARGET_BKG    0.25

#define RANGE_P  200      				//  200% normal  2000% for Nicolat?

function findMidtonesBalance( v0, v1, eps ) {
	if ( v1 <= 0 )
		return 0;

	if ( v1 >= 1 )
		return 1;

	v0 = Math.range( v0, 0.0, 1.0 );

	if ( eps )
		eps = Math.max( 1.0e-15, eps );
	else
		eps = 5.0e-05;

	var m0, m1;
	if ( v1 < v0 ) {
		m0 = 0;
		m1 = 0.5;
	} else {
		m0 = 0.5;
		m1 = 1;
	}

   for ( ;; ) {
		var m = (m0 + m1)/2;
		var v = Math.mtf( m, v1 );

		if ( Math.abs( v - v0 ) < eps )
			return m;

		if ( v < v0 )
			m1 = m;
		else
			m0 = m;
	}
}

function SHO_AIP() {		// engine object
   if(DEBUG) Console.writeln('DEBUG:SHO_AIP');
   this.RGBView = ImageWindow.activeWindow.mainView;
   this.L1 		= new ImageWindow();
   this.L2 		= new ImageWindow();
   this.L3 		= new ImageWindow();

   if(this.RGBView.image.width==0) {
         var msg = new MessageBox( "No target images are available", "Warning", StdIcon.Warning, StdButton.Ok );
         msg.execute();
   } else {
	   this.DialogPreview= new ImageWindow(this.RGBView.image.width,
                  this.RGBView.image.height,
                  3,
                  32,
                  true,
                  true,
                  "MIXSHO_AIP_DIALOG");

	   this.DialogPreview.mainView.beginProcess(UndoFlag.NoSwapFile);
	   this.DialogPreview.mainView.image.fill( 0 );
	   this.DialogPreview.mainView.endProcess();
	   this.DialogPreview.hide();

	   this.Preview= new ImageWindow(this.RGBView.image.width,
			   this.RGBView.image.height,
			   3,
			   32,
			   true,
			   true,
	   		   "MIXSHO_AIP");

      this.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
      this.Preview.mainView.image.fill( 0 );
      this.Preview.mainView.endProcess();
      this.Preview.zoomFactor=12;
      this.Preview.fitWindow();
      this.Preview.zoomToOptimalFit();
      this.Preview.hide();
   }

   this.NewPic= function() {
      this.RGBView= ImageWindow.activeWindow.mainView;

      this.DialogPreview= new ImageWindow(this.RGBView.image.width,
              this.RGBView.image.height,
              3,
              32,
              true,
              true,
              "MIXSHO_AIP_DIALOG");

      this.Preview= new ImageWindow(this.RGBView.image.width,
                                    this.RGBView.image.height,
                                    3,
                                    32,
                                    true,
                                    true,
                                    "MIXSHO_AIP");

      this.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
      this.Preview.mainView.image.fill( 0 );
      this.Preview.mainView.endProcess();
      this.Preview.zoomFactor=12;
      this.Preview.fitWindow();
      this.Preview.zoomToOptimalFit();
      this.Preview.show();
   }

   this.formule2C = new Array();
   this.formule2C["Darken"] = "Min( (IMG1 * K1), (IMG2 * K2) )";
   this.formule2C["Multiply"] = "(IMG1 * K1) * (IMG2 * K2)";
   this.formule2C["Lighten"] = "Max( (IMG1 * K1), (IMG2 * K2) )";
   this.formule2C["Screen"] = "~(~(IMG1 * K1) * ~(IMG2 * K2))";
   this.formule2C["Overlay"] = "iif( (IMG1 * K1) > 0.5, ~(~(2*((IMG1 * K1) - 0.5)) * ~(IMG2 * K2)), 2*(IMG1 * K1)*(IMG2 * K2) )";
   this.formul2C = this.formule2C["Darken"];

   this.formule3C = new Array();
   this.formule3C["Darken"] = "Min( (IMG1 * K1) , (IMG2 * K2), (IMG3 * K3) )";
   this.formule3C["Lighten"] = "Max( (IMG1 * K1), (IMG2 * K2),(IMG3 * K3) )";
   this.formule3C["Screen"] = "~(~(IMG1 * K1) * ~(IMG2 * K2) * ~(IMG3 * K3))";
   this.formule3C["Average"] = "Avg( (IMG1 * K1), (IMG2 * K2),(IMG3 * K3) )";
   this.formule3C["Non Use"] = ""; // to have same number than 2C
   this.formul3C = this.formule3C["Darken"];

   this.Last_Mix = 0;

   var workspace_windows = ImageWindow.windows;
   maxID=0;
   this.List_ID = new Array();
   for ( var j = 0; j < workspace_windows.length; ++j ) {
	   if(this.Preview.mainView.id != workspace_windows[j].mainView.id && workspace_windows[j].mainView.id.search("MIXSHO_AIP")==-1)
      {
         this.List_ID[maxID]= workspace_windows[j].mainView.id;
         maxID++;
      }
   }
};

var engine = new SHO_AIP;

class parametersDialog extends Dialog
{
constructor()
{
   super();

   this.windowTitle = TITLE + ' ' + VERSION_SHO;

   var labelWidth1 = this.font.width( "---------------------------------" + 'T' );

   function ApplyAutoSTF( view, shadowsClipping, targetBackground, rgbLinked ) {
	   if(DEBUG) Console.writeln( "DEBUG:ApplyAutoSTF-"+view.fullId );
      var stf = new ScreenTransferFunction;

      var n = view.image.isColor ? 3 : 1;

      if ( rgbLinked ) {
         /*
          * Try to find how many channels look as channels of an inverted image.
          * We know a channel has been inverted because the main histogram peak is
          * located over the right-hand half of the histogram. Seems simplistic
          * but this is consistent with astronomical images.
          */
         var invertedChannels = 0;
         for ( var c = 0; c < n; ++c )
         {
            view.image.selectedChannel = c;
            if ( view.image.median() > 0.5 )
               ++invertedChannels;
         }
         view.image.resetSelections();

         if ( invertedChannels < n ) {
            // Noninverted image
            var c0 = 0;
            var m = 0;
            for ( var c = 0; c < n; ++c ) {
               view.image.selectedChannel = c;
               var median = view.image.median();
               var avgDev = view.image.avgDev();
               c0 += median + shadowsClipping*avgDev;
               m  += median;
            }
            view.image.resetSelections();
            c0 = Math.range( c0/n, 0.0, 1.0 );
            m = findMidtonesBalance( targetBackground, m/n - c0 );

            stf.STF = [ // c0, c1, m, r0, r1
                        [c0, 1, m, 0, 1],
                        [c0, 1, m, 0, 1],
                        [c0, 1, m, 0, 1],
                        [0, 1, 0.5, 0, 1] ];
         } else {
            // Inverted image
            var c1 = 0;
            var m = 0;
            for ( var c = 0; c < n; ++c ) {
               view.image.selectedChannel = c;
               var median = view.image.median();
               var avgDev = view.image.avgDev();
               m  += median;
               c1 += median - shadowsClipping*avgDev;
            }
            view.image.resetSelections();
            c1 = Math.range( c1/n, 0.0, 1.0 );
            m = 1 - findMidtonesBalance( targetBackground, c1 - m/n );

            stf.STF = [ // c0, c1, m, r0, r1
                        [0, c1, m, 0, 1],
                        [0, c1, m, 0, 1],
                        [0, c1, m, 0, 1],
                        [0, 1, 0.5, 0, 1] ];
         }
      } else {
         var A = [ // c0, c1, m, r0, r1
                  [0, 1, 0.5, 0, 1],
                  [0, 1, 0.5, 0, 1],
                  [0, 1, 0.5, 0, 1],
                  [0, 1, 0.5, 0, 1] ];

         for ( var c = 0; c < n; ++c ) {
            view.image.selectedChannel = c;
            var median = view.image.median();
            var avgDev = view.image.avgDev();

            if ( median < 0.5 ) {
               // Noninverted channel
               var c0 = Math.range( median + shadowsClipping*avgDev, 0.0, 1.0 );
               var m  = findMidtonesBalance( targetBackground, median - c0 );
               A[c] = [c0, 1, m, 0, 1];
            } else {
               // Inverted channel
               var c1 = Math.range( median - shadowsClipping*avgDev, 0.0, 1.0 );
               var m  = 1 - findMidtonesBalance( targetBackground, c1 - median() );
               A[c] = [0, c1, m, 0, 1];
            }
         }

         stf.STF = A;
         view.image.resetSelections();
      }

      Console.writeln( "<end><cbr/><br/><b>", view.fullId, "</b>:" );
      for ( var c = 0; c < n; ++c ) {
         Console.writeln( "channel #", c );
         Console.writeln( format( "c0 = %.6f", stf.STF[c][0] ) );
         Console.writeln( format( "m  = %.6f", stf.STF[c][2] ) );
         Console.writeln( format( "c1 = %.6f", stf.STF[c][1] ) );
      }

      stf.executeOn( view );
      Console.writeln( "<end><cbr/><br/>" );
   }

   this.applySTF=function( img, stf ) {
	      var HT = new HistogramTransformation;
	      if (img.isColor) {
	         HT.H =	[	[stf[0][1], stf[0][0], stf[0][2], stf[0][3], stf[0][4]],
	                  [stf[1][1], stf[1][0], stf[1][2], stf[1][3], stf[1][4]],
	                  [stf[2][1], stf[2][0], stf[2][2], stf[2][3], stf[2][4]],
	                  [ 0, 0.5, 1, 0, 1]
	               ];
	      } else {
	         HT.H =	[	[ 0, 0.5, 1, 0, 1],
	                  [ 0, 0.5, 1, 0, 1],
	                  [ 0, 0.5, 1, 0, 1],
	                  [stf[0][1], stf[0][0], stf[0][2], stf[0][3], stf[0][4]]
	               ];
	      }

	      if(DEBUG) Console.writeln("R/K: ",  stf[0][0], ",", stf[0][1], ",", stf[0][2], ",", stf[0][3], ",", stf[0][4]);
	      if(DEBUG) Console.writeln("G  : ",  stf[1][0], ",", stf[1][1], ",", stf[1][2], ",", stf[1][3], ",", stf[1][4]);
	      if(DEBUG) Console.writeln("B  : ",  stf[2][0], ",", stf[2][1], ",", stf[2][2], ",", stf[2][3], ",", stf[2][4]);
	      if(DEBUG) Console.writeln("L  : ",  stf[3][0], ",", stf[3][1], ",", stf[3][2], ",", stf[3][3], ",", stf[3][4]);
	      if(DEBUG) Console.writeln("width: ", img.width, " height: ", img.height, " , channels: " , img.numberOfChannels, " , bitsperpixel: ", img.bitsPerSample, " , sample: ", img.sampleType, " ,is color: ", img.isColor);

	      var wtmp = new ImageWindow( img.width, img.height, img.numberOfChannels, img.bitsPerSample, img.sampleType == 1 /* float */, img.isColor, "tmpSTFWindow" );
	      var v = wtmp.mainView;
	      v.beginProcess( UndoFlag.NoSwapFile );
	      v.image.assign( img );
	      v.endProcess();
	      HT.executeOn( v, false ); // no swap file
	      var image=v.image;
	      var result=new Image(	image.width, image.height, image.numberOfChannels, image.colorSpace, image.bitsPerSample, image.sampleType);
	      result.assign(v.image);
	      wtmp.forceClose();
	      return result;
   };

   this.changeLM = function() {
	   var cnt = 0;
	   if(this.L1_ImageList.currentItem != -1) cnt++;
	   if(this.L2_ImageList.currentItem != -1) cnt++;
	   if(this.L3_ImageList.currentItem != -1) cnt++;
	   if(lmCount != cnt) {
		   lmCount = cnt;
		   var key;
		   if(cnt == 2) {
			   this.blendModeComboC.clear();
			   for (key in engine.formule2C) {
				   this.blendModeComboC.addItem(key);
			   }
		   } else if(cnt == 3){
			   this.blendModeComboC.clear();
			   for (key in engine.formule3C) {
				   this.blendModeComboC.addItem(key);
			   }
		   }
	   }
   }

   this.RemovePinkHalos = function () {
	   if(DEBUG) Console.writeln( "DEBUG:Removing Pink Halos" );
	   engine.Preview.hide();
	   this.cursor = new Cursor( StdCursor.ArrowWait);
	   Console.show();
	   var P = new Invert;
	   engine.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
       P.executeOn(engine.Preview.mainView);
       engine.Preview.mainView.endProcess();

	   var P = new SCNR;
	   //P.amount = 0.50;
	   P.amount = 1.00;
	   P.protectionMethod = SCNR.AverageNeutral;
	   P.colorToRemove = SCNR.Green;
	   P.preserveLightness = true;
	   engine.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
       P.executeOn(engine.Preview.mainView);
       engine.Preview.mainView.endProcess();

	   var P = new Invert;
	   engine.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
       P.executeOn(engine.Preview.mainView);
       engine.Preview.mainView.endProcess();

       if(STF) {
    	   if(DEBUG) Console.writeln('DEBUG:Remove Pink Halos:AutoSTF');
    	   ApplyAutoSTF( engine.Preview.mainView, SHADOWS_CLIP, TARGET_BKG,  OPT);

    	   engine.DialogPreviewImageSTF = this.applySTF(engine.Preview.mainView.image,engine.Preview.mainView.stf);
    	   engine.DialogPreview.mainView.beginProcess(UndoFlag.NoSwapFile);
    	   engine.DialogPreview.mainView.image.assign(engine.DialogPreviewImageSTF);
    	   engine.DialogPreview.mainView.endProcess();
       }
       engine.Preview.zoomFactor=12;
       engine.Preview.fitWindow();
       engine.Preview.zoomToOptimalFit();
       engine.Preview.show();
       Console.hide();
       this.cursor = new Cursor( StdCursor.PointingHand);
   }

   this.Calculate_L = function(c) {
	   // Create L image in Preview window
	   if(DEBUG) Console.writeln( "DEBUG:Calculate_L" );

	   if(this.L1_ImageList.currentItem == -1 && this.L2_ImageList.currentItem == -1 &&this.L3_ImageList.currentItem == -1) {
		   var msg = new MessageBox( "You must select at least 2 images", "Warning", StdIcon.Warning, StdButton.Ok );
		   msg.execute();
		   return;
	   }

	   if(lock==0) {
		 if(DEBUG) Console.writeln( "DEBUG:Calculate_L Eq 0" );
		 if(isLuminance) engine.Luminance.hide();
		 engine.Preview.hide();
		 var i = 0;
		 var masterError = false;
		 if(this.L1_ImageList.currentItem >= 0) {
			 if(this.L2_ImageList.currentItem >= 0) {
				 i = 2;
				 if(this.L3_ImageList.currentItem >= 0) {
					 i = 3;
				 }
			 } else {
				 masterError = true;
			 }
		 } else {
			 masterError = true;
		 }
		 if(masterError) {
			 var msg = new MessageBox( "You must select at least 2 images in sequence", "Warning", StdIcon.Warning, StdButton.Ok );
			 msg.execute();
			 return;
		 }

		 lock=1;
         this.cursor = new Cursor( StdCursor.ArrowWait);
         Console.show();
         var scale_L1 = opacityL1/100;
         var scale_L2 = opacityL2/100;
         var FL1 = format("%.2f", scale_L1);
         var FL2 = format("%.2f", scale_L2);

         var FL = "";

         if(i == 3) {
            var scale_L3 = opacityL3/100;
            var FL3 = format("%.2f", scale_L3);
            FL = "K1 = " + FL1 + "; K2 = " + FL2 +"; K3 = " + FL3 +"; IMG1 = " + engine.L1 + "; IMG2 = " + engine.L2 + "; IMG3 = " + engine.L3 + "; " + engine.formul3C  ;
         } else {
            FL = "K1 = " + FL1 + "; K2 = " + FL2 +"; IMG1 = " + engine.L1 + "; IMG2 = " + engine.L2 + "; " + engine.formul2C ;
         }

          var Pix = new PixelMath;
          Pix.expression = FL;
          Pix.expression1 = "";
          Pix.expression2 = "";
          Pix.expression3 = "";
          Pix.useSingleExpression = true;
          Pix.symbols = "IMG1, IMG2, IMG3, K1,K2,K3";
          Pix.use64BitWorkingImage = false;
          Pix.rescale = RES;
          Pix.rescaleLower = 0.0000000000;
          Pix.rescaleUpper = 1.0000000000;
          Pix.truncate = true;
          Pix.truncateLower = 0.0000000000;
          Pix.truncateUpper = 1.0000000000;
          Pix.createNewImage = false;
          Pix.newImageId = "";
          Pix.newImageWidth = 0;
          Pix.newImageHeight = 0;
          Pix.newImageAlpha = false;
          Pix.newImageColorSpace = PixelMath.SameAsTarget;
          Pix.newImageSampleFormat = PixelMath.SameAsTarget;

         var CCol = new ConvertToGrayscale;
         engine.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         if(engine.Preview.mainView.image.colorSpace==1) CCol.executeOn(engine.Preview.mainView);
         Pix.executeOn(engine.Preview.mainView);
         engine.Preview.mainView.endProcess();

         if(!isLuminance) {
        	 isLuminance = true;
        	 engine.Luminance = new ImageWindow(engine.RGBView.image.width,
                     engine.RGBView.image.height,
                     3,
                     32,
                     true,
                     true,
                     "MIX_L_AIP");
        	 this.LImage_ComboBox.addItem("MIX_L_AIP");
         }
         engine.Luminance.mainView.beginProcess(UndoFlag.NoSwapFile);
         engine.Luminance.mainView.image.assign(engine.Preview.mainView.image);
         engine.Luminance.mainView.endProcess();
         engine.Luminance.zoomFactor=12;
         engine.Luminance.fitWindow();
         engine.Luminance.zoomToOptimalFit();
         engine.Luminance.show();
         engine.Last_Mix=2;


         if(STF) {
        	 if(DEBUG) Console.writeln('DEBUG:STF-AutoSTF Preview');
        	 ApplyAutoSTF( engine.Luminance.mainView, SHADOWS_CLIP, TARGET_BKG,  OPT);
        	 ApplyAutoSTF( engine.Preview.mainView, SHADOWS_CLIP, TARGET_BKG,  OPT);

        	 engine.DialogPreviewImageSTF = this.applySTF(engine.Preview.mainView.image,engine.Preview.mainView.stf);
        	 engine.DialogPreview.mainView.beginProcess(UndoFlag.NoSwapFile);
        	 engine.DialogPreview.mainView.image.assign(engine.DialogPreviewImageSTF);
        	 engine.DialogPreview.mainView.endProcess();
         }

         lock=0;
         Console.hide();
         this.cursor = new Cursor( StdCursor.PointingHand);
      } else {
 		 if(DEBUG) Console.writeln( "DEBUG:Calculate_L Eq 1" );
      }
   }

   this.Calculate_SHO = function() {
	   if(DEBUG) Console.writeln( "DEBUG:Calculate_SHO" );
	   if(lock==0) {
		 engine.Preview.hide();
         lock=1;
         engine.Last_Mix=1;
         this.cursor = new Cursor( StdCursor.ArrowWait);
         Console.show();
         var Pix = new PixelMath;
         Pix.expression  = engine.S_Image+"*"+PC_S_DANS_R+"+"+engine.H_Image+"*"+PC_H_DANS_R+"+"+engine.O_Image+"*"+PC_O_DANS_R+"+"+engine.N_Image+"*"+PC_N_DANS_R+"+"+engine.R_Image+"*"+PC_R_DANS_R;
         Pix.expression1 = engine.S_Image+"*"+PC_S_DANS_V+"+"+engine.H_Image+"*"+PC_H_DANS_V+"+"+engine.O_Image+"*"+PC_O_DANS_V+"+"+engine.N_Image+"*"+PC_N_DANS_V+"+"+engine.V_Image+"*"+PC_V_DANS_V;
         Pix.expression2 = engine.S_Image+"*"+PC_S_DANS_B+"+"+engine.H_Image+"*"+PC_H_DANS_B+"+"+engine.O_Image+"*"+PC_O_DANS_B+"+"+engine.N_Image+"*"+PC_N_DANS_B+"+"+engine.B_Image+"*"+PC_B_DANS_B;
         Pix.expression3 = "";
         Pix.useSingleExpression = false;
         Pix.symbols = "";
         Pix.use64BitWorkingImage = false;
         Pix.rescale = RES;
         Pix.rescaleLower = 0.0000000000;
         Pix.rescaleUpper = 1.0000000000;
         Pix.truncate = true;
         Pix.truncateLower = 0.0000000000;
         Pix.truncateUpper = 1.0000000000;
         Pix.createNewImage = false;
         Pix.newImageId = "";
         Pix.newImageWidth = 0;
         Pix.newImageHeight = 0;
         Pix.newImageAlpha = false;
         Pix.newImageColorSpace = PixelMath.RGB;
         Pix.newImageSampleFormat = PixelMath.SameAsTarget;

         var CCol = new ConvertToRGBColor;
         engine.Preview.mainView.beginProcess(UndoFlag.NoSwapFile);
         if(engine.Preview.mainView.image.colorSpace!=1) CCol.executeOn(engine.Preview.mainView);
         Pix.executeOn(engine.Preview.mainView);
         engine.Preview.mainView.endProcess();

         if(BAKN) {
            var BG = new BackgroundNeutralization;
            BG.backgroundReferenceViewId = "";
            BG.backgroundLow = 0.000000;
            BG.backgroundHigh = 0.100000;
            BG.useROI = false;
            BG.roiX0 = 0;
            BG.roiY0 = 0;
            BG.roiX1 = 0;
            BG.roiY1 = 0;
            BG.mode = BackgroundNeutralization.RescaleAsNeeded;
            BG.targetBackground = 0.010000;
            BG.executeOn(engine.Preview.mainView);
         }

         if(STF) {
        	 if(DEBUG) Console.writeln('DEBUG:STF-AutoSTF Preview');
        	 ApplyAutoSTF( engine.Preview.mainView, SHADOWS_CLIP, TARGET_BKG,  OPT);

        	 engine.DialogPreviewImageSTF = this.applySTF(engine.Preview.mainView.image,engine.Preview.mainView.stf);
        	 engine.DialogPreview.mainView.beginProcess(UndoFlag.NoSwapFile);
        	 engine.DialogPreview.mainView.image.assign(engine.DialogPreviewImageSTF);
        	 engine.DialogPreview.mainView.endProcess();
         }

         engine.Preview.zoomFactor=12;
         engine.Preview.fitWindow();
         engine.Preview.zoomToOptimalFit();
         engine.Preview.show();
         lock=0;
         Console.hide();
         this.cursor = new Cursor( StdCursor.PointingHand);
      }
   }

   this.Calculate_L_SHO = function(target_window, S_Image, H_Image, O_Image, N_Image, L_Image, R_Image, V_Image, B_Image) {
	   engine.Preview.hide();
      engine.Last_Mix=1;
	   Console.show();
	   this.cursor = new Cursor( StdCursor.ArrowWait);
	   if(DEBUG) Console.writeln('DEBUG:Calculate_L_SHO');
	   var Pix = new PixelMath;
	   Pix.expression  = S_Image+"*"+PC_S_DANS_R+"+"+H_Image+"*"+PC_H_DANS_R+"+"+O_Image+"*"+PC_O_DANS_R+"+"+N_Image+"*"+PC_N_DANS_R+"+"+R_Image+"*"+PC_R_DANS_R;
	   Pix.expression1 = S_Image+"*"+PC_S_DANS_V+"+"+H_Image+"*"+PC_H_DANS_V+"+"+O_Image+"*"+PC_O_DANS_V+"+"+N_Image+"*"+PC_N_DANS_V+"+"+V_Image+"*"+PC_V_DANS_V;
	   Pix.expression2 = S_Image+"*"+PC_S_DANS_B+"+"+H_Image+"*"+PC_H_DANS_B+"+"+O_Image+"*"+PC_O_DANS_B+"+"+N_Image+"*"+PC_N_DANS_B+"+"+B_Image+"*"+PC_B_DANS_B;
	   Pix.expression3 = "";
	   Pix.useSingleExpression = false;
	   Pix.symbols = "";
	   Pix.use64BitWorkingImage = false;
	   Pix.rescale = RES;
	   Pix.rescaleLower = 0.0000000000;
	   Pix.rescaleUpper = 1.0000000000;
	   Pix.truncate = true;
	   Pix.truncateLower = 0.0000000000;
	   Pix.truncateUpper = 1.0000000000;
	   Pix.createNewImage = false;
	   Pix.newImageId = "";
	   Pix.newImageWidth = 0;
	   Pix.newImageHeight = 0;
	   Pix.newImageAlpha = false;
	   Pix.newImageColorSpace = PixelMath.RGB;
	   Pix.newImageSampleFormat = PixelMath.SameAsTarget;
	   var CCol = new ConvertToRGBColor;
	   var ll = PC_L/100;

	   target_window.mainView.beginProcess(UndoFlag.NoSwapFile);
	   if(target_window.mainView.image.colorSpace!=1) CCol.executeOn(target_window.mainView);
	   Pix.executeOn(target_window.mainView);
	   target_window.mainView.endProcess();

	   if(AIPMIX) {
	      //Console.writeln( "Start Mix HA with RGB  33%" );
	      var P1 = new LRGBCombination;
	      P1.channels = [ 						// enabled, id, k
	    	  [false, "", 1.00000],
	    	  [false, "", 1.00000],
	    	  [false, "", 1.00000],
	    	  [true, L_Image, 0.33000*ll]    	//  33%
	    	];

	      P1.mL = 0.5;
	      P1.mc = 0.5;
	      P1.clipHighlights = true;
	      P1.noiseReduction = false;
	      P1.layersRemoved = 4;
	      P1.layersProtected = 2;

	      target_window.mainView.beginProcess(UndoFlag.NoSwapFile);
	      P1.executeOn(target_window.mainView);
	      target_window.mainView.endProcess();

	      var P2 = new ACDNR;
	      P2.applyToLightness = true;
	      P2.applyToChrominance = true;
	      P2.useMaskL = false;
	      P2.useMaskC = false;
	      P2.sigmaL = 1.5;
	      P2.sigmaC = 2.0;
	      P2.shapeL = 0.50;
	      P2.shapeC = 0.50;
	      P2.amountL = 0.20;
	      P2.amountC = 1.00;
	      P2.iterationsL = Flout_L;
	      P2.iterationsC = Flout_L;
	      P2.prefilterMethodL = ACDNR.None;
	      P2.prefilterMethodC = ACDNR.None;
	      P2.protectionMethodL = ACDNR.WeightedAverage3x3;
	      P2.protectionMethodC = ACDNR.UnweightedAverage3x3;
	      P2.minStructSizeL = 5;
	      P2.minStructSizeC = 5;
	      P2.protectDarkSidesL = false;
	      P2.protectDarkSidesC = true;
	      P2.darkSidesThresholdL = 0.015;
	      P2.darkSidesThresholdC = 0.030;
	      P2.darkSidesOverdriveL = 0.00;
	      P2.darkSidesOverdriveC = 0.00;
	      P2.protectBrightSidesL = false;
	      P2.protectBrightSidesC = true;
	      P2.brightSidesThresholdL = 0.015;
	      P2.brightSidesThresholdC = 0.030;
	      P2.brightSidesOverdriveL = 0.00;
	      P2.brightSidesOverdriveC = 0.00;
	      P2.starProtectionL = true;
	      P2.starProtectionC = true;
	      P2.starThresholdL = 0.030;
	      P2.starThresholdC = 0.030;
	      P2.previewMask = false;
	      P2.maskRemovedWaveletLayers = 1;
	      P2.maskShadowsClipping = 0.00000;
	      P2.maskHighlightsClipping = 1.00000;
	      P2.maskMTF = 0.50000;

	      target_window.mainView.beginProcess(UndoFlag.NoSwapFile);

	      P2.executeOn(target_window.mainView);
	      target_window.mainView.endProcess();

	      var P3 = new LRGBCombination;
	      P3.channels = [ 					// enabled, id, k
	    	  [false, "", 1.00000],
	    	  [false, "", 1.00000],
	    	  [false, "", 1.00000],
	    	  [true, L_Image, 0.66*ll]      // 66%
	    	];

	      P3.mL = 0.5;
	      P3.mc = 0.5;
	      P3.clipHighlights = true;
	      P3.noiseReduction = false;
	      P3.layersRemoved = 4;
	      P3.layersProtected = 2;

	      target_window.mainView.beginProcess(UndoFlag.NoSwapFile);
	      P3.executeOn(target_window.mainView);
	      target_window.mainView.endProcess();

	      var P4 = new ACDNR;
	      P4.applyToLightness = true;
	      P4.applyToChrominance = true;
	      P4.useMaskL = false;
	      P4.useMaskC = false;
	      P4.sigmaL = 1.5;
	      P4.sigmaC = 2.0;
	      P4.shapeL = 0.50;
	      P4.shapeC = 0.50;
	      P4.amountL = 0.20;
	      P4.amountC = 1.00;
	      P4.iterationsL = Flout_L;
	      P4.iterationsC = Flout_L;
	      P4.prefilterMethodL = ACDNR.None;
	      P4.prefilterMethodC = ACDNR.None;
	      P4.protectionMethodL = ACDNR.WeightedAverage3x3;
	      P4.protectionMethodC = ACDNR.UnweightedAverage3x3;
	      P4.minStructSizeL = 5;
	      P4.minStructSizeC = 5;
	      P4.protectDarkSidesL = false;
	      P4.protectDarkSidesC = true;
	      P4.darkSidesThresholdL = 0.015;
	      P4.darkSidesThresholdC = 0.030;
	      P4.darkSidesOverdriveL = 0.00;
	      P4.darkSidesOverdriveC = 0.00;
	      P4.protectBrightSidesL = false;
	      P4.protectBrightSidesC = true;
	      P4.brightSidesThresholdL = 0.015;
	      P4.brightSidesThresholdC = 0.030;
	      P4.brightSidesOverdriveL = 0.00;
	      P4.brightSidesOverdriveC = 0.00;
	      P4.starProtectionL = true;
	      P4.starProtectionC = true;
	      P4.starThresholdL = 0.030;
	      P4.starThresholdC = 0.030;
	      P4.previewMask = false;
	      P4.maskRemovedWaveletLayers = 1;
	      P4.maskShadowsClipping = 0.00000;
	      P4.maskHighlightsClipping = 1.00000;
	      P4.maskMTF = 0.50000;

	      target_window.mainView.beginProcess(UndoFlag.NoSwapFile);
	      P4.executeOn(target_window.mainView);
	      target_window.mainView.endProcess();
	   }	// if AIPMIX

	   var P5 = new LRGBCombination;
	   P5.channels = [ 						// enabled, id, k
	    [false, "", 1.00000],
	    [false, "", 1.00000],
	    [false, "", 1.00000],
	    [true, L_Image, 1.0*ll]           	// 100%
	   ];
	   P5.mL = lightness;
	   P5.mc = saturation;
	   P5.clipHighlights = true;
	   P5.noiseReduction = noiser;
	   P5.layersRemoved = smoothed;
	   P5.layersProtected = protectedw;

	   target_window.mainView.beginProcess(UndoFlag.NoSwapFile);
	   P5.executeOn(target_window.mainView);
	   target_window.mainView.endProcess();

       if(BAKN) {
           var BG = new BackgroundNeutralization;
           BG.backgroundReferenceViewId = "";
           BG.backgroundLow = 0.000000;
           BG.backgroundHigh = 0.100000;
           BG.useROI = false;
           BG.roiX0 = 0;
           BG.roiY0 = 0;
           BG.roiX1 = 0;
           BG.roiY1 = 0;
           BG.mode = BackgroundNeutralization.RescaleAsNeeded;
           BG.targetBackground = 0.010000;
           BG.executeOn(target_window.mainView);
       }

	   if(STF) {
		 if(DEBUG) Console.writeln('DEBUG:STF-AutoSTF Preview');
      	 ApplyAutoSTF( engine.Preview.mainView, SHADOWS_CLIP, TARGET_BKG,  OPT);

      	 engine.DialogPreviewImageSTF = this.applySTF(engine.Preview.mainView.image,engine.Preview.mainView.stf);
      	 engine.DialogPreview.mainView.beginProcess(UndoFlag.NoSwapFile);
      	 engine.DialogPreview.mainView.image.assign(engine.DialogPreviewImageSTF);
      	 engine.DialogPreview.mainView.endProcess();
       }

       engine.Preview.zoomFactor=12;
       engine.Preview.fitWindow();
       engine.Preview.zoomToOptimalFit();
       engine.Preview.show();
	   Console.hide();
	   this.cursor = new Cursor( StdCursor.PointingHand);
   }

   this.ScrollControl = new Control( this );
   this.ScrollControl.toolTip = "<p>Control the Preview window (zoom/scroll) using this image</p>";
   var w = engine.Preview.mainView.image.width;
   var h = engine.Preview.mainView.image.height;
   var SizeW=engine.Preview.viewportWidth/2;
   var SizeH=engine.Preview.viewportHeight/2;
   this.ScrollControl.setMinSize( SizeW, SizeH);
   this.ScrollControl.cursor = new Cursor( StdCursor.CirclePlus );
   this.ScrollControl.onPaint = function() {
	   if(!isClosing) {
		   var G = new Graphics( this );
		   G.drawScaledBitmap( this.boundsRect, engine.DialogPreview.mainView.image.render() );
		   G.pen = new Pen( 0xFF00FF00 ); 	//Green
		   G.drawRect( this.imageRect() );
		   G.end()
		   // V8: gc() removed -- deprecated, V8 handles GC automatically
	   }
   }

   this.ScrollControl.dragging = false;
   this.ScrollControl.dragOffset = null;

   this.ScrollControl.onMousePress = function(x,y) {
	   //engine.Preview.setViewport( x*w/SizeW, y*w/SizeW );
	   //this.update();
	   this.dragging = true;
	   this.dragOffset = new Point( x, y );
	   this.dragOffset.sub( this.imageRect().center );
   }

   this.ScrollControl.onMouseMove = function(x,y) {
	   if ( this.dragging ) {
	         var scale = this.scalingFactor();
	         engine.Preview.setViewport( (x - this.dragOffset.x)/scale, (y - this.dragOffset.y)/scale );
	         this.update();
	   	}
   }

   this.ScrollControl.onMouseRelease = function() {
      this.dragging = false;
      this.dragOffset = null;
   };

   this.onMouseWheel = function(Dx,Dy, MouseWheel) {
	   if (MouseWheel >0) {
			engine.Preview.zoomOut();
	   } else {
			engine.Preview.zoomIn();
	   }
	   this.ScrollControl.repaint();
   }

   this.ScrollControl.imageRect = function() {
	   // V8 fix: ImageWindow.viewportToImage() no longer accepts a Rect
	   // directly ("Invalid argument type: numeric value expected", found
	   // via testing) -- only the (Number x, Number y) point overload is
	   // exposed. Transform each corner separately and rebuild the Rect.
	   var vr = engine.Preview.visibleViewportRect;
	   var p0 = engine.Preview.viewportToImage( vr.x0, vr.y0 );
	   var p1 = engine.Preview.viewportToImage( vr.x1, vr.y1 );
	   var rect = new Rect( p0.x, p0.y, p1.x, p1.y );
	   rect.mul( this.scalingFactor() );
	   return rect;
   };

   this.ScrollControl.scalingFactor = function() {
	   return Math.sqrt( this.boundsRect.area/engine.Preview.mainView.image.bounds.area );
   };

   this.ScrollControl.updateView = function() {
	   if(DEBUG) Console.writeln( "DEBUG:updateView" );
      var imageWidth = engine.Preview.mainView.image.width;
      var imageHeight = engine.Preview.mainView.image.height;
      var width, height;
      if ( imageWidth > imageHeight ) {
         width = PREVIEW_SIZE;
         height = PREVIEW_SIZE*imageHeight/imageWidth;
      } else {
         width = PREVIEW_SIZE*imageWidth/imageHeight;
         height = PREVIEW_SIZE;
      }
      this.setFixedSize( width, height );
      this.kw = 1/imageWidth*width;
      this.kh = 1/imageHeight*height;
      this.update();
      this.dialog.adjustToContents();
   };

   this.ScrollControl.updateView( engine.Preview.mainView );

   ////  LUMI Selector

   engine.L_Image = engine.List_ID[0];
   engine.S_Image = engine.List_ID[0];
   engine.H_Image = engine.List_ID[0];
   engine.O_Image = engine.List_ID[0];
   engine.N_Image = engine.List_ID[0];
   engine.R_Image = engine.List_ID[0];
   engine.V_Image = engine.List_ID[0];
   engine.B_Image = engine.List_ID[0];

   this.L1_ImageList = new ComboBox( this );
   this.L2_ImageList = new ComboBox( this );
   this.L3_ImageList = new ComboBox( this );
   this.LImage_ComboBox = new ComboBox( this );
   this.SImage_ComboBox = new ComboBox( this );
   this.OImage_ComboBox = new ComboBox( this );
   this.HImage_ComboBox = new ComboBox( this );
   this.NImage_ComboBox = new ComboBox( this );
   this.RImage_ComboBox = new ComboBox( this );
   this.VImage_ComboBox = new ComboBox( this );
   this.BImage_ComboBox = new ComboBox( this );

   for ( var j = 0; j < maxID; ++j )
   {
	  this.L1_ImageList.addItem( engine.List_ID[j] );
      this.L2_ImageList.addItem( engine.List_ID[j] );
      this.L3_ImageList.addItem( engine.List_ID[j] );
      this.LImage_ComboBox.addItem( engine.List_ID[j] );
      this.SImage_ComboBox.addItem( engine.List_ID[j] );
      this.HImage_ComboBox.addItem( engine.List_ID[j] );
      this.OImage_ComboBox.addItem( engine.List_ID[j] );
      this.NImage_ComboBox.addItem( engine.List_ID[j] );
      this.RImage_ComboBox.addItem( engine.List_ID[j] );
      this.VImage_ComboBox.addItem( engine.List_ID[j] );
      this.BImage_ComboBox.addItem( engine.List_ID[j] );
   }

   this.L1_ImageList.onItemSelected = function(j) {engine.L1 = engine.List_ID[j]; this.parent.parent.changeLM();}
   this.L2_ImageList.onItemSelected = function(j) {engine.L2 = engine.List_ID[j]; this.parent.parent.changeLM();}
   this.L3_ImageList.onItemSelected = function(j) {engine.L3 = engine.List_ID[j]; this.parent.parent.changeLM();}
   this.LImage_ComboBox.onItemSelected = function(j) { engine.L_Image = engine.List_ID[j]; }
   this.SImage_ComboBox.onItemSelected = function(j) { engine.S_Image = engine.List_ID[j]; }
   this.HImage_ComboBox.onItemSelected = function(j) { engine.H_Image = engine.List_ID[j]; }
   this.OImage_ComboBox.onItemSelected = function(j) { engine.O_Image = engine.List_ID[j]; }
   this.NImage_ComboBox.onItemSelected = function(j) { engine.N_Image = engine.List_ID[j]; }
   this.RImage_ComboBox.onItemSelected = function(j) { engine.R_Image = engine.List_ID[j]; }
   this.VImage_ComboBox.onItemSelected = function(j) { engine.V_Image = engine.List_ID[j]; }
   this.BImage_ComboBox.onItemSelected = function(j) { engine.B_Image = engine.List_ID[j]; }

   this.L1_ImageList.currentItem=-1;
   this.L2_ImageList.currentItem=-1;
   this.L3_ImageList.currentItem=-1;
   this.LImage_ComboBox.currentItem=-1;
   this.SImage_ComboBox.currentItem=-1;
   this.HImage_ComboBox.currentItem=-1;
   this.OImage_ComboBox.currentItem=-1;
   this.NImage_ComboBox.currentItem=-1;
   this.RImage_ComboBox.currentItem=-1;
   this.VImage_ComboBox.currentItem=-1;
   this.BImage_ComboBox.currentItem=-1;

   if(PRELOAD_SHONRVB_IMAGES)
   {
      for ( var j = 0; j < maxID; ++j )
      {
         if(engine.List_ID[j][0]=='L' || engine.List_ID[j][0]=='l') { this.LImage_ComboBox.currentItem = j; engine.L_Image = engine.List_ID[j];}
         if(engine.List_ID[j][0]=='S' || engine.List_ID[j][0]=='s') { this.SImage_ComboBox.currentItem = j; engine.S_Image = engine.List_ID[j];}
         if(engine.List_ID[j][0]=='H' || engine.List_ID[j][0]=='h') { this.HImage_ComboBox.currentItem = j; engine.H_Image = engine.List_ID[j];}
         if(engine.List_ID[j][0]=='O' || engine.List_ID[j][0]=='o') { this.OImage_ComboBox.currentItem = j; engine.O_Image = engine.List_ID[j];}
         if(engine.List_ID[j][0]=='N' || engine.List_ID[j][0]=='n') { this.NImage_ComboBox.currentItem = j; engine.N_Image = engine.List_ID[j];}
         if(engine.List_ID[j][0]=='R' || engine.List_ID[j][0]=='r') { this.RImage_ComboBox.currentItem = j; engine.R_Image = engine.List_ID[j];}
         if(engine.List_ID[j][0]=='V' || engine.List_ID[j][0]=='v' || engine.List_ID[j][0]=='G' || engine.List_ID[j][0]=='g') { this.VImage_ComboBox.currentItem = j; engine.V_Image = engine.List_ID[j];}
         if(engine.List_ID[j][0]=='B' || engine.List_ID[j][0]=='b') { this.BImage_ComboBox.currentItem = j; engine.B_Image = engine.List_ID[j];}
      }
   }

   this.PreviewGroupsizer = new VerticalSizer;
   this.PreviewGroupsizer.margin = 6;
   this.PreviewGroupsizer.spacing = 4;
   this.PreviewGroupsizer.add( this.ScrollControl );

   this.showLC_Button = new PushButton( this );
   this.showLC_Button.text = TEXT7;          		// "Create Luminance Image"
   this.showLC_Button.onClick = function() {
	   this.parent.parent.Calculate_L(0);
	   this.parent.parent.ScrollControl.repaint();
   }

   this.topImageLabel = new Label( this );
   this.topImageLabel.text = "Master 1:";
   this.topImageLabel.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.opacity_L1 = new NumericControl (this);
   this.opacity_L1.label.text = "%";
   this.opacity_L1.setRange (0, 100);
   this.opacity_L1. slider.setRange (0, 100);
   this.opacity_L1.slider.minWidth = 100;
   this.opacity_L1.setPrecision (0);
   this.opacity_L1.setValue (100);
   this.opacity_L1.onValueUpdated = function (value) { opacityL1 = value; };

   this.topImageSizer = new HorizontalSizer;
   this.topImageSizer.spacing = 4;
   this.topImageSizer.addSpacing( 5 );
   this.topImageSizer.add( this.topImageLabel );
   this.topImageSizer.addSpacing( 10 );
   this.topImageSizer.add( this.L1_ImageList,60 );
   this.topImageSizer.addSpacing( 10 );
   this.topImageSizer.add( this.opacity_L1 );
   this.topImageSizer.addSpacing( 5 );

   this.bottomImageLabel = new Label( this );
   this.bottomImageLabel.text = "Master 2:";
   this.bottomImageLabel.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.opacity_L2 = new NumericControl (this);
   this.opacity_L2.label.text = "%";
   this.opacity_L2.setRange (0, 100);
   this.opacity_L2.slider.setRange (0, 100);
   this.opacity_L2.slider.minWidth = 100;
   this.opacity_L2.setPrecision (0);
   this.opacity_L2.setValue (100);
   this.opacity_L2.onValueUpdated = function (value) { opacityL2 = value; };

   this.bottomImageSizer = new HorizontalSizer;
   this.bottomImageSizer.spacing = 4;
   this.bottomImageSizer.addSpacing( 5 );
   this.bottomImageSizer.add( this.bottomImageLabel );
   this.bottomImageSizer.addSpacing( 10 );
   this.bottomImageSizer.add( this.L2_ImageList,60 );
   this.bottomImageSizer.addSpacing( 10 );
   this.bottomImageSizer.add( this.opacity_L2 );
   this.bottomImageSizer.addSpacing( 5 );

   this.ImageLabelL3 = new Label( this );
   this.ImageLabelL3.text = "Master 3:";
   this.ImageLabelL3.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.opacity_L3 = new NumericControl (this);
   this.opacity_L3.label.text = "%";
   this.opacity_L3.setRange (0, 100);
   this.opacity_L3.slider.setRange (0, 100);
   this.opacity_L3.slider.minWidth = 100;
   this.opacity_L3.setPrecision (0);
   this.opacity_L3.setValue (100);
   this.opacity_L3.onValueUpdated = function (value) { opacityL3 = value; };

   this.L3ImageSizer = new HorizontalSizer;
   this.L3ImageSizer.spacing = 4;
   this.L3ImageSizer.addSpacing( 5 );
   this.L3ImageSizer.add( this.ImageLabelL3 );
   this.L3ImageSizer.addSpacing( 10 );
   this.L3ImageSizer.add( this.L3_ImageList,60 );
   this.L3ImageSizer.addSpacing( 10 );
   this.L3ImageSizer.add( this.opacity_L3 );
   this.L3ImageSizer.addSpacing( 5 );

   this.blendModeLabelC = new Label( this );
   this.blendModeLabelC.text = "method :";
   this.blendModeLabelC.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

   this.blendModeComboC = new ComboBox( this );

   this.blendModeComboC.onItemSelected = function( index ) {
	   var i = 0;
	   for (key in engine.formule2C) {
           if (i == index) {
             engine.formul2C = engine.formule2C[key];
           }
           i++;
	   }
      i = 0;
      for (key in engine.formule3C) {
           if (i == index) {
             engine.formul3C = engine.formule3C[key];
           }
           i++;
	   }
   }

   this.showSHO_Button = new PushButton( this );
   this.showSHO_Button.text = TEXT15;          			// "Mixing SHONRVB"
   this.showSHO_Button.onClick = function() {
	   this.parent.parent.Calculate_SHO();
	   this.parent.parent.ScrollControl.repaint();
   }

    this.showLSHO_Button = new PushButton( this );
    this.showLSHO_Button.text = TEXT14;             	// "Mixing L-SHONRVB"
    this.showLSHO_Button.onClick = function() {
    	if(lock==0) {
    		lock=1;
    		this.dialog.cursor = new Cursor( StdCursor.ArrowWait);
    		this.parent.parent.Calculate_L_SHO(engine.Preview,engine.S_Image,engine.H_Image,engine.O_Image,engine.N_Image,engine.L_Image,engine.R_Image,engine.V_Image,engine.B_Image);
    		this.parent.parent.ScrollControl.repaint();
    		lock=0;
            this.dialog.cursor = new Cursor( StdCursor.PointingHand);
    	}
    }

    if(REMOVE_PINK_HALOS) {
	    this.removePinkHalos_Button = new PushButton( this );
	    this.removePinkHalos_Button.text = TEXT27;      	// "Remove Pink Halos"
	    this.removePinkHalos_Button.onClick = function() {
	    	if(lock==0) {
	    		lock=1;
	    		this.parent.parent.RemovePinkHalos();
	    		this.parent.parent.ScrollControl.repaint();
	    		lock=0;
	    	}
	    }
    }

   this.Newp_Button = new PushButton( this );
   this.Newp_Button.text = TEXT18;
   this.Newp_Button.onClick = function() {
	   this.dialog.LImage_ComboBox.addItem( engine.Preview.mainView.id );
	   this.dialog.SImage_ComboBox.addItem( engine.Preview.mainView.id );
	   this.dialog.OImage_ComboBox.addItem( engine.Preview.mainView.id );
	   this.dialog.HImage_ComboBox.addItem( engine.Preview.mainView.id );
	   this.dialog.NImage_ComboBox.addItem( engine.Preview.mainView.id );
	   this.dialog.RImage_ComboBox.addItem( engine.Preview.mainView.id );
	   this.dialog.VImage_ComboBox.addItem( engine.Preview.mainView.id );
	   this.dialog.BImage_ComboBox.addItem( engine.Preview.mainView.id );

	   this.dialog.L1_ImageList.addItem( engine.Preview.mainView.id );
	   this.dialog.L2_ImageList.addItem( engine.Preview.mainView.id );
	   this.dialog.L3_ImageList.addItem( engine.Preview.mainView.id );

       engine.NewPic();
   }

   this.FitImage_Button = new PushButton( this );
   this.FitImage_Button.text = TEXT28;					// "Zoom To Fit"
   this.FitImage_Button.onClick = function() {
	   engine.Preview.zoomToOptimalFit();
   }

   this.AIP_CheckBox = new CheckBox( this );
   this.AIP_CheckBox.text = TEXT13;          			// "Mixing with AIP Method"
   this.AIP_CheckBox.checked = AIPMIX;
   this.AIP_CheckBox.onCheck = function( checked ) {
	   AIPMIX = checked;
   };

   this.FloutControl = new NumericControl( this );

   this.FloutControl.setRange( 1, 5 );
   this.FloutControl.label.text = TEXT12;				// "Noise Iterations "
   this.FloutControl.label.minWidth = 50;
   this.FloutControl.slider.setRange( 1, 5 );
   this.FloutControl.slider.minWidth = 100;
   this.FloutControl.setPrecision (0);
   this.FloutControl.setValue( Flout_L);
   this.FloutControl.onValueUpdated = function( value ) {
	   Flout_L = value;
   };

   this.pourcentl = new NumericControl( this );
   this.pourcentl.setRange( 1, 100 );
   this.pourcentl.label.text = "L % : ";
   this.pourcentl.label.minWidth = 50;
   this.pourcentl.slider.setRange( 1, 100 );
   this.pourcentl.slider.minWidth = 100;
   this.pourcentl.setPrecision (0);
   this.pourcentl.setValue( PC_L);
   this.pourcentl.onValueUpdated = function( value ) {
	   PC_L = value;
   };

   this.number0fLayers_Sizer = new HorizontalSizer;
   // V8 fix: this.number0fLayers_Sizer.setAlignment was assigned as a property, not
   // called as a method -- that's read-only now and throws. This was
   // already a no-op in the original script (never actually centered
   // anything), so removed rather than changed to a real call, to keep
   // the dialog's appearance identical to the original.
   this.number0fLayers_Sizer.addStretch();
   this.number0fLayers_Sizer.add( this.AIP_CheckBox );
   this.number0fLayers_Sizer.addStretch();
   this.number0fLayers_Sizer.add( this.FloutControl );
   this.number0fLayers_Sizer.addStretch();
   this.number0fLayers_Sizer.add( this.pourcentl );
   this.number0fLayers_Sizer.addStretch();


   this.lightnessControl = new NumericControl( this );
   this.lightnessControl.setRange( 0.001, 1.0 );
   this.lightnessControl.label.text = "Transfer Functions - Lightness: ";
   this.lightnessControl.slider.setRange( 0.001, 200);
   this.lightnessControl.slider.minWidth = 0;
   this.lightnessControl.setPrecision (3);
   this.lightnessControl.setValue( lightness);
   this.lightnessControl.onValueUpdated = function( value ) {
	   lightness = value;
   };

   this.saturationControl = new NumericControl( this );
   this.saturationControl.setRange( 0.0, 1.0 );
   this.saturationControl.label.text = "Saturation: ";
   this.saturationControl.slider.setRange( 0, 200);
   this.saturationControl.slider.minWidth = 0;
   this.saturationControl.setPrecision (3);
   this.saturationControl.setValue( saturation);
   this.saturationControl.onValueUpdated = function( value ) {
	   saturation = value;
   };

   this.CNR_CheckBox = new CheckBox( this );
   this.CNR_CheckBox.text = TEXT11; 					// "Chroma Noise Reduction"
   this.CNR_CheckBox.checked = noiser;
   this.CNR_CheckBox.onCheck = function( checked ) {
	   noiser = checked;
   };

   this.smoothed_Label = new Label (this);
   this.smoothed_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.smoothed_Label.margin = 6;
   this.smoothed_Label.text = " SmothedWL : ";

   this.smoothed_SpinBox = new SpinBox( this );
   this.smoothed_SpinBox.minValue = 1;
   this.smoothed_SpinBox.maxValue = 6;
   this.smoothed_SpinBox.value = smoothed;
   this.smoothed_SpinBox.onValueUpdated = function( value )
   {
      smoothed = value;
   };

   this.protected_Label = new Label (this);
   this.protected_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.protected_Label.margin = 6;
   this.protected_Label.text = " ProtectedWL : ";
   this.protected_SpinBox = new SpinBox( this );
   this.protected_SpinBox.minValue = 0;
   this.protected_SpinBox.maxValue = 5;
   this.protected_SpinBox.value = protectedw;
   this.protected_SpinBox.onValueUpdated = function( value )
   {
      protectedw = value;
   };

   this.number3fLayers_Sizer = new HorizontalSizer;
   // V8 fix: this.number3fLayers_Sizer.setAlignment was assigned as a property, not
   // called as a method -- that's read-only now and throws. This was
   // already a no-op in the original script (never actually centered
   // anything), so removed rather than changed to a real call, to keep
   // the dialog's appearance identical to the original.
   this.number3fLayers_Sizer.addStretch();
   this.number3fLayers_Sizer.add( this.lightnessControl );
   this.number3fLayers_Sizer.addSpacing( 10 );
   this.number3fLayers_Sizer.add( this.saturationControl );
   this.number3fLayers_Sizer.addStretch();

   this.number4fLayers_Sizer = new HorizontalSizer;
   // V8 fix: this.number4fLayers_Sizer.setAlignment was assigned as a property, not
   // called as a method -- that's read-only now and throws. This was
   // already a no-op in the original script (never actually centered
   // anything), so removed rather than changed to a real call, to keep
   // the dialog's appearance identical to the original.
   this.number4fLayers_Sizer.addStretch();
   this.number4fLayers_Sizer.add( this.CNR_CheckBox );
   this.number4fLayers_Sizer.add( this.smoothed_Label );
   this.number4fLayers_Sizer.add( this.smoothed_SpinBox );
   this.number4fLayers_Sizer.add( this.protected_Label );
   this.number4fLayers_Sizer.add( this.protected_SpinBox );
   this.number4fLayers_Sizer.addStretch();

   this.boutL_Sizer = new HorizontalSizer;
   // V8 fix: this.boutL_Sizer.setAlignment was assigned as a property, not
   // called as a method -- that's read-only now and throws. This was
   // already a no-op in the original script (never actually centered
   // anything), so removed rather than changed to a real call, to keep
   // the dialog's appearance identical to the original.
   this.boutL_Sizer.addStretch();
   this.boutL_Sizer.add( this.showLC_Button,260);
   this.boutL_Sizer.addSpacing( 20 );
   this.boutL_Sizer.add( this.blendModeLabelC );
   this.boutL_Sizer.addSpacing( 20 );
   this.boutL_Sizer.add( this.blendModeComboC,150 );
   this.boutL_Sizer.addStretch();

   this.boutSHO_Sizer = new HorizontalSizer;
   // V8 fix: this.boutSHO_Sizer.setAlignment was assigned as a property, not
   // called as a method -- that's read-only now and throws. This was
   // already a no-op in the original script (never actually centered
   // anything), so removed rather than changed to a real call, to keep
   // the dialog's appearance identical to the original.
   this.boutSHO_Sizer.addStretch();
   this.boutSHO_Sizer.add( this.showSHO_Button,250);
   this.boutSHO_Sizer.addSpacing( 20 );
   this.boutSHO_Sizer.add( this.showLSHO_Button,250 );
   if(REMOVE_PINK_HALOS) {
	   this.boutSHO_Sizer.addSpacing( 20 );
	   this.boutSHO_Sizer.add( this.removePinkHalos_Button,250 );
   }
   this.boutSHO_Sizer.addStretch();

   this.Res_CheckBox = new CheckBox( this );
   this.Res_CheckBox.text = TEXT10;    			// "Mixing with Rescale"
   this.Res_CheckBox.checked = RES;
   this.Res_CheckBox.onCheck = function( checked ) {
		RES = checked;
   };

   this.Res2_CheckBox = new CheckBox( this );
   this.Res2_CheckBox.text = TEXT9;          	// "Background Auto Equalise"
   this.Res2_CheckBox.checked = BAKN;
   this.Res2_CheckBox.onCheck = function( checked ) {
		BAKN = checked;
   };

   this.ASTF_CheckBox = new CheckBox( this );
   this.ASTF_CheckBox.text = "Auto STF";
   this.ASTF_CheckBox.checked = STF;
   this.ASTF_CheckBox.onCheck = function( checked ) {
		STF = checked;
   };

   this.OSTF_CheckBox = new CheckBox( this );
   this.OSTF_CheckBox.text = "Optimise STF";
   this.OSTF_CheckBox.checked = OPT;
   this.OSTF_CheckBox.onCheck = function( checked ) {
		OPT = checked;
   };

   this.helpLabel = new Label (this);
   this.helpLabel.setMaxHeight(15);
   this.helpLabel.wordWrapping = true;
   this.helpLabel.useRichText = true;
   this.helpLabel.text = "L Bourgon, P Bernhard & D Watson";

   this.ihelpLabel = new HorizontalSizer;
   // V8 fix: this.ihelpLabel.setAlignment was assigned as a property, not
   // called as a method -- that's read-only now and throws. This was
   // already a no-op in the original script (never actually centered
   // anything), so removed rather than changed to a real call, to keep
   // the dialog's appearance identical to the original.
   this.ihelpLabel.addSpacing( 5 );
   this.ihelpLabel.add( this.helpLabel);

   this.helpLabel2 = new Label (this);
   this.helpLabel2.setMaxHeight(15);
   this.helpLabel2.wordWrapping = true;
   this.helpLabel2.useRichText = true;
   this.helpLabel2.text = "&mdash; Copyright &copy; 2020 &mdash;";

   this.ihelpLabel2 = new HorizontalSizer;
   // V8 fix: this.ihelpLabel2.setAlignment was assigned as a property, not
   // called as a method -- that's read-only now and throws. This was
   // already a no-op in the original script (never actually centered
   // anything), so removed rather than changed to a real call, to keep
   // the dialog's appearance identical to the original.
   this.ihelpLabel2.addSpacing( 35 );
   this.ihelpLabel2.add( this.helpLabel2);

   this.number8fLayers_Sizer = new VerticalSizer;
   // V8 fix: this.number8fLayers_Sizer.setAlignment was assigned as a property, not
   // called as a method -- that's read-only now and throws. This was
   // already a no-op in the original script (never actually centered
   // anything), so removed rather than changed to a real call, to keep
   // the dialog's appearance identical to the original.
   //this.number8fLayers_Sizer.addStretch();
   this.number8fLayers_Sizer.addSpacing( 10 );
   this.number8fLayers_Sizer.add( this.ihelpLabel);
   this.number8fLayers_Sizer.add( this.ihelpLabel2);
   this.number8fLayers_Sizer.addSpacing( 10 );
   this.number8fLayers_Sizer.add( this.Newp_Button);
   this.number8fLayers_Sizer.addSpacing( 5 );
   this.number8fLayers_Sizer.add( this.FitImage_Button);
   this.number8fLayers_Sizer.addSpacing( 5 );
   this.number8fLayers_Sizer.add( this.Res_CheckBox );
   this.number8fLayers_Sizer.addSpacing( 5 );
   this.number8fLayers_Sizer.add( this.Res2_CheckBox );
   this.number8fLayers_Sizer.addSpacing( 5 );
   this.number8fLayers_Sizer.add( this.ASTF_CheckBox );
   this.number8fLayers_Sizer.addSpacing( 5 );
   this.number8fLayers_Sizer.add( this.OSTF_CheckBox );
   this.number8fLayers_Sizer.addSpacing( 40 );
   //this.number8fLayers_Sizer.addStretch();

   this.PWGroupBox = new Control( this );
   this.PWGroupBox.sizer = new HorizontalSizer;
   this.PWGroupBox.sizer.spacing = 4;
   this.PWGroupBox.sizer.add( this.PreviewGroupsizer);
   this.PWGroupBox.sizer.add( this.number8fLayers_Sizer);

   this.LAIPBox = new Control( this );
   this.LAIPBox.sizer = new VerticalSizer;
   this.LAIPBox.sizer.spacing = 6;
   this.LAIPBox.sizer.add( this.topImageSizer);
   this.LAIPBox.sizer.add( this.bottomImageSizer);
   this.LAIPBox.sizer.add( this.L3ImageSizer);
   this.LAIPBox.sizer.add( this.boutL_Sizer);

   this.PWMixBox = new Control( this );
   this.PWMixBox.sizer = new VerticalSizer;
   this.PWMixBox.sizer.spacing = 6;
   this.PWMixBox.sizer.add( this.number0fLayers_Sizer);
   this.PWMixBox.sizer.add( this.number3fLayers_Sizer);
   this.PWMixBox.sizer.add( this.number4fLayers_Sizer);

   // Image Selection Labels
   // Target
   this.TargetImage_Label = new Label (this);
   this.TargetImage_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.TargetImage_Label.margin = 6;
   this.TargetImage_Label.text = "Image L :";
   // S
   this.SImage_Label = new Label (this);
   this.SImage_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.SImage_Label.margin = 6;
   this.SImage_Label.text = "Image  SII :";
   // H
   this.HImage_Label = new Label (this);
   this.HImage_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.HImage_Label.margin = 6;
   this.HImage_Label.text = "Image  HA :";
   // O
   this.OImage_Label = new Label (this);
   this.OImage_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.OImage_Label.margin = 6;
   this.OImage_Label.text = "Image  OIII :";
   // N
   this.NImage_Label = new Label (this);
   this.NImage_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.NImage_Label.margin = 6;
   this.NImage_Label.text = "Image  NII :";
   // R
   this.RImage_Label = new Label (this);
   this.RImage_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.RImage_Label.margin = 6;
   this.RImage_Label.text = "Image  R :";
   // V
   this.VImage_Label = new Label (this);
   this.VImage_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.VImage_Label.margin = 6;
   this.VImage_Label.text = "Image  V :";
   // B
   this.BImage_Label = new Label (this);
   this.BImage_Label.textAlignment = TextAlignment.Left|TextAlignment.VertCenter;
   this.BImage_Label.margin = 6;
   this.BImage_Label.text = "Image  B :";
   // ----
   this.TargetImage_Sizer = new HorizontalSizer;
   this.TargetImage_Sizer.add( this.TargetImage_Label,40 );
   this.TargetImage_Sizer.addSpacing( 20 );
   this.TargetImage_Sizer.add( this.LImage_ComboBox,80);
   this.TargetImage_Sizer.addSpacing( 6 );
   this.TargetImage_Sizer.add( this.NImage_Label,40);
   this.TargetImage_Sizer.addSpacing( 20 );
   this.TargetImage_Sizer.add( this.NImage_ComboBox,80);
   this.TargetImage_Sizer.addSpacing( 6 );

   this.SImage_Sizer = new HorizontalSizer;
   this.SImage_Sizer.add( this.SImage_Label,40 );
   this.SImage_Sizer.addSpacing( 20 );
   this.SImage_Sizer.add( this.SImage_ComboBox,80);
   this.SImage_Sizer.addSpacing( 6 );
   this.SImage_Sizer.add( this.RImage_Label,40 );
   this.SImage_Sizer.addSpacing( 20 );
   this.SImage_Sizer.add( this.RImage_ComboBox, 80 );
   this.SImage_Sizer.addSpacing( 6 );

   this.HImage_Sizer = new HorizontalSizer;
   this.HImage_Sizer.add( this.HImage_Label ,40);
   this.HImage_Sizer.addSpacing( 20 );
   this.HImage_Sizer.add( this.HImage_ComboBox, 80 );
   this.HImage_Sizer.addSpacing( 6 );
   this.HImage_Sizer.add( this.VImage_Label ,40);
   this.HImage_Sizer.addSpacing( 20 );
   this.HImage_Sizer.add( this.VImage_ComboBox, 80 );
   this.HImage_Sizer.addSpacing( 6 );

   this.OImage_Sizer = new HorizontalSizer;
   this.OImage_Sizer.add( this.OImage_Label ,40);
   this.OImage_Sizer.addSpacing( 20 );
   this.OImage_Sizer.add( this.OImage_ComboBox, 80 );
   this.OImage_Sizer.addSpacing( 6 );
   this.OImage_Sizer.add( this.BImage_Label ,40);
   this.OImage_Sizer.addSpacing( 20 );
   this.OImage_Sizer.add( this.BImage_ComboBox, 80 );
   this.OImage_Sizer.addSpacing( 6 );

   this.Images_GroupBox = new Control (this);
   this.Images_GroupBox.sizer = new VerticalSizer;
   this.Images_GroupBox.sizer.addSpacing( 0 );
   this.Images_GroupBox.sizer.add ( this.TargetImage_Sizer );
   this.Images_GroupBox.sizer.add ( this.SImage_Sizer );
   this.Images_GroupBox.sizer.add ( this.HImage_Sizer );
   this.Images_GroupBox.sizer.add ( this.OImage_Sizer );
   this.Images_GroupBox.sizer.addSpacing( 10 );
   this.Images_GroupBox.sizer.add ( this.boutSHO_Sizer);

   this.S_in_R_Control = new NumericControl( this );
   this.S_in_R_Control.setRange( 0, RANGE_P );
   this.S_in_R_Control.label.text = TEXT6;  			// "Layer Red --- % SII : "
   this.S_in_R_Control.label.minWidth = labelWidth1;
   this.S_in_R_Control.slider.setRange( 0, RANGE_P );
   this.S_in_R_Control.slider.minWidth = 350;
   this.S_in_R_Control.setPrecision (0);
   this.S_in_R_Control.setValue( PC_S_DANS_R * 100);
   this.S_in_R_Control.onValueUpdated = function( value ) {
	   PC_S_DANS_R = value/100;
   };

   this.H_in_R_Control = new NumericControl( this );
   this.H_in_R_Control.setRange( 0, RANGE_P );
   this.H_in_R_Control.label.text = "% HA : ";
   this.H_in_R_Control.label.minWidth = labelWidth1;
   this.H_in_R_Control.slider.setRange( 0, RANGE_P );
   this.H_in_R_Control.slider.minWidth = 350;
   this.H_in_R_Control.setPrecision (0);
   this.H_in_R_Control.setValue( PC_H_DANS_R * 100);
   this.H_in_R_Control.onValueUpdated = function( value ) {
	   PC_H_DANS_R = value/100;
   };

   this.O_in_R_Control = new NumericControl( this );
   this.O_in_R_Control.setRange( 0, RANGE_P );
   this.O_in_R_Control.label.text = "% OIII : ";
   this.O_in_R_Control.label.minWidth = labelWidth1;
   this.O_in_R_Control.slider.setRange( 0, RANGE_P );
   this.O_in_R_Control.slider.minWidth = 350;
   this.O_in_R_Control.setPrecision (0);
   this.O_in_R_Control.setValue( PC_O_DANS_R * 100);
   this.O_in_R_Control.onValueUpdated = function( value ) {
	   PC_O_DANS_R = value/100;
   };

   this.N_in_R_Control = new NumericControl( this );
   this.N_in_R_Control.setRange( 0, RANGE_P );
   this.N_in_R_Control.label.text = "% NII : ";
   this.N_in_R_Control.label.minWidth = labelWidth1;
   this.N_in_R_Control.slider.setRange( 0, RANGE_P );
   this.N_in_R_Control.slider.minWidth = 350;
   this.N_in_R_Control.setPrecision (0);
   this.N_in_R_Control.setValue( PC_N_DANS_R * 100);
   this.N_in_R_Control.onValueUpdated = function( value ) {
	   PC_N_DANS_R = value/100;
   };

   this.S_in_V_Control = new NumericControl( this );
   this.S_in_V_Control.setRange( 0, RANGE_P );
   this.S_in_V_Control.label.text = TEXT5;           					// "Layer Green -- % SII : "
   this.S_in_V_Control.label.minWidth = labelWidth1;
   this.S_in_V_Control.slider.setRange( 0, RANGE_P );
   this.S_in_V_Control.slider.minWidth = 350;
   this.S_in_V_Control.setPrecision (0);
   this.S_in_V_Control.setValue( PC_S_DANS_V * 100);
   this.S_in_V_Control.onValueUpdated = function( value ) {
	   PC_S_DANS_V = value/100;
   };

   this.H_in_V_Control = new NumericControl( this );
   this.H_in_V_Control.setRange( 0, RANGE_P );
   this.H_in_V_Control.label.text = "% HA : ";
   this.H_in_V_Control.label.minWidth = labelWidth1;
   this.H_in_V_Control.slider.setRange( 0, RANGE_P );
   this.H_in_V_Control.slider.minWidth = 350;
   this.H_in_V_Control.setPrecision (0);
   this.H_in_V_Control.setValue( PC_H_DANS_V * 100);
   this.H_in_V_Control.onValueUpdated = function( value ) {
	   PC_H_DANS_V = value/100;
   };

   this.O_in_V_Control = new NumericControl( this );
   this.O_in_V_Control.setRange( 0, RANGE_P );
   this.O_in_V_Control.label.text = "% OIII : ";
   this.O_in_V_Control.label.minWidth = labelWidth1;
   this.O_in_V_Control.slider.setRange( 0, RANGE_P );
   this.O_in_V_Control.slider.minWidth = 350;
   this.O_in_V_Control.setPrecision (0);
   this.O_in_V_Control.setValue( PC_O_DANS_V * 100);
   this.O_in_V_Control.onValueUpdated = function( value ) {
	   PC_O_DANS_V = value/100;
   };

   this.N_in_V_Control = new NumericControl( this );
   this.N_in_V_Control.setRange( 0, RANGE_P );
   this.N_in_V_Control.label.text = "% NII : ";
   this.N_in_V_Control.label.minWidth = labelWidth1;
   this.N_in_V_Control.slider.setRange( 0, RANGE_P );
   this.N_in_V_Control.slider.minWidth = 350;
   this.N_in_V_Control.setPrecision (0);
   this.N_in_V_Control.setValue( PC_N_DANS_V * 100);
   this.N_in_V_Control.onValueUpdated = function( value ) {
	   PC_N_DANS_V = value/100;
   };

   this.S_in_B_Control = new NumericControl( this );
   this.S_in_B_Control.setRange( 0, RANGE_P );
   this.S_in_B_Control.label.text = TEXT4;          						// "Layer Blue --- % SII : "
   this.S_in_B_Control.label.minWidth = labelWidth1;
   this.S_in_B_Control.slider.setRange( 0, RANGE_P );
   this.S_in_B_Control.slider.minWidth = 350;
   this.S_in_B_Control.setPrecision (0);
   this.S_in_B_Control.setValue( PC_S_DANS_B * 100);
   this.S_in_B_Control.onValueUpdated = function( value ) {
	   PC_S_DANS_B = value/100;
   };

   this.H_in_B_Control = new NumericControl( this );
   this.H_in_B_Control.setRange( 0, RANGE_P );
   this.H_in_B_Control.label.text = "% HA : ";
   this.H_in_B_Control.label.minWidth = labelWidth1;
   this.H_in_B_Control.slider.setRange( 0, RANGE_P );
   this.H_in_B_Control.slider.minWidth = 350;
   this.H_in_B_Control.setPrecision (0);
   this.H_in_B_Control.setValue( PC_H_DANS_B * 100);
   this.H_in_B_Control.onValueUpdated = function( value ) {
	   PC_H_DANS_B = value/100;
   };

   this.O_in_B_Control = new NumericControl( this );
   this.O_in_B_Control.setRange( 0, RANGE_P );
   this.O_in_B_Control.label.text = "% OIII : ";
   this.O_in_B_Control.label.minWidth = labelWidth1;
   this.O_in_B_Control.slider.setRange( 0, RANGE_P );
   this.O_in_B_Control.slider.minWidth = 350;
   this.O_in_B_Control.setPrecision (0);
   this.O_in_B_Control.setValue( PC_O_DANS_B * 100);
   this.O_in_B_Control.onValueUpdated = function( value ) {
	   PC_O_DANS_B = value/100;
   };

   this.N_in_B_Control = new NumericControl( this );
   this.N_in_B_Control.setRange( 0, RANGE_P );
   this.N_in_B_Control.label.text = "% NII : ";
   this.N_in_B_Control.label.minWidth = labelWidth1;
   this.N_in_B_Control.slider.setRange( 0, RANGE_P );
   this.N_in_B_Control.slider.minWidth = 350;
   this.N_in_B_Control.setPrecision (0);
   this.N_in_B_Control.setValue( PC_N_DANS_B * 100);
   this.N_in_B_Control.onValueUpdated = function( value ) {
	   PC_N_DANS_B = value/100;
   };

   this.R_in_R_Control = new NumericControl( this );
   this.R_in_R_Control.setRange( 0, RANGE_P );
   this.R_in_R_Control.label.text = "% R : ";
   this.R_in_R_Control.label.minWidth = labelWidth1;
   this.R_in_R_Control.slider.setRange( 0, RANGE_P );
   this.R_in_R_Control.slider.minWidth = 350;
   this.R_in_R_Control.setPrecision (0);
   this.R_in_R_Control.setValue( PC_R_DANS_R * 100);
   this.R_in_R_Control.onValueUpdated = function( value ) {
	   PC_R_DANS_R = value/100;
   };

   this.V_in_V_Control = new NumericControl( this );
   this.V_in_V_Control.setRange( 0, RANGE_P );
   this.V_in_V_Control.label.text = "% V : ";
   this.V_in_V_Control.label.minWidth = labelWidth1;
   this.V_in_V_Control.slider.setRange( 0, RANGE_P );
   this.V_in_V_Control.slider.minWidth = 350;
   this.V_in_V_Control.setPrecision (0);
   this.V_in_V_Control.setValue( PC_V_DANS_V * 100);
   this.V_in_V_Control.onValueUpdated = function( value ) {
	   PC_V_DANS_V = value/100;
   };

   this.B_in_B_Control = new NumericControl( this );
   this.B_in_B_Control.setRange( 0, RANGE_P );
   this.B_in_B_Control.label.text = "% B : ";
   this.B_in_B_Control.label.minWidth = labelWidth1;
   this.B_in_B_Control.slider.setRange( 0, RANGE_P );
   this.B_in_B_Control.slider.minWidth = 350;
   this.B_in_B_Control.setPrecision (0);
   this.B_in_B_Control.setValue( PC_B_DANS_B * 100);
   this.B_in_B_Control.onValueUpdated = function( value ) {
	   PC_B_DANS_B = value/100;
   };

   this.ChannelGroupBox = new Control( this );
   this.ChannelGroupBox.sizer = new VerticalSizer;
   this.ChannelGroupBox.sizer.margin = 5;
   this.ChannelGroupBox.sizer.spacing = 0;
   this.ChannelGroupBox.sizer.add( this.S_in_R_Control);
   this.ChannelGroupBox.sizer.add( this.H_in_R_Control);
   this.ChannelGroupBox.sizer.add( this.O_in_R_Control);
   this.ChannelGroupBox.sizer.add( this.N_in_R_Control);
   this.ChannelGroupBox.sizer.add( this.R_in_R_Control);
   this.ChannelGroupBox.sizer.addSpacing( 6 );
   this.ChannelGroupBox.sizer.add( this.S_in_V_Control);
   this.ChannelGroupBox.sizer.add( this.H_in_V_Control);
   this.ChannelGroupBox.sizer.add( this.O_in_V_Control);
   this.ChannelGroupBox.sizer.add( this.N_in_V_Control);
   this.ChannelGroupBox.sizer.add( this.V_in_V_Control);
   this.ChannelGroupBox.sizer.addSpacing( 6 );
   this.ChannelGroupBox.sizer.add( this.S_in_B_Control);
   this.ChannelGroupBox.sizer.add( this.H_in_B_Control);
   this.ChannelGroupBox.sizer.add( this.O_in_B_Control);
   this.ChannelGroupBox.sizer.add( this.N_in_B_Control);
   this.ChannelGroupBox.sizer.add( this.B_in_B_Control);

   this.browseDocumentationButton = new ToolButton(this);
   this.browseDocumentationButton.icon = this.scaledResource(":/process-interface/browse-documentation.png");
   this.browseDocumentationButton.toolTip = "<p>Open a browser to view documentation</p>";
   this.browseDocumentationButton.onClick = function() {
	   if (!Dialog.browseScriptDocumentation(TITLE)) {
		   (new MessageBox(
				   "<p>Documentation has not been installed</p>",
				   TITLE,
				   StdIcon.Warning,
				   StdButton.Ok
		   )).execute();
	   }
   }

   this.Load_Button = new PushButton (this);
   this.Load_Button.text = "Load";
   this.Load_Button.onClick = function()
   {
      var loadFile = new OpenFileDialog;
      if(loadFile.execute())
      {
         var fileName = loadFile.filePath;
         var f = new File;

         f.openForReading(fileName);

         PC_S_DANS_R = f.read(DataType.Float,1);
         PC_H_DANS_R = f.read(DataType.Float,1);
         PC_O_DANS_R = f.read(DataType.Float,1);
         PC_N_DANS_R = f.read(DataType.Float,1);
         PC_R_DANS_R = f.read(DataType.Float,1);

         PC_S_DANS_V = f.read(DataType.Float,1);
         PC_H_DANS_V = f.read(DataType.Float,1);
         PC_O_DANS_V = f.read(DataType.Float,1);
         PC_N_DANS_V = f.read(DataType.Float,1);
         PC_V_DANS_V = f.read(DataType.Float,1);

         PC_S_DANS_B = f.read(DataType.Float,1);
         PC_H_DANS_B = f.read(DataType.Float,1);
         PC_O_DANS_B = f.read(DataType.Float,1);
         PC_N_DANS_B = f.read(DataType.Float,1);
         PC_B_DANS_B = f.read(DataType.Float,1);

         this.dialog.S_in_R_Control.setValue( PC_S_DANS_R * 100);
         this.dialog.H_in_R_Control.setValue( PC_H_DANS_R * 100);
         this.dialog.O_in_R_Control.setValue( PC_O_DANS_R * 100);
         this.dialog.N_in_R_Control.setValue( PC_N_DANS_R * 100);
         this.dialog.R_in_R_Control.setValue( PC_R_DANS_R * 100);

         this.dialog.S_in_V_Control.setValue( PC_S_DANS_V * 100);
         this.dialog.H_in_V_Control.setValue( PC_H_DANS_V * 100);
         this.dialog.O_in_V_Control.setValue( PC_O_DANS_V * 100);
         this.dialog.N_in_V_Control.setValue( PC_N_DANS_V * 100);
         this.dialog.V_in_V_Control.setValue( PC_V_DANS_V * 100);

         this.dialog.S_in_B_Control.setValue( PC_S_DANS_B * 100);
         this.dialog.H_in_B_Control.setValue( PC_H_DANS_B * 100);
         this.dialog.O_in_B_Control.setValue( PC_O_DANS_B * 100);
         this.dialog.N_in_B_Control.setValue( PC_N_DANS_B * 100);
         this.dialog.B_in_B_Control.setValue( PC_B_DANS_B * 100);

         f.close();
      }
   };

   this.Save_Button = new PushButton (this);
   this.Save_Button.text = "Save";
   this.Save_Button.onClick = function()
   {
      var saveFile = new SaveFileDialog;
        if(saveFile.execute()) {
            var fileName = saveFile.filePath;
            var f = new File;
            f.createForWriting(fileName);

            f.write(PC_S_DANS_R,DataType.Float);
            f.write(PC_H_DANS_R,DataType.Float);
            f.write(PC_O_DANS_R,DataType.Float);
            f.write(PC_N_DANS_R,DataType.Float);
            f.write(PC_R_DANS_R,DataType.Float);

            f.write(PC_S_DANS_V,DataType.Float);
            f.write(PC_H_DANS_V,DataType.Float);
            f.write(PC_O_DANS_V,DataType.Float);
            f.write(PC_N_DANS_V,DataType.Float);
            f.write(PC_V_DANS_V,DataType.Float);

            f.write(PC_S_DANS_B,DataType.Float);
            f.write(PC_H_DANS_B,DataType.Float);
            f.write(PC_O_DANS_B,DataType.Float);
            f.write(PC_N_DANS_B,DataType.Float);
            f.write(PC_B_DANS_B,DataType.Float);

            f.close();
        }
   };

   this.okButton = new PushButton( this );
   this.okButton.text = "OK";
   #ifneq __PI_PLATFORM__ MACOSX
     this.okButton.icon = new Bitmap( ":/icons/ok.png" );
   #endif
   this.okButton.onClick = function() {
	   isClosing = true;
	   engine.DialogPreview.forceClose();
	   engine.Preview.deletePreviews();
	   
	   if(engine.Last_Mix != 1) engine.Preview.forceClose();
	   else engine.Preview.show();
	   
	   this.dialog.ok();
   }

   this.cancelButton = new PushButton( this );
   this.cancelButton.text = "Cancel";
   #ifneq __PI_PLATFORM__ MACOSX
   	this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
   #endif
   this.cancelButton.onClick = function() {
	   isClosing = true;
	   engine.DialogPreview.forceClose();
	   engine.Preview.deletePreviews();
	   engine.Preview.forceClose();
	   this.dialog.cancel();
   }


   this.buttons_Sizer = new HorizontalSizer;
   this.buttons_Sizer.frameStyle = FrameStyle.Box;
   this.buttons_Sizer.margin = 4;
   this.buttons_Sizer.add (this.browseDocumentationButton);
   this.buttons_Sizer.addSpacing( 80 );
   this.buttons_Sizer.add (this.Load_Button);
   this.buttons_Sizer.addSpacing( 5 );
   this.buttons_Sizer.add (this.Save_Button);
   this.buttons_Sizer.addStretch();
   this.buttons_Sizer.add (this.cancelButton);
   this.buttons_Sizer.addSpacing( 5 );
   this.buttons_Sizer.add (this.okButton);

   this.PWGroupBoxBar = new SectionBar(this);
   this.PWGroupBoxBar.setTitle(TEXT3);          	// "Window Preview Control"
   this.PWGroupBox.adjustToContents();
   this.PWGroupBox.setFixedHeight(this.PWGroupBox.height);
   this.PWGroupBox.show();
   this.PWGroupBoxBar.setSection(this.PWGroupBox);

   this.LAIPBoxBar = new SectionBar(this);
   this.LAIPBoxBar.setTitle(TEXT7);       			// "Mixing Luminance"
   this.LAIPBox.adjustToContents();
   this.LAIPBox.setFixedHeight(this.LAIPBox.height);
   this.LAIPBox.hide();
   this.LAIPBoxBar.setSection(this.LAIPBox);

   this.PWMixBoxBar = new SectionBar(this);
   this.PWMixBoxBar.setTitle(TEXT8);   				// "Mixing L SHONRVB"
   this.PWMixBox.adjustToContents();
   this.PWMixBox.setFixedHeight(this.PWMixBox.height);
   this.PWMixBox.hide();
   this.PWMixBoxBar.setSection(this.PWMixBox);

   this.Images_GroupBoxBar = new SectionBar(this);
   this.Images_GroupBoxBar.setTitle(TEXT2);     	// "Images Selection"
   this.Images_GroupBox.adjustToContents();
   this.Images_GroupBox.setFixedHeight(this.Images_GroupBox.height);
   this.Images_GroupBox.show();
   this.Images_GroupBoxBar.setSection(this.Images_GroupBox);

   this.ChannelGroupBoxBar = new SectionBar(this);
   this.ChannelGroupBoxBar.setTitle(TEXT1);     	// "Layer for pour Mix SHONRVB"
   this.ChannelGroupBox.adjustToContents();
   this.ChannelGroupBox.setFixedHeight(this.ChannelGroupBox.height);
   this.ChannelGroupBox.show();
   this.ChannelGroupBoxBar.setSection(this.ChannelGroupBox);

   this.sizer = new VerticalSizer;
   this.sizer.spacing = 4;
   this.sizer.margin = 6;
   this.sizer.add(this.PWGroupBoxBar);
   this.sizer.add(this.PWGroupBox);
   this.sizer.add(this.LAIPBoxBar);
   this.sizer.add(this.LAIPBox);
   this.sizer.add(this.PWMixBoxBar);
   this.sizer.add(this.PWMixBox);
   this.sizer.add(this.Images_GroupBoxBar);
   this.sizer.add(this.Images_GroupBox);
   this.sizer.add(this.ChannelGroupBoxBar);
   this.sizer.add(this.ChannelGroupBox);
   this.sizer.add(this.buttons_Sizer);

   this.adjustToContents();
   this.cursor = new Cursor( StdCursor.PointingHand);
}

} // class parametersDialog

// Execute Script
function main() {
   //Console.hide();

   Console.writeln(' ');
   Console.writeln('SHO AIP script ' + VERSION_SHO);
   Console.writeln('Multichannel Synthesis utility');
   Console.writeln(' ');

   var window = ImageWindow.activeWindow;

   if ( window.isNull ) {
      Console.show();
      Console.writeln(ERROR1);
   } else {
      var dialog = new parametersDialog();
      dialog.execute();
   }

};

var maxID;

var PREVIEW_SIZE = 300;

var PC_S_DANS_R = 1;
var PC_H_DANS_R = 0;
var PC_O_DANS_R = 0;
var PC_N_DANS_R = 0;
var PC_R_DANS_R = 0;

var PC_S_DANS_V = 0;
var PC_H_DANS_V = 1;
var PC_O_DANS_V = 0;
var PC_N_DANS_V = 0;
var PC_V_DANS_V = 0;

var PC_S_DANS_B = 0;
var PC_H_DANS_B = 0;
var PC_O_DANS_B = 1;
var PC_N_DANS_B = 0;
var PC_B_DANS_B = 0;

var Flout_L		= 1 ;

var PC_L		= 100;
var OPT			= false;

var LS 			= false;
var LH 			= true;
var LO 			= false;
var LMIX		= true;
var AIPMIX		= true;		// Mixing with AIP method, only applied on mixing L-SHONRVB
var RES			= true;

var STF			= false;
var BAKN		= false;

var opacityL1 	= 100;
var opacityL2 	= 100;
var opacityL3 	= 100;

var lock		= 0;
var lmCount		= 0;
var isClosing 	= false;
var isLuminance = false;
var lightness 	= 0.5;
var saturation 	= 0.5;
var smoothed 	= 4;
var protectedw 	= 2;
var noiser		= false;

main();
