#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// RatioCrop.js — PixInsight PJSR Script
// (c) 2026 Dale A. Chamberlain with credits to Claude
//
// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// May 2026. Original script copyright remains with Dale A. Chamberlain.
// No rights to the original work are claimed or implied.
// ----------------------------------------------------------------------------
//
// Controls:
//   - Ratio presets + custom ratio input
//   - Size slider (ratio locked)
//   - 2D joystick pad — drag the dot to reposition the crop box
//   - Arrow buttons — nudge the crop box in small steps
//   - Live preview rectangle on the image viewport
//   - Apply crops and records in History Explorer

#feature-id    RatioCrop : MoP V8 > RatioCrop
#feature-info  Ratio-locked crop with joystick pad and arrow nudge controls.

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function clamp( v, lo, hi ) { return Math.max( lo, Math.min( hi, v ) ); }

// Returns a unique view id with the given base id prefix.
function uniqueViewId( baseId ) {
   var id = baseId;
   for ( var i = 1; ; ++i ) {
      var v = View.viewById( id );
      if ( v == null || v.isNull )
         break;
      id = baseId + format( "%02d", i );
   }
   return id;
}

function computeRect( imgW, imgH, ratioW, ratioH, normCX, normCY, normW ) {
   var cropW = Math.round( clamp( normW, 0.01, 1.0 ) * imgW );
   var cropH = Math.round( cropW * ratioH / ratioW );
   if ( cropH > imgH ) {
      cropH = imgH;
      cropW = Math.round( cropH * ratioW / ratioH );
   }
   var cx = Math.round( normCX * imgW );
   var cy = Math.round( normCY * imgH );
   var x  = clamp( cx - Math.floor( cropW / 2 ), 0, imgW - cropW );
   var y  = clamp( cy - Math.floor( cropH / 2 ), 0, imgH - cropH );
   return { x: x, y: y, width: cropW, height: cropH };
}

var PREVIEW_ID = "RatioCropPreview";
var PAD_SIZE   = 160;
var NUDGE_STEP = 0.01;

// ---------------------------------------------------------------------------
// Joystick pad control
// ---------------------------------------------------------------------------

class JoystickPad extends Control
{
constructor( parent )
{
   super( parent );

   this.normX      = 0.5;
   this.normY      = 0.5;
   this.isDragging = false;
   this.onChange   = null;

   this.setFixedSize( PAD_SIZE, PAD_SIZE );
   this.cursor = new Cursor( StdCursor.Cross );

   var pad = this;

   this.onPaint = function( x, y, w, h ) {
      var g = new Graphics( pad );
      g.antialiasing = true;

      g.fillRect( 0, 0, w, h, new Brush( 0xFF282828 ) );

      g.pen = new Pen( 0xFF464646 );
      g.drawLine( w/2, 0, w/2, h );
      g.drawLine( 0, h/2, w, h/2 );
      g.drawLine( w/4, 0, w/4, h );
      g.drawLine( 3*w/4, 0, 3*w/4, h );
      g.drawLine( 0, h/4, w, h/4 );
      g.drawLine( 0, 3*h/4, w, 3*h/4 );

      g.pen = new Pen( 0xFF646464 );
      g.drawRect( 0, 0, w-1, h-1 );

      var dotX = Math.round( pad.normX * (w-1) );
      var dotY = Math.round( pad.normY * (h-1) );

      g.pen = new Pen( 0x00000000 );
      g.fillEllipse( dotX-7, dotY-7, dotX+9, dotY+9, new Brush( 0x88000000 ) );
      g.fillEllipse( dotX-6, dotY-6, dotX+8, dotY+8, new Brush( 0xFF40A0FF ) );
      g.pen = new Pen( 0xFFC8E6FF );
      g.drawEllipse( dotX-6, dotY-6, dotX+8, dotY+8 );
      g.pen = new Pen( 0xBBFFFFFF );
      g.drawLine( dotX, dotY-4, dotX, dotY+4 );
      g.drawLine( dotX-4, dotY, dotX+4, dotY );

      g.end();
   };

   this.onMousePress = function( x, y, button, buttons, modifiers ) {
      pad.isDragging = true;
      pad.setFromMouse( x, y );
   };

   this.onMouseMove = function( x, y, buttons, modifiers ) {
      if ( pad.isDragging )
         pad.setFromMouse( x, y );
   };

   this.onMouseRelease = function( x, y, button, buttons, modifiers ) {
      pad.isDragging = false;
   };
}

setFromMouse( mx, my ) {
   this.normX = clamp( mx / (PAD_SIZE - 1), 0, 1 );
   this.normY = clamp( my / (PAD_SIZE - 1), 0, 1 );
   this.update();
   if ( this.onChange ) this.onChange( this.normX, this.normY );
}

setNorm( nx, ny ) {
   this.normX = clamp( nx, 0, 1 );
   this.normY = clamp( ny, 0, 1 );
   this.update();
}

} // class JoystickPad

// ---------------------------------------------------------------------------
// Main dialog
// ---------------------------------------------------------------------------

class RatioCropDialog extends Dialog
{
constructor()
{
   super();

   var dlg = this;

   this.imgW   = 0;
   this.imgH   = 0;
   this.ratioW = 3;
   this.ratioH = 2;
   this.normCX = 0.5;
   this.normCY = 0.5;
   this.normW  = 1.0;
   this.targetWindow = null;
   this.parametersLoaded = false;

   var PRESETS = [
      { label: "1:1",  w: 1,  h: 1  }, { label: "4:3",  w: 4,  h: 3  },
      { label: "3:2",  w: 3,  h: 2  }, { label: "5:4",  w: 5,  h: 4  },
      { label: "16:9", w: 16, h: 9  }, { label: "2:1",  w: 2,  h: 1  },
      { label: "3:4",  w: 3,  h: 4  }, { label: "2:3",  w: 2,  h: 3  },
      { label: "4:5",  w: 4,  h: 5  }, { label: "9:16", w: 9,  h: 16 }
   ];

   // --- Title ---------------------------------------------------------------
   this.titleLabel = new Label( this );
   this.titleLabel.text =
      "Drag the pad or use arrow buttons to position. " +
      "Size slider scales (ratio locked). Click Apply to crop.";
   this.titleLabel.wordWrapping = true;
   this.titleLabel.minWidth = 400;

   // --- Presets -------------------------------------------------------------
   this.presetBtn = [];
   for ( var i = 0; i < PRESETS.length; i++ ) {
      var btn = new PushButton( this );
      btn.text = PRESETS[i].label;
      btn.rW   = PRESETS[i].w;
      btn.rH   = PRESETS[i].h;
      btn.onClick = function() {
         dlg.ratioW_Edit.text = String( this.rW );
         dlg.ratioH_Edit.text = String( this.rH );
         dlg.onRatioChanged();
      };
      this.presetBtn.push( btn );
   }

   this.presetRow1_Sizer = new HorizontalSizer;
   this.presetRow1_Sizer.spacing = 4;
   for ( var i = 0; i < 6; i++ ) this.presetRow1_Sizer.add( this.presetBtn[i] );
   this.presetRow1_Sizer.addStretch();

   this.presetRow2_Sizer = new HorizontalSizer;
   this.presetRow2_Sizer.spacing = 4;
   for ( var i = 6; i < PRESETS.length; i++ ) this.presetRow2_Sizer.add( this.presetBtn[i] );
   this.presetRow2_Sizer.addStretch();

   this.presets_Sizer = new VerticalSizer;
   this.presets_Sizer.margin  = 6;
   this.presets_Sizer.spacing = 4;
   this.presets_Sizer.add( this.presetRow1_Sizer );
   this.presets_Sizer.add( this.presetRow2_Sizer );

   this.presetGroupBox = new GroupBox( this );
   this.presetGroupBox.title = "Presets";
   this.presetGroupBox.sizer = this.presets_Sizer;

   // --- Custom ratio --------------------------------------------------------
   this.ratioW_Label = new Label( this );
   this.ratioW_Label.text = "Width :";
   this.ratioW_Label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
   this.ratioW_Label.minWidth = 52;

   this.ratioW_Edit = new Edit( this );
   this.ratioW_Edit.text = "3";
   this.ratioW_Edit.minWidth = 52;
   this.ratioW_Edit.onTextUpdated = function() { dlg.onRatioChanged(); };

   this.ratioH_Label = new Label( this );
   this.ratioH_Label.text = "Height :";
   this.ratioH_Label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
   this.ratioH_Label.minWidth = 52;

   this.ratioH_Edit = new Edit( this );
   this.ratioH_Edit.text = "2";
   this.ratioH_Edit.minWidth = 52;
   this.ratioH_Edit.onTextUpdated = function() { dlg.onRatioChanged(); };

   this.custom_Sizer = new HorizontalSizer;
   this.custom_Sizer.margin  = 6;
   this.custom_Sizer.spacing = 6;
   this.custom_Sizer.add( this.ratioW_Label );
   this.custom_Sizer.add( this.ratioW_Edit  );
   this.custom_Sizer.addSpacing( 12 );
   this.custom_Sizer.add( this.ratioH_Label );
   this.custom_Sizer.add( this.ratioH_Edit  );
   this.custom_Sizer.addStretch();

   this.customGroupBox = new GroupBox( this );
   this.customGroupBox.title = "Custom Ratio";
   this.customGroupBox.sizer = this.custom_Sizer;

   // --- Size slider ---------------------------------------------------------
   this.sizeLabel = new Label( this );
   this.sizeLabel.text = "Size :";
   this.sizeLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
   this.sizeLabel.minWidth = 52;

   this.size_Slider = new Slider( this );
   this.size_Slider.minValue = 1;
   this.size_Slider.maxValue = 100;
   this.size_Slider.value    = 100;
   this.size_Slider.minWidth = 180;
   this.size_Slider.onValueUpdated = function( v ) {
      dlg.normW = v / 100.0;
      dlg.updateAll();
   };

   this.sizeValue_Label = new Label( this );
   this.sizeValue_Label.text = "100%";
   this.sizeValue_Label.minWidth = 40;
   this.sizeValue_Label.textAlignment = TextAlignment.Left | TextAlignment.VertCenter;

   this.size_Sizer = new HorizontalSizer;
   this.size_Sizer.spacing = 6;
   this.size_Sizer.add( this.sizeLabel       );
   this.size_Sizer.add( this.size_Slider     );
   this.size_Sizer.add( this.sizeValue_Label );

   this.sizeGroupBox = new GroupBox( this );
   this.sizeGroupBox.title = "Size  (ratio locked)";
   this.sizeGroupBox.sizer = this.size_Sizer;

   // --- Joystick pad + arrow buttons ----------------------------------------
   this.pad = new JoystickPad( this );
   this.pad.onChange = function( nx, ny ) {
      dlg.normCX = nx;
      dlg.normCY = ny;
      dlg.updateAll();
   };

   this.upBtn     = new PushButton( this ); this.upBtn.text     = "\u25b2"; this.upBtn.setFixedSize( 36, 28 );
   this.downBtn   = new PushButton( this ); this.downBtn.text   = "\u25bc"; this.downBtn.setFixedSize( 36, 28 );
   this.leftBtn   = new PushButton( this ); this.leftBtn.text   = "\u25c4"; this.leftBtn.setFixedSize( 36, 28 );
   this.rightBtn  = new PushButton( this ); this.rightBtn.text  = "\u25ba"; this.rightBtn.setFixedSize( 36, 28 );
   this.centerBtn = new PushButton( this ); this.centerBtn.text = "\u25a0"; this.centerBtn.setFixedSize( 36, 28 );
   this.centerBtn.toolTip = "Reset to center";

   this.upBtn.onClick    = function() { dlg.nudge(  0, -1 ); };
   this.downBtn.onClick  = function() { dlg.nudge(  0,  1 ); };
   this.leftBtn.onClick  = function() { dlg.nudge( -1,  0 ); };
   this.rightBtn.onClick = function() { dlg.nudge(  1,  0 ); };
   this.centerBtn.onClick = function() {
      dlg.normCX = 0.5; dlg.normCY = 0.5;
      dlg.pad.setNorm( 0.5, 0.5 );
      dlg.updateAll();
   };

   this.arrowTop_Sizer = new HorizontalSizer;
   this.arrowTop_Sizer.addStretch();
   this.arrowTop_Sizer.add( this.upBtn );
   this.arrowTop_Sizer.addStretch();

   this.arrowMid_Sizer = new HorizontalSizer;
   this.arrowMid_Sizer.spacing = 2;
   this.arrowMid_Sizer.add( this.leftBtn   );
   this.arrowMid_Sizer.add( this.centerBtn );
   this.arrowMid_Sizer.add( this.rightBtn  );

   this.arrowBot_Sizer = new HorizontalSizer;
   this.arrowBot_Sizer.addStretch();
   this.arrowBot_Sizer.add( this.downBtn );
   this.arrowBot_Sizer.addStretch();

   this.arrows_Sizer = new VerticalSizer;
   this.arrows_Sizer.spacing = 2;
   this.arrows_Sizer.addStretch();
   this.arrows_Sizer.add( this.arrowTop_Sizer );
   this.arrows_Sizer.add( this.arrowMid_Sizer );
   this.arrows_Sizer.add( this.arrowBot_Sizer );
   this.arrows_Sizer.addStretch();

   this.padAndArrows_Sizer = new HorizontalSizer;
   this.padAndArrows_Sizer.spacing = 10;
   this.padAndArrows_Sizer.add( this.pad          );
   this.padAndArrows_Sizer.add( this.arrows_Sizer );
   this.padAndArrows_Sizer.addStretch();

   this.posGroupBox = new GroupBox( this );
   this.posGroupBox.title = "Position  (drag pad or use arrows)";
   this.posGroupBox.sizer = new VerticalSizer;
   this.posGroupBox.sizer.margin  = 8;
   this.posGroupBox.sizer.spacing = 4;
   this.posGroupBox.sizer.add( this.padAndArrows_Sizer );

   // --- Info panel ----------------------------------------------------------
   this.infoLabel = new Label( this );
   this.infoLabel.text = "Loading...";
   this.infoLabel.wordWrapping = true;
   this.infoLabel.minWidth  = 320;
   this.infoLabel.minHeight = 70;

   this.info_Sizer = new HorizontalSizer;
   this.info_Sizer.margin = 6;
   this.info_Sizer.add( this.infoLabel );

   this.infoGroupBox = new GroupBox( this );
   this.infoGroupBox.title = "Crop Info";
   this.infoGroupBox.sizer = this.info_Sizer;

   // --- Output options --------------------------------------------------
   this.replaceCheck = new CheckBox( this );
   this.replaceCheck.text    = "Replace target image";
   this.replaceCheck.checked = false;
   this.replaceCheck.toolTip =
      "If checked, the crop is applied directly to the active image.\n" +
      "If unchecked, a new view is created with the cropped result, " +
      "leaving the original image untouched.";

   this.outputGroupBox = new GroupBox( this );
   this.outputGroupBox.title = "Output";
   this.outputGroupBox.sizer = new HorizontalSizer;
   this.outputGroupBox.sizer.margin = 6;
   this.outputGroupBox.sizer.add( this.replaceCheck );

   // --- Buttons -------------------------------------------------------------
   this.newInstanceButton = new ToolButton( this );
   this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
   this.newInstanceButton.setScaledFixedSize( 24, 24 );
   this.newInstanceButton.toolTip = "New Instance — drag to create a process icon with the current settings.";
   this.newInstanceButton.onMousePress = () => {
      dlg.saveParameters();
      dlg.newInstance();
   };

   this.apply_Button = new PushButton( this );
   this.apply_Button.text    = "Apply";
   this.apply_Button.icon    = this.scaledResource( ":/icons/ok.png" );
   this.apply_Button.enabled = false;
   this.apply_Button.onClick = function() { dlg.removePreview(); dlg.ok(); };

   this.close_Button = new PushButton( this );
   this.close_Button.text = "Cancel";
   this.close_Button.icon = this.scaledResource( ":/icons/cancel.png" );
   this.close_Button.onClick = function() { dlg.removePreview(); dlg.cancel(); };

   this.buttons_Sizer = new HorizontalSizer;
   this.buttons_Sizer.spacing = 8;
   this.buttons_Sizer.add( this.newInstanceButton );
   this.buttons_Sizer.addStretch();
   this.buttons_Sizer.add( this.apply_Button );
   this.buttons_Sizer.add( this.close_Button );

   // --- Main layout ---------------------------------------------------------
   this.sizer = new VerticalSizer;
   this.sizer.margin  = 8;
   this.sizer.spacing = 8;
   this.sizer.add( this.titleLabel     );
   this.sizer.add( this.presetGroupBox );
   this.sizer.add( this.customGroupBox );
   this.sizer.add( this.sizeGroupBox   );
   this.sizer.add( this.posGroupBox    );
   this.sizer.add( this.infoGroupBox   );
   this.sizer.add( this.outputGroupBox );
   this.sizer.add( this.buttons_Sizer  );

   this.windowTitle = "RatioCrop";
   this.adjustToContents();
   this.setFixedSize();

   this.loadParameters();

   this.onShow = function() { dlg.init(); };
}

init() {
   var win = ImageWindow.activeWindow;
   if ( win == null || win.isNull ) return;
   this.targetWindow = win;
   this.imgW = win.mainView.image.width;
   this.imgH = win.mainView.image.height;

   if ( !this.parametersLoaded ) {
      var r = computeRect( this.imgW, this.imgH, this.ratioW, this.ratioH, 0.5, 0.5, 1.0 );
      this.normW = r.width / this.imgW;
      this.size_Slider.value = Math.round( this.normW * 100 );
      this.pad.setNorm( 0.5, 0.5 );
   }
   else {
      this.pad.setNorm( this.normCX, this.normCY );
   }
   this.updateAll();
}

nudge( dx, dy ) {
   this.normCX = clamp( this.normCX + dx * NUDGE_STEP, 0, 1 );
   this.normCY = clamp( this.normCY + dy * NUDGE_STEP, 0, 1 );
   this.pad.setNorm( this.normCX, this.normCY );
   this.updateAll();
}

onRatioChanged() {
   var w = parseFloat( this.ratioW_Edit.text );
   var h = parseFloat( this.ratioH_Edit.text );
   if ( !isNaN(w) && !isNaN(h) && w > 0 && h > 0 ) {
      this.ratioW = w; this.ratioH = h;
   }
   this.updateAll();
}

removePreview() {
   if ( this.targetWindow == null || this.targetWindow.isNull ) return;
   var previews = this.targetWindow.previews;
   for ( var i = 0; i < previews.length; i++ ) {
      if ( previews[i].id == PREVIEW_ID ) {
         this.targetWindow.deletePreview( previews[i] );
         break;
      }
   }
}

updatePreviewBox( rect ) {
   if ( this.targetWindow == null || this.targetWindow.isNull ) return;
   this.removePreview();
   this.targetWindow.createPreview(
      new Rect( rect.x, rect.y, rect.x + rect.width, rect.y + rect.height ),
      PREVIEW_ID
   );
   this.targetWindow.currentView = this.targetWindow.mainView;
}

updateAll() {
   if ( this.imgW === 0 ) return;
   var rect = computeRect( this.imgW, this.imgH,
                            this.ratioW, this.ratioH,
                            this.normCX, this.normCY, this.normW );
   this.updatePreviewBox( rect );
   this.sizeValue_Label.text = Math.round( this.normW * 100 ) + "%";
   this.infoLabel.text =
      "Image      :  " + this.imgW + " x " + this.imgH + " px\n" +
      "Crop size  :  " + rect.width + " x " + rect.height + " px\n" +
      "Position   :  x=" + rect.x + " px,  y=" + rect.y + " px\n" +
      "Ratio      :  " + this.ratioW + " : " + this.ratioH;
   this.apply_Button.enabled =
      ( rect.width < this.imgW || rect.height < this.imgH );
}

getRect() {
   return computeRect( this.imgW, this.imgH,
                       this.ratioW, this.ratioH,
                       this.normCX, this.normCY, this.normW );
}

getReplaceTarget() {
   return this.replaceCheck.checked;
}

saveParameters() {
   Parameters.set( "ratioW",       this.ratioW );
   Parameters.set( "ratioH",       this.ratioH );
   Parameters.set( "normCX",       this.normCX );
   Parameters.set( "normCY",       this.normCY );
   Parameters.set( "normW",        this.normW );
   Parameters.set( "replaceTarget", this.replaceCheck.checked );
}

loadParameters() {
   if ( !Parameters.has( "ratioW" ) && !Parameters.has( "normW" ) )
      return;   // nothing saved — use defaults computed by init()

   this.parametersLoaded = true;

   if ( Parameters.has( "ratioW" ) )        this.ratioW = Parameters.getReal( "ratioW" );
   if ( Parameters.has( "ratioH" ) )        this.ratioH = Parameters.getReal( "ratioH" );
   if ( Parameters.has( "normCX" ) )        this.normCX = Parameters.getReal( "normCX" );
   if ( Parameters.has( "normCY" ) )        this.normCY = Parameters.getReal( "normCY" );
   if ( Parameters.has( "normW" ) )         this.normW  = Parameters.getReal( "normW" );
   if ( Parameters.has( "replaceTarget" ) ) this.replaceCheck.checked = Parameters.getBoolean( "replaceTarget" );

   this.ratioW_Edit.text = String( this.ratioW );
   this.ratioH_Edit.text = String( this.ratioH );
   this.size_Slider.value = Math.round( this.normW * 100 );
}

} // class RatioCropDialog

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

function main() {
   Console.show();

   var win = ImageWindow.activeWindow;
   if ( win == null || win.isNull ) {
      (new MessageBox( "No active image window — open an image first.",
         "RatioCrop", StdIcon.Error, StdButton.Ok )).execute();
      return;
   }

   var dialog = new RatioCropDialog();
   if ( dialog.execute() != 1 )
      return;

   var rect = dialog.getRect();
   var replaceTarget = dialog.getReplaceTarget();

   try {
      var targetWin = win;
      var img;

      if ( !replaceTarget ) {
         // Create a new window with a copy of the active image and crop
         // that instead, leaving the original untouched.
         var srcImage = win.mainView.image;
         var newId    = uniqueViewId( win.mainView.id + "_crop" );

         targetWin = new ImageWindow(
            srcImage.width,
            srcImage.height,
            srcImage.numberOfChannels,
            srcImage.bitsPerSample,
            srcImage.sampleType != 0,   // != 0 means float/real
            srcImage.colorSpace != 0,   // 0 = grayscale
            newId
         );

         targetWin.mainView.beginProcess( UndoFlag.NoSwapFile );
         targetWin.mainView.image.assign( srcImage );
         targetWin.mainView.endProcess();

         targetWin.show();
      }

      img = targetWin.mainView.image;

      var P = new DynamicCrop;
      P.centerX           = ( rect.x + rect.width  / 2 ) / img.width;
      P.centerY           = ( rect.y + rect.height / 2 ) / img.height;
      P.width             = rect.width  / img.width;
      P.height            = rect.height / img.height;
      P.angle             = 0.0;
      P.scaleX            = 1.0;
      P.scaleY            = 1.0;
      P.optimizeFast      = true;
      P.interpolation     = DynamicCrop.Auto;
      P.clampingThreshold = 0.30;
      P.smoothness        = 1.50;
      P.forceResolution   = false;

      P.executeOn( targetWin.mainView, true );

      Console.writeln(
         "<end><cbr>RatioCrop: " +
         dialog.ratioW + ":" + dialog.ratioH +
         " -> " + rect.width + "x" + rect.height +
         " px  (x=" + rect.x + ", y=" + rect.y + ")" +
         ( replaceTarget ? "  [replaced target]" : "  [new view: " + targetWin.mainView.id + "]" )
      );
   } catch ( e ) {
      (new MessageBox( "Error applying crop:\n" + e.message,
         "RatioCrop", StdIcon.Error, StdButton.Ok )).execute();
   }
}

main();
