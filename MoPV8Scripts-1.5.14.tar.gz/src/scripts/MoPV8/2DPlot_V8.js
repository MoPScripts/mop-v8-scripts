/*

   2DPlot.js: Pixel Intensity Plot.
================================================================================

   Draws intensity curves along lines between 2 points

   This is a complete replacement for 2DPlot from 2014


   Copyright (C) 2013, Hartmut V. Bornemann

   Code used from
   PreviewControl.jsh, Copyright (C) 2013-2020, Andres del Pozo

   Many thanks to Herbert Walter for his critical comments and
   inspiring suggestions

   Version history
           4.0.2   2022-03-01 GUI changed, satellite track removal removed
           4.0.10  2021-10-27 GUI changed, satellite track removal in a tabBox
           4.0.8   2021-10-10 some GUI adjustments for a better look
           4.0.7   2021-06-05 message, if script was started without image
           4.0.5   2020-05-26 minor adjustments
           4.0.4   2020-05-23 features added
           4.0.0   2020-05-16 NEW


================================================================================


*/

#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Hartmut V. Bornemann.
// PreviewControl code originally by Andres del Pozo. No rights to the
// original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; removed all
// 14 #include <pjsr/...> directives (PJSR globals available without them);
// converted showDialog (extends Dialog), PreviewControl (extends Frame),
// and infoDialog (extends Dialog) from __base__/.prototype = new X to
// class extends X / super(); replaced 2 .prototype. enum references
// (AutomaticBackgroundExtractor, DynamicPSF) with direct class access;
// replaced underscore constants with dot notation across TextAlign_*,
// FrameStyle_Box, StdIcon_*, StdButton_Ok, UndoFlag_NoSwapFile,
// StdCursor_*, ColorSpace_Gray, PenStyle_*, MouseButton_*, KeyModifier_
// Control; VectorGraphics -> Graphics; removed one deprecated gc(true)
// call; replaced 6 bare processEvents() with
// CoreApplication.processEvents(); replaced 3 SaveFileDialog.fileName
// with .filePath; replaced 10 lowercase console. calls with Console.
// (the systemic bug found across most of the MoP V8 repo).
//
// Also fixed a brace-less "expression closure" --
// `this.btn.onClick = function(checked) dialog.done(0);` with no braces
// around the body -- a non-standard SpiderMonkey extension V8 never
// supported at all (same class of hard parse-time failure as the
// for-each-in syntax found in other scripts in this project).
//
// This is by far the largest with()-block conversion in this project:
// 74 with() blocks, all expanded and verified by hand rather than by
// automated tooling, following the methodology established on
// EmissionLineIntegration and PSFImage -- checking every bare
// identifier (including inside nested callback bodies, since with()
// extends its scope into nested closures) against the target's real
// properties, the enclosing function's own local variables, and any
// top-level functions of the same name (a few spots call genuinely
// global functions like plotter()-style helpers from inside a with()
// block; those correctly stay bare rather than getting prefixed).
// While converting the three class boundaries, an initial assumption
// about where showDialog's constructor actually closed turned out to
// be wrong by about 1300 lines (it closes well before PreviewControl,
// not right before it) -- caught by running an actual Node.js syntax
// check rather than trusting a naive brace-counting scan, which can be
// fooled by braces appearing inside strings and comments.
//
// 2026-08-27: two fixes found via user testing. (1)
// AutomaticBackgroundExtractor.f32 (the ORIGINAL script used the .prototype.
// form) doesn't exist as a namespace constant in V8 -- I incorrectly
// mechanically stripped ".prototype." and kept the dot access, the same
// mistake made once before with SampleType_Real on a different script.
// modelImageSampleFormat needs the raw integer 1 (float), same convention
// as SampleType (0=integer, 1=float). Fixed; the other
// AutomaticBackgroundExtractor/DynamicPSF constants in this file (None,
// SameAsTarget, Star_DetectedOk, Scale_Pixels, Function_Gaussian,
// PSF_FittedOk) are genuine namespaced enums and were left as-is. (2)
// Several bare Graphics API references inside the two big with(graphics)
// blocks (canvas.onPaint and previewControl.onCustomPaint) were missed
// during conversion -- "pen", used as a plain value on the right-hand
// side of `var oldPen = pen;`, and "textRect(...)" called as part of a
// variable declaration rather than as its own statement. The scripted
// substitution used for these two blocks only matched identifiers at
// the very start of a line (as an assignment target or a bare call);
// it never scanned for the same identifiers appearing mid-expression or
// on the right-hand side of an unrelated assignment. Swept both blocks
// exhaustively for the same pattern (found 3 more instances beyond the
// one reported) and checked every other converted script in this
// project for it too -- none of the others had it.
// ----------------------------------------------------------------------------

#feature-id    2DPlot : MoP V8 > 2DPlot

#define TITLE "2DPlot - View image profiles, erase bright tracks - "
#define VERSION "4.0.2"
#define DEFAULT_AUTOSTRETCH_SCLIP -2.80
// Target mean background in the [0,1] range.
#define DEFAULT_AUTOSTRETCH_TBGND   0.25
#define DEFAULT_AUTOSTRETCH_CLINK   false
#define SETTINGS_MODULE_SCRIPT "SOLVER"


#define Graphics_Offset 11
#define Slider_Radius   5.5
#define Scale_Width     25
#define Scale_Button_Width 7
#define boxHeight 24

#define Horizontal      0
#define Vertical        1
#define DiagonalDn      2
#define DiagonalUp      3
#define Single_Point    4
#define Double_Point    5
#define maxLineSize    25

#define lineMode 0
#define starMode 1
#define panMode  2

#define PSF_starIndex   0
#define PSF_function    1
#define PSF_circular    2
#define PSF_status      3
#define PSF_B           4
#define PSF_A           5
#define PSF_cx          6
#define PSF_cy          7
#define PSF_sx          8
#define PSF_sy          9
#define PSF_theta      10
#define PSF_beta       11
#define PSF_residual   12
#define PSF_mad   	  12
#define PSF_x0         13
#define PSF_y0         14
#define PSF_x1         15
#define PSF_y1         16


/* ****************************************************************************
 *
 *    Dialog
 *
 * ****************************************************************************
 */
function blackLine(size, angle, p1, p2, channelFlags, mode)
{
   this.size         = size;
   this.angle        = angle;
   this.p1           = new Point(p1.x, p1.y);
   this.p2           = new Point(p2.x, p2.y);
   this.channelFlags = channelFlags;
   this.mode         = mode;

   this.getColor = function ()
   {
      var s = ['0xff'];
      for (var i = 0; i < this.channelFlags.length; i++)
      {
         if (this.channelFlags[i])
            s.push('00');
         else
            s.push('ff');
      }
      var c = s.join('');
      return parseInt(c);
   }
}

function controlVariables()
{
   this.angle = 0;               // line angle
   this.blackLines = [];         // collection of black lines
   this.blackLineIndex = -1;     // index of viewing black line
   this.buttonIndex = 0;         // button with mouseOver
   this.buttonMoving = false;
   this.buttonPos = null;
   this.channels = 0;            // # of channels
   this.celestialCoord = null;
   this.coordinates = [];        // points along the line p1 -> p2
   this.currentView = null;
   this.dataChanged = false;
   this.imageData = null;        // object with image and background pixels
   this.lineSize = 0;            // thickness of black line
   this.magnify = 11;            // magnify glass scale
   this.magnification = false;
   this.maxValue = 1;
   this.maxValueData = 0;
   this.meanCentroid = null;     // average of RGB
   this.metadata = null;
   this.minValue = 0;
   this.minValueData = 0;
   this.mode = Horizontal;
   this.mouseMode = lineMode;
   this.mouseOver = false;       // mouse moving, no buttons
   this.mousePos  = null;
   this.p1 = null;               // click position
   this.p2 = null;
   this.paintClear = false;
   this.lineOffset = 0;          // parallel moves line
   this.p1Home = null;           // click position
   this.p2Home = null;
   this.pixelPos = null;
   this.pScale = 1;
   this.scaleLen = 0;
   this.scanData = [];           // array with arrays of scanData
   this.smallRect = new Rect(0, 0, 20, 20);
   this.starProfiles = [];
   this.starPosition = null;
   this.starPSF = null;          // PSF object
   this.STF = false;             // true, if STF viewing
   this.verticalBar = 0;
   this.z = 0;                   // beginning of lineGraph
}


class showDialog extends Dialog
{
constructor()
{
   super();
   this.userResizable = true;
   var dialog = this;


   var formsScaling = this.displayPixelRatio ;
   var Screen = GetPrimaryScreenDimensions(dialog);

   var h = 650;
   var w = 600;
   var scaleNumRect     = new Rect();


   this.rectButtons  = [new Rect(-Scale_Button_Width, -Scale_Button_Width,
                                 +Scale_Button_Width, +Scale_Button_Width),
                        new Rect(-Scale_Button_Width, -Scale_Button_Width,
                                 +Scale_Button_Width, +Scale_Button_Width)];

   this.title        = TITLE + VERSION;

   var cv = new controlVariables();
   setScaleNumRect();

   var sizerpos            = 0;
   var plotFrameMinsize    = 0;
   var imageFrameMinsize   = 0;
   var dialogMinSize       = 0;

   var normalSize;
   var isNormalSize = true;

   //var primaryScreen       = primaryScreenDimensions(dialog);
   var normalDialogWin     = null;
   var magnifyRect = new Rect(0, 0, cv.smallRect.x1, cv.smallRect.y1);
   magnifyRect.mul(cv.magnify);


   // my ©

   this.lblCopyright = new Label(this)
   this.lblCopyright.text = "© 2020, Hartmut V. Bornemann";


   this.scaleFrame = new Frame(this);
   this.scaleFrame.frameStyle  = FrameStyle.Box;
      this.scaleFrame.setFixedWidth(Scale_Width);
      this.scaleFrame.backgroundColor = 0xffd0d0d0;
      this.scaleFrame.toolTip = 'Adjust diagram value range by moving white and black buttons.<p>' +
                'A double click resets the range to 0..1';

      this.scaleFrame.onPaint = function( x0, y0, x1, y1 )
      {
         let graphics = new Graphics( this );
            var h = dialog.scaleFrame.clientRect.height - 2 * Graphics_Offset;
            var w = dialog.scaleFrame.clientRect.width;

            // fill value area darker

            var top = (1 - cv.maxValueData) * h;
            var bot = (1 - cv.minValueData) * h;
            var dark = new Brush(0xffa0a0a0);
            graphics.fillRect(0, top + Graphics_Offset, w, bot + Graphics_Offset, dark);

            graphics.pen = new Pen(0xff000000);

            graphics.translateTransformation(Scale_Width / 2, 0);

            // vertical line

            graphics.drawLine(0, Graphics_Offset, 0, h + Graphics_Offset);
            graphics.drawLine(-Graphics_Offset, Graphics_Offset, Graphics_Offset, Graphics_Offset);
            graphics.drawLine(-Graphics_Offset, h + Graphics_Offset, Graphics_Offset, h + Graphics_Offset);

            // buttons

            var buttonValues = [cv.maxValue, cv.minValue];

            var brushes = [new Brush(0xffffffff), new Brush(0xff000000)];

            for (var i = 0; i < 2; i++)
            {
               var y = (1 - buttonValues[i]) * h;
               dialog.rectButtons[i].center = new Point(0, y + Graphics_Offset);
            }

            var j = 1 - cv.buttonIndex;

            graphics.antialiasing = true;
            for (var i = 0; i < 2; i++)
            {
               graphics.brush = brushes[j];
               graphics.fillRoundedRect(dialog.rectButtons[j]);
               graphics.drawRoundedRect(dialog.rectButtons[j]);
               j = 1 - j;
            }

            graphics.antialiasing = false;
            for (var k = 0; k < 2; k++)
            {
               graphics.pen = new Pen([0xff000000, 0xffffffff][k]);
               var u = dialog.rectButtons[k].center.y;
               graphics.drawLine (dialog.rectButtons[k].left, u, dialog.rectButtons[k].right, u);
            }
            graphics.end();
      }

      this.scaleFrame.onMouseDoubleClick = function( x, y, buttonState, modifiers )
      {
         cv.maxValue = 1;
         cv.minValue = 0;
         dialog.scaleFrame.repaint();
         dialog.canvas.repaint();
      }

      this.scaleFrame.onMouseMove = function( x, y, buttonState, modifiers )
      {
         if (buttonState == MouseButton.Left && cv.buttonMoving )
         {
            var m = y - dialog.rectButtons[cv.buttonIndex].center.y;  // delta pixels
            var a = [cv.maxValue, cv.minValue];
            var v = a[cv.buttonIndex];
            var u = v - m / cv.scaleLen;
            u = Math.range(u, 0, 1);
            a[cv.buttonIndex] = u;
            if ((a[0] > a[1]))
            {
               cv.maxValue = a[0];
               cv.minValue = a[1];
               dialog.scaleFrame.repaint();
               dialog.canvas.repaint();
            }
         }
      }

      this.scaleFrame.onMousePress = function( x, y, button, buttonState, modifiers)
      {
         if (buttonState == MouseButton.Left)
         {
            //
            // select the button
            //
            cv.buttonMoving = false;
            var minDist = Scale_Button_Width + 2;
            for (var i = 0; i < 2; i++)
            {
               var d = Math.abs(y - dialog.rectButtons[i].center.y);
               if (d < minDist)
               {
                  minDist = d;
                  cv.buttonIndex = i;
                  cv.buttonMoving = true;
                  dialog.scaleFrame.cursor = new Cursor( StdCursor.ClosedHand );
               }
            }
         }
      }

      this.scaleFrame.onMouseRelease = function( x, y, button, buttonState, modifiers)
      {
         dialog.scaleFrame.cursor = new Cursor( StdCursor.Arrow);
      }

      this.scaleFrame.onResize = function(wNew, hNew, wOld, hOld )
      {
         cv.scaleLen = hNew - (Graphics_Offset+1) * 2;
      }

   this.canvas = new Frame(this);
   this.canvas.backgroundColor = 0xffffffff;
      this.canvas.setVariableSize();
      this.canvas.onPaint = function( x0, y0, x1, y1 )
      {
         let graphics = new Graphics( this );
            // gridlines
            //
            graphics.pen = new Pen(0xff000000);
            var ya = Graphics_Offset + 1;
            var yb = Graphics_Offset + cv.scaleLen;
            var range = cv.maxValue - cv.minValue;

            var w = cv.imageData.bounds.width;
            var h = cv.imageData.bounds.height;

            var H = dialog.canvas.clientRect.height;

            var ticklen = 7;

            var dv = range / 10;
            var y  = ya;
            var dy = (yb - ya) / 10;
            var m = cv.maxValue;

            cv.z = scaleNumRect.width + ticklen + 2;
            var b = scaleNumRect.height / 2;

            for (var i = 0; i < 11; i++)
            {
               scaleNumRect.moveTo(new Point(cv.z - scaleNumRect.width - ticklen - 4,  y - b));
               if (cv.pScale == 1)
               {
                  graphics.drawTextRect( scaleNumRect, m.toFixed(6), TextAlignment.Center | TextAlignment.Right);
               }
               else
               {
                  graphics.drawTextRect( scaleNumRect, (m * cv.pScale).toFixed(0),
                     TextAlignment.Center | TextAlignment.Right);
               }
               m -= dv;
               y += dy;
               if (m < 0) m = 0;
            }

            var dv = range / 10;
            var y  = ya;
            var dy = (yb - ya) / 10;

            for (var i = 0; i < 11; i++)
            {
               graphics.pen = new Pen(0xff000000);
               graphics.drawLine(cv.z - ticklen, y, cv.z, y);
               graphics.pen = new Pen(0x60000000, 0.5, PenStyle.DashDot);
               graphics.drawLine(cv.z  , y, x1, y);
               y += dy;
            }

            // channel flags

            var cf = [dialog.cbR.checked, dialog.cbG.checked, dialog.cbB.checked];

            var colors;
            if (cv.imageData.isGrayscale())
               colors = [0xff000000];
            else
               colors = [Color.RED, Color.GREEN, Color.BLUE];

            // pixel profile(s)

            for (var c = 0; c < cv.imageData.numberOfChannels(); c++)
            {

               if (cv.p1 != null && cv.p2 != null)
               {
                  var f  = cv.scaleLen / range;
                  var xs = cv.p2.x - cv.p1.x;
                  var ys = cv.p2.y - cv.p1.y;
                  if (!cf[c]) continue;
                  //
                  // paint intensities
                  //
                  var scanData = cv.scanData[c];

                  graphics.pen = new Pen(colors[c]);

                  if (scanData.length == 0) continue;

                  var xLen = dialog.canvas.clientRect.width - cv.z;
                  var xy = [];
                  var x = cv.z;
                  var dx = xLen / scanData.length;

                  for (var i = 0; i < scanData.length; i++)
                  {
                     var v = cv.scaleLen - (scanData[i].i  - cv.minValue) * f;
                     xy.push(new Point(x, v + Graphics_Offset));
                     x += dx;
                     xy.push(new Point(x, v + Graphics_Offset));
                  }

                  graphics.drawPolyline(xy);

                  if (cv.imageData.isGrayscale()) graphics.pen = new Pen(Color.RED);

                  if (dialog.cbMean.checked)
                  {
                     var oldPen = graphics.pen;
                     var m = cv.scaleLen - (cv.imageData.getMean(c) - cv.minValue) * f;
                     graphics.drawLine(cv.z, m + Graphics_Offset, x1, m + Graphics_Offset);
                     graphics.pen = oldPen;
                  }

                  if (cv.mouseMode == starMode && cv.starPSF != null)
                  {
                     if (cv.starPSF.isValid())
                     {
                        //
                        // PSF curve
                        //
                        var polyLine = [];
                        var curve    = cv.starPSF.getCurve(30);

                        var offset = 0;
                        if (cv.mode == Horizontal)
                           offset = cv.p1.x;
                        else
                           offset = cv.p1.y;
                        for (var i = 0; i < curve.length; i++)
                        {
                           var u = cv.z + (curve[i].x - offset) * dx;
                           var v = Graphics_Offset +
                                   cv.scaleLen - (curve[i].y - cv.minValue) * f;
                           polyLine.push(new Point(u, v));
                        }

                        graphics.drawPolyline(polyLine);

                        // FWHM

                        var txt = 'FWHM ';

                        var cent  = cv.starPSF.centroid();
                        var fwhm  = cv.starPSF.fwhm();
                        var fwhmC = 0;
                        var fwhmScaled = 0;

                        var txt   = 'FWHM ';

                        if (cv.mode == Horizontal)
                        {
                            fwhmC = (cent.x - cv.p1.x) * dx; // center
                            fwhmScaled = fwhm * cv.imageData.imageScale()[0];
                        }
                        else
                        {
                            fwhmC = (cent.y - cv.p1.y) * dx; // center
                            fwhmScaled = fwhm * cv.imageData.imageScale()[1];
                        }

                        var fwhmL = fwhmC - fwhm / 2 * dx;
                        var fwhmR = fwhmC + fwhm / 2 * dx;
                        var fwhmY = cv.starPSF.profile().A / 2 + cv.starPSF.profile().B;
                        fwhmY     = cv.scaleLen - (fwhmY - cv.minValue) * f;
                        fwhmL    += cv.z;
                        fwhmR    += cv.z;
                        fwhmY    += Graphics_Offset;

                        graphics.drawLine(fwhmL, fwhmY, fwhmR, fwhmY);

                        graphics.pen = new Pen(pen.color, 3);

                        graphics.drawLine(fwhmL, fwhmY - 8, fwhmL, fwhmY + 8);
                        graphics.drawLine(fwhmR, fwhmY - 8, fwhmR, fwhmY + 8);

                        // draw text

                        if (cv.imageData.solved())
                           txt += fwhmScaled.toFixed(2) + '"';
                        else
                           txt += fwhmScaled.toFixed(2) + 'px';

                        var txtR = graphics.textRect(new Rect(0, 0, 200, 100), txt);//, TextAlignment.Center);

                        txtR.moveTo(fwhmC + cv.z - txtR.width / 2, fwhmY + 8);

                        graphics.pen = new Pen(0xff000000);

                        graphics.drawTextRect(txtR, txt);

                        // draw centroid icon

                        graphics.pen = new Pen(colors[c]);

                        var polygon = [];
                        var v;
                        if (cv.mode == Horizontal)
                        {
                           v = (cv.starPSF.centroid().x - cv.p1.x) * dx + cv.z;
                        }
                        else if (cv.mode == Vertical)
                        {
                           v = (cv.starPSF.centroid().y - cv.p1.y) * dx + cv.z;
                        }

                        polygon.push(new Point(v, H - Graphics_Offset));
                        polygon.push(new Point(v - Graphics_Offset / 1.732, H));
                        polygon.push(new Point(v + Graphics_Offset / 1.732, H));
                        graphics.fillPolygon(polygon, 0, new Brush(pen.color));
                     }
                  }
               }

               if (cv.pixelPos != null)
               {
                  var pos = cv.verticalBar;
                  graphics.pen = new Pen(Color.BLACK, 1, PenStyle.Dot);
                  graphics.drawLine(pos, 0, pos, H);
               }
            }

            graphics.pen = new Pen(0xff000000, 2);

            graphics.drawLine(cv.z, y0, cv.z, y1);

            graphics.end();
      }

      this.canvas.onMouseMove = function (x, y, buttonState, modifiers)
      {
         if (setPixelPos(x)) displayValues();
         cv.verticalBar = x;
         dialog.previewControl.repaint();
         dialog.canvas.repaint();
      }

      this.canvas.onMousePress = function (x, y, buttonState, modifiers)
      {
         if (setPixelPos(x)) displayValues();
         cv.verticalBar = x;
         dialog.previewControl.repaint();
         dialog.canvas.repaint();
      }

      this.canvas.onMouseRelease = function (x, y, buttonState, modifiers)
      {
         cv.pixelPos = null;
         dialog.previewControl.repaint();
         dialog.canvas.repaint();
      }


   this.btnReport = new PushButton(this);//.canvas);
      //this.btnReport.icon = this.scaledResource( ":/icons/report-open.png");
      this.btnReport.text = 'Star info';
      this.btnReport.toolTip = 'Display star profile data';
      //this.btnReport.visible = false;
      this.btnReport.enabled = false;
      this.btnReport.onClick = function(checked)
      {
         var dialog = new infoDialog(cv);
         dialog.execute();
      }


   this.leftTop = new Frame(this);
   this.leftTop.setVariableSize();
      this.leftTop.sizer = new HorizontalSizer();
      this.leftTop.sizer.add (this.scaleFrame);
         this.leftTop.sizer.add (this.canvas);

   this.viewList =  new  ViewList( this );
   this.viewList.excludeIdentifiersPattern = 'temp_2d*';
      this.viewList.getAll();
      this.viewList.onViewSelected = function( view )
      {
         updateView(cv);       // update current view
         if (view.id == '')
         {
            dialog.viewList.currentView = cv.currentView;
            return;
         }

         dialog.cbSTF.checked = false;
         cv.STF = false;

         setBitmapFromView(view);

         dialog.viewList.reload();
         dialog.previewControl.SetImage(cv.imageData.getBitmap(cv.STF), cv.metadata);

         cv.p1 = new Point(0, cv.imageData.bounds.height / 2);
         cv.p2 = new Point(cv.imageData.bounds.width - 1, cv.imageData.bounds.height / 2);
         pixelOfLine(cv.p1, cv.p2);
         refresh();
         dialog.rbHorizontal.checked = true;
      }


   this.cbSTF = new CheckBox(this);
   this.cbSTF.text = 'STF';
      this.cbSTF.toolTip = "ScreenTransferFunction applied to selected image or background";
      this.cbSTF.onCheck = function(checked)
      {
         cv.STF = checked;
         var u = cv.p1;
         var v = cv.p2;

         dialog.waitLabel.visible = true;
         CoreApplication.processEvents();

         var bmp = cv.imageData.getBitmap(checked);

         var zoom = dialog.previewControl.zoom;

         dialog.previewControl.SetImage(bmp, cv.metadata, zoom);

         dialog.waitLabel.visible = false;
         CoreApplication.processEvents();

         if (u != null)
         {
            cv.p1 = u;
            cv.p2 = v;

            pixelOfLine(cv.p1, cv.p2);
            refresh();
         }
         dialog.canvas.repaint();
      }


   this.saveData_Button = new ToolButton( this );
   this.saveData_Button.enabled = false;
      this.saveData_Button.text = "Save Data";
      this.saveData_Button.toolTip = "Write selected pixels to tab separated file";
      this.saveData_Button.onClick = function(checked )
      {
         var lines = cv.imageData.getAllIntensities(cv.coordinates);

         var txt = dataToString(lines, dialog.cbR.checked, dialog.cbG.checked, dialog.cbB.checked);
         var fileD = new SaveFileDialog();
         fileD.caption = "Save Intensities as csv";
         fileD.overwritePrompt = true;
         fileD.filters = [["CSV Files", ".csv", ".txt"]];
         fileD.selectedFileExtension = ".csv";
         if (fileD.execute())
         {
            try {
               File.writeTextFile(fileD.filePath, txt);
            }
            catch (err) {
               new MessageBox(err.message, "Error writing CSV-File",
                  StdIcon.Error, StdButton.Ok).execute();
            }
         }
      }

   this.saveDiagram_Button = new ToolButton( this );
   this.saveDiagram_Button.enabled = false;
      this.saveDiagram_Button.text = 'Save Diagram';
      this.saveDiagram_Button.toolTip = 'Copy diagram to jpg file';
      this.saveDiagram_Button.onClick = function(checked )
      {
         var bmp = dialog.canvas.render();
         var fileD = new SaveFileDialog();
         fileD.caption = "Save Intensities as csv";
         fileD.overwritePrompt = true;
         fileD.filters = [["JPEG File", ".jpg"]];
         fileD.selectedFileExtension = ".jpg";
         if (fileD.execute())
         {
            try {
               bmp.save(fileD.filePath);
            }
            catch (err) {
               new MessageBox(err.message, "Error writing JPG-File",
                  StdIcon.Error, StdButton.Ok).execute();
            }
         }
      }

   this.closeButton = new PushButton(this)
   this.closeButton.icon = this.scaledResource(':/toolbar/file-exit.png');
      this.closeButton.text = 'Exit';
      this.closeButton.toolTip = 'Close script';
      this.closeButton.onClick = function(checked)
      {
         updateView(cv);       // update current view
         removeViews();
         dialog.done(0);
      }

   this.box1 = new Frame(this);
   //this.box1.setFixedHeight(this.viewList.height);
      //this.box1.setVariableSize();
      this.box1.setScaledFixedHeight(boxHeight);
      this.box1.sizer = new HorizontalSizer();
      //this.box1.sizer.margin = 4;
         this.box1.sizer.add(this.viewList);
         this.box1.sizer.addSpacing(8);
         this.box1.sizer.add(this.cbSTF);
         this.box1.sizer.addStretch();
         this.box1.sizer.add(this.btnReport);
         this.box1.sizer.addSpacing(8);
         this.box1.sizer.add(this.saveData_Button);
         this.box1.sizer.addSpacing(8);
         this.box1.sizer.add(this.saveDiagram_Button);

   var bm = new Bitmap(1,1);
   var g = new Graphics(bm);
   var lw = g.textRect(0, 50, 0, 100, 'MM').width;
   g.end();

   var lv = lw * 3;
   this.xlabel = new Label( this );
   this.xlabel.setScaledFixedWidth(lw);
   this.xlabel.text = "X:";
   this.xlabel.textAlignment = TextAlignment.VertCenter;
   this.xvalue = new Label( this );
   this.xvalue.text = "0";
   this.xvalue.setScaledFixedWidth(lv);
   this.xvalue.textAlignment = TextAlignment.VertCenter;

   this.ylabel = new Label( this );
   this.ylabel.text = "Y:";
   this.ylabel.setScaledFixedWidth(lw);
   this.ylabel.textAlignment = TextAlignment.VertCenter;
   this.yvalue = new Label( this );
   this.yvalue.text = "0";
   this.yvalue.setScaledFixedWidth(lv);
   this.yvalue.textAlignment = TextAlignment.VertCenter;

   lv = lw * 4;
   this.rlabel = new Label( this );
   this.rlabel.text = "R:";
   this.rlabel.setScaledFixedWidth(lw);
   this.rlabel.textAlignment = TextAlignment.VertCenter;
   this.rvalue = new Label( this );
   this.rvalue.text = "0.000000";
   this.rvalue.setScaledFixedWidth(lv);
   this.rvalue.textAlignment = TextAlignment.VertCenter;

   this.glabel = new Label( this );
   this.glabel.text = "G:";
   this.glabel.setScaledFixedWidth(lw);
   this.glabel.textAlignment = TextAlignment.VertCenter;
   this.gvalue = new Label( this );
   this.gvalue.text = "0.000000";
   this.gvalue.setScaledFixedWidth(lv);
   this.gvalue.textAlignment = TextAlignment.VertCenter;

   this.blabel = new Label( this );
   this.blabel.text = "B:";
   this.blabel.setScaledFixedWidth(lw);
   this.blabel.textAlignment = TextAlignment.VertCenter;
   this.bvalue = new Label( this );
   this.bvalue.text = "0.000000";
   this.bvalue.setScaledFixedWidth(lv);
   this.bvalue.textAlignment = TextAlignment.VertCenter;

   this.valueLabels = [this.xvalue, this.yvalue, this.rvalue, this.gvalue, this.bvalue];

   this.waitLabel = new Label(this)
      this.waitLabel.font = new Font('Consolas', 12);
         this.waitLabel.backgroundColor =  0xff008000;
         this.waitLabel.foregroundColor = 0xffFFFF0000;
         this.waitLabel.text = ' * please wait * ';
         this.waitLabel.visible = false;

   this.box0 = new Frame(this);
   //this.box0.setFixedHeight(this.xlabel.height);
      //this.box0.setVariableSize();
      this.box0.setScaledFixedHeight(boxHeight);
      this.box0.sizer = new HorizontalSizer();
      //this.box0.sizer.margin = 6;
         this.box0.sizer.add(this.xlabel);
         this.box0.sizer.add(this.xvalue);
         this.box0.sizer.addSpacing(8);
         this.box0.sizer.add(this.ylabel);
         this.box0.sizer.add(this.yvalue);
         this.box0.sizer.addSpacing(8);
         this.box0.sizer.add(this.rlabel);
         this.box0.sizer.add(this.rvalue);
         this.box0.sizer.addSpacing(8);
         this.box0.sizer.add(this.glabel);
         this.box0.sizer.add(this.gvalue);
         this.box0.sizer.addSpacing(8);
         this.box0.sizer.add(this.blabel);
         this.box0.sizer.add(this.bvalue);
         this.box0.sizer.addStretch();
         this.box0.sizer.add(this.waitLabel);
         this.box0.sizer.addStretch();
         //this.box0.sizer.add(this.closeButton);


   this.rbHorizontal = new RadioButton(this);
   this.rbHorizontal.text = 'Horizontal';
      this.rbHorizontal.toolTip = 'Select and draw a horizontal center line (angle = 0)';
      this.rbHorizontal.onCheck = function(checked )
      {
         if (checked)
         {
            cv.mode = Horizontal;
            if (cv.mouseMode == lineMode)
            {
               cv.p1 = new Point(0, Math.floor(cv.imageData.bounds.height / 2));
               cv.p2 = new Point(cv.imageData.bounds.width - 1, Math.floor(cv.imageData.bounds.height / 2));
            }
            else if (cv.mouseMode == starMode)
            {
               analyzeStarPos();
            }
            else if (cv.mouseMode == panMode) return;
            setLineOffsetStatus(true);
            pixelOfLine(cv.p1, cv.p2);
            refresh();
            enableBtnBlackLine();
            dialog.previewControl.Distval_Label.visible = false;
         }
      }

   this.rbVertical = new RadioButton(this);
   this.rbVertical.text = 'Vertical';
      this.rbVertical.toolTip = 'Select and draw a vertical center line (angle = 90)';
      this.rbVertical.onCheck = function(checked )
      {
         if (checked)
         {
            cv.mode = Vertical;
            if (cv.mouseMode == lineMode)
            {
               cv.p1 = new Point(Math.floor(cv.imageData.bounds.width / 2), 0);
               cv.p2 = new Point(Math.floor(cv.imageData.bounds.width / 2), cv.imageData.bounds.height - 1);
            }
            else if (cv.mouseMode == starMode)
            {
               analyzeStarPos();
            }
            else if (cv.mouseMode == panMode) return;
            setLineOffsetStatus(true);
            pixelOfLine(cv.p1, cv.p2);
            refresh();
            enableBtnBlackLine();
            dialog.previewControl.Distval_Label.visible = false;
         }
      }

   this.rbDiagonalDn = new RadioButton(this);
   this.rbDiagonalDn.text = 'Diagonal down';
      this.rbDiagonalDn.toolTip = 'Select and draw a line from left top to right bottom (angle = atan(height / width))';
      this.rbDiagonalDn.onCheck = function(checked ) {
         cv.mode = DiagonalDn;
         if (checked)
         {
            cv.p1 = new Point(0, 0);
            cv.p2 = new Point(cv.imageData.bounds.width - 1, cv.imageData.bounds.height - 1);
            setLineOffsetStatus(true);
            pixelOfLine(cv.p1, cv.p2);
            refresh();
            enableBtnBlackLine();
            dialog.previewControl.Distval_Label.visible = false;
         }
      }

   this.rbDiagonalUp = new RadioButton(this);
   this.rbDiagonalUp.text = 'Diagonal up';
      this.rbDiagonalUp.toolTip = 'Select and draw a line from left bottom to right top (angle = -atan(height / width))';
      this.rbDiagonalUp.onCheck = function(checked ) {
         cv.mode = DiagonalUp;
         if (checked)
         {
            cv.p1 = new Point(0, cv.imageData.bounds.height - 1);
            cv.p2 = new Point(cv.imageData.bounds.width - 1, 0);
            setLineOffsetStatus(true);
            pixelOfLine(cv.p1, cv.p2);
            refresh();
            enableBtnBlackLine();
            dialog.previewControl.Distval_Label.visible = false;
         }
      }

   this.rbSinglePoint = new RadioButton(this);
   this.rbSinglePoint.text = 'Single point';
      this.rbSinglePoint.toolTip = 'Select and draw a line @ x,y using same angle';
      this.rbSinglePoint.onCheck = function(checked )
      {
         if (checked)
         {
            cv.mode = Single_Point;
            cv.p2 = null;
            dialog.previewControl.repaint();
            dialog.canvas.repaint();
            enableBtnBlackLine();
            dialog.previewControl.Distval_Label.visible = false;
         }
      }

   this.rbDoublePoint = new RadioButton(this);
   this.rbDoublePoint.text = 'DoublePoint point';
      this.rbDoublePoint.toolTip = 'Select and draw a line between two points<p>' +
                'Holding down left button on the 2nd point give a rubber band effect</p><p>' +
                'Sets the angle = atan(dy / dx)';
      this.rbDoublePoint.onCheck = function(checked )
      {
         if (checked)
         {
            cv.mode = Double_Point;
            cv.p1 = null;
            cv.p2 = null;
            setLineOffsetStatus(false);
            dialog.previewControl.repaint();
            dialog.canvas.repaint();
            enableBtnBlackLine();
            dialog.previewControl.Distval_Label.visible = true;
         }
      }

   this.box2 = new Frame(this);
   this.box2.setScaledFixedHeight(boxHeight);
      this.box2.sizer = new HorizontalSizer();
      //this.box2.sizer.margin = 4;
         this.box2.sizer.add(this.rbHorizontal);
         this.box2.sizer.addSpacing(8);
         this.box2.sizer.add(this.rbVertical);
         this.box2.sizer.addSpacing(8);
         this.box2.sizer.add(this.rbDiagonalDn);
         this.box2.sizer.addSpacing(8);
         this.box2.sizer.add(this.rbDiagonalUp);
         this.box2.sizer.addSpacing(8);
         this.box2.sizer.add(this.rbSinglePoint);
         this.box2.sizer.addSpacing(8);
         this.box2.sizer.add(this.rbDoublePoint);
         this.box2.sizer.addStretch();

   this.rbImage = new RadioButton(this);
   this.rbImage.checked = true;
      this.rbImage.text = 'Image';
      this.rbImage.toolTip = 'Image view';
      this.rbImage.onCheck = function(checked )
      {
         if (checked)
         {
            cv.imageData.selectImage( 0 );
            pixelOfLine(cv.p1, cv.p2);
            var bmp = cv.imageData.getBitmap(cv.STF);
            var zoom = dialog.previewControl.zoom;
            dialog.previewControl.SetImage(bmp, cv.metadata, zoom);
            refresh();
         }
      }

   this.rbBack = new RadioButton(this);
   this.rbBack.text = 'Background';
      this.rbBack.toolTip = 'Background from open image, if available';
      this.rbBack.onCheck = function(checked )
      {
         if (checked)
         {
            dialog.waitLabel.visible = true;
            CoreApplication.processEvents();

            cv.imageData.selectImage( 1 );

            dialog.waitLabel.visible = false;
            CoreApplication.processEvents();

            if (cv.imageData.hasBackground())
            {
               pixelOfLine(cv.p1, cv.p2);
               var bmp = cv.imageData.getBitmap(cv.STF);
               var zoom = dialog.previewControl.zoom;
               dialog.previewControl.SetImage(bmp, cv.metadata, zoom);
               refresh();
               return;
            }
            dialog.rbImage.checked = true;
            dialog.rbBack.enabled = false;
         }
      }

   this.cbR  = new ToolButton(this);
   this.cbR.icon = this.scaledResource(':/toolbar/image-display-red.png');
      this.cbR.checkable = true;
      this.cbR.checked = true;
      this.cbR.toolTip = 'Red channel or K for grayscale images';
      this.cbR.onCheck = function(checked)
      {
         dialog.canvas.repaint();
      }

   this.cbG  = new ToolButton(this);
   this.cbG.icon = this.scaledResource(':/toolbar/image-display-green.png');
      this.cbG.checkable = true;
      this.cbG.checked = true;
      this.cbG.toolTip = 'Green channel';
      this.cbG.onCheck = function(checked)
      {
         dialog.canvas.repaint();
      }

   this.cbB  = new ToolButton(this);
   this.cbB.icon = this.scaledResource(':/toolbar/image-display-blue.png');
      this.cbB.checkable = true;
      this.cbB.checked = true;
      this.cbB.toolTip = 'Blue channel';
      this.cbB.onCheck = function(checked)
      {
         dialog.canvas.repaint();
      }

   this.cbMean = new CheckBox(this);
   this.cbMean.text    = 'Mean';
      this.cbMean.toolTip = 'Mean value(s)<p>RGB colors or red for grayscale images';
      this.cbMean.onCheck = function(checked)
      {
         dialog.canvas.repaint();
      }

   this.pixScale = new ComboBox(this);
   this.pixScale.toolTip = 'Change representation of numbers<p>This value preset when image is loaded';
      this.pixScale.addItem("Normalized [0,1]");
      this.pixScale.addItem("8-bit [0,255]");
      this.pixScale.addItem("10-bit [0,1023]");
      this.pixScale.addItem("12-bit [0,4095]");
      this.pixScale.addItem("14-bit [0,16383]");
      this.pixScale.addItem("16-bit [0,65535]");

      this.pixScale.onItemSelected = function(index)
      {
         cv.pScale = [1, 255, 1023, 4095, 16383, 65535][index];
         setScaleNumRect();
         dialog.canvas.repaint();
      }

   this.box3 = new Frame(this);
   this.box3.setScaledFixedHeight(boxHeight);
      this.box3.sizer = new HorizontalSizer();
      // this.box3.sizer.margin = 6;
         this.box3.sizer.add(this.rbImage);
         this.box3.sizer.addSpacing(8);
         this.box3.sizer.add(this.rbBack);
         this.box3.sizer.addSpacing(16);
         this.box3.sizer.add(this.cbR);
         this.box3.sizer.addSpacing(8);
         this.box3.sizer.add(this.cbG);
         this.box3.sizer.addSpacing(8);
         this.box3.sizer.add(this.cbB);
         this.box3.sizer.addSpacing(8);
         this.box3.sizer.add(this.cbMean);
         this.box3.sizer.addStretch();
         this.box3.sizer.add(this.pixScale);

   this.btnUnDo = new ToolButton(this);
   this.btnUnDo.enabled = false;
      this.btnUnDo.icon = this.scaledResource(':/toolbar/image-undo.png');
      this.btnUnDo.onClick = function( checked )
      {
         restoreBlackLine(cv.blackLineIndex);
         cv.blackLineIndex -= 1;
         dialog.btnUnDo.enabled = cv.blackLineIndex > -1;
         dialog.btnReDo.enabled = true;
         if (cv.blackLineIndex > -1)
            dialog.closeButton.text = 'Apply && Exit';
         else
            dialog.closeButton.text = 'Exit';
         refresh();
      }

   this.btnReDo = new ToolButton(this);
   this.btnReDo.enabled = false;
      this.btnReDo.icon = this.scaledResource(':/toolbar/image-redo.png');
      this.btnReDo.onClick = function( checked )
      {
         cv.blackLineIndex += 1;
         restoreBlackLine(cv.blackLineIndex);
         dialog.btnReDo.enabled = cv.blackLineIndex < cv.blackLines.length - 1;
         dialog.btnUnDo.enabled = true;
         if (cv.blackLineIndex > -1)
            dialog.closeButton.text = 'Apply && Exit';
         else
            dialog.closeButton.text = 'Exit';
         refresh();
      }

   this.lblBlackLine = new Label(this);
   this.lblBlackLine.text = 'Black line';
   this.lblBlackLine.textAlignment = TextAlignment.VertCenter;

   this.imgBlackLine = new Frame(this);
   this.imgBlackLine.lineWidth = 1;
      //this.imgBlackLine.style  = 1;
      this.imgBlackLine.enabled = false;
      this.imgBlackLine.setScaledMaxHeight(22);
      this.imgBlackLine.setScaledMinWidth (64);
      this.imgBlackLine.toolTip = 'Click here to set pixels along the pixel selection line to 0 [black].<\n>';

  /*    this.imgBlackLine.onMousePress = function ( x, y, button, buttonState, modifiers )
      {
         if (cv.p1 != null && cv.p2 != null)
         {
            while (cv.blackLines.length > (cv.blackLineIndex + 1)) cv.blackLines.pop();
            var cf = [dialog.cbR.checked, dialog.cbG.checked, dialog.cbB.checked];
            var bl = new blackLine(cv.lineSize, cv.angle, cv.p1, cv.p2, cf, cv.mode);

            cv.blackLines.push(bl);
            cv.blackLineIndex       = cv.blackLines.length - 1;
            dialog.btnUnDo.enabled  = true;

            cv.p1 = null;
            cv.p2 = null;

            refresh();
         }
      }*/

      this.imgBlackLine.onPaint = function ( x0, y0, x1, y1 )
      {
         var g = new Graphics(dialog.imgBlackLine);
         g.fillRect(x0, y0, x1, y1, new Brush(0xffffffff) );
         g.pen = new Pen(0xff000000, cv.lineSize);
         if (cv.lineSize > 0) g.drawLine(x0, (y1 - y0) / 2 , x1,  (y1 - y0) / 2 );
         g.pen = new Pen(0xff0000ff);
         g.drawRect(x0, y0, x1, y1 );
         g.end();
      }

   this.btnBlackLine = new PushButton(this);
   this.btnBlackLine.text = 'Plot black line';
      this.btnBlackLine.enabled = false;

      this.btnBlackLine.toolTip = 'Click here to set pixels along the pixel selection line to 0 [black].<\n>';

      this.btnBlackLine.onClick = function (checked)
      {
         if (cv.p1 != null && cv.p2 != null)
         {
            while (cv.blackLines.length > (cv.blackLineIndex + 1)) cv.blackLines.pop();
            var cf = [dialog.cbR.checked, dialog.cbG.checked, dialog.cbB.checked];
            var bl = new blackLine(cv.lineSize, cv.angle, cv.p1, cv.p2, cf, cv.mode);

            cv.blackLines.push(bl);
            cv.blackLineIndex       = cv.blackLines.length - 1;
            dialog.btnUnDo.enabled  = true;

            cv.p1 = null;
            cv.p2 = null;

            if (cv.blackLines.length > 0)
               dialog.closeButton.text = 'Apply && Exit';
            else
               dialog.closeButton.text = 'Exit';

            refresh();
         }
      }


   this.numLineSize = new NumericEdit(this);
   this.numLineSize.label.text = '';
      this.numLineSize.setRange(0, maxLineSize);
      this.numLineSize.setReal(false);
      this.numLineSize.value = 0;
      this.numLineSize.onValueUpdated = function (value)
      {
         cv.lineSize = value;
         dialog.btnSizePlus.enabled  = cv.lineSize < maxLineSize;
         dialog.btnSizeMinus.enabled = cv.lineSize > 0;
         enableBtnBlackLine();
         dialog.imgBlackLine.repaint();
      }

      this.numLineSize.onMouseWheel = function ( x, y, delta, buttonState, modifiers)
      {
         if (delta > 0)
         {
            if (dialog.numLineSize.value < dialog.numLineSize.upperBound)
               dialog.numLineSize.setValue(dialog.numLineSize.value + 1);
         }
         else if (delta < 0)
         {
            if (dialog.numLineSize.value > 0)
               dialog.numLineSize.setValue(dialog.numLineSize.value - 1);
         }
         cv.lineSize = dialog.numLineSize.value;
         enableBtnBlackLine();
         dialog.imgBlackLine.repaint();
      }

   this.btnSizeMinus = new ToolButton(this);
   this.btnSizeMinus.text = '-';
      this.btnSizeMinus.enabled = false;
      this.btnSizeMinus.onClick = function (checked)
      {
         cv.lineSize -= 1;
         dialog.numLineSize.setValue(cv.lineSize);
         dialog.btnSizePlus.enabled  = cv.lineSize < maxLineSize;
         dialog.btnSizeMinus.enabled = cv.lineSize > 0;
         enableBtnBlackLine();
         dialog.imgBlackLine.repaint();
      }

   this.btnSizePlus = new ToolButton(this);
   this.btnSizePlus.text = '+';
      this.btnSizePlus.enabled = true;
      this.btnSizePlus.onClick = function (checked)
      {
         cv.lineSize += 1;
         dialog.numLineSize.setValue(cv.lineSize);
         dialog.btnSizePlus.enabled  = cv.lineSize < maxLineSize;
         dialog.btnSizeMinus.enabled = cv.lineSize > 0;
         enableBtnBlackLine();
         dialog.imgBlackLine.repaint();
      }

   this.cbRedLine  = new CheckBox(this);
   this.cbRedLine.text = 'Red line';
      this.cbRedLine.checked = false;
      this.cbRedLine.toolTip = 'If checked, pixel selection line painted red';
      this.cbRedLine.onCheck = function(checked)
      {
         dialog.previewControl.repaint();
      }

   this.lblLineOffset = new Label(this);
   this.lblLineOffset.text = 'Line offset';
   this.lblLineOffset.textAlignment = TextAlignment.VertCenter;

   this.btnOffsetMinus = new ToolButton(this);
   this.btnOffsetMinus.text = '-';
      this.btnOffsetMinus.enabled = false;
      this.btnOffsetMinus.onClick = function (checked)
      {
         var line = offsetLine(-1);
         if (line[0] == null) return;
         cv.p1 = line[0];
         cv.p2 = line[1];
         pixelOfLine(cv.p1, cv.p2);
         refresh();
      }

   this.btnOffsetPlus = new ToolButton(this);
   this.btnOffsetPlus.text = '+';
      this.btnOffsetPlus.enabled = false;
      this.btnOffsetPlus.onClick = function (checked)
      {
         var line = offsetLine(1);
         if (line[0] == null) return;
         cv.p1 = line[0];
         cv.p2 = line[1];
         pixelOfLine(cv.p1, cv.p2);
         refresh();
      }


   this.box4 = new Frame(this);
   this.box4.setScaledFixedHeight(boxHeight * 1.0);
      this.box4.sizer = new HorizontalSizer();
      this.box4.sizer.margin = 4;
        /* this.box4.sizer.add(this.btnUnDo);
         this.box4.sizer.addSpacing(2);
         this.box4.sizer.add(this.btnReDo);
         this.box4.sizer.addSpacing(4);
         this.box4.sizer.add(this.lblBlackLine);
         this.box4.sizer.addSpacing(4);
         this.box4.sizer.add(this.btnBlackLine);
         this.box4.sizer.addSpacing(4);
         this.box4.sizer.add(this.btnSizeMinus);
         this.box4.sizer.add(this.numLineSize);
         this.box4.sizer.addSpacing(10);
         this.box4.sizer.add(this.btnSizePlus);
         this.box4.sizer.addStretch();*/
         this.box4.sizer.add(this.cbRedLine);
         //this.box4.sizer.addStretch();
         this.box4.sizer.addSpacing(32);
         this.box4.sizer.add(this.lblLineOffset);
         this.box4.sizer.addSpacing(8);
         this.box4.sizer.add(this.btnOffsetMinus);
         this.box4.sizer.add(this.btnOffsetPlus);
         this.box4.sizer.addStretch();

   this.box5 = new Frame(this);
   //this.box5.setScaledFixedHeight(boxHeight * 2);
      this.box5.sizer = new HorizontalSizer();
      this.box5.sizer.margin = 4;
         this.box5.sizer.addStretch();
         this.box5.sizer.add(this.closeButton);
         this.box5.sizer.addStretch();


   this.leftBottom = new Frame(this);
   //this.leftBottom.setScaledMaxSize(600, 6 * boxHeight + 20 );
      this.leftBottom.setScaledMaxWidth(600);
      this.leftBottom.sizer = new VerticalSizer();

      this.leftBottom.sizer.margin = 4;
         this.leftBottom.sizer.add (this.box3);
         this.leftBottom.sizer.addSpacing(4);
         this.leftBottom.sizer.add (this.box2);
         this.leftBottom.sizer.addSpacing(4);
         this.leftBottom.sizer.add (this.box4);
         this.leftBottom.sizer.addSpacing(4);
         this.leftBottom.sizer.add (this.box1);
         this.leftBottom.sizer.addSpacing(4);
         this.leftBottom.sizer.add (this.box0);
         this.leftBottom.sizer.addSpacing(4);
         this.leftBottom.sizer.add(this.box5);

   this.crFrame = new Frame(this);
   this.crFrame.setFixedHeight(this.lblCopyright.height);
      this.crFrame.sizer = new HorizontalSizer();
      this.crFrame.sizer.add(this.lblCopyright);

   this.SatTrackPanel = new Frame(this);
   this.SatTrackPanel.visible = false;     // disabled, use SKill.js
      this.SatTrackPanel.sizer = new HorizontalSizer();
      this.SatTrackPanel.sizer.margin = 4;
         this.SatTrackPanel.sizer.addStretch();
         this.SatTrackPanel.sizer.add(this.btnUnDo);
         this.SatTrackPanel.sizer.addSpacing(2);
         this.SatTrackPanel.sizer.add(this.btnReDo);
         this.SatTrackPanel.sizer.addSpacing(32);
         this.SatTrackPanel.sizer.add(this.lblBlackLine);
         this.SatTrackPanel.sizer.addSpacing(4);
         this.SatTrackPanel.sizer.add(this.imgBlackLine);
         this.SatTrackPanel.sizer.addSpacing(4);
         this.SatTrackPanel.sizer.add(this.btnSizeMinus);
         this.SatTrackPanel.sizer.add(this.numLineSize);
         this.SatTrackPanel.sizer.addSpacing(10);
         this.SatTrackPanel.sizer.add(this.btnSizePlus);
         this.SatTrackPanel.sizer.addSpacing(32);
         this.SatTrackPanel.sizer.add(this.btnBlackLine);
         this.SatTrackPanel.sizer.addStretch();


   this.tabSelector = new TabBox(this);
   this.tabSelector.addPage(this.leftTop, 'Readout profiles' );
      //this.tabSelector.addPage(this.SatTrackPanel, 'Manual erase satellite tracks' );

      this.tabSelector.currentPageIndex = 0;

      this.tabSelector.onPageSelected = function ( pageIndex )
      {
         if (pageIndex == 1)
         {
          /*  dialog.rbDoublePoint.checked = true;
            cv.mode = Double_Point;
            cv.p1 = null;
            cv.p2 = null;
            setLineOffsetStatus(false);
            dialog.previewControl.repaint();
            dialog.canvas.repaint();
            enableBtnBlackLine();
            dialog.previewControl.Distval_Label.visible = true;
            */

            new MessageBox('This function', '',
                  StdIcon.Information, StdButton.Ok).execute();
         }
      }

   this.plotFrame = new Frame(this);
   // this.plotFrame.setVariableSize();
      this.plotFrame.sizer = new VerticalSizer();
      this.plotFrame.sizer.margin = 4;
         this.plotFrame.sizer.add (this.crFrame);
         this.plotFrame.sizer.addSpacing(2);
         //this.plotFrame.sizer.add(this.leftTop);
         this.plotFrame.sizer.add(this.tabSelector);
         this.plotFrame.sizer.addSpacing(2);
         this.plotFrame.sizer.add (this.leftBottom);

      this.plotFrame.onResize = function ( wNew, hNew, wOld, hOld )
      {
         if (true) return;
         dialog.leftTop.height = hNew -
            8 -      // 2x margin
            4 -      // 2x spacing
            dialog.crFrame.height -
            dialog.leftBottom.height;
      }


   this.magnifyButton = new ToolButton(this);
   this.magnifyButton.icon = this.scaledResource(':/icons/item.png');

      this.magnifyButton.checkable = true;
      this.magnifyButton.checked  = false;
      this.magnifyButton.toolTip  = 'Turn on/off magnify glass';

      this.magnifyButton.onClick = function ( checked )
      {
         cv.magnification = checked;
         cv.paintClear = !checked;
         dialog.previewControl.repaint();
      }



   this.maximizeButton = new ToolButton(this);
   //this.maximizeButton.visible = primaryScreen.width > 0 && primaryScreen.height > 0;
      this.maximizeButton.icon =  this.scaledResource(':/icons/window.png');

      this.maximizeButton.onClick = function(checked)
      {
         if (!isNormalSize)
         {
            dialog.move(normalSize.x0, normalSize.y0);
            dialog.resize(normalSize.width, normalSize.height);
            isNormalSize = true;
         }
         else
         {
            var x0 = dialog.position.x;
            var y0 = dialog.position.y;
            var x1 = dialog.position.x + dialog.width;
            var y1 = dialog.position.y + dialog.height;
            normalSize = new Rect(x0, y0, x1, y1);
            dialog.move(0, 0);
            dialog.resize(Screen.width, Screen.height - 36 * formsScaling);
            isNormalSize = false;
         }

        /* if (normalDialogWin == null)
         {
            normalDialogWin = new Rect(dialog.position.x, dialog.position.y,
            dialog.position.x + dialog.width, dialog.position.y + dialog.height);
            dialog.move(primaryScreen.x0, primaryScreen.y0);
            dialog.resize(primaryScreen.width, primaryScreen.height);
            dialog.maximizeButton.icon = this.scaledResource(':/icons/windows.png');
         }
         else
         {
            dialog.move(normalDialogWin.x0, normalDialogWin.y0);
            dialog.resize(normalDialogWin.width, normalDialogWin.height);
            normalDialogWin = null;
            dialog.maximizeButton.icon = this.scaledResource(':/icons/window.png');
         }*/
      }



   this.previewControl = new PreviewControl(this);
   dialog.view = ImageWindow.activeWindow.currentView;
      setBitmapFromView(ImageWindow.activeWindow.currentView);
      this.viewList.currentView = ImageWindow.activeWindow.currentView;
      this.previewControl.buttons_Box.sizer.add(this.magnifyButton);
      this.previewControl.buttons_Box.sizer.addStretch();
      this.previewControl.buttons_Box.sizer.add(this.maximizeButton);

      this.previewControl.onCustomMouseDown = function (x, y, button, buttonState, modifiers)
      {
         if (!cv.imageData.bounds.includes(x, y)) return;

         setLineOffsetStatus(false);

         if (cv.mouseMode == lineMode)
         {
            if (cv.mode == Double_Point)
            {
               if (cv.p1 == null && cv.p2 == null)
               {
                  cv.p1 = new Point(x, y);
                  dialog.previewControl.repaint();
                  dialog.canvas.repaint();
                  return;
               }
               else if (cv.p1 != null && cv.p2 !=null)
               {
                  setLineOffsetStatus(true);
                  cv.p1 = new Point(x, y);
                  cv.p2 = null;
                  dialog.previewControl.repaint();
                  dialog.canvas.repaint();
                  return;
               }
               else
               {
                  if (cv.p2 == null)
                  {
                     cv.p2 = new Point(x, y);
                  }
               }
               enableBtnBlackLine();
            }
            else if (cv.mode == DiagonalDn || cv.mode == DiagonalUp)
               return
            else
            {
               cv.p1 = new Point(x, y);
            }

            var width  = cv.imageData.bounds.width;
            var height = cv.imageData.bounds.height;
            switch (cv.mode)
            {
               case Horizontal:
                  cv.p1 = new Point(0, cv.p1.y);
                  cv.p2 = new Point(width - 1, cv.p1.y);
                  break;

               case Vertical:
                  cv.p1 = new Point(cv.p1.x, 0);
                  cv.p2 = new Point(cv.p1.x, height - 1);
                  break;

               case Single_Point:
                  // cross line, same angle
                  var l = getLine(cv.p1, cv.angle, new Rect(0, 0, width - 1, height - 1));
                  cv.p1 = l.p1;
                  cv.p2 = l.p2;
                  break;
               case Double_Point:
                  break;
            }

            enableBtnBlackLine();

            pixelOfLine(cv.p1, cv.p2);

            setLineOffsetStatus(true);

            refresh();
         }
         else if (cv.mouseMode == starMode)
         {
            cv.starPosition = new Point(x, y);

            analyzeStarPos();

            refresh();
         }
      }

      this.previewControl.onCustomMouseMove = function ( x, y, buttonState, modifiers )
      {
         if (buttonState == MouseButton.Left)
         {
            cv.mouseOver = false;

            if (cv.mode == Double_Point)
            {
               if (cv.p1 != null && cv.p2 != null)
               {
                  if (!cv.imageData.bounds.includes(x, y)) return;

                  cv.p2 = new Point(x, y);

                  pixelOfLine(cv.p1, cv.p2);

                  refresh();
               }
            }
         }
         else if (buttonState == MouseButton.Unknown && cv.magnification)
         {
            if (modifiers == KeyModifier.Control)
            {
               cv.paintClear = true;
               dialog.previewControl.repaint();
            }
            else
            {
               cv.mousePos  = new Point(x, y);
               cv.mouseOver = true;
               dialog.previewControl.repaint();
            }

         }
      }

      this.previewControl.onCustomMouseRelease = function ( x, y, buttonState, modifiers )
      {
         if (cv.mouseMode == lineMode && cv.mode == Double_Point)
            displayDistanceValue();
      }

      this.previewControl.onCustomPaint = function (graphics, x0, y0, x1, y1 )
      {
            // draw black lines

            if (cv.paintClear)
            {
               cv.paintClear = false;
               cv.mouseOver = false;
            }

            for (var i = -1; i < cv.blackLineIndex; i++)
            {
               var bl = cv.blackLines[i + 1];
               graphics.pen = new Pen(bl.getColor(), bl.size);
               graphics.drawLine(bl.p1, bl.p2);
            }

            if (cv.mouseOver)
            {
               graphics.pen = new Pen(0xffff00ff);
               var p = cv.mousePos;
               var x = p.x;
               var y = p.y;
               var o = Math.floor(cv.magnify);
               cv.smallRect.center = p;
               magnifyRect.center = p;
               magnifyRect.moveBy(-cv.magnify / 2, -cv.magnify / 2);

               var sourceRect = cv.imageData.bounds.intersection( cv.smallRect );
               var destRect   = new Rect(magnifyRect.x0, magnifyRect.y0,
                                         magnifyRect.x1, magnifyRect.y1);

               graphics.smoothInterpolation = false;

               graphics.drawScaledBitmapRect(destRect,
                                    cv.imageData.getBitmap(cv.STF),
                                    sourceRect);
               graphics.drawRect(magnifyRect);
               graphics.drawLine(magnifyRect.x0, y, x - o, y);
               graphics.drawLine(x + o, y, magnifyRect.x1, y);
               graphics.drawLine(x, magnifyRect.y0, x, y - o);
               graphics.drawLine(x, y + o, x, magnifyRect.y1);
            }

            if (cv.p1 == null) return;

            graphics.pen = new Pen(0xffffffff);
            graphics.antialiasing = true;
            graphics.smoothInterpolation =true;
            var radius =  8 / dialog.previewControl.scale;
            var tick   = 10 / dialog.previewControl.scale;

            if (dialog.cbRedLine.checked)
               graphics.pen = new Pen(Color.RED);
            else
               graphics.pen = new Pen(Color.WHITE);
            graphics.drawCircle(cv.p1, radius);
            graphics.drawLine(cv.p1.x - tick, cv.p1.y,
                     cv.p1.x + tick, cv.p1.y)
            graphics.drawLine(cv.p1.x, cv.p1.y - tick,
                     cv.p1.x, cv.p1.y + tick)

            if (cv.p2 != null)
            {
               graphics.drawCircle(cv.p2, radius);
               graphics.drawLine(cv.p2.x - tick, cv.p2.y,
                        cv.p2.x + tick, cv.p2.y)
               graphics.drawLine(cv.p2.x, cv.p2.y - tick,
                        cv.p2.x, cv.p2.y + tick)

               graphics.drawLine(cv.p1, cv.p2);
            }


            if (cv.pixelPos != null)
            {
               if (dialog.view.image.numberOfChannels == 1)
                  graphics.pen = new Pen(0xcfffff00, 1 / dialog.previewControl.scale,
                                 PenStyle.Dash);
               var x = cv.pixelPos.x;
               var y = cv.pixelPos.y;
               dialog.previewControl.Xval_Label.text = x.toString();
               dialog.previewControl.Yval_Label.text = y.toString();

               graphics.drawLine(x, 0, x, cv.imageData.bounds.height);
               graphics.drawLine(0, y, cv.imageData.bounds.width, y);

               var strX = 'X = ' + x.toString();
               var strY = 'Y = ' + y.toString();

               graphics.resetTransformation();
               graphics.scaleTransformation(1, 1);

               var offset = dialog.previewControl.getOffset();

               graphics.translateTransformation(offset.x, offset.y);

               var scale = dialog.previewControl.scale;

               var rectX = graphics.textRect( new Rect(0, 0, 60, 30), strX);
               var rectY = graphics.textRect( new Rect(0, 0, 60, 30), strY);

               var w = Math.max(rectX.width, rectY.width);
               var h = rectX.height + rectY.height;

               var imgW = cv.imageData.bounds.width * scale;
               var imgH = cv.imageData.bounds.width * scale;


               x *= scale;
               y *= scale;

               // find align position

               var alignPos = 0; // top, right

               if (x < imgW - (w + 16))
               {
                  // left from limit
                  if (y < h + 16)
                     alignPos = 0;
                  else
                     alignPos = 2;
               }
               else
               {
                  // right from limit
                  if (y > h + 16)
                     alignPos = 1;
                  else
                     alignPos = 3;
               }

               switch (alignPos)
               {
                  case 0:
                     graphics.drawText(x + 4, y + h + 4, strX);
                     graphics.drawText(x + 4, y + h/2 +4, strY);
                     break;
                  case 1:
                     graphics.drawText(x - 4 - w, y - h + 4, strX);
                     graphics.drawText(x - 4 - w, y - h/2 + 4, strY);
                     break;
                  case 2:
                     graphics.drawText(x + 4, y - h + 4, strX);
                     graphics.drawText(x + 4, y - h/2 + 4, strY);
                     break;
                  case 3:
                     graphics.drawText(x - 4 - w, y + h + 4, strX)
                     graphics.drawText(x - 4 - w, y + h/2 + 4, strY);
                     break;
               }
            }
      }

      this.previewControl.onModeChanged = function (mode)
      {
         cv.mouseMode = mode;
         dialog.box2.enabled = cv.mouseMode != panMode;

         if (dialog.box2.enabled)
         {
               dialog.rbDiagonalDn.enabled    = cv.mouseMode == lineMode;
               dialog.rbDiagonalUp.enabled    = cv.mouseMode == lineMode;
               dialog.rbSinglePoint.enabled   = cv.mouseMode == lineMode;
               dialog.rbDoublePoint.enabled   = cv.mouseMode == lineMode;
         }

         cv.p1 = null;
         cv.p2 = null;
         cv.starPSF = null;
         setLineOffsetStatus(false);

         if (cv.mouseMode == starMode)
         {
            cv.mode = Horizontal;
            cv.p1 = null;
            cv.p2 = null
            cv.imageData.selectImage( 0 );
            dialog.rbImage.checked = true;
            dialog.rbBack.enabled = false;
            dialog.rbHorizontal.checked = true;
            var bmp = cv.imageData.getBitmap(cv.STF);
            dialog.previewControl.SetImage(bmp, cv.metadata, zoom);
         }
         else
         {
            dialog.rbBack.enabled = cv.imageData.hasBackground();
            dialog.btnReport.enabled = false;
         }

         refresh();
      }


   this.sizeBar = new Frame(this);
   this.sizeBar.backgroundColor = 0xaff0f0f0;
      this.sizeBar.cursor  = new Cursor(StdCursor.HorizontalSplit );
      this.sizeBar.setFixedWidth(7);

      this.sizeBar.onMousePress = function( x, y, button, buttonState, modifiers )
      {
         if (button == MouseButton.Left)
         {
            sizerpos = x;
         }
      }

      this.sizeBar.onMouseMove = function( x, y, button, buttonState, modifiers )
      {
         if (button == MouseButton.Left)
         {
            var dx = x - sizerpos;
            var plotFrameSize   = Math.max(plotFrameMinsize, dialog.plotFrame.width + dx);
            var imageFrameSize  = dialog.imageFrame.width - dx;

            if (imageFrameSize >= imageFrameMinsize)
            {
              // dialog.plotFrame.setFixedWidth(plotFrameSize);
               dialog.sizeBar.move( plotFrameSize, 0 );
               dialog.imageFrame.width = imageFrameSize;
               sizerpos = x;
            }
         }
      }

      this.sizeBar.onPaint = function( x0, y0, x1, y1 )
      {
         var g = new Graphics(dialog.sizeBar);
         g.drawLine(3, 0, 3, y1);
         g.end();
      }

   this.imageFrame = new Frame(this);
   this.imageFrame.setVariableSize();
      this.imageFrame.sizer = new VerticalSizer();
      this.imageFrame.sizer.margin = 4;
         this.imageFrame.sizer.add (this.previewControl);

   this.setVariableSize();

   this.sizer = new HorizontalSizer();
   this.sizer.margin = 8;
      this.sizer.add(this.plotFrame);
      this.sizer.add(this.sizeBar);
      this.sizer.add(this.imageFrame);


	this.adjustToContents();

   CoreApplication.processEvents();

   plotFrameMinsize  = this.plotFrame.width;
   imageFrameMinsize = this.imageFrame.width;

   this.plotFrame.setFixedWidth(plotFrameMinsize);

   // 1st display

   this.previewControl.SetImage(cv.imageData.getBitmap(false), cv.metadata);

   cv.p1 = new Point(0, Math.floor(cv.imageData.bounds.height / 2));
   cv.p2 = new Point(cv.imageData.bounds.width - 1, Math.floor(cv.imageData.bounds.height / 2));
   setLineOffsetStatus(true);
   pixelOfLine(cv.p1, cv.p2);
   refresh();

   /***************************************************************************/
   /***************************************************************************/
   /***************************************************************************/
   /***************************************************************************/

   function refresh()
   {
      dialog.previewControl.repaint();
      dialog.canvas.repaint();
      if (cv.dataChanged) dialog.scaleFrame.repaint();
      cv.dataChanged = false;
   }

   function pixelOfLine(p1, p2)
   {
      if (p1 == null || p2 == null)
      {
         cv.angle = 0;
         cv.coordinates = [];
         cv.scanData = [];
         dialog.saveData_Button.enabled = true;
         dialog.saveDiagram_Button.enabled = true;
         dialog.previewControl.Aval_Label.text = cv.angle.toFixed("0.00");
         return;
      }

      if (p1.x > p2.x)
      {
         var p = p1;
         p1 = p2;
         p2 = p;
      }
      var width  = dialog.view.image.width;
      var height = dialog.view.image.height;

      cv.coordinates = getPixelCoordinates(p1.x, p1.y, p2.x, p2.y);
      cv.angle = Math.atan2(p2.y - p1.y, p2.x - p1.x) * Math.DEG;
      dialog.saveData_Button.enabled = true;
      dialog.saveDiagram_Button.enabled = true;
      dialog.previewControl.Aval_Label.text = cv.angle.toFixed("0.00");
      cv.scanData = [];

      for (var c = 0; c < cv.channels; c++)
      {
         cv.scanData.push(cv.imageData.getIntensities(c, cv.coordinates));
      }

      cv.maxValueData = 0;
      cv.minValueData = 1;

      for (var c = 0; c < cv.channels; c++)
      {
         var scanData = cv.scanData[c];
         for (var j = 0; j < scanData.length; j++)
         {
            cv.minValueData = Math.min(cv.minValueData, scanData[j].i);
            cv.maxValueData = Math.max(cv.maxValueData, scanData[j].i);
         }
      }

      cv.dataChanged = true;
   }

   function setBitmapFromView(view)
   {
      dialog.waitLabel.visible = true;
      CoreApplication.processEvents();

      cv.currentView = view;
      //var bgView = extractBackground(view);


      cv.imageData = new ImageData(view, null);

      cv.blackLines = [];           // collection of black lines
      cv.blackLineIndex = -1;       // index of next line to add


      cv.channels = cv.imageData.numberOfChannels();

      cv.imageData.bounds = new Rect (0, 0, view.image.width, view.image.height);

      cv.starPosition = null;

      cv.mouseMode   = lineMode;
      cv.starPSF     = null;


      if (cv.imageData.isGrayscale())
      {
         dialog.cbG.visible = false;
         dialog.cbB.visible = false;
         dialog.cbR.icon = dialog.scaledResource(':/toolbar/image-display-black.png');
         dialog.rlabel.text = 'K:';
         dialog.glabel.visible = false;
         dialog.blabel.visible = false;
         dialog.gvalue.visible = false
         dialog.bvalue.visible = false
      }
      else
      {
         dialog.cbG.visible = true;
         dialog.cbB.visible = true;
         dialog.cbR.icon = dialog.scaledResource(':/toolbar/image-display-red.png');
         dialog.rlabel.text = 'R:';
         dialog.glabel.visible = true;
         dialog.blabel.visible = true;
         dialog.gvalue.visible = true
         dialog.bvalue.visible = true
      }

      cv.metadata = {width:view.image.width, height:view.image.height};
      if (view.image.bitsPerSample == 32) dialog.pixScale.currentItem = 0;
      if (view.image.bitsPerSample ==  8) dialog.pixScale.currentItem = 1;
      if (view.image.bitsPerSample == 10) dialog.pixScale.currentItem = 2;
      if (view.image.bitsPerSample == 12) dialog.pixScale.currentItem = 3;
      if (view.image.bitsPerSample == 14) dialog.pixScale.currentItem = 4;
      if (view.image.bitsPerSample == 16) dialog.pixScale.currentItem = 5;
      cv.pScale = [1, 255, 1023, 4095, 16383, 65535][dialog.pixScale.currentItem];
      dialog.rbHorizontal.checked = true;
      cv.mode = Horizontal;
      setLineOffsetStatus(true);

      if (view.window.filePath != '')
         dialog.windowTitle = dialog.title + ' - ' + view.window.filePath;
      else
         dialog.windowTitle = dialog.title + ' - ' + view.id;

      dialog.rbBack.enabled = true;    // enable after image load, disable, if no background found
      //if (!cv.imageData.hasBackground())   //bgView == null)
      //{
         dialog.rbImage.checked = true;
      //}
      dialog.cbSTF.checked = false;
      dialog.btnBlackLine.enabled = view.isMainView && cv.lineSize > 0;
      dialog.btnSizeMinus.enabled = view.isMainView;
      dialog.btnSizePlus.enabled  = view.isMainView;
      dialog.numLineSize.enabled  = view.isMainView;

      dialog.waitLabel.visible = false;
      dialog.btnReport.enabled = false;
   }

   function analyzeStarPos()
   {
      if (cv.starPosition == null) return;
      var x = cv.starPosition.x;
      var y = cv.starPosition.y;

      var dynPSF       = new DynamicPSF();
      var searchRadius = 8;

      var processStars = [];

      // viewIndex, channel, status, x0, y0, x1, y1, x, y

      var channels = cv.imageData.numberOfChannels();
      for (var channel = 0; channel < channels; channel++)
         processStars.push([0, channel, DynamicPSF.Star_DetectedOk,
                     x - searchRadius, y - searchRadius,
                     x + searchRadius, y + searchRadius,
                     x, y]);

      dynPSF.stars = processStars;
      dynPSF.astrometry     = true;
      dynPSF.autoAperture   = true;
      dynPSF.autoPSF        = true;
      dynPSF.circularPSF    = false;
      dynPSF.astrometry     = false;
      dynPSF.gaussianPSF    = true;
      dynPSF.moffatPSF      = false;
      dynPSF.regenerate     = true;
      dynPSF.scaleMode      = DynamicPSF.Scale_Pixels;
      dynPSF.scaleValue     = 1.00;
      dynPSF.searchRadius   = searchRadius;
      dynPSF.signedAngles   = true;
      dynPSF.threshold      = 1.00;
      dynPSF.views          = [[cv.currentView.fullId]];

      dynPSF.executeGlobal();

      var psf               = dynPSF.psf;
      cv.starProfiles       = [];
      var channels          = [];
      for (var c = 0; c < dynPSF.stars.length; c++)
      {
         if (dynPSF.stars[c][2] == DynamicPSF.Star_DetectedOk)
         {
            channels.push(dynPSF.stars[c][1]);
         }
      }

      cv.starPSF = new PSF(psf, cv.imageData.bounds, channels);
      cv.meanCentroid = cv.starPSF.meanCentroid();

      if (cv.imageData.solved())
      {
         var window = cv.imageData.getView().window;
         cv.celestialCoord = window.imageToCelestial(cv.meanCentroid.x, cv.meanCentroid.y);
      }


      if (cv.starPSF != null)
      {
         //
         // get endpoints from psf, if on starMode
         //
         if (cv.mode == Horizontal)
            cv.starPSF.select(0, 0);
         else
            cv.starPSF.select(0, 1);

         if (cv.starPSF.isValid())
         {
            var line = cv.starPSF.line();
            cv.p1 = line[0];
            cv.p2 = line[1];
            pixelOfLine(cv.p1, cv.p2);
            //dialog.btnReport.move(cv.z + 2, 2);
            dialog.btnReport.enabled = true;
         }
         else
            dialog.btnReport.enabled = false;
      }
      else
         dialog.btnReport.enabled = false;
   }


   function PSF(psf, bounds, channels)
   {
      var centroids     = [];
      var meancentroid  = null;
      var fwhm          = [];
      var profiles      = [];
      var radius        = [];       // radius of both axis
      var lines         = [];       // 1st and last pos of both axis
      this.bounds       = bounds;

      var functionNames = ['Gaussian',    // 0
                           'Moffat',      // 1
                           'Moffat10',    // 2
                           'Moffat8',     // 3
                           'Moffat6',     // 4
                           'Moffat4',     // 5
                           'Moffat25',    // 6
                           'Moffat15',    // 7
                           'Lorentzian'   // 8
                          ]

      var xColl = [];
      var yColl = [];

      for (var i = 0; i < psf.length; i++)
      {
         var a = psf[i];
         var psfItem =
         {
            psf_function: a[1],
            circular    : a[2],
            status      : a[3],
            B           : a[4],
            A           : a[5],
            cx          : a[6],
            cy          : a[7],
            sx          : a[8],
            sy          : a[9],
            theta       : a[10],
            beta        : a[11],
            mad         : a[12],
            celestial   : a[13],
            alpha       : a[14],
            delta       : a[15],
            name        : functionNames[a[1]],
            FWHMx       : 0,
            FWHMy       : 0,
            r           : 0,
            channel     : channels[i]
         }
         profiles.push(psfItem);

         psfItem.r = psfItem.sy / psfItem.sx;
            var fwhm0 = 0;
            var fwhm1 = 0;

            if (psfItem.psf_function == DynamicPSF.Function_Gaussian)
            {
               fwhm0 = 2.35482 * psfItem.sx;
               fwhm1 = 2.35482 * psfItem.sy;
            }
            else
            {
               fwhm0 = 2 * psfItem.sx * Math.sqrt(Math.pow(2, 1 / psfItem.beta) - 1);
               fwhm1 = 2 * psfItem.sy * Math.sqrt(Math.pow(2, 1 / psfItem.beta) - 1);
            }
            fwhm.push([fwhm0, fwhm1]);

            psfItem.FWHMx = fwhm0;
            psfItem.FWHMy = fwhm1;

            radius.push([ 2.5 * fwhm0 + 0.5, 2.5 * fwhm1 + 0.5]);

            // line axis 0

            lines.push([ [ new Point(Math.round(psfItem.cx - radius[i][0]), Math.round(psfItem.cy)),
                           new Point(Math.round(psfItem.cx + radius[i][0]), Math.round(psfItem.cy))
                         ],
                         [ new Point(Math.round(psfItem.cx), Math.round(psfItem.cy - radius[i][1])),
                           new Point(Math.round(psfItem.cx), Math.round(psfItem.cy + radius[i][1]))
                         ]
                       ]);

            centroids.push(new Point(psfItem.cx, psfItem.cy));

            xColl.push(psfItem.cx);
            yColl.push(psfItem.cy);
      }

      meancentroid = new Point(Math.mean(xColl), Math.mean(yColl));
      var valid   = false;
      var channel = 0;
      var axis    = 0;  // 0=horizontal, 1=vertical

      this.channelCount = function ()
      {
         return profiles.length;
      }

      this.isValid = function ()
      {
         return valid;
      }

      this.select = function (image_channel, image_axis)
      {
         channel = image_channel;
         axis    = image_axis;

         valid = channel > -1 && channel < profiles.length &&
                 axis > -1 && axis < 2;
         if (valid)
            valid = profiles[channel].status == DynamicPSF.PSF_FittedOk;
      }

      this.centroid = function ()
      {
         if (valid)
            return centroids[channel];
         else
            return 0;
      }

      this.meanCentroid = function ()
      {
         return meancentroid;
      }

      this.fwhm = function ()
      {
         if (valid)
            return fwhm[channel][axis];
         else
            return 0;
      }

      this.line = function ()
      {
         if (valid)
         {
            var p1 = null;
            var p2 = null;
            //
            // get the max line of all channels
            //
            for (var c = 0; c < lines.length; c++)
            {
               var l = lines[c][axis];
               if (axis == 0)
               {
                  // horizontal
                  if (p1 == null)
                  {
                     p1 = l[0];
                     p2 = l[1];
                  }
                  else
                  {
                     if (l[0].x < p1.x) p1 = new Point(l[0].x, p1.y)
                     if (l[1].x > p2.x) p2 = new Point(l[1].x, p2.y)
                  }
               }
               else
               {
                  // vertical
                  if (p1 == null)
                  {
                     p1 = l[0];
                     p2 = l[1];
                  }
                  else
                  {
                     if (l[0].y < p1.y) p1 = new Point(p1.x, l[0].y)
                     if (l[1].x > p2.x) p2 = new Point(p2.x, l[1].y)
                  }
               }
            }
            return [p1, p2];// lines[channel][axis];
         }
         else
            return [];
      }

      this.profile = function ()
      {
         return profiles[channel];
      }

      this.profileOfChannel = function(channel)
      {
         return profiles[channel];
      }

      this.psf_function = function ()
      {
         if (valid)
            return profiles[channel].psf_function;
         else
            return -1;
      }

      this.getCurve = function (resolution)
      {
         //
         // resolution = points / pixel
         //
         var curve = [];
         var dxy   = 1 / resolution;

         if (valid)
         {
            //
            // calculate curve points with gauss or moffat profile
            //
            var rAxis = radius[channel][axis];// this.radius();
            //
            //var centroid = this.centroid();
            //
            var p = profiles[channel];
            if (axis == 0)                   // x
               {
                  var x = p.cx - rAxis;
                  if (p.psf_function == 0)        // Gauss
                  {
                     while (x <= p.cx + rAxis)
                     {
                        if (this.bounds.includes(x, p.cy))
                        {
                           var v = gauss(x, p.cy, p.B, p.A, p.cx, p.cy, p.sx, p.sy);
                           curve.push(new Point(x, v));
                        }
                        x += dxy;
                     }
                  }
                  else                          // moffat, lorentz
                  {
                     while (x <= p.cx + rAxis)
                     {
                        if (this.bounds.includes(x, p.cy))
                        {
                           var v = moffat(x, p.cy, p.B, p.A, p.cx, p.cy, p.beta, p.sx, p.sy);
                           curve.push(new Point(x, v));
                        }
                        x += dxy;
                     }
                  }
               }
               else  // axis 1, y
               {
                  var y = p.cy - rAxis;
                  if (p.psf_function == 0)        // Gauss
                  {
                     while (y <= p.cy + rAxis)
                     {
                        if (this.bounds.includes(p.cx, y))
                        {
                           var v = gauss(p.cx, y, p.B, p.A, p.cx, p.cy, p.sx, p.sy);
                           curve.push(new Point(y, v));
                        }
                        y += dxy;
                     }
                  }
                  else                          // moffat, lorentz
                  {
                     while (y <= p.cy + rAxis)
                     {
                        if (this.bounds.includes(p.cx, y))
                        {
                           var v = moffat(p.cx, y, p.B, p.A, p.cx, p.cy, p.beta, p.sx, p.sy);
                           curve.push(new Point(y, v));
                        }
                        y += dxy;
                     }
                  }
               }
         }
         return curve;
      }
   }

   function displayDistanceValue()
   {
      // find centroids of stars next to p1 and p2

      if (cv.p2 == null) return;

      if (cv.imageData.solved())
      {
         //
         // pixel disdance in degrees
         //
         var window = cv.imageData.getView().window;

         var c1 = window.imageToCelestial(cv.p1);
         var c2 = window.imageToCelestial(cv.p2);


         var a = angularSeparation(c1.x, c1.y, c2.x, c2.y);

         if (a >= 1)
         {
            dialog.previewControl.Distval_Label.text = a.toFixed(3) + '°';
         }
         else if (a >= 1 / 60)
         {
            a *= 60;
            dialog.previewControl.Distval_Label.text = a.toFixed(3) + "\'";
         }
         else
         {
            a *= 3600;
            dialog.previewControl.Distval_Label.text = a.toFixed(3) + '"';
         }
         return;
      }

      var pixelDist = Math.sqrt(Math.pow(cv.p2.x - cv.p1.x, 2) +
                                Math.pow(cv.p2.y - cv.p1.y, 2));
      dialog.previewControl.Distval_Label.text = pixelDist.toFixed(2) + 'px';
   }

   function updateView(cv)
   {
      //
      // transfer black lines to the view
      //
      if (cv.blackLineIndex > -1)
      {
         var view = cv.imageData.getView();

         view.beginProcess();

         for (var i = 0; i < cv.channels; i++)
         {
            var bm  = new Bitmap(cv.imageData.bounds.width, cv.imageData.bounds.height);
            var img = new Image( bm.width, bm.height);
            var g = new Graphics(bm);

            g.fillRect (cv.imageData.bounds, new Brush(0xffffffff));

            for (var b = 0; b < cv.blackLineIndex + 1; b++)
            {
               var bl = cv.blackLines[b];
               if (bl.channelFlags[i])
               {
                  g.pen = new Pen(0xff000000, bl.size);
                  g.drawLine(bl.p1, bl.p2);
               }
            }

            g.end();

            img.blend(bm);

            view.image.selectedChannel = i;
            var a = new Float32Array(view.image.numberOfPixels );
            var v = new Vector(a);
            view.image.getSamples(v);

            var z = new Float32Array(view.image.numberOfPixels );
            var u = new Vector(z);
            img.getSamples(u);

            for (var j = 0; j < a.length; j++)
            {
               if (u.at(j) == 0) v.at(j, 0);
            }

            view.image.setSamples(v);
         }

         view.endProcess();
      }
   }

   function displayValues()
   {
      if (cv.pixelPos == null) return;
      //
      // update labels
      //
      dialog.valueLabels[0].text = cv.pixelPos.x.toString();
         dialog.valueLabels[1].text = cv.pixelPos.y.toString();
         var index = cv.pixelPos.y * cv.imageData.bounds.width + cv.pixelPos.x;
         for (var i = 0; i < cv.channels; i++)
         {
            if (cv.pScale == 1)
               dialog.valueLabels[i + 2].text = cv.imageData.getValue(i, index).toFixed(6);
            else
               dialog.valueLabels[i + 2].text = (cv.pScale * cv.imageData.getValue(i, index)).toFixed(2);
         }
   }

   function setPixelPos(x)
   {
      if (x < cv.z ||
          x > dialog.canvas.clientRect.width ||
          cv.coordinates.length == 0)
      {
         cv.pixelPos = null;
         return false;
      }
      else
      {
         if (cv.p1 == null || cv.p2 == null) return false;
         var X = x - cv.z;
         var i = Math.floor(X /
            (dialog.canvas.clientRect.width - cv.z - 1)
               * (cv.coordinates.length - 0));
         cv.pixelPos = cv.coordinates[i];
         return true;
      }
   }

   function setScaleNumRect()
   {
         var scaleNumTemplate = '';

         if (cv.pScale == 1)
            scaleNumTemplate = 'M.MMMMMM';
         else if (cv.pScale < 1000)
            scaleNumTemplate = 'MMM';
         else if (cv.pScale < 10000)
            scaleNumTemplate = 'MMMM';
         else if (cv.pScale < 100000)
            scaleNumTemplate = 'MMMMM';

         var bm = new Bitmap(1, 1);
         var g = new Graphics (bm);
         scaleNumRect= g.textRect( new Rect(0, 100,0, 100), scaleNumTemplate,
                               TextAlignment.Center | TextAlignment.Right);
   }

   function setLineOffsetStatus(status)
   {
      if (status)
      {
         cv.lineOffset = 0;
         cv.p1Home = cv.p1;
         cv.p2Home = cv.p2;
         dialog.btnOffsetMinus.enabled = true;
         dialog.btnOffsetPlus.enabled = true;
      }
      else
      {
         dialog.btnOffsetMinus.enabled = false;
         dialog.btnOffsetPlus.enabled = false;
      }
   }

   function offsetLine(direction)
   {
      // get line with offset to p1Home, p2Home by cv.lineOffset

      var line = null;
      var offs = cv.lineOffset + direction;

      if (cv.angle>= -45 && cv.angle <= 45)
      {
         var p1 = new Point(cv.p1Home.x, cv.p1Home.y + offs);
         var p2 = new Point(cv.p2Home.x, cv.p2Home.y + offs);
         line = limiter(p1, p2);
      }
      else
      {
         var p1 = new Point(cv.p1Home.x + offs, cv.p1Home.y);
         var p2 = new Point(cv.p2Home.x + offs, cv.p2Home.y);
         line = limiter(p1, p2);
      }

      if (line[0] != null) cv.lineOffset = offs;

      return line;
   }

   function limiter(p1, p2)
   {
      var co = getPixelCoordinates(p1.x, p1.y, p2.x, p2.y);

      var first = null;     //
      var last  = null;

      for (var i = 0; i < co.length; i++)
      {
         if (cv.imageData.bounds.includes(co[i]))
         {
            if (first == null)
            {
               first = co[i];
            }
            last = co[i];
         }
      }
      return [first, last];
   }

   function enableBtnBlackLine()
   {
      dialog.btnBlackLine.enabled = cv.lineSize > 0 && cv.p1 != null && cv.p2 != null;
   }

   function restoreBlackLine(index)
   {
      var blackline = cv.blackLines[index];

      cv.p1          = new Point(blackline.p1.x, blackline.p1.y);
         cv.p2          = new Point(blackline.p2.x, blackline.p2.y);
         cv.angle       = blackline.angle;
         cv.lineSize    = blackline.size;
         cv.mode        = blackline.mode;
         dialog.numLineSize.setValue(cv.lineSize);
         switch (cv.mode)
         {
            case Horizontal:
               dialog.rbHorizontal.checked   = true;
               break;
            case Vertical:
               dialog.rbVertical.checked     = true;
               break;
            case DiagonalDn:
               dialog.rbDiagonalDn.checked   = true;
               break;
            case DiagonalUp:
               dialog.rbDiagonalUp.checked   = true;
               break;
            case Single_Point:
               dialog.rbSinglePoint.checked  = true;
               break;
            case Double_Point:
               dialog.rbDoublePoint.checked  = true;
               break;
         }

      setLineOffsetStatus(true);
      enableBtnBlackLine();
      dialog.imgBlackLine.repaint();
      pixelOfLine(cv.p1, cv.p2);
      dialog.canvas.repaint();
      dialog.previewControl.repaint();
   }
}

} // class showDialog


function ImageData(viewImage, viewBackground)
{
   // store pixel values of both views
   //

   this.cursor = new Cursor( StdCursor.Wait );
   var imageSelected = 0;       // 0 = image, 1 = background

   this.bounds        = new Rect(0,
                                 0,
                                 viewImage.image.width,
                                 viewImage.image.height);

   var width          = this.bounds.width;
   //
   //  arrays images, channeldata, background mean
   //
   var numberChannel       = viewImage.image.numberOfChannels;
   var grayScale           = viewImage.image.isGrayscale;
   //
   // input views
   //
   var images              = [viewImage, viewBackground];
   //
   // output bitmaps, channelData and mean values
   //
   var bitmaps             = [null, null];
   var bitmapsSTF          = [null, null];
   var imageChannels       = [null, null];
   var backgChannels       = [null, null];
   var mean                = [0, 0];
   var keywords            = viewImage.window.mainView.window.keywords;
   var iScale              = [1, 1];
   var solved_             = false;
   var imagePosition       = new Point(0, 0);
   var hasbackground       = false;
   var tryBGLoad           = false;

   this.selectImage = function (index)
   {
      if (index == 1 && images[index] == null)
      {
         // try loading background
         if (!tryBGLoad)
         {
            var bg = extractBackground(images[0]);
            tryBGLoad = true;
            if (bg == null) return;
            hasbackground = true;
            images[1] = bg;
            extractData(1);
         }
         else
            return;
      }
      imageSelected = index;
   }

   this.hasBackground = function ()
   {
      return hasbackground;
   }

   if (viewImage.isPreview)
   {
      var r = viewImage.window.previewRect( viewImage );
      imagePosition = new Point(r.x0, r.y0);
   }

   if (keywords != null && keywords.length > 0)
   {
      //for (var i = 0; i < keywords.length; i++) Console.writeln(keywords[i]);

      var CD1_1   = fitsKey('CD1_1', keywords);
      var CD1_2   = fitsKey('CD1_2', keywords);
      var CD2_1   = fitsKey('CD2_1', keywords);
      var CD2_2   = fitsKey('CD2_2', keywords);
      var CTYPE1  = fitsKey('CTYPE1', keywords);

      if (CD1_1 != null && CD1_1 != null && CD1_1 != null && CD1_1 != null)
      {
         solved_  = true;
         var xinc = Math.sqrt(CD1_1 * CD1_1 + CD1_2 * CD1_2) * 3600;
         var yinc = Math.sqrt(CD2_1 * CD2_1 + CD2_2 * CD2_2) * 3600;

         if (CTYPE1.startsWith("RA"))
            iScale = [xinc, yinc];
         else
            iScale = [yinc, xinc];
      }
   }

   extractData(0);

   this.cursor = new Cursor( StdCursor.Arrow );

   this.numberOfChannels = function ()
   {
      return numberChannel;
   }

   this.isGrayscale = function ()
   {
      return grayScale;
   }

   this.getImage = function()
   {
      return images[imageSelected].image;
   }

   this.getView = function()
   {
      return images[imageSelected];
   }

   this.getBitmap = function(boolSTF)
   {
      if (!boolSTF)
      {
         return bitmaps[imageSelected];
      }
      else
      {
         if (bitmapsSTF[imageSelected] == null)
         {
            var view = viewFromChannels(images[imageSelected],
                                        imageChannels[imageSelected]);
            var autoSTF = new AutoStretch()
            autoSTF.HardApply(view, true,
               DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND);
            bitmapsSTF[imageSelected] = view.image.render();
         }
         return bitmapsSTF[imageSelected];
      }
   }

   this.getMean = function(channelIndex)
   {
      return mean[imageSelected][channelIndex];
   }

   this.getPixels = function(channelIndex)
   {
      return imageChannels[imageSelected][channelIndex];
   }

   this.getValue = function(channelIndex, pixelIndex)
   {
      return imageChannels[imageSelected][channelIndex][pixelIndex];
   }

   this.getIntensities = function(channelIndex, coordinates)
   {
      // coordinates is an array of points
      //
      var data = imageChannels[imageSelected][channelIndex];
      //
      //
      //
      var intensities = [];

      for (var j = 0; j < coordinates.length; j++)
      {
         var p = coordinates[j];
         var x = p.x;
         var y = p.y;
         var v = data[y * width + x];
         intensities.push({i:v, x:x, y:y});
      }
      return intensities;
   }

   this.getAllIntensities = function (coordinates)
   {
      var a = [];
      for (var c = 0; c < numberChannel; c++)
      {
         a.push(this.getIntensities(c, coordinates));
      }
      return a;
   }

   function extractChannels(view)
   {
      var channels = [];

      view.image.resetChannelSelection();
      for (var c = 0; c < view.image.numberOfChannels; c++)
      {
         view.image.selectedChannel = c;
         var pixels = [];
         view.image.getSamples(pixels);
         channels.push(new Float32Array(pixels));
      }
      return channels;
   }

   function extractMean(view)
   {
      var mean = [];

      view.image.resetChannelSelection();
      for (var c = 0; c < view.image.numberOfChannels; c++)
      {
         view.image.selectedChannel = c;
         mean.push(view.image.mean());
      }
      return mean;
   }

   function extractData(index)
   {
      if (images[index] != null)
      {
         if (images[index].image != null)
         {
            imageChannels[index]  = extractChannels(images[index]);
            images[index].image.firstSelectedChannel = 0;
            images[index].image.lastSelectedChannel  = numberChannel - 1;
            bitmaps[index]        = images[index].image.render();
            mean[index]           = extractMean(images[index]);
         }
         else
            bitmaps[i]        = null;
      }
   }

   this.RD = function (p)
   {
      if (solved_)
         return images[0].window.imageToCelestial(p.x + imagePosition.x,
                                                  p.y + imagePosition.y);
      else
         return null;
   }

   this.solved = function ()
   {
      return solved_;
   }

   this.imageScale = function ()
   {
      return iScale;
   }

   function extractBackground(view)
   {
      var P = new AutomaticBackgroundExtractor;
      P.tolerance = 1.000;
      P.deviation = 0.800;
      P.unbalance = 1.800;
      P.minBoxFraction = 0.050;
      P.maxBackground = 1.0000;
      P.minBackground = 0.0000;
      P.useBrightnessLimits = false;
      P.polyDegree = 4;
      P.boxSize = 5;
      P.boxSeparation = 5;
      P.modelImageSampleFormat = 1; // f32 (float) -- no namespace constant exists in V8, matching the same SampleType raw-integer convention (0=integer, 1=float)
      P.abeDownsample = 2.00;
      P.writeSampleBoxes = false;
      P.justTrySamples = false;
      P.targetCorrection = 0; // None -- no namespace constant exists in V8 for this process; best-reasoned value, please confirm this behaves as "None" when tested
      P.normalize = false;
      P.discardModel = false;
      P.replaceTarget = false;
      P.correctedImageId = "";
      P.correctedImageSampleFormat = 0; // SameAsTarget -- same situation as targetCorrection above
      P.verboseCoefficients = false;
      P.compareModel = false;
      P.compareFactor = 10.00;
      var ok = false;

      try
      {
         ok = P.executeOn(view);
      }
      catch (ex)
      {
         Console.writeln(ex);
      }

      if (ok)
      {
         var len = ImageWindow.openWindows.length;
         var bg = ImageWindow.openWindows[len - 1].mainView;
         //
         // check size
         //
         var sx = view.image.width / bg.image.width;
         var sy = view.image.height / bg.image.height;
         //
         if (sx != 1 || sy != 1)
         {
            var img = new Image(bg.image);
            img.resample(sx, sy, 0, 0);
            var window = new ImageWindow(img.width, img.height, img.numberOfChannels,
                                          view.window.bitsPerSample,
                                          view.window.isFloatSample,
                                          view.image.colorSpace != ColorSpace.Gray);
            var nview = window.mainView;

            nview.beginProcess(UndoFlag.NoSwapFile);

            nview.image.apply(img);

            nview.endProcess();

            nview.id = getNewName('temp', '_2d');

            nview.setPropertyValue('delete', true);

            bg.window.forceClose();

            return nview;
         }
      else
         return null;
      }
      return bg;
   }

}

function getPixelCoordinates(x0, y0, x1, y1)
{
   /*
   input:   start point (x0, y0)
            end point   (x1, y1)
            image object
            data of selected channel

   return:  array of points
   */
   x0 = Math.floor(x0);
   y0 = Math.floor(y0);
   x1 = Math.floor(x1);
   y1 = Math.floor(y1);

   var points = [];
   var tmp;
   // *************************************
   // check vertical scan
   // *************************************
   if (x0 == x1)
   {
      if (y1 < y0)
      {
         tmp = y1;
         y1  = y0;
         y0  = tmp;
      }
      for (var y = y0; y < y1 ; y++) points.push(new Point(x0, y));
      return points;
      }
   // *************************************
   // check horizontal scan
   // *************************************
   if (y0 == y1)
   {
      if (x1 < x0)
      {
         tmp = x1;
         x1  = x0;
         x0  = tmp;
      }
      for (var x = x0; x < x1; x++) points.push(new Point(x, y0));
      return points;
   }
   else
   {
      // **************************************
      // Bresenham's line algorithm implemented
      //
      // **************************************
      var dx  = Math.abs(x1-x0);
      var dy  = Math.abs(y1-y0);
      var sx  = (x0 < x1) ? 1 : -1;
      var sy  = (y0 < y1) ? 1 : -1;
      var err = dx - dy;
      var x   = x0;
      var y   = y0;

      while(true)
      {
         points.push(new Point(x, y));
         if ((x == x1) && (y == y1)) break; // ready
         var e2 = 2 * err;
         if (e2 > -dy){ err -= dy; x  += sx; }
         if (e2 <  dx){ err += dx; y  += sy; }
      }

      return points;
   }
}


function getLine(p, angle, rect)
{
   // compute line x0, y0, .. x1, y1
   // p = Point
   // angle = angle of line
   // rect, boundary
   if (!rect.includes(p))
      return null;
   if (angle == 0)
   {
      var p1 = new Point(rect.x0, p.y);
      var p2 = new Point(rect.x1, p.y);
      return {p1:p1, p2:p2};
   }
   else if (Math.abs(angle)  == 90)
   {
      var p1 = new Point(p.x, rect.y0);
      var p2 = new Point(p.x, rect.y1);
      return {p1:p1, p2:p2};
   }
   else
   {
      var x;
      var y;
      var x0 = p.x;
      var y0 = p.y;
      var p1;
      var p2;

      var topP = null;   // line crossing top
      var botP = null;   // line crossing bottom
      var lftP = null;   // line crossing left
      var rgtP = null;   // line crossing right

      var m = Math.tan(angle * Math.RAD);

      // check horizontal top
      x = x0 + (rect.y0 - y0) / m;
      if (x >= rect.x0 && x <= rect.x1) topP = new Point(Math.round(x), rect.y0);

      // check horizontal bottom
      x = x0 + (rect.y1 - y0) / m;
      if (x >= rect.x0 && x <= rect.x1) botP = new Point(Math.round(x), rect.y1);

      // check vertical left
      y = y0 + (rect.x0 - x0) * m;
      if (y >= rect.y0 && y < rect.y1) lftP = new Point(rect.x0, Math.round(y));

      // check vertical right
      y = y0 + (rect.x1 - x0) * m;
      if (y >= rect.y0 && y < rect.y1) rgtP = new Point(rect.x1,  Math.round(y));

      if (topP != null && lftP != null) return {p1:lftP, p2:topP};
      if (topP != null && rgtP != null) return {p1:topP, p2:rgtP};
      if (topP != null && botP != null) return {p1:topP, p2:botP};
      if (lftP != null && rgtP != null) return {p1:lftP, p2:rgtP};
      if (lftP != null && botP != null) return {p1:lftP, p2:botP};
      if (rgtP != null && botP != null) return {p1:botP, p2:rgtP};
      return null;
   }
}

function lineIntersect(p, angle, p0, p1)
{
   var m = Math.tan(angle * Math.RAD);
}

function viewFromChannels(view, channels)
{

   var width  = view.image.width;
   var height = view.image.height;

   var img = new Image(width, height, channels.length);

   for (var channel = 0; channel < channels.length; channel +=1)
   {
      var v = new Vector(channels[channel]);
      img.setSamples(v, new Rect(0, 0, width, height), channel);
   }

   var window = new ImageWindow(img.width, img.height, img.numberOfChannels,
                                 view.window.bitsPerSample,
                                 view.window.isFloatSample,
                                 view.image.colorSpace != ColorSpace.Gray);
   window.hide();

   var nview = window.mainView;

   nview.beginProcess(UndoFlag.NoSwapFile);

   nview.image.apply(img);

   nview.endProcess();

   nview.id = getNewName('temp', '_2d');

   nview.setPropertyValue('delete', true);

   return nview;
}



function gauss(x, y, B, A, cx, cy, sigmax, sigmay)
{
	var sqx = sigmax * sigmax * 2;
	var sqy = sigmay * sigmay * 2;
	var dx2 = Math.pow(x - cx, 2);
	var dy2 = Math.pow(y - cy, 2);
	return B + A * Math.exp(-(dx2 / sqx + dy2 / sqy));
}


function moffat(x, y, B, A, cx, cy, beta, sigmax, sigmay)
{
	var sqx = sigmax * sigmax;
	var sqy = sigmay * sigmay;
	var dx2 = Math.pow(x - cx, 2);
	var dy2 = Math.pow(y - cy, 2);
	var m = B + A / Math.pow((1 + dx2 / sqx + dy2 / sqy), beta);
   return m;
}


// Helper functions

function getNewName(name, suffix)
{
   var newName = name + suffix;
   let n = 1;
   while (!ImageWindow.windowById(newName).isNull)
   {
      ++n;
      newName = name + suffix + n;
   }
   return newName;
}


// *********
// This object has been copied and simplified from the AutoSTF script from Juan Conejero
// *********

function AutoStretch()
{
   // Default STF Parameters
   var SHADOWS_CLIP = -1.25; // Shadows clipping point measured in sigma units from the main histogram peak.
   var TARGET_BKG   =  0.25; // Target background in the [0,1] range.

   /*
    * Find a midtones balance value that transforms v1 into v0 through a midtones
    * transfer function (MTF), within the specified tolerance eps.
    */
   this.findMidtonesBalance = function (v0, v1, eps)
   {
      if (v1 <= 0)
         return 0;

      if (v1 >= 1)
         return 1;

      v0 = Math.range(v0, 0.0, 1.0);

      if (eps)
         eps = Math.max(1.0e-15, eps);
      else
         eps = 5.0e-05;

      var m0, m1;
      if (v1 < v0)
      {
         m0 = 0;
         m1 = 0.5;
      }
      else
      {
         m0 = 0.5;
         m1 = 1;
      }

      for (; ;)
      {
         var m = (m0 + m1) / 2;
         var v = Math.mtf(m, v1);

         if (Math.abs(v - v0) < eps)
            return m;

         if (v < v0)
            m1 = m;
         else
            m0 = m;
      }
   }

   this.CalculateStretch = function(view, verbose, shadowsClipping, targetBackground)
   {
      if (shadowsClipping == undefined)
         shadowsClipping = SHADOWS_CLIP;
      if (targetBackground == undefined)
         targetBackground = TARGET_BKG;
      if (verbose == undefined)
         verbose = false;

      view.image.resetSelections();

      // Noninverted image

      var c0 = 0;
      var m = 0;
      view.image.selectedChannel = 0;
      var median = view.image.median();
      var avgDev = view.image.avgDev();
      c0 += median + shadowsClipping * avgDev;
      m += median;
      view.image.resetSelections();
      //Console.writeln('C0 = ' + c0);
      c0 = Math.range(c0, 0.0, 1.0);
      m = this.findMidtonesBalance(targetBackground, m - c0);

      return {m:m, c0:c0, c1:1};
   }
   /*
    * STF Auto Stretch routine
    */
   this.Apply = function (view, verbose, shadowsClipping, targetBackground)
   {
      var stretch = this.CalculateStretch(view, verbose, shadowsClipping, targetBackground);
      var stf = [
         // m, c0, c1, r0, r1
         [stretch.m, stretch.c0, stretch.c1, 0, 1],
         [stretch.m, stretch.c0, stretch.c1, 0, 1],
         [stretch.m, stretch.c0, stretch.c1, 0, 1],
         [0, 1, 0.5, 0, 1]
      ];

      if (verbose)
      {
         Console.writeln("<end><cbr/><br/><b>", view.fullId, "</b>:");
         Console.writeln(format("c0 = %.6f", stf[0][1]));
         Console.writeln(format("m  = %.6f", stf[0][0]));
         Console.writeln(format("c1 = %.6f", stf[0][2]));
         Console.writeln("<end><cbr/><br/>");
      }

      view.stf = stf;
   }

   this.HardApply = function(view, verbose, shadowsClipping, targetBackground)
   {
      var stretch =  this.CalculateStretch(view, verbose, shadowsClipping, targetBackground);

      if ( stretch.c0 > 0 || stretch.m != 0.5 || stretch.c1 != 1 ) // if not an identity transformation
      {
         if (verbose)
         {
            Console.writeln("<end><cbr/><br/><b>", view.fullId, "</b>:");
            Console.writeln(format("c0 = %.6f", stretch.c0));
            Console.writeln(format("m  = %.6f", stretch.m));
            Console.writeln(format("c1 = %.6f", stretch.c1));
            Console.writeln("<end><cbr/><br/>");
         }

         var HT = new HistogramTransformation;
         HT.H = [[  0, 0.5,   1, 0, 1],
            [  0, 0.5,   1, 0, 1],
            [  0, 0.5,   1, 0, 1],
            [stretch.c0, stretch.m, stretch.c1, 0, 1],
            [  0, 0.5,   1, 0, 1]];

         HT.executeOn( view, false ); // no swap file
      }
   }
}

/* ********************************************************************
 *
 * external functions to plotdlg
 *
 **********************************************************************
*/

function SaveGraphics(ctl, CExt)
{
   var bm = ctl.render();
   var fileD = new SaveFileDialog();
   fileD.caption = "Save Drawing";
   fileD.overwritePrompt = true;
   fileD.loadImageFilters();
   fileD.selectedFileExtension = CExt;
   if (fileD.execute())
   {
      bm.save(fileD.filePath);
      CExt = fileD.selectedFileExtension;
   }
}

function SaveData()
{
   //
   // write csv with all selected intensities
   // format
   // index;x;y;i <CrLf>
   //
   var fileD = new SaveFileDialog();
   fileD.caption = "Save Intensities as csv";
   fileD.overwritePrompt = true;
   fileD.filters = [["CSV Files", ".csv", ".txt"]];
   fileD.selectedFileExtension = ".csv";
}

function dataToString(lines, R, G, B)
{
   var tab = '\t';
   var cf = [R, G, B];        // true, for each selected channel
   var channelId;
   if (lines.length == 1)
      channelId = ['K'];
   else
      channelId = ['Red', 'Green', 'Blue'];
   var textLines = [];
   //
   // begin header
   //
   var line = 'Index' + tab + 'X' + tab + 'Y';
   for (var c = 0; c < lines.length; c++)
   {
      if (cf[c]) line += tab + channelId[c]
   }
   textLines.push(line);
   //
   // data
   //
   var i = 0;
   var samples = 0;
             // Console.writeln(lines[0].length);
   while (true)
   {
      for (var c = 0; c < lines.length; c++)
      {
         if (!cf[c]) continue;
         var data = lines[c];
         samples = data.length;
         line = i.toString() + tab +
                data[i].x.toString() + tab +
                data[i].y.toString() + tab +
                data[i].i.toFixed(8);          // intensity 1st selected channel
         for (var k = c + 1; k < lines.length; k++)
         {
            if (!cf[k]) continue;
            data = lines[k];
            line += tab + data[i].i.toFixed(8);
         }
         textLines.push(line);
         break;
      }
      i += 1;
      if (i >= samples) break;
   }

   var allText = textLines.join('\n');
   return allText;
}


function GetPrimaryScreenDimensions(dialog)
{
   //
   // get MainWindow\Geometry width & height
   //
   var roamingDir = File.homeDirectory + '/AppData/Roaming/Pleiades';
   var ini = roamingDir + '/PixInsight.ini';
   var x = 0;
   var y = 0;
   var w = 1920;
   var h = 1080;

   if (File.exists(ini))
   {
      var n = 0;
      var iniStrings = File.readLines(ini);
      for (var i = 0; i < iniStrings.length; i++)
      {
         var s = iniStrings[i];
         var a = s.split('=');
         var j = s.indexOf('=');

         var k = a[0];
         var v = a[1];

         if (k == 'MainWindow\\Geometry\\Top')
         {
            y = v.toInt();
            n++;
         }
         if (k == 'MainWindow\\Geometry\\Left')
         {
            x = v.toInt();
            n++;
         }
         if (k == 'MainWindow\\Geometry\\DesktopWidth')
         {
            w = v.toInt();
            n++;
         }
         if (k == 'MainWindow\\Geometry\\DesktopHeight')
         {
            h = v.toInt();
            n++;
         }

         if (n == 4) break;
      }
   }

   var scale = dialog.logicalPixelsToPhysical;
   return {left:x,top:y,width:w,height:h};
}



/*
   Preview Control


   modified, thanks Andre for this code

   This file is part of the AnnotateImage script

   Copyright (C) 2013-2020, Andres del Pozo
   Contributions (C) 2019-2020, Juan Conejero (PTeam)
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
   AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
   IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
   ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
   LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
   CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
   SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
   INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
   CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
   ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   POSSIBILITY OF SUCH DAMAGE.
 */

class PreviewControl extends Frame
{
constructor( parent )
{
   super( parent );

   this.mouseMode = lineMode;    //


   this.SetImage = function( image, metadata, zoom )
   {
      this.image = image;
      this.imageRect = new Rect(0, 0, image.width, image.height);
      this.metadata = metadata;
      this.scaledImage = null;
      this.SetZoomOutLimit();
      if (zoom === undefined) zoom = -100;
      this.UpdateZoom( zoom );
   };

   this.UpdateZoom = function( newZoom, refPoint )
   {
      newZoom = Math.max( this.zoomOutLimit, Math.min( 4, newZoom ) );
      if ( newZoom == this.zoom && this.scaledImage )
         return;

      if ( refPoint == null )
         refPoint = new Point( this.scrollbox.viewport.width/2, this.scrollbox.viewport.height/2 );

      let imgx = null;
      if ( this.scrollbox.maxHorizontalScrollPosition > 0 )
         imgx = (refPoint.x + this.scrollbox.horizontalScrollPosition)/this.scale;

      let imgy = null;
      if ( this.scrollbox.maxVerticalScrollPosition > 0 )
         imgy = (refPoint.y + this.scrollbox.verticalScrollPosition)/this.scale;

      this.zoom = newZoom;
      this.scaledImage = null;
      // V8: gc(true) removed -- deprecated, V8 handles GC automatically

      if ( this.zoom > 0 )
      {
         this.scale = this.zoom;
         this.zoomVal_Label.text = format( "%d:1", this.zoom );
      }
      else
      {
         this.scale = 1/(-this.zoom + 2);
         this.zoomVal_Label.text = format( "1:%d", -this.zoom + 2 );
      }

      if ( this.image )
         this.scaledImage = this.image.scaled( this.scale );
      else
         this.scaledImage = {
            width: this.metadata.width * this.scale,
            height: this.metadata.height * this.scale
         };

      this.scrollbox.maxHorizontalScrollPosition = Math.max( 0, this.scaledImage.width - this.scrollbox.viewport.width );
      this.scrollbox.maxVerticalScrollPosition = Math.max( 0, this.scaledImage.height - this.scrollbox.viewport.height );

      if ( this.scrollbox.maxHorizontalScrollPosition > 0 && imgx != null )
         this.scrollbox.horizontalScrollPosition = imgx*this.scale - refPoint.x;
      if ( this.scrollbox.maxVerticalScrollPosition > 0 && imgy != null )
         this.scrollbox.verticalScrollPosition = imgy*this.scale - refPoint.y;

      this.scrollbox.viewport.update();
   };

   this.zoomIn_Button = new ToolButton( this );
   this.zoomIn_Button.icon = this.scaledResource( ":/icons/zoom-in.png" );
   this.zoomIn_Button.setScaledFixedSize( 24, 24 );
   this.zoomIn_Button.toolTip = "Zoom In";
   this.zoomIn_Button.onMousePress = function()
   {
      this.parent.parent.UpdateZoom( this.parent.parent.zoom + 1 );
   };

   this.zoomOut_Button = new ToolButton( this );
   this.zoomOut_Button.icon = this.scaledResource( ":/icons/zoom-out.png" );
   this.zoomOut_Button.setScaledFixedSize( 24, 24 );
   this.zoomOut_Button.toolTip = "Zoom Out";
   this.zoomOut_Button.onMousePress = function()
   {
      this.parent.parent.UpdateZoom( this.parent.parent.zoom - 1 );
   };

   this.zoom11_Button = new ToolButton( this );
   this.zoom11_Button.icon = this.scaledResource( ":/icons/zoom-1-1.png" );
   this.zoom11_Button.setScaledFixedSize( 24, 24 );
   this.zoom11_Button.toolTip = "Zoom 1:1";
   this.zoom11_Button.onMousePress = function()
   {
      this.parent.parent.UpdateZoom( 1 );
   };

   this.buttons_Box   = new Frame(this);
   this.buttons_Box.backgroundColor = 0xff0078d7;
      this.buttons_Box.sizer = new HorizontalSizer;
      this.buttons_Box.sizer.margin = 4;
      this.buttons_Box.sizer.spacing = 4;
      this.buttons_Box.sizer.add( this.zoomIn_Button );
      this.buttons_Box.sizer.add( this.zoomOut_Button );
      this.buttons_Box.sizer.add( this.zoom11_Button );

   this.setScaledMinSize( 600, 400 );
   this.zoom = 1;
   this.scale = 1;
   this.zoomOutLimit = -5;
   this.scrollbox = new ScrollBox( this );
   this.scrollbox.autoScroll = true;
   this.scrollbox.tracking = true;
   //this.scrollbox.cursor = new Cursor( StdCursor.UpArrow );
   this.scrollbox.cursor = new Cursor( StdCursor.Arrow );


   this.scroll_Sizer = new HorizontalSizer;
   this.scroll_Sizer.add( this.scrollbox );

   this.SetZoomOutLimit = function()
   {
      let scaleX = Math.ceil( this.metadata.width / this.scrollbox.viewport.width );
      let scaleY = Math.ceil( this.metadata.height / this.scrollbox.viewport.height );
      let scale = Math.max( scaleX, scaleY );
      this.zoomOutLimit = -scale + 2;
   };

   this.scrollbox.onHorizontalScrollPosUpdated = function( newPos )
   {
      this.viewport.update();
   };

   this.scrollbox.onVerticalScrollPosUpdated = function( newPos )
   {
      this.viewport.update();
   };

   this.forceRedraw = function()
   {
      this.scrollbox.viewport.update();
   };

   this.scrollbox.viewport.onMouseWheel = function( x, y, delta, buttonState, modifiers )
   {
      let preview = this.parent.parent;
      preview.UpdateZoom( preview.zoom + ((delta > 0) ? -1 : 1), new Point( x, y ) );
   };

   this.scrollbox.viewport.onMousePress = function( x, y, button, buttonState, modifiers )
   {
      let preview = this.parent.parent;

      if (preview.mouseMode == panMode)
      {
         if ( preview.scrolling || button != MouseButton.Left )
            return;
         preview.scrolling = {
            orgCursor: new Point( x, y ),
            orgScroll: new Point( preview.scrollbox.horizontalScrollPosition, preview.scrollbox.verticalScrollPosition )
         };
      }
      else
      {
         if(preview.onCustomMouseDown)
         {
            var p =  preview.transform(x, y, preview);
            preview.onCustomMouseDown.call(this, p.x, p.y, button, buttonState, modifiers )
         }
      }

      this.cursor = new Cursor( StdCursor.ClosedHand );
   };

   this.transform = function(x, y, preview)
   {
      var scrollbox = preview.scrollbox;
      var ox = 0;
      var oy = 0;
      ox = scrollbox.maxHorizontalScrollPosition>0 ? -scrollbox.horizontalScrollPosition : (scrollbox.viewport.width-preview.scaledImage.width)/2;
      oy = scrollbox.maxVerticalScrollPosition>0 ? -scrollbox.verticalScrollPosition: (scrollbox.viewport.height-preview.scaledImage.height)/2;
      var coordPx = new Point((x - ox) / preview.scale, (y - oy) / preview.scale);
      return new Point(coordPx.x, coordPx.y);
   }


   this.scrollbox.viewport.onMouseMove = function( x, y, buttonState, modifiers )
   {
      let preview = this.parent.parent;
      if ( preview.scrolling )
      {
         preview.scrollbox.horizontalScrollPosition = preview.scrolling.orgScroll.x - (x - preview.scrolling.orgCursor.x);
         preview.scrollbox.verticalScrollPosition = preview.scrolling.orgScroll.y - (y - preview.scrolling.orgCursor.y);
      }

      let ox = (this.parent.maxHorizontalScrollPosition > 0) ?
                  -this.parent.horizontalScrollPosition : (this.width - preview.scaledImage.width)/2;
      let oy = (this.parent.maxVerticalScrollPosition > 0) ?
                  -this.parent.verticalScrollPosition : (this.height - preview.scaledImage.height)/2;
      let coordPx = new Point( (x - ox)/preview.scale, (y - oy)/preview.scale );
      if ( coordPx.x < 0 ||
           coordPx.x > preview.metadata.width ||
           coordPx.y < 0 ||
           coordPx.y > preview.metadata.height ||
           !preview.metadata.projection )
      if (preview.imageRect.includes(coordPx))
      {
         preview.Xval_Label.text = coordPx.x.toFixed(0);// "---";
         preview.Yval_Label.text = coordPx.y.toFixed(0);// "---";
         //preview.RAval_Label.text = "---";
         //preview.Decval_Label.text = "---";

         if(preview.onCustomMouseMove)
         {
            //preview.cursor = new Cursor(StdCursor.NoCursor);
            var p =  preview.transform(x, y, preview);
            //  Console.writeln('Call onCustomMouseMove  ' + p.x + '  ' +p.y + '      ' +buttonState);
            preview.onCustomMouseMove.call(this, p.x, p.y, buttonState, modifiers );
         }
      }
      else
      {
         try
         {
            if(preview.onCustomMouseMove)
            {
               var p =  preview.transform(x, y, preview);
               preview.onCustomMouseMove.call(this, -1, -1, MouseButton.Unknown, KeyModifier.Control );
            }
            preview.Xval_Label.text = format( "%8.2f", coordPx.x );
            preview.Yval_Label.text = format( "%8.2f", coordPx.y );
            /*
            let coordRD = preview.metadata.Convert_I_RD( coordPx );
            if ( coordRD.x < 0 )
               coordRD.x += 360;
            preview.RAval_Label.text = DMSangle.FromAngle( coordRD.x*24/360 ).ToString( true );
            preview.Decval_Label.text = DMSangle.FromAngle( coordRD.y ).ToString( false );
            */
         }
         catch ( ex )
         {
            preview.Xval_Label.text = "---";
            preview.Yval_Label.text = "---";
            //preview.RAval_Label.text = "---";
            //preview.Decval_Label.text = "---";
         }
      }
   };

   this.scrollbox.viewport.onMouseRelease = function( x, y, button, buttonState, modifiers )
   {
      let preview = this.parent.parent;
      if ( preview.scrolling && button == MouseButton.Left )
      {
         preview.scrollbox.horizontalScrollPosition = preview.scrolling.orgScroll.x - (x - preview.scrolling.orgCursor.x);
         preview.scrollbox.verticalScrollPosition = preview.scrolling.orgScroll.y - (y - preview.scrolling.orgCursor.y);
         preview.scrolling = null;
         if (preview.mouseMode == lineMode || preview.mouseMode == starMode)
            this.cursor = new Cursor( StdCursor.Arrow  );
         else
            this.cursor = new Cursor( StdCursor.UpArrow );
      }
      else
      {
         this.cursor = new Cursor( StdCursor.Arrow  );
      }

      if ( preview.onCustomMouseRelease )
      {
         var p =  preview.transform(x, y, preview);
         preview.onCustomMouseRelease.call(this, p.x, p.y, buttonState, modifiers );
      }
   };

   this.scrollbox.viewport.onResize = function( wNew, hNew, wOld, hOld )
   {
      let preview = this.parent.parent;
      if ( preview.metadata && preview.scaledImage )
      {
         this.parent.maxHorizontalScrollPosition = Math.max( 0, preview.scaledImage.width - wNew );
         this.parent.maxVerticalScrollPosition = Math.max( 0, preview.scaledImage.height - hNew );
         preview.SetZoomOutLimit();
         preview.UpdateZoom( preview.zoom );
      }
      this.update();
   };

   this.scrollbox.viewport.onPaint = function( x0, y0, x1, y1 )
   {
      let preview = this.parent.parent;
      let graphics = new Graphics( this );

      graphics.fillRect( x0, y0, x1, y1, new Brush( 0xff202020 ) );

      let offsetX = (this.parent.maxHorizontalScrollPosition > 0) ?
            -this.parent.horizontalScrollPosition : ( this.width - preview.scaledImage.width ) / 2;
      let offsetY = (this.parent.maxVerticalScrollPosition > 0) ?
            -this.parent.verticalScrollPosition : ( this.height - preview.scaledImage.height ) / 2;
      graphics.translateTransformation( offsetX, offsetY );


      preview.offsetX = offsetX;
      preview.offsetY = offsetY;

      if ( preview.image )
         graphics.drawBitmap( 0, 0, preview.scaledImage );
      else
         graphics.fillRect( 0, 0, preview.scaledImage.width, preview.scaledImage.height, new Brush( 0xff000000 ) );

      graphics.pen = new Pen( 0x80ffffff, 0 );
      graphics.drawRect( -1, -1, preview.scaledImage.width + 1, preview.scaledImage.height + 1 );

      if ( preview.onCustomPaint )
      {
         graphics.scaleTransformation( preview.scale, preview.scale );
         preview.onCustomPaint.call( preview.onCustomPaint,
            graphics, 0, 0, preview.scaledImage.width, preview.scaledImage.height );
      }

      graphics.end();
   };

   this.offsetX = 0;
   this.offsetY = 0;

   this.getOffset = function()
   {
      return new Point(this.offsetX, this.offsetY);
   }

   this.zoomLabel_Label = new Label( this );
   this.zoomLabel_Label.text = "Zoom:";
   this.zoomVal_Label = new Label( this );
   this.zoomVal_Label.text = "1:1";

   this.Xlabel_Label = new Label( this );
   this.Xlabel_Label.text = "X:";
   this.Xval_Label = new Label( this );
   this.Xval_Label.text = "---";

   this.Ylabel_Label = new Label( this );
   this.Ylabel_Label.text = "Y:";
   this.Yval_Label = new Label( this );
   this.Yval_Label.text = "---";
/*
   this.RAlabel_Label = new Label( this );
   this.RAlabel_Label.text = "\u03B1:";
   this. = new Label( this );
   this.RAval_Label.text = "---";
   this.RAlabel_Label.visible = true;
   this.RAval_Label.visible = true;

   this.Declabel_Label = new Label( this );
   this.Declabel_Label.text = "\u03B4:";
   this.Decval_Label = new Label( this );
   this.Decval_Label.text = "---";
   this.Declabel_Label.visible = true;
   this.Decval_Label.visible = true;
  */


   this.Alabel_Label = new Label( this );
   this.Alabel_Label.text = "Angle:";
   this.Aval_Label = new Label( this );
   this.Aval_Label.text = "---";

   this.Dist_Label = new Label( this );
   this.Dist_Label.text = "Dist:";
   this.Distval_Label = new Label( this );
   this.Distval_Label.text = "-----";
   this.Distval_Label.visible = false;

   this.modeSelector = new ComboBox(this);
   this.modeSelector.addItem('Point');
      this.modeSelector.addItem('Star');
      this.modeSelector.addItem('Pan view');

      this.modeSelector.toolTip = 'Choose viewing operations:<p>' +
                '- Point enables point/line selections<p>' +
                '- Star enables star selection and draws the star profile<p>' +
                '- Pan view enable panning large views with the left mouse button';

      this.modeSelector.onItemSelected = function(index)
      {
         let preview = this.parent.parent;
         preview.mouseMode = index;
         preview.onModeChanged.call(preview.onModeChanged, preview.mouseMode);
      }

/*
   var astrometricSolution = null;

   this.setAstrometricSolution = function(astrometry)
   {
      astrometricSolution = astrometry;
   }
*/
   this.coords_Frame = new Frame( this );
   this.coords_Frame.styleSheet = this.scaledStyleSheet(
      "QLabel { font-family: Hack; background: white; }" );
   this.coords_Frame.backgroundColor = 0xffffffff;
   this.coords_Frame.sizer = new HorizontalSizer;
   this.coords_Frame.sizer.margin = 4;
   this.coords_Frame.sizer.spacing = 4;
   this.coords_Frame.sizer.add( this.zoomLabel_Label );
   this.coords_Frame.sizer.add( this.zoomVal_Label );
   this.coords_Frame.sizer.addSpacing( 20 );
   this.coords_Frame.sizer.add( this.Xlabel_Label );
   this.coords_Frame.sizer.add( this.Xval_Label );
   this.coords_Frame.sizer.addSpacing( 20 );
   this.coords_Frame.sizer.add( this.Ylabel_Label );
   this.coords_Frame.sizer.add( this.Yval_Label );
   this.coords_Frame.sizer.addStretch();//.addSpacing( 20 );
/*   this.coords_Frame.sizer.add( this.RAlabel_Label );
   this.coords_Frame.sizer.add( this.RAval_Label );
   this.coords_Frame.sizer.addSpacing( 20 );
   this.coords_Frame.sizer.add( this.Declabel_Label );
   this.coords_Frame.sizer.add( this.Decval_Label );*/
   this.coords_Frame.sizer.add(this.Alabel_Label);
   this.coords_Frame.sizer.add(this.Aval_Label);
   this.coords_Frame.sizer.addSpacing( 10 );
   this.coords_Frame.sizer.add(this.Dist_Label);
   this.coords_Frame.sizer.add(this.Distval_Label);
   //this.coords_Frame.sizer.add( this.ScrollMode );
   //this.coords_Frame.sizer.addStretch();
   this.coords_Frame.sizer.addSpacing( 20 );
   this.coords_Frame.sizer.add( this.modeSelector );


   this.sizer = new VerticalSizer;
   this.sizer.add( this.buttons_Box);// this.buttons_Sizer );
   this.sizer.add( this.scroll_Sizer );
   this.sizer.add( this.coords_Frame );
}

} // class PreviewControl


class infoDialog extends Dialog
{
constructor(cv)
{
   super();
   this.userResizable = true;
   this.title = 'Star information';

   var dialog = this;

   var s = [];
   if (cv.mouseMode == starMode)
   {
      var c = 10;
      s.push('PSF parameters');
      s.push(pad('Channel', '.', c) +    pstr(cv, 'channel'));
      s.push(pad('Function', '.', c) +   pstr(cv, 'name'));
      s.push(pad('B', '.', c) +          pstr(cv, 'B'));
      s.push(pad('A', '.', c) +          pstr(cv, 'A'));
      s.push(pad('cx', '.', c) +         pstr(cv, 'cx'));
      s.push(pad('cy', '.', c) +         pstr(cv, 'cy'));
      s.push(pad('sx', '.', c) +         pstr(cv, 'sx'));
      s.push(pad('sy', '.', c) +         pstr(cv, 'sy'));
      s.push(pad('FWHMx', '.', c) +      pstr(cv, 'FWHMx'));
      s.push(pad('FWHMy', '.', c) +      pstr(cv, 'FWHMy'));
      s.push(pad('r', '.', c) +          pstr(cv, 'r'));
      s.push(pad('theta', '.', c) +      pstr(cv, 'theta'));
      s.push(pad('beta', '.', c) +       pstr(cv, 'beta'));
      s.push(pad('MAD', '.', c) +        pstr(cv, 'mad'));

      if (cv.imageData.solved())
      {
         s.push('');
         s.push(pad('Scale X', '.', c) + padR(cv.imageData.imageScale()[0].toFixed(3) + '"', ' ', 11));
         s.push(pad('Scale Y', '.', c) + padR(cv.imageData.imageScale()[1].toFixed(3) + '"', ' ', 11));
         var rd = cv.imageData.RD(cv.meanCentroid);
         s.push(pad('Ra', '.', c) +     ' ' + DMSangle.FromAngle( rd.x/15 ).ToString().replace('+', ' ') +
                     '\t' + '(' + rd.x.toFixed(7) + ')');
         s.push(pad('Dec', '.', c) +    ' ' + DMSangle.FromAngle( rd.y ).ToString() + '\t' + '(' +
                     rd.y.toFixed(7) + ')');
      }
   }
   else
   {
      s.push('Select star mode and click a star');
   }

   var b = new Bitmap(100, 100);

   this.tbx = new TextBox(this);
   this.tbx.font = new Font('Consolas', 10);
   this.tbx.readOnly = true;
   this.tbx.text = s.join('\n');
   var g = new Graphics(b);
   g.font = this.tbx.font;
   var textBoxLen = 80;
   var r = null;
   for (var i = 0; i < s.length; i++)
   {
      r = g.textRect( 0, 0, 1000, 100, s[i]);
      textBoxLen = Math.max(textBoxLen, r.x1);
   }
   this.tbx.setScaledMinWidth(textBoxLen + 35);
   this.tbx.setScaledMinHeight(r.height * (s.length + 1));

   this.btn = new PushButton(this);
   this.btn.icon = this.scaledResource(':/toolbar/file-exit.png');
   this.btn.text = 'Exit';
   this.btn.onClick = function(checked) { dialog.done(0); };

   this.bottomFrame = new Frame(this);
   this.bottomFrame.sizer = new HorizontalSizer();
       this.bottomFrame.sizer.margin = 12;
            this.bottomFrame.sizer.addStretch();
            this.bottomFrame.sizer.add(this.btn);

   this.sizer = new VerticalSizer();
   this.sizer.add(this.tbx);
   this.sizer.add(this.bottomFrame);

   this.adjustToContents();

   function pad(s, padChar, length)
   {
      var x = s;
      while (x.length < length) x += padChar;
      return x;
   }

   function padR(s, padChar, length)
   {
      var x = s;
      while (x.length < length) x = padChar + x;
      return x;
   }

   function pstr(cv, parameter)
   {
      var s = [];
      for (var i = 0; i < cv.starPSF.channelCount(); i++)
      {
         var profile = cv.starPSF.profileOfChannel(i);
         var v = profile[parameter];
         switch (parameter)
         {
            case 'name':
               s.push(padR(v, ' ', 11));
               break;
            case 'A':
            case 'B':
               s.push(padR(v.toFixed(6), ' ', 11));
               break;
            case 'cx':
            case 'cy':
            case 'sx':
            case 'sy':
            case 'theta':
            case 'beta':
               s.push(padR(v.toFixed(2), ' ', 11));
               break;
            case 'FWHMx':
               s.push(padR(v.toFixed(2) + 'px', ' ', 11));
               break;
            case 'FWHMy':
               s.push(padR(v.toFixed(2) + 'px', ' ', 11));
               break;
            case 'r':
               s.push(padR(v.toFixed(3), ' ', 11));
               break;
            case 'mad':
               s.push(padR(v.toExponential(3), ' ', 11));
               break;
            case 'channel':
               s.push(padR(v.toString(), ' ', 11));
               break;
         }
      }
      return s.join('  ');
   }
}

} // class infoDialog

//////////////////////////////////////////////////////////////////////////////

function angularSeparation(ra1, de1, ra2, de2)
{
   // degrees to radiant
   var a1 = ra1 * Math.RAD;
   var a2 = ra2 * Math.RAD;
   var d1 = de1 * Math.RAD;
   var d2 = de2 * Math.RAD;
   var z  = Math.acos(Math.sin(d1) * Math.sin(d2) + Math.cos(d1) * Math.cos(d2) * Math.cos(a1 - a2));
   var d  = Math.abs(z) * Math.DEG;
   return d % 360.0;
}

function fitsKey(name, keywords)
{
   for (var i = 0; i < keywords.length; i++)
   {
      var fk = new FITSKeyword(keywords[i]);
      if (fk.name == name) return fk.value;
   }
   return null;
}
/*
 * DMSangle: Helper class to simplify the use of angles in DMS format.
 *
 * Source: WCS metadata class
 */
function DMSangle()
{
   this.deg = 0;
   this.min = 0;
   this.sec = 0;
   this.sign = 1;

   this.GetValue = function()
   {
      return this.sign*(this.deg + (this.min + this.sec/60)/60);
   };

   this.ToString = function( hours )
   {
      let plus = hours ? "" : "+";
      if ( this.deg != null && this.min != null && this.sec != null && this.sign != null )
         return ((this.sign < 0) ? "-": plus) +
               format( "%02d %02d %0*.*f", this.deg, this.min, hours ? 6 : 5, hours ? 3 : 2, this.sec );
      return "<* invalid *>";
   };
}

DMSangle.FromString = function( coordStr, mindeg, maxdeg )
{
   let match = coordStr.match( "'?([+-]?)([0-9]*)[ :]([0-9]*)[ :]([0-9]*(.[0-9]*)?)'?" );
   if ( match == null )
      return null;
   let coord = new DMSangle();
   if ( match.length < 4 )
      throw new Error( "Invalid coordinates" );
   coord.deg = parseInt( match[2], 10 );
   if ( coord.deg < mindeg || coord.deg > maxdeg )
      throw new Error( "Invalid coordinates" );
   coord.min = parseInt( match[3], 10 );
   if ( coord.min < 0 || coord.min >= 60 )
      throw new Error( "Invalid coordinates (minutes)" );
   coord.sec = parseFloat( match[4] );
   if ( coord.sec < 0 || coord.sec >= 60 )
      throw new Error( "Invalid coordinates (seconds)" );
   coord.sign = (match[1] == '-') ? -1 : 1;
   return coord;
}

DMSangle.FromAngle = function( angle )
{
   let coord = new DMSangle();
   if ( angle < 0 )
   {
      coord.sign = -1;
      angle = -angle;
   }
   coord.deg = Math.trunc( angle );
   coord.min = Math.trunc( (angle - coord.deg)*60 );
   coord.sec = (angle - coord.deg - coord.min/60)*3600;

   if ( coord.sec > 59.999 )
   {
      coord.sec = 0;
      coord.min++;
      if ( coord.min == 60 )
      {
         coord.min = 0;
         coord.deg++;
      }
   }

   return coord;
}

/*
function primaryScreenDimensions(dialog)
{
   //
   // get MainWindow\Geometry width & height
   //
   var roamingDir = File.homeDirectory + '/AppData/Roaming/Pleiades';
   var ini = roamingDir + '/PixInsight.ini';
   var x = 0;
   var y = 0;
   var w = 0;
   var h = 0;

   if (File.exists(ini))
   {
      var iniStrings = File.readLines(ini);
      for (var i = 0; i < iniStrings.length; i++)
      {
         var s = iniStrings[i];
         var j = s.indexOf('=');
         if (s.startsWith('MainWindow\\Geometry\\Top') && y == 0)
            y = s.substr(j + 1).toInt();
         if (s.startsWith('MainWindow\\Geometry\\Left') && x == 0)
            x = s.substr(j + 1).toInt();
         if (s.startsWith('MainWindow\\Geometry\\Width') && w == 0)
            w = s.substr(j + 1).toInt();
         if (s.startsWith('MainWindow\\Geometry\\Height') && h == 0)
            h = s.substr(j + 1).toInt();
         if (x > 0 && y > 0 &&  w > 0 && h > 0) break;
      }

   }

   var formsScaling = dialog.displayPixelRatio ;
      //return new Rect(x, y, x + w, y + h);
      return new Rect(0, 0, w * formsScaling, h * formsScaling);
}
*/

function removeViews()
{
   var windows = ImageWindow.windows;
   for (var i in windows)
   {
      var prop = windows[i].mainView.propertyValue('delete');
      if (prop == true)
      {
         windows[i].forceClose();
      }
   }
}

/* ****************************************************************************

   Main script entry point

 * ****************************************************************************
 */
function main()
{
   //
   //
   // Get access to the current active image window.
   //
   Console.abortEnabled = true;
   //Console.hide();
   removeViews();
   var windows = ImageWindow.windows;
   if (windows.length > 0)
   {
      var dialog = new showDialog();
      dialog.execute();
   }
   else
   {
       new MessageBox("Please open an image and restart 2DPlot again", "No image",
                  StdIcon.Information, StdButton.Ok).execute();
   }
}

main();
