#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Hartmut V. Bornemann.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; replaced all
// .prototype. enum references with direct class access.
// No dialogs, with() statements, or #includes were present.
// ----------------------------------------------------------------------------

/*

DeLinear.js: Transform linear image to a non-linear form
================================================================================

Die Transformation vom linearen auf das gestreckte Bild ist mit wenigen
Handgriffen über die ScreenTransferFunction und einer nachfolgenden
HistogramTransformation zu machen. Das Script erledigt das in einem Vorgang.

A simple script to transform the active linear image into a non-linear form.
This script makes the following steps:

    * STF with separate channels
    * STF appliance to the HistogramTransformation process
    * STF disable
    * Histogram appliance to the view

================================================================================
 *
 * Copyright (C) 2016, Hartmut V. Bornemann
 *
 * 28.01.2020 changed to version 2.0.2, skip initial STF, if stf applied before
 * 24.11.2017 changed to version 2.0.0
 * function ApplyAutoSTF taken from the AutoSTF script
 */

#feature-id    MoP V8 > DeLinear
#define VERSION "2.0.2"

#feature-info  A script that transforms a linear image into a non-linear (streched) form.<br/>\
   Copyright (C) 2016, Hartmut V. Bornemann


// Shadows clipping point in (normalized) MAD units from the median.
#define DEFAULT_AUTOSTRETCH_SCLIP  -2.80
// Target mean background in the [0,1] range.
#define DEFAULT_AUTOSTRETCH_TBGND   0.25

#define test 0

function main()
{
   // access current active image window.
   //
   var window = ImageWindow.activeWindow;
   if ( window.isNull )
      throw new Error( "No active image" );

   Console.writeln( "<end><cbr><br><b>De-linearize " + window.currentView.fullId + "</b>" );
   Console.flush();

   var currentView = ImageWindow.activeWindow.currentView;


   var stfApplied = true;

   for (var i = 0; i < currentView.stf.length; i++)
   {
      stfApplied = stfApplied && currentView.stf[i].toString() == currentView.stf[0].toString();
   }
   stfApplied = !stfApplied;

   Console.writeln('STF applied on image: ' +  stfApplied);

   if (!stfApplied)
   {
      Console.writeln('ApplyAutoSTF');

      ApplyAutoSTF( currentView,
                 DEFAULT_AUTOSTRETCH_SCLIP,
                 DEFAULT_AUTOSTRETCH_TBGND,
                 true );
   }
   else
   {
      if (test) printArray("ScreenTransferFunction tempView:", currentView.stf);
   }

	var c0 = currentView.stf[0][1];
	var m  = currentView.stf[0][0];

   if (test) printArray("HistogramTransformation input matrix:", H);

	var HT = new HistogramTransformation;

   HT.H =  [[  0, 0.5, 1.0, 0, 1.0],
            [  0, 0.5, 1.0, 0, 1.0],
            [  0, 0.5, 1.0, 0, 1.0],
            [ c0,   m, 1.0, 0, 1.0],
            [  0, 0.5, 1.0, 0, 1.0]];

   currentView.beginProcess();
   HT.executeOn(currentView.image);
   currentView.endProcess();

   Console.writeln( "De-Linearize end" );

   if (test)
   {
      printArray("HistogramTransformation output matrix:", HT.H);
   }
   //
   Console.writeln('ApplyAutoSTF');

   ApplyAutoSTF( currentView,
              DEFAULT_AUTOSTRETCH_SCLIP,
              DEFAULT_AUTOSTRETCH_TBGND,
              true );
}


// Helper functions

function getNewName(name, suffix)
{
   var newName = name + suffix;
   let n = 1;
   while (!ImageWindow.windowById(newName).isNull)
   {
      ++n;
      newName = name + suffix + n;
   }
   return newName;
}

function copyView( view, newName)
{
   var P = new PixelMath;
   P.expression = "$T";
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.symbols = "";
   P.generateOutput = true;
   P.singleThreaded = false;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = true;
   P.showNewImage = true;
   P.newImageId = newName;
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.SameAsTarget;
   P.newImageSampleFormat = PixelMath.SameAsTarget;
   if (P.executeOn(view))
      return View.viewById(newName);
   {
      message("Mask creation failed in function copyView", "Error");
      return null;
   }
}

function printArray(comment, a)
{
	if (test)
	{
      Console.writeln(comment);
		for (var i = 0; i < a.length; i++)
		{
			var b = a[i];
			Console.write("[" + i + "]  ");
			for (var j = 0; j < b.length; j++)
			{
				Console.write(format("  %.6f", b[j]));
			}
			Console.writeln();
		}
	}
}

/*
 * STF Auto Stretch routine
 */
function ApplyAutoSTF( view, shadowsClipping, targetBackground, rgbLinked )
{
   var P = new ScreenTransferFunction( );

   var n = view.image.isColor ? 3 : 1;

   var median = view.computeOrFetchProperty( "Median" );

   var mad = view.computeOrFetchProperty( "MAD" );
   mad.mul( 1.4826 ); // coherent with a normal distribution

   if ( rgbLinked )
   {
      /*
       * Try to find how many channels look as channels of an inverted image.
       * We know a channel has been inverted because the main histogram peak is
       * located over the right-hand half of the histogram. Seems simplistic
       * but this is consistent with astronomical images.
       */
      var invertedChannels = 0;
      for ( var c = 0; c < n; ++c )
         if ( median.at( c ) > 0.5 )
            ++invertedChannels;

      if ( invertedChannels < n )
      {
         /*
          * Noninverted image
          */
         var c0 = 0, m = 0;
         for ( var c = 0; c < n; ++c )
         {
            if ( 1 + mad.at( c ) != 1 )
               c0 += median.at( c ) + shadowsClipping * mad.at( c );
            m  += median.at( c );
         }
         c0 = Math.range( c0/n, 0.0, 1.0 );
         m = Math.mtf( targetBackground, m/n - c0 );

         P.STF = [ // c0, c1, m, r0, r1
                     [c0, 1, m, 0, 1],
                     [c0, 1, m, 0, 1],
                     [c0, 1, m, 0, 1],
                     [0, 1, 0.5, 0, 1] ];
         Console.writeln('Noninverted image');
      }
      else
      {
         /*
          * Inverted image
          */
         var c1 = 0, m = 0;
         for ( var c = 0; c < n; ++c )
         {
            m  += median.at( c );
            if ( 1 + mad.at( c ) != 1 )
               c1 += median.at( c ) - shadowsClipping * mad.at( c );
            else
               c1 += 1;
         }
         c1 = Math.range( c1/n, 0.0, 1.0 );
         m = Math.mtf( c1 - m/n, targetBackground );

         P.STF = [ // c0, c1, m, r0, r1
                     [0, c1, m, 0, 1],
                     [0, c1, m, 0, 1],
                     [0, c1, m, 0, 1],
                     [0, 1, 0.5, 0, 1] ];
         Console.writeln('Inverted image');
      }
   }
   else
   {
      Console.writeln('Unlinked RGB channnels');
      /*
       * Unlinked RGB channnels: Compute automatic stretch functions for
       * individual RGB channels separately.
       */
      var A = [ // c0, c1, m, r0, r1
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1] ];

      for ( var c = 0; c < n; ++c )
      {
         if ( median.at( c ) < 0.5 )
         {
            /*
             * Noninverted channel
             */
            var c0 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) + shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 0.0;
            var m  = Math.mtf( targetBackground, median.at( c ) - c0 );
            A[c] = [c0, 1, m, 0, 1];
         }
         else
         {
            /*
             * Inverted channel
             */
            var c1 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) - shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 1.0;
            var m  = Math.mtf( c1 - median.at( c ), targetBackground );
            A[c] = [0, c1, m, 0, 1];
         }
      }

      P.STF = A;
   }

   P.executeOn( view );
}


main();
