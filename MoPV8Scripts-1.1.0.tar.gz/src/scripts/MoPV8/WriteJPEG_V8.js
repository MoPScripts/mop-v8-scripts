#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Hartmut V. Bornemann.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; replaced all
// .prototype. enum references with direct class access.
// No dialogs, with() statements, or #includes were present.
// ----------------------------------------------------------------------------

/*

WriteJpeg.js: Write linear image as Jpeg-file
================================================================================

Bilder können grundsätzlich mit PixInsight Tools ausgegeben werden, in dem die
ScreenTransferFunction des aktiven Bildes auf eine HistogramTransformation
übertragen wird (Drag/Drop Process Icon). Danach wird das Histogramm in gleicher
Weise auf das Bild angewandt. Das nichtlineare Bild wird mit File/Save und
jpg-Format ausgegeben, wobei noch Einfluß auf die Qualität möglich ist.
WriteJPEG schließt diese Schritte ein und verzichtet durch Festlegung auf 100%
auch auf die Qualitätsabfrage und sonstige Hinweise. Es umgeht also auf die
Behandlung der sonst erforderlichen Bedingungen.
 
A routine to write a JPEG file from linear image without constraint.
================================================================================
 *
 * Parameters: the active image window, STF controlled
 *
 * On sucess, this routine creates a new JPEG image file at the specified path.
 * On error, an Error exception is thrown. Detailed information is written to
 * the console.
 * The output path is saved in a Settings object for subsequent use
 *    key == TITLE
 *
 * Original routine code: Hartmut V. Bornemann
 *
 * Changelog:
 * 1.3.0: STF copy from source image
 * 1.2.0: Settings added to remember last used output directory
 * 1.1.0: First release
 *
*/

#feature-id    MoP V8 > WriteJPEG
#feature-info  "<p>A routine to write a JPEG image without constraint.</p>"

#define TITLE  "WriteJPEG"
#define VERSION "1.3.0"


function WriteJPEG()
{
/* ----------------------------------------------------------------------------
   Extensions to the String object
   ----------------------------------------------------------------------------
   Returns true if this string ends with the specified substring.
*/
   if ( !String.prototype.endsWith )
   String.prototype.endsWith = function( s )
   {
      var pos = this.lastIndexOf( s );
      return pos >= 0 && pos == this.length - s.length;
   };

// end extension

   var jpeg_filename = ImageWindow.activeWindow.currentView.id;

   var currentPath = File.extractDirectory( ImageWindow.activeWindow.filePath);

   try
   {
      var temp;
      temp = Settings.read (TITLE , DataType.String);
      if (Settings.lastReadOK) {currentPath = temp;}
   }
   catch (x)
   {
      Console.writeln( x );
   }

   var sfdlg = new SaveFileDialog;
   sfdlg.caption = "Save " + jpeg_filename + " as JPEG";

   sfdlg.initialPath = currentPath;

   if ( !( sfdlg.initialPath.endsWith( '/' )))
      {
         sfdlg.initialPath += '/';
      }

   sfdlg.initialPath += jpeg_filename + ".jpg";

   sfdlg.selectedFileExtension = ".jpg";
   sfdlg.overwritePrompt = true;
   sfdlg.filters = [["JPEG Files", "*.jpg"]];
      if ( sfdlg.execute() )
      {
         jpeg_filename = sfdlg.filePath;
         try
         {
            // obtain the original image
            var img = ImageWindow.activeWindow.currentView.image;
            var id  = ImageWindow.activeWindow.currentView.id;
            var temp_win = new ImageWindow(img.width,
                                           img.height,
                                           img.numberOfChannels,
                                           img.bitsPerSample,
                                           img.isReal,
                                           img.isColor);

            var view = temp_win.mainView;
            view.beginProcess( UndoFlag.NoSwapFile );
            view.image.apply(ImageWindow.activeWindow.currentView.image);
            view.endProcess();
            ApplySTF (view, ImageWindow.activeWindow.currentView.stf);

            var fileFormat = new FileFormat( ".jpg", false/*toRead*/, true/*toWrite*/ );

            if ( fileFormat.isNull )
               throw new Error( "No installed file format can write .jpg files." );
            var file = new FileFormatInstance( fileFormat );

            if ( file.isNull )
               throw new Error( "Unable to instantiate file format: " + fileFormat.name );

            if ( !file.create( jpeg_filename, format( "quality %d", 100 ) ) )
               throw new Error( "Error creating file: " + jpeg_filename );

            if ( !file.writeImage( view.image ) )
               throw new Error( "Error writing file: " + jpeg_filename );

            file.close();

            Console.writeln( "<end/><cbr/><br/><b>==> File written: " + jpeg_filename + "</b>" );

            var finf = new FileInfo(jpeg_filename);

            if (!(finf.directory == currentPath))
            {
               Settings.write ( TITLE , DataType.String, finf.directory);
            }

            temp_win.forceClose();
         }
         catch ( x )
         {
            throw x;
         }
         return true;
      }
      return false;
   }

function ApplySTF(view, stf)
{
   PrintMat(stf);
   var low = (stf[0][1] + stf[1][1] + stf[2][1]) / 3;
   var mtf = (stf[0][0] + stf[1][0] + stf[2][0]) / 3;
   var hgh = (stf[0][2] + stf[1][2] + stf[2][2]) / 3;
   Console.writeln("low "+ low);
   Console.writeln("mtf "+ mtf);
   Console.writeln("hgh "+ hgh);
   if (low > 0 || mtf != 0.5 || hgh != 1) // if not an identity transformation
   {
      console.writeln(format("<b>Applying STF to '%ls'</b>:\x1b[38;2;100;100;100m",view.id));
      var HT = new HistogramTransformation;
      HT.H = [
         [  0, 0.5, 1, 0, 1],
         [  0, 0.5, 1, 0, 1],
         [  0, 0.5, 1, 0, 1],
         [low, mtf, hgh, 0, 1],
         [  0, 0.5, 1, 0, 1]
      ];

      HT.executeOn(view, false); // no swap file
      console.write("\x1b[0m");
   }
}

// diagnostic help

function PrintMat(stf)
{
   Console.writeln("STF");
   for (var y = 0; y < stf.length; y++)
   {
      var stfElement = stf[y];
      for (var x = 0; x < stfElement.length; x++)
      {
         Console.write(stfElement[x].toFixed(8) + '\t');
      }
   Console.writeln("");
   }
}

function main()
{
   Console.hide();
   var window = ImageWindow.activeWindow;

   if ( window.isNull )
   {
      Console.show();
      Console.writeln("\n<b>Error:</b> No active image.");
   }
   else
   {
      WriteJPEG();
   }
}; // main()

main();
