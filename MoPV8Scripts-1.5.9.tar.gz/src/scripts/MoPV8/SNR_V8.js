/*

SNR.js: SNR of top view
================================================================================

Das Signal-Rausch-Verhältnis (engl. signal to noise ratio) gibt die Qualität
eines Nutzsignals an, das immer von einem Rauschsignal überlagert ist.
SNR berechnet die Werte für das aktive Bild und gibt das Verhältnis als absolute
Größe und in Dezibel (db = 10 * log10(snr)) an.

SNR measures the power of a signal in relation to the power of noise.
The ratio is a quality indicator. SNR calculates the value für the active image
as an absolute number and also in decibels (db = 10 * log10(snr)),
which is often better readable.
================================================================================

 * Estimation of the signal-to-noise ratio function:
 *
 * SNR(f,g) = E(f^2) / E((f - g)^2)
 *
 * where f is a distribution function, g is a sample, and E(.) is the expected
 * value of the argument. The denominator is the mean square error, which we
 * approximate with the variance of the noise.
 *
 * Source
 *    PCL\src\modules\processes\ImageIntegration\ImageIntegrationInstance.cpp
 */

#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. No original author byline was present in the source file.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; replaced 9
// lowercase Console. calls with Console. (PJSR has no lowercase console
// global, only Console -- the same systemic bug found across most of the
// MoP V8 repo). No #include directives, with() statements, .prototype.
// enum references, or underscore constants were present.
// ----------------------------------------------------------------------------

#feature-id SNR : MoP V8 > SNR


function SNREvaluation ( img )
{
   var E = new NoiseEvaluation( img );
   var snr = img.meanOfSquares(img.selectedRect)/ E.sigma / E.sigma;
   var db = 10 * Math.log10(snr);
   Console.writeln(format("SNR = %.3e, %.2f db ", snr, db));
}

function NoiseEvaluation( img )
{
   var a, n = 4, m = 0.01*img.selectedRect.area;
   for ( ;; )
   {
      a = img.noiseMRS( n );
      if ( a[1] >= m )
         break;
      if ( --n == 1 )
      {
         Console.writeln( "<end><cbr>** Warning: No convergence in MRS noise evaluation routine - using k-sigma noise estimate." );
         a = img.noiseKSigma();
         break;
      }
   }
   this.sigma = a[0]; // estimated stddev of Gaussian noise
   this.count = a[1]; // number of pixels in the noise pixels set
   this.layers = n;   // number of layers used for noise evaluation
}

function main()
{
   // Get access to the current active image window.
   var window = ImageWindow.activeWindow;
   if ( window.isNull )
      throw new Error( "No active image" );

   Console.show();
   Console.writeln( "<end><cbr><br><b>" + window.currentView.fullId + "</b>" );
   Console.writeln( "Calculating SNR" );
   Console.flush();

   Console.abortEnabled = true;

   var img = window.currentView.image;
   for ( var c = 0; c < img.numberOfChannels; ++c )
   {
      Console.writeln( "<end><cbr><br>* Channel #", c );
      Console.flush();
      img.selectedChannel = c;
      SNREvaluation ( img );
      Console.flush();
   }
}

main();

