/*
	EmissionLineIntegration.js: Narrow-band application on RGB images
================================================================================

Schmalband-Filter werden in der Astronomie eingesetzt, um die Intensität von
Emissionsstrahlern zu messen. Da diese Filter einen Durchlassbereich von einigen
Nanometer (nm) haben, addieren sich Fehler, die aus eng benachbarten Quellen
stammen. So ist z.B. Ein H-alpha Filter mit 6 nm Bandbreite noch aufnahmefähig
für die NII Linie, deren Wellenlänge nur einen Abstand von 2 nm hat.
Die Continuum Subtraction (kurz CS) soll hier helfen, die Strahlung aus dem
Continuum herauszufiltern. Das Ergebnis kann dann für die Berechnung der
Intensität eines Objektes genutzt werden. In der Astrofotografie erzeugt
die Addition des Differenzbildes auf einen Breitbandkanal eine merkliche
Verstärkung der Objekte.

Formeln

	NB 	= Schmalband
	BB 	= Breitband
	BB*	= Breitband intensiviert
	mue	= Anteil Continuum im Schmalband

	Ie 	= NB - mue x BB							(1)
	BB*	= BB + Ie									(2)


Narrow-band filters see use in astronomy to measure the intensity of emission
emitters. Since these filters have a range of bandwidth of around a few
nanometers (nm), errors from neighbouring sources will accumulate. For example,
a H-alpha-filter with 6nm bandwidth is receptive to the NII line with a
wavelength distance of 2nm. This is where the continuum subtraction (CS) helps
filter the emission out of the continuum. The resulting data can be used to
calculate the intensity of an object. In astro-photography, the addition of
the difference image onto a broadband channel generates a noticeable
amplification of the objects.

Formula

	NB 	= narrow band
	BB 	= braod band
	BB*	= braod band intensified
	mue	= fraction of continuum found in narrow band

	Ie 	= NB - mue x BB							(1)
	BB*	= BB + Ie									(2)

================================================================================


 Input

 1. Active window, RGB after ChannelCombination

 2. A narrowband at least for one channel

	It is recommended, that a DynamicBackroundExtraction-process has been
	applied to RGB and NB-channel[s] prior to ContinuumSub

 Copyright Hartmut V. Bornemann, 2017, 2018


History

   23.07.20 Release 2.1.0, mask removed in emission application (PixelMath)
   13.06.20 Release 2.0.3, error, graphics object not disposed
   25.09.19 Release 2.0.2, quadratic solver solveQ added
   25.09.19 Release 2.0.1, minor changes
   23.09.19 Release 2.0.0, new layout with better performance
   01.03.19 curve analysis strategy
   12.02.19 curve analysis
   02.02.19 curve analysis error, index limits corrected
	30.10.18 continuumsub reworked, improved mue evaluation
	27.10.18 mask application moved to function continuumsub
	23.10.18 mask and GUI handling improved
	22.10.18 dialog window handling improved
	21.08.18	slope criteria changed to half of maximum (slope <= ms * 0.2)
	12.05.18	temporary views excluded from ViewLists
	27.04.18	Release and introduced on PI-Workshop in Austria (Attersee)
*/

#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Hartmut V. Bornemann.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; removed all
// 17 #include <pjsr/...> directives (PJSR globals available without them);
// converted showDialog (extends Dialog) and ImageView (extends Frame)
// from __base__/.prototype = new X to class extends X / super(); replaced
// 3 .prototype. enum references (PixelMath) with direct class access;
// replaced underscore constants with dot notation (TextAlign_* ->
// TextAlignment.*, FrameStyle_Box -> FrameStyle.Box, StdIcon_Question ->
// StdIcon.Question, StdButton_Cancel/No/Yes -> StdButton.Cancel/No/Yes,
// StdCursor_Arrow/Wait -> StdCursor.Arrow/Wait, DataType_String ->
// DataType.String, UndoFlag_NoSwapFile -> UndoFlag.NoSwapFile);
// VectorGraphics -> Graphics; Image.getPixels() -> Image.getSamples()
// (4 occurrences); removed 2 deprecated bare gc() calls; replaced 3 bare
// processEvents() with CoreApplication.processEvents(); replaced 6
// lowercase console. calls with Console.; added null-safety to 4
// View.viewById() calls immediately following a new-image creation (V8
// can return real null rather than an isNull-object for a name that
// isn't found, per the same rule that bit BatchPostProcessing.js and
// AutoPalette.js earlier in this project).
//
// Expanded all 26 with() blocks by hand, not by automated tooling --
// this file exposed two real bugs in the automated with()-expander used
// on earlier scripts (it was prefixing JS keywords like "if"/"for" as if
// they were method names, and blindly prefixing calls to global
// functions like plotter() as if they belonged to the with() target),
// and confirmed empirically that with() extends its scope into nested
// callback closures (onClick, onCheck, etc.), not just the immediate
// block, persisting even after the block exits. Two spots specifically
// needed "this" rather than the with()-target's own variable name to
// stay correct: radioButton and numContingent are both created in a
// loop and reused (var, function-scoped) across iterations, so a
// deferred callback referencing the loop variable by name would -- once
// actually invoked later by user interaction -- incorrectly resolve to
// whichever object the loop variable held last, not the specific one
// the callback was defined for. "this" inside each control's own event
// handler correctly refers to the specific triggering control instead,
// matching what the original with()-based closure actually captured.
//
// 2026-08-17: fixed a real bug found via user testing -- "TypeError:
// Cannot assign to read only property 'cancel'". showDialog used
// this.cancel as a custom boolean flag ("has the user requested
// cancellation of the current operation"), but Dialog already has a
// built-in cancel() method. V7 apparently tolerated a plain property
// silently shadowing it; V8 protects the built-in and throws instead.
// Renamed the custom flag to cancelRequested throughout (8 occurrences,
// confirmed no genuine dialog.cancel() method calls existed anywhere in
// this file to conflict with the rename). Swept the rest of the MoP V8
// repo for the same pattern -- none found elsewhere.
// ----------------------------------------------------------------------------

#feature-id    EmissionLineIntegration : MoP V8 > EmissionLineIntegration

#define TITLE "Emission Line Integration"
#define VERSION "2.1.0"
// Shadows clipping point in (normalized) MAD units from the median.
#define DEFAULT_AUTOSTRETCH_SCLIP  -2.80
// Target mean background in the [0,1] range.
#define DEFAULT_AUTOSTRETCH_TBGND   0.25
#define DEFAULT_AUTOSTRETCH_CLINK   true

#define Dispose "dispose"
#define tab '\t'
#define test 0
#define TempView "TempView_"
//
// csNRGB manages the channels, mask and mainview modification
//
function csNRGB(mainView, dialog)
{
	Console.writeln("mainView " + mainView.id);
	this.applied 	= false;
	this.copyName	= getNewName(mainView.id, "_copy");
	this.mainCopy	= copyView( mainView, this.copyName);
	this.mainView	= mainView;
	this.modifView	= null;
	this.dialog		= dialog;
	this.maskView	= null;
	this.useMask	= false;
	this.keepMask	= false;
	this.pixCount	= mainView.image.width * mainView.image.height;
	this.doRefresh	= false;
	this.channels	= [null, null, null];
	this.bitmap 	= linearViewToBMP(this.mainView);
   this.rect      = mainView.image.selectedRect;
	setDisposal(this.mainCopy, true);

	this.rgbPixels	= [];
	for (var i = 0; i < 3; i++)
	{
      var a       = [];
      this.mainView.image.getSamples(a, this.rect, i);
      this.rgbPixels.push( new Float32Array(a) );
	}
	var  b  			= new ArrayBuffer(this.pixCount);
	this.maskFlags	= new Int8Array(b);		// mask map with 1
	for (var j = 0; j < this.pixCount; j++) this.maskFlags[j] = 1;

	this.channels	= extractChannels(mainView);
	for (var i in this.channels)
	{
		this.channels[i].window.hide();
		setDisposal(this.channels[i], true);
	}

	this.apply = function()
	{
		var description = "Emission Line Integration";
		description 	+= '\n';
		description 	+= "========================="
		description 	+= '\n';
		description 	+= this.mainView.id;
		description 	+= '\n';
		description 	+= this.channels[0].getHistory();
		description 	+= this.channels[1].getHistory();
		description 	+= this.channels[2].getHistory();
		if (this.useMask)
		{
			description += "Masked with " + this.maskView.id + '\n';
		}
		var P = new PixelMath;
		P.expression = this.modifView.id;
		P.expression1 = "";
		P.expression2 = "";
		P.expression3 = "";
		P.useSingleExpression = true;
		P.symbols = "";
		P.generateOutput = true;
		P.singleThreaded = false;
		P.use64BitWorkingImage = false;
		P.rescale = false;
		P.rescaleLower = 0;
		P.rescaleUpper = 1;
		P.truncate = true;
		P.truncateLower = 0;
		P.truncateUpper = 1;
		P.createNewImage = false;
		P.setDescription(description);
		if (P.executeOn(this.mainView))
		{
			this.applied = true;
			return true;
		}
		else
		{
			return false;
		}
	}

	this.refresh = function()
	{
		if (this.applied)
		{
			var P = new PixelMath;
			P.expression = this.mainCopy.id;
			P.expression1 = "";
			P.expression2 = "";
			P.expression3 = "";
			P.useSingleExpression = true;
			P.symbols = "";
			P.generateOutput = true;
			P.singleThreaded = false;
			P.use64BitWorkingImage = false;
			P.rescale = false;
			P.truncate = false;
			P.createNewImage = false;
			P.executeOn(this.mainView)
		}
		this.applied = false;

		if (this.refreshed && this.doRefresh)
		{
			this.refreshed.call(this, this.dialog);
			this.doRefresh = false;
		}
	}

	this.setMask = function(maskView)
	{
		if (maskView.id != "")
		{
			if (!maskView.image.isGrayscale)
			{
				message(maskView.id + " is not a gray scale image");
				return;
			}
			else
			{
				var c = maskView.image.width * maskView.image.height;
            if (!this.rect.isEqualTo(maskView.image.selectedRect))
				{
					message(maskView.id + " has a different image geometry");
					return;
				}
			}

			var maskPix = new Array(this.pixCount);
			maskView.image.getSamples(maskPix);
			//
			// calculate dark areas, skip bright stars
			//
			var cnt = 0;
			var threshold = maskView.image.mean();
			for (var j = 0; j < this.pixCount; j++)
			{
				if (maskPix[j] > threshold)
				{
					this.maskFlags[j] = 0;		// skip star
					cnt += 1;
				}
				else
				{
					this.maskFlags[j] = 1;		// evaluate object & background
				}
			}
			// evaluate each pixel in this mask
			// set false in each location of MM for pixels
			// falling below a threshold
			//
			Console.writeln("# of pixel rejected " + cnt + ", mask threshold " +
								 threshold.toFixed(6));
			this.maskView   = maskView;
			this.useMask	= true;

         this.channels[0].mustEvaluate = this.channels[0].hasNarrowBand;
         this.channels[1].mustEvaluate = this.channels[1].hasNarrowBand;
         this.channels[2].mustEvaluate = this.channels[2].hasNarrowBand;
		}
		else
		{
			this.useMask	= false;
			for (var j = 0; j < this.pixCount; j++) this.maskFlags[j] = 1;
		}
		//
		// setting/removing mask forces re-evaluation of mue
		//
		for (var i in this.channels)
		{
			this.channels[i].mue = 0.0;
		}
	}
	//
	//
	//
	this.addEmission = function()
	{
		var id = getNewName(this.mainView.id, "_Test");
		this.modifView = copyView(this.mainCopy, id);
		var P = new PixelMath;
		P.expression 	= this.channels[0].expression();
		P.expression1	= this.channels[1].expression();
		P.expression2 	= this.channels[2].expression();
		P.useSingleExpression = false;
		P.symbols = "";
		P.generateOutput = true;
		P.singleThreaded = false;
		P.use64BitWorkingImage = false;
		P.rescale = false;
		P.rescaleLower = 0;
		P.rescaleUpper = 1;
		P.truncate = true;
		P.truncateLower = 0;
		P.truncateUpper = 1;
		P.createNewImage = false;
		var rc = false;
		try
		{
			rc =  P.executeOn( this.modifView );
		}
		catch (e)
		{
			rc = false
		}

		if (rc)
		{
			this.bitmap = linearViewToBMP(this.modifView);
			setDisposal(this.modifView, true);
			return this.modifView;
		}
		else
			return null;
	}

	this.setMaskDisposal = function(keep)
	{
		this.keepMask = keep;
		if (this.maskView != null)
		{
			setDisposal(this.maskView, !keep);
		}
	}


	this.maskShow = function(keep)
	{
		if (this.maskView != null)
		{
			var dispose = this.maskView.propertyValue(Dispose);
			if (!dispose)
			{
				this.maskView.window.show();
			}
		}
	}


	this.graphicalAnalysis = function(mainView)
	{
		// plot curves of modified channel(s)
 		for (var i = 0; i < 3; i++)
		{
			var channel = this.channels[i];
			if (channel.mue == 0) continue;
			if (channel.NRGB.useMask)
				plotter(channel.curves.xyy, channel.mue, channel.narrowBand.id, channel.broadBand.id, channel.emission.id, channel.NRGB.maskView.id);
			else
				plotter(channel.curves.xyy, channel.mue, channel.narrowBand.id, channel.broadBand.id, channel.emission.id, "");
		}
	}
}
//
// csChannel, class with methods and properties for one
// 	broadband/narrowband combination
//
function csChannel(NRGB, channelIndex)
{
	this.NRGB				= NRGB;
	this.channelIndex		= channelIndex;
	this.channelID			= "RGB".charAt(channelIndex);
	this.broadBand 		= this.NRGB.channels[channelIndex];
	this.narrowBand 		= null;
	this.emission 			= null;
	this.mue 				= 0.0;
   this.mustEvaluate    = false;
	this.dialog				= this.NRGB.dialog;
	this.contingent		= 1.0;
	this.medBroadband		= this.broadBand.image.median();
	this.medNarrowband	= 0.0;
	this.hasNarrowBand	= false
	this.nbPixelArray		= null;
	this.bitmap				= null;
   this.curves          = null;

	//
	// change views to csChannel class
	//
	NRGB.channels[channelIndex] = this;
  	//
	//
	//
	this.setNarrowBand = function(narrowBand)
	{
      if (!NRGB.rect.isEqualTo(narrowBand.image.selectedRect))
      {
         message(narrowBand.id + " has a different image geometry");
         return;
      }
		this.narrowBand  = narrowBand;
		this.mue = 0.0;
		if (this.narrowBand.id != "")
		{
			var a       		 = new Array(this.NRGB.pixCount);
			this.narrowBand.image.getSamples(a);
			this.nbPixelArray	 = new Float32Array(a);
			this.medNarrowband = narrowBand.image.median();
			this.hasNarrowBand = true;
         this.mustEvaluate  = true;
		}
		else
		{
			this.hasNarrowBand = false;
         this.mustEvaluate  = false;
		}
		this.NRGB.refresh();
		if (this.emission != null)
		{
			this.emission.window.forceClose();
		}
	}
 	//
	//
	//
	this.setContingent = function(contingent)
	{
		this.contingent = contingent;
	}
   //
   //
   //
   this.canEvaluate = function()
   {
      return this.hasNarrowBand && this.mustEvaluate;
   }
 	//
	//
   //
	this.getEmission = function()
	{
		if (this.canEvaluate())
		{
         this.dialog.cancelRequested = false;
         //
         // make temp copy of the broadband channel for subtraction
         //
         var bbLfit = copyViewChannel(this.NRGB.mainView, this.channelIndex);

         equalizeMean(bbLfit, this.narrowBand);
         //
         // nb and bb pixels to array
         //
         var a          = [];

         bbLfit.image.getSamples(a);
         var bbPixels   = new Float32Array(a);

         this.narrowBand.image.getSamples(a);
         var nbPixels   = new Float32Array(a);
         //
         // broadband data in bbPixels array
         //
         Console.writeln("Narrowdband image...." + this.narrowBand.id);
         Console.writeln("Broadband image......" + bbLfit.id);
         if (this.mask != null)
            Console.writeln("Mask image..........." + this.mask.id);

         if (this.maskFlags == null)
         {
            this.maskFlags = new Int8Array(this.NRGB.pixCount);
            for (var j = 0; j < this.NRGB.pixCount; j++) this.maskFlags[j] = 1;
         }

         // bb and nb should have nearly same mean after LinearFit

         var bbMedian   = bbLfit.image.median();
         var beginWith = Math.min(this.narrowBand.image.median(), bbMedian)
                       / Math.max(this.narrowBand.image.median(), bbMedian) * 0.5;

         var stepSize = 0.00025;

         Console.writeln("Start with mue......." + beginWith);
         Console.writeln("Increment............" + stepSize);
         //
         // evaluate mue
         //
         this.curves = new mueCurves(nbPixels,
                                    bbPixels,
                                    this.maskFlags,
                                    beginWith,
                                    stepSize,
                                    this.dialog.advanceProgress,
                                    this.dialog);
         if (this.dialog.cancelRequested) return false;

         this.mue = this.curves.mue;

         Console.writeln("Curve points " + this.curves.xyy.length);

         Console.writeln("Reduction factor mue: " + this.mue.toFixed(8) +
            " of " + this.NRGB.mainView.id + '[' + this.channelIndex.toString() + ']');

         if (this.mue > 0)
         {
            this.emission = Subtract(this.narrowBand, bbLfit, this.NRGB.mainView,
                                     null/*this.NRGB.maskView*/, this.mue, this.channelIndex);
            this.mustEvaluate = false;
            //
            // set flag in view
            //
            if (!this.emission.setPropertyValue("CS:js", "T" ))
               Console.writeln("View setPropertyValue failed " + this.emission.id);
            //
            // STF
            //
            ApplyAutoSTF ( this.emission, -2.80, 0.25 );
            //
            // add keywords
            //
            var keywords = [];
            keywords.push(new FITSKeyword("EMISSION", "T", "Emission line image"));
            this.emission.beginProcess(UndoFlag.NoSwapFile);
            this.emission.window.keywords = keywords;
            this.emission.endProcess();
         }
         else
         {
            message ("CS processing returned no solution");
         }

         bbLfit.window.forceClose();

         this.bitmap = linearViewToBMP(this.emission);
	   }

      return this.mue > 0;
   }
	//
	//
	//
	this.expression = function()
	{
 		if (this.mue == 0.0)
		{
			return "$T";
		}
		else
		{
			return "$T + " + this.emission.id + " * " + this.contingent;
		}
	}
	//
	// create a history string
	//
	this.getHistory = function()
	{
		var s = "Channel " + this.channelIndex;
		if (this.mue == 0.0)
		{
			s += " no modification" + '\n';
		}
		else
		{
			s += '\n';
			s += "Narrowband " + this.narrowBand.id + '\n';
			s += "Mue " + this.mue;
			s += '\n';
			s += "Contingent " + this.contingent + '\n';
		}
		return s;
	}

	/* ***************************************************************************
	 *
	 * Evaluate the optimal quantity to be subtracted from the narrow band channel
	 *
	 * This quantity is the broad band image x mue
	 *
	 * ***************************************************************************/

   function mueCurves(NB, BB, MM, initialMue, stepSize, callback, dlg)
	{
		//
		// evaluate first derivative of counts over mue
		//
		var minStep = stepSize;
		var stp     = minStep * 4;
		var n       = NB.length;
      var maxC    = n * 0.9;
      var pF      = 1 / n;
		var bp 		= new Int8Array(MM);	// blackpoints
		var ii		= -1;						// loop index
		var stps 	= stp * 12.0;			// slope base

		this.mue 	= initialMue - stp;
		this.xy     = [];						// mue, count pairs
      this.xyy    = [];                // mue, xy, dxy combined

      var lastCnt = -1;

      var cnt    = 0;
      var progr  = 0;


		for (;;)
		{
			ii += 1;							// 0..

         CoreApplication.processEvents();
         if (dlg.cancelRequested)
         {
            Console.writeln("***cancel*** mue = " + this.mue.toFixed(4) +
                            ", black level counts = " + cnt);
            return;
         }

			this.mue += stp;

         var p = Math.floor(cnt * pF * 1000);

         if (p > progr)
         {
            callback( cnt * pF);
            progr = p;
         }
			// -----------------------------------------------------------------------
			// subtract mue-fraction of BB
			// -----------------------------------------------------------------------
         var gt0 = 0;
 			for (var j = 0; j < n; j++)
			{
				if (bp[j])					// if 1, check this position
            {                       //
                                    // count non-masked pixels
                                    //
					if ((NB[j] - BB[j] * this.mue) > 0)
               {
                  gt0 += 1;         // count the non-black ones
                  continue;         // non-black
               }
					bp[j] = 0;				// skip this pixel in next run
				}
			}

         cnt = n - gt0;

			this.xy.push(new Point(this.mue, cnt));

         if (cnt > maxC)
         {
            var t = findTurningPoint(this.xy, n, stps);
            this.mue = t.mue;
            this.xyy = t.xyy;
            return;
         }
		}
      return;     // leave this.xyy empty for no solution
	}

   function findTurningPoint(xy, n, stps)
   {
      //
      // normalize xy array of points
      //
      for (var k = 0; k < xy.length; k++) xy[k] = new Point(xy[k].x, xy[k].y /  n);

      // find 1st maximum in 1st deviation dy / dx

      var im  = -1;   // index of max slope
      var ms  =  0;   // max slope
      var dxy = [];   // combine mue, y and slope in array elements
      var u   = 0
      var k0  = 0;
      var k1  = 0;
      var points = [];
      var mdy = 0;
      var ym  = 0;
      var ps  = 0;   // previous slope

      for (var k = 4; k < xy.length; k++)
      {
			var slope = (xy[k - 4].y - 8 * xy[k - 3].y + 8 * xy[k - 1].y - xy[k].y) / stps;
         dxy.push({x:xy[k].x, y:xy[k].y, slope:slope});

         var dy  = Math.abs(slope - ps);

         if (k > 4 && dy > mdy) mdy = dy;

         ps = slope

         if (slope > ms)
         {
            ms = slope;
            im = u;
            k0 = k;
         }
         u += 1;
      }
      var yk = ms - 2 * mdy;   // y min at max

      // collect points

      for (var k = 0; k < dxy.length; k++)
      {
         if (dxy[k].slope > yk) //[2] > yk)
            points.push(new Point(dxy[k].x, dxy[k].slope));
         else
         {
            if (k > k0) break;
         }
      }

      var coeff = Polynomials(points, 3); // Polynomials(points, 4);

      for (var k in coeff) Console.writeln("Coeff "+k+'\t'+coeff[k]);


      // dy/dx
      // 0 = c + bx + ax^2
      // x = -b +- sqrt(b^2 - 4ac) / 2a

      var X = solveQ(3 * coeff[3], 2 * coeff[2], coeff[1]);

      // Console.writeln("X " + X[0]+'\t'+X[1]);

      // find max in polynom curve

      var max = new Point(0, 0);
      for (var k in points)
      {
         var x = points[k].x;
         var y = poly(coeff, x);
         if (y > max.y) max = new Point(x, y);
      }

      // normalize slope values

      for (var k = 0; k < dxy.length; k++)
         dxy[k] ={x:dxy[k].x, y:dxy[k].y, slope:dxy[k].slope / ms};

      if (im > dxy.length - 7) return {mue:-1, xy:xy, dxy:dxy};

      //var mue = max.x;

      var mue;

      if ((Math.abs(X[0]  - max.x)) < (Math.abs(X[1] - max.x)))
         mue = X[0];
      else
         mue = X[1];


      Console.writeln("solved " + mue);

      // -----------------------------------------------------------------------
      // combine the curves
      // -----------------------------------------------------------------------

      var m0 = 0;
      var i0 = 0;
      for (var i in dxy)
      {
         if (dxy[i].slope > 0.025)
         {
            m0 = dxy[i].x;
            i0 = i;
            break;
         }
      }

      // x where dxy ~0.1 right of mue

      var m1 = mue + (mue - m0);

      var xyy = [];        // collect most interesting points for the graph
      for (var i = i0; i < dxy.length; i++)
      {
         xyy.push(dxy[i]);
      }
      return {mue:mue, xy:xy, dxy:dxy, xyy:xyy};
   }

	function Subtract(nb, bb, rbb, mask, mue, channel)
	{
		var name = '';

      Console.writeln('Subtract '+mue + '\t'+ channel);

		var d = "\nContinuum Subtraction " + VERSION;
		d 	+= '\n';
		d 	+= "===========================";
		d 	+= '\n';
		d 	+= "NB:  " + nb.id;
		d 	+= '\n';
      if (rbb.image.isColor)
      {
         name = getNewName(nb.id, '_' + rbb.id + '_' +
                  new Array('Red', 'Green', 'Blue')[channel]);
		   d 	+= "BB:  " + rbb.id + ', channel: ' + 'RGB'[channel]; // original bb image
      }
      else
      {
         name = getNewName(nb.id, '_' + rbb.id);
         d 	+= "BB:  " + rbb.id;
      }
		d 	+= '\n';
      if (mask != null)
      {
		   d 	+= "Mask:  " + mask.id;
         d 	+= '\n';
      }
      else
   		d 	+= '\n';
		d 	+= "mue: " + mue;
		d 	+= '\n';
		d 	+= "id:  " + name;
		d 	+= '\n';

		var P = new PixelMath;
      if (mask == null)
         P.expression = nb.id + " - " + bb.id + " * " + mue;
      else
         P.expression = '(' + nb.id + " - " + bb.id + " * " + mue + ") * ~" + mask.id;
      P.expression1 = "";
      P.expression2 = "";
      P.expression3 = "";
      P.useSingleExpression = true;
      P.symbols = "";
      P.generateOutput = true;
      P.singleThreaded = false;
      P.use64BitWorkingImage = false;
      P.rescale = false;
      P.truncate = true;
      P.truncateLower = 0;
      P.truncateUpper = 1;
      P.createNewImage = true;
      P.showNewImage = false;
      P.newImageId = name;
      P.newImageWidth = nb.image.width;
      P.newImageHeight = nb.image.height;
      P.newImageAlpha = false;
      P.newImageColorSpace = PixelMath.Gray;
      P.newImageSampleFormat = PixelMath.f32;
      P.setDescription(d);
      P.executeOn(nb);
			var view = View.viewById(name);
       	if (view == null)
       	   throw new Error("Subtract: could not find newly-created view '" + name + "'");
       	return view;
	}


   function equalizeMean(view, targetView)
   {
      var f = targetView.image.mean() / view.image.mean();

      var P = new PixelMath;
      P.expression = "$T * " + f.toString();
      P.expression1 = "";
      P.expression2 = "";
      P.expression3 = "";
      P.useSingleExpression = true;
      P.symbols = "";
      P.generateOutput = true;
      P.singleThreaded = false;
      P.use64BitWorkingImage = false;
      P.rescale = false;
      P.truncate = true;
      P.truncateLower = 0;
      P.truncateUpper = 1;
      P.createNewImage = false;
      P.newImageAlpha = false;
      P.newImageColorSpace = PixelMath.SameAsTarget;
      P.newImageSampleFormat = PixelMath.SameAsTarget;

      P.executeOn(view);
   }
}

/* *****************************************************************************
 * *****************************************************************************
 *		DIALOG
 * *****************************************************************************
 * *****************************************************************************
 *
*/

function eliParms()
{
   this.dialogWindowWidth = 0;
   this.dialogWindowHeight = 0;
   this.amplify_R = 1;
   this.amplify_G = 1;
   this.amplify_B = 1;
   this.version = VERSION;
}

class showDialog extends Dialog
{
constructor(viewRGB)
{
   super();
   this.userResizable = true;

   var RGB = "RGBM"

   var dialog = this;

   var setVal = Settings.read('EmissionLineIntegration', DataType.String);
   var parms  = new eliParms();
   if (setVal != null) parms = JSON.parse(setVal);

   this.cancelRequested = false;

	var nbTested = false;
   var testing  = false;

   // control arrays

   var ctls    				= [null, null, null];
   var c_views 				= [null, null, null];
	this.contingentControls = [null, null, null];
	this.greenLabelControls = [null, null, null];
	this.radioButtons 		= [null, null, null, null];

	//

	this.NRGB = new csNRGB(viewRGB, this);
	this.NRGB.refreshed = function (dialog)
	{
		if (dialog.radioButtons[0].checked)
		{
         dialog.imageview.SetImage(dialog.NRGB.bitmap);
		}
		dialog.applyButton.enabled = false;
	}

	this.csChannels = [null, null, null];

	for (var i = 0; i < 3; i++)
	{
		this.csChannels[i] = new csChannel(this.NRGB, i);
		this.csChannels[i].csSubtracted = function(channel)
		{
			//
			// is this channel selected by radioButton?
			//
			dialog.radioButtons[channel.channelIndex + 1].enabled = true;
			for (var i = 0; i < 3; i++)
			{
				if (dialog.radioButtons[i + 1].checked)
				{
               dialog.imageview.SetImage(channel.bitmap);
				}
			}
		}
	}

   this.progress = 0;

   //

   Console.writeln("Narrowband application on RGB images");
   Console.writeln("====================================");
   Console.writeln("Processing " + viewRGB.id);

	// ------------------------------------------------------------------------
   // main panels left (preview), right (controls)
   // ------------------------------------------------------------------------

   this.panelLeft = new Frame(this);
   this.panelRight = new Frame(this);

   this.panelLeft.backgroundColor  = 0xff000080;
   this.panelLeft.setMinSize(800, 600 );
   this.panelLeft.onResize = function( wNew, hNew, wOld, hOld )
   {
      Console.writeln(wNew+'\t'+ hNew+'\t'+ wOld+'\t'+ hOld );
      dialog.imageview.resize(wNew, hNew);
   }

   this.imageview = new ImageView(this.panelLeft, this);

   this.lblHeadLine = new Label(this)
   this.lblHeadLine.useRichText = true;
   this.lblHeadLine.text ="<b>RGB: " + viewRGB.id +"</b>";

   // my ©


   this.lblCopyright = new Label(this)
   this.lblCopyright.text = "© 2017, Hartmut V. Bornemann, ver. " + VERSION;

	for (var i = 0; i < 4; i++)
	{
		var radioButton = new RadioButton(this);
		if (i == 0)
		{
			radioButton.checked = true;
			radioButton.text = "RGB";
			radioButton.toolTip = "View the current RGB image";
		}
		else
		{
			radioButton.text = "E" + i;
			radioButton.enabled = false;
			radioButton.toolTip = "View the emission line image";
		}
		radioButton.onCheck = function( checked )
		{
			if (this.parent == null) return;
			for (var j = 0; j < dialog.radioButtons.length; j++)
			{
				if (dialog.radioButtons[j] == this)
				{
					if (j > 0)
					{
						//
						// view RGB
						//
                     dialog.imageview.SetImage(dialog.csChannels[j - 1].bitmap);
					}
					else
					{
						//
						// view narrowband
						//
                     dialog.imageview.SetImage(dialog.NRGB.bitmap);
					}
				}
			}
		}
		dialog.radioButtons[i] = radioButton;
	}

	this.testButton =  new PushButton( this );
	this.testButton.enabled = false;
      this.testButton.defaultButton = true;
	this.testButton.text = "Test";
	this.testButton.toolTip = "<p>Evaluate subtraction quantity for each channel" +
				 " and display the result in the preview</p>";
	this.testButton.onClick = function(checked)
      {
         testing = true;
         dialog.resetLights();
         dialog.cancelRequested = false;
			this.enabled = false;
			dialog.okButton.enabled = false;
			dialog.applyButton.enabled = false;

			dialog.NRGB.refresh();

			for (var i = 0; i < dialog.csChannels.length; i++)
			{
            if (!dialog.csChannels[i].canEvaluate()) continue;

            dialog.greenLabelControls[i].foregroundColor = 0xffffff00;

            dialog.advanceProgress(0);

            CoreApplication.processEvents();

				if (dialog.csChannels[i].getEmission())
				{
               if (dialog.cancelRequested) break;
					if (dialog.csChannels[i].mue > 0.0)
					{
						Console.writeln(dialog.csChannels[i].emission.id + " = " + dialog.csChannels[i].narrowBand.id +
						" - " + dialog.csChannels[i].mue.toFixed(5) + " * " + dialog.csChannels[i].broadBand.id);
                     dialog.radioButtons[i + 1].enabled = true;
                     dialog.greenLabelControls[i].foregroundColor = 0xFF00FF00;
					}
                  else
                  {
                     dialog.radioButtons[i + 1].enabled = false;
                  }
					continue;
				}
			}

         if (!dialog.cancelRequested)
         {
            dialog.NRGB.addEmission();
            if (dialog.radioButtons[0].checked)
            {
               //this.parent.previewControl.RefreshImage(this.parent.NRGB.bitmap);
               //this.parent.previewControl.SetImage(this.parent.NRGB.bitmap);
               dialog.imageview.SetImage(dialog.NRGB.bitmap);
            }
         }

			this.enabled = true;
			nbTested = true;
			dialog.okButton.enabled = true;
			dialog.applyButton.enabled = true;
			dialog.advanceProgress(0);
         testing = false;
		}

	this.lblTick = new Label(this);
   this.lblTick.backgroundColor = 0xff8fcfef;
      this.lblTick.frameStyle = FrameStyle.Box;
		this.lblTick.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;
      var w = this.font.width( 'MMMMMM' );
      this.lblTick.setFixedWidth( w * 2);

      this.lblTick.onPaint = function( x0, y0, x1, y1 )
      {
         var g = new Graphics(dialog.lblTick);
         var str = (dialog.progress * 100).toFixed() + '%';
         var r = g.textRect( x0, y0, x1, y1, str, TextAlignment.Center );
         g.drawTextRect( r, str);
         if (dialog.progress > 0)
         {
            var x = (x1 - x0) * dialog.progress;
            g.pen = new Pen(0xffff0000, 5);
            g.drawLine(0, 2, x, 2);
         }
         g.end();
      }


	this.cancelButton = new PushButton(this);
	this.cancelButton.text = "Cancel";
	this.cancelButton.toolTip = "<p>Interrupt evaluation process</p>";
	this.cancelButton.onClick = function(checked) {
         dialog.cancelRequested = true;
         if (!testing)
         {
            // cancel in idle state terminates the dialog
            Console.hide();
            dialog.done(1);
         }
	}

	this.applyButton = new PushButton( this );
      this.applyButton.defaultButton = false;
	this.applyButton.text = "Apply";
	this.applyButton.toolTip = "<p>Apply the reduced NB images to the MainView</p>";
	this.applyButton.enabled = false;
	this.applyButton.onClick = function(checked) {
			if (dialog.NRGB.apply())
			{
				stfMainView(this.parent);
			}
			else
				Console.writeln("Update failed");
			this.enabled = false;
			nbTested = false;
	}


   this.okButton = new PushButton( this );
      this.okButton.defaultButton = false;
      this.okButton.icon = this.scaledResource( ":/icons/ok.png" );
      this.okButton.text = "OK";
		this.okButton.toolTip = "<p>Exit this dialog</p>";

      this.okButton.onClick = function(checked)
      {
			if (nbTested)
			{
				var query = new MessageBox("The image was modified'\r\n'"
							+ "'Yes' copies to view '\r\n'"
							+ "'Cancel' continues '\r\n'"
							+ "'No' quits without updating",
							"Save view",
											StdIcon.Question,
											StdButton.Yes,
											StdButton.No,
											StdButton.Cancel);
				var answ = query.execute();
				if (answ == StdButton.Yes)
				{
					if (dialog.NRGB.apply())
					{
						stfMainView(dialog);
					}
					else
					{
						Console.writeln("Update failed");
					}
				}
				else if (answ == StdButton.Cancel)
				{
					return; // continue script
				}
				else
				{
					Console.writeln("Image not updated");
				}
			}
         //
			// show or remove views
			//
			if (dialog.retainNB.checked)
			{
 		 		keepEmissionLineViews(dialog);
				stfEmissionViews(dialog);
				//
				// add the graphical analysis
				//
				dialog.NRGB.graphicalAnalysis(dialog.NRGB.mainView);
			}
			//
			//
			//
			dialog.NRGB.maskShow();
			//
			// current parameters to Settings
			//
         parms.dialogWindowWidth  = dialog.width;
         parms.dialogWindowHeight = dialog.height;
         parms.amplify_R = dialog.csChannels[0].contingent;
         parms.amplify_G = dialog.csChannels[1].contingent;
         parms.amplify_B = dialog.csChannels[2].contingent;
         var strVal = JSON.stringify(parms);
         Settings.write('EmissionLineIntegration', DataType.String, strVal);

			//
			// write files in test-mode
			//
			if (test)
			{
				for (var i = 0; i < 3; i++)
				{
					if (dialog.csChannels[i].xy != null)
					{
						var filename = File.systemTempDirectory +
											"\\XYEmission" + "RGB"[i] + ".csv";
						var f = new File(filename,FileMode_Create);
						f.outTextLn( "mue" +tab + "count")
						for (var j = 0; j < dialog.csChannels[i].xy.length; j++)
						{
							f.outTextLn(dialog.csChannels[i].xy[j][0] + tab +
                                 dialog.csChannels[i].xy[j][1])
						}
						f.close();
					}
					if (dialog.csChannels[i].xy != null)
					{
						var filename = File.systemTempDirectory +
											"\\DXYEmission" + "RGB"[i] + ".csv";
						var f = new File(filename,FileMode_Create);
						f.outTextLn( "mue" +tab + "count")
						for (var j = 0; j < dialog.csChannels[i].dxy.length; j++)
						{
							f.outTextLn( dialog.csChannels[i].dxy[j][0] + tab +
											 dialog.csChannels[i].dxy[j][1])
						}
						f.close();
					}
				}
			}
			//
			// end dialog
			//
         Console.hide();
			dialog.done(0);
      };
   //
   // create a controlbox for each channel and one optional mask
   //
   for (var i = 0; i < 4; i++)
   {
      var gbx = new GroupBox( this );
      gbx.sizer = new HorizontalSizer;
      gbx.sizer.margin = 6;
      gbx.sizer.spacing = 4;
      if (i < 3)
			{
         gbx.title = "Narrowband on channel " + RGB[i];
			}
      else
			{
         gbx.title = "Star Mask [opt.]";
			}
      ctls[i] = gbx;


      // image select

		var vList = new ViewList( this );
      vList.index = i;
			vList.setVariableSize();
			vList.excludeIdentifiersPattern  = TempView;
         vList.getAll();
         vList.onViewSelected = function( view )
			{
         	this.cursor = new Cursor(StdCursor.Wait);
				if (this.index < 3)
				{
					dialog.csChannels[this.index].setNarrowBand(view);
					//
					// set controls with mue, contingent from view
					//
					dialog.radioButtons[this.index + 1].enabled = dialog.csChannels[this.index].hasNarrowBand &&
					dialog.csChannels[this.index].emission != null;;
               dialog.greenLabelControls[this.index].foregroundColor = 0x40880000;
				}
				else
				{
					//
					// set mask
					//
					dialog.NRGB.setMask(view);
               //
               // reset lights
               //
               dialog.resetLights();
				}
         	this.cursor = new Cursor(StdCursor.Arrow);
				//
				// at least one channel selected?
				//
				dialog.testButton.enabled = false;
				for (var j in dialog.csChannels)
				{
					if (dialog.csChannels[j].hasNarrowBand)
					{
						dialog.testButton.enabled = true;
						break;
					}
				}
            dialog.advanceProgress(0);
			}
		//
		// label greenLight
		//
		if (i < 3)
		{
			var lblGreenLight  = new Label(this);
			lblGreenLight.font = new Font("WebDings", 11)
			lblGreenLight.text = "n";
			lblGreenLight.foregroundColor = 0x40808080;
			this.greenLabelControls[i] = lblGreenLight;
		}
      // label: Contingent
		//
      if (i < 3)
      {
         var numContingent = new NumericEdit (this);
         numContingent.index = i;
				numContingent.autoEditWidth = true;
            numContingent.label.text = "Amplify:";
				numContingent.edit.rightAlignment = true;
            numContingent.setPrecision( 2 );
				numContingent.setRange(0, 100);
				numContingent.setReal( true );
            numContingent.setValue( 1.00 );
            numContingent.toolTip = "<p>Apply a factor for this emission image, when added to the broadband channel" +
                      " (0..100). Default = 1</p>";
            numContingent.onValueUpdated = function( value )
            {
             	dialog.csChannels[this.index].setContingent(value);
            }
            numContingent.onMouseDoubleClick = function( x, y, buttonState, modifiers )
            {
               this.setValue (1.00);
           		dialog.csChannels[this.index].setContingent(1.0);
            }
				numContingent.onMouseWheel = function( x, y, delta, buttonState, modifiers )
				{
					var step = 0.1 * Math.sign(delta);
					var v = this.value - step;
					if (v > this.upperBound) v = this.upperBound;
					if (v < this.lowerBound) v = this.lowerBound;
					this.setValue(v);
             	dialog.csChannels[this.index].setContingent(v);
				}
			this.contingentControls[i] = numContingent;
      }

      // fill the groupBox

		gbx.sizer.spacing = 4;

         gbx.sizer.add( vList );
       	if (i < 3)
         {
            gbx.sizer.addSpacing( 8 );
				gbx.sizer.add( lblGreenLight );
            gbx.sizer.addSpacing( 8 );
            gbx.sizer.add( numContingent );
            gbx.sizer.addSpacing( 8 );
            gbx.sizer.addStretch();
         }
			else
			{
				gbx.sizer.addStretch();
			}

      // save controls

      c_views[i] = vList;
   }

   // CheckBoxes

   this.retainNB = new CheckBox(this);
   this.retainNB.text = "Retain emission view(s)";
      this.retainNB.toolTip = "<p>Keep emission line view for visual or scientific analysis.</p>";

   this.checkBoxSizer = new HorizontalSizer();
   this.checkBoxSizer.margin = 4;
   this.checkBoxSizer.addStretch()
   this.checkBoxSizer.add(this.retainNB);

   this.testButtonSizer = new HorizontalSizer;
   this.testButtonSizer.margin = 4;
		this.testButtonSizer.add( this.testButton );
      this.testButtonSizer.addSpacing(8);
      this.testButtonSizer.add(this.lblTick);

   // OK and Cancel button

   this.mainButtons = new HorizontalSizer;
   this.mainButtons.margin = 4;
		this.mainButtons.add(this.cancelButton);
		this.mainButtons.addStretch();
		this.mainButtons.add( this.applyButton );
		this.mainButtons.addStretch();
      this.mainButtons.add( this.okButton );

   this.viewlabel = new Label(this);
   this.viewlabel.text = 'View:';

	this.radioButtonSizer = new HorizontalSizer;
		//add( this.lblCopyright );
		this.radioButtonSizer.addStretch();
      this.radioButtonSizer.add(this.viewlabel);
		for (var i = 0; i < this.radioButtons.length; i++)
		{
      	this.radioButtonSizer.addSpacing( 16 );
			this.radioButtonSizer.add(this.radioButtons[i]);
		}

   try
   {
      this.contingentControls[0].setValue( parms.amplify_R );
      this.contingentControls[1].setValue( parms.amplify_G );
      this.contingentControls[2].setValue( parms.amplify_B );
      this.csChannels[0].setContingent( parms.amplify_R );
      this.csChannels[1].setContingent( parms.amplify_G );
      this.csChannels[2].setContingent( parms.amplify_B );
   }
   catch (ex)
   {
   }

   // all controls together

   this.panelRight.sizer = new VerticalSizer();
   this.panelRight.sizer.margin = 4;
      this.panelRight.sizer.spacing = 8;
      this.panelRight.sizer.add(this.lblHeadLine);
      this.panelRight.sizer.spacing = 8;
      this.panelRight.sizer.add(this.lblCopyright);

      for (var i = 0; i < ctls.length; i++)
      {
         this.panelRight.sizer.spacing = 8;
         this.panelRight.sizer.add(ctls[i]);
      }
      this.panelRight.sizer.spacing = 8;
      this.panelRight.sizer.add(this.radioButtonSizer);
      this.panelRight.sizer.spacing = 8;
      this.panelRight.sizer.add(this.checkBoxSizer);
      this.panelRight.sizer.addStretch();
      this.panelRight.sizer.add(this.testButtonSizer);
      this.panelRight.sizer.spacing = 8;
      this.panelRight.sizer.add(this.mainButtons);


	function stfMainView(dialog)
	{
		//
		// ApplyAutoSTF on image
		//
		ApplyAutoSTF( viewRGB,
					DEFAULT_AUTOSTRETCH_SCLIP,
					DEFAULT_AUTOSTRETCH_TBGND, true );
	}

	function stfEmissionViews(dialog)
	{
		//
		// ApplyAutoSTF emission line view(s)
		//
		for (var i = 0; i < 3; i++)
		{
			if (dialog.csChannels[i].emission != null)
			{
				if (dialog.retainNB.checked)
				{
					Console.writeln("Emission on " + RGB[i] + ", View " +
						dialog.csChannels[i].emission.id+ ", mue = " +
						dialog.csChannels[i].mue );
					//
					// retain emission line views?
					//
					ApplyAutoSTF(dialog.csChannels[i].emission,
							DEFAULT_AUTOSTRETCH_SCLIP,
							DEFAULT_AUTOSTRETCH_TBGND, true );
				}
			}
		}
	}

	function keepEmissionLineViews(dialog)
	{
		//
		// keep or retain emission line views depending on dislog's checkBox
		//
		for (var i = 0; i < 3; i++)
		{
			if (dialog.csChannels[i].emission != null)
			{
				//
				// keep away from disposal function
				//
				setDisposal(dialog.csChannels[i].emission, false);
				dialog.csChannels[i].emission.window.show();
			}
		}
	}

   this.advanceProgress = function(progress)
   {
      //dialog.lblTick.text = (progress * 100).toFixed() + '%';
      dialog.progress = progress;
      dialog.lblTick.repaint();
      CoreApplication.processEvents();
   }

   this.resetLights = function()
   {
      for (var j in dialog.csChannels)
      {
         if (dialog.csChannels[j].hasNarrowBand)
            dialog.greenLabelControls[j].foregroundColor = 0x40880000;
         else
            dialog.greenLabelControls[j].foregroundColor = 0x40808080;
      }
   }

   this.imageview.SetImage(this.NRGB.bitmap);

   this.sizer = new HorizontalSizer();
   this.sizer.margin = 4;
      this.sizer.add(this.panelLeft);
      this.sizer.addSpacing(8);
      this.sizer.add(this.panelRight);

   // dialog window
   this.windowTitle = TITLE + " " + VERSION;
   this.adjustToContents();

   this.panelRight.setFixedWidth(this.panelRight.width);


   if (parms.dialogWindowWidth > 0 && parms.dialogWindowHeight > 0)
	{
		this.width  = parms.dialogWindowWidth;
		this.height = parms.dialogWindowHeight;
	}

}

} // class showDialog

function imageMetadata(view)
{
   this.width  = view.image.width;
   this.height = view.image.height;
}

/* *****************************************************************************
 *
 *    Display with ImageView Control
 *
 * *****************************************************************************
*/
class ImageView extends Frame
{
constructor(parent, dialog)
{
   super(parent);

   var frame   = parent;

   var prnt = frame;
   while (prnt.parent != null)
   {
      prnt = prnt.parent;
   }

   var bitmap = null;
   var scaledImage = null;

   this.SetImage = function(bitmap_)
   {
      bitmap = null;
      // V8: gc() removed -- deprecated, V8 handles GC automatically
      bitmap = bitmap_;
      resize_();
      frame.repaint();
   }

   frame.onPaint = function (x0, y0, x1, y1)
   {
      if (bitmap == null) return;

      var graphics = new Graphics(this);

      graphics.fillRect(x0,y0, x1, y1, new Brush(0xff000000));

      var x = (frame.width - scaledImage.width) / 2;
      var y = (frame.height - scaledImage.height) / 2;

      graphics.drawBitmap(x, y, scaledImage);

      graphics.pen = new Pen(0xffffffff,0);
      graphics.drawRect(x-1, y-1, x + scaledImage.width + 1, y + scaledImage.height + 1);
      graphics.end();
   }

   frame.onResize = function (wNew, hNew, wOld, hOld)
   {
      resize_();
      frame.repaint();
   }

   function resize_()
   {
      if (bitmap == null) return;
      var zoom = Math.min(((frame.width - 7) / bitmap.width), ((frame.height - 7) / bitmap.height));
      scaledImage = bitmap.scaled(zoom);
   }

   dialog.onResize = function (wNew, hNew, wOld, hOld)
   {
      var dx = wNew - wOld;
      var dy = hNew - hOld;
      frame.resize(frame.width + dx, frame.height + dy);
   }
}

} // class ImageView

function extractChannels(view)
{
   // retrieve RGBs from view, quiet solution instead of using ChannelExtraction
   var r = getNewName(view.id, "_R");
   var g = getNewName(view.id, "_G");
   var b = getNewName(view.id, "_B");

	for (var i = 0; i < 3; i++)
	{
		view.image.selectedChannel = i;
		var image = new Image(view.image);
		var w = new ImageWindow(image.width, image.height );
		w.mainView.beginProcess( UndoFlag.NoSwapFile );
		w.mainView.image.apply(image);
		w.mainView.endProcess();
		w.mainView.id = [r, g, b][i];
	}

	var rView = View.viewById(r), gView = View.viewById(g), bView = View.viewById(b);
	if (rView == null || gView == null || bView == null)
		throw new Error("extractChannels: could not find one or more newly-created channel views");
	return [rView, gView, bView];
}

function copyView( view, newName)
{
   Console.writeln('function copyView: ' + view.id+'\t'+newName);
   var P = new PixelMath;
   P.expression = "$T";
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.symbols = "";
   P.generateOutput = true;
   P.singleThreaded = false;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = true;
   P.showNewImage = false;
   P.newImageId = newName;
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.SameAsTarget;
   P.newImageSampleFormat = PixelMath.SameAsTarget;
   if (P.executeOn(view))
	{
      var newView = View.viewById(newName);
      if (newView == null)
      {
         message("Could not find newly-created view '" + newName + "'", "Error");
         return null;
      }
      return newView;
	}
   {
      message("Mask creation failed in function copyView", "Error");
      return null;
   }
}


function copyViewChannel(view, channel)
{
   var newName = getNewName(view.id, "_lfit");
   var P = new PixelMath;
      P.expression = '$T[' + channel.toString() + ']';
      P.expression1 = "";
      P.expression2 = "";
      P.expression3 = "";
      P.useSingleExpression = true;
      P.symbols = "";
      P.generateOutput = true;
      P.singleThreaded = false;
      P.use64BitWorkingImage = false;
      P.rescale = false;
      P.rescaleLower = 0;
      P.rescaleUpper = 1;
      P.truncate = true;
      P.truncateLower = 0;
      P.truncateUpper = 1;
      P.createNewImage = true;
      P.showNewImage = false;
      P.newImageId = newName;
      P.newImageWidth = 0;
      P.newImageHeight = 0;
      P.newImageAlpha = false;
      P.newImageColorSpace = PixelMath.Gray;
      P.newImageSampleFormat = PixelMath.SameAsTarget;
      P.executeOn(view);
   var newView = View.viewById(newName);
   if (newView == null)
      throw new Error("copyViewChannel: could not find newly-created view '" + newName + "'");
   return newView;
}

function linearViewToBMP(view)
{
   //Console.writeln('  linearViewToBMP  ' + view.id);
 	var nlinName = getNewName(view.id, "_preview");
	var viewCopy = copyView(view, nlinName);
   ApplyAutoSTF( viewCopy,
						DEFAULT_AUTOSTRETCH_SCLIP,
						DEFAULT_AUTOSTRETCH_TBGND,
						DEFAULT_AUTOSTRETCH_CLINK );
	ApplyHistogram(viewCopy);
   var bmp  = viewCopy.image.render();
   viewCopy.window.forceClose();
	return bmp;
}

// ========================================================================
//      STF Auto Stretch routine
// ========================================================================
//
function ApplyAutoSTF( view, shadowsClipping, targetBackground, rgbLinked )
{
   var stf = new ScreenTransferFunction;

   var n = view.image.isColor ? 3 : 1;

   var median = view.computeOrFetchProperty( "Median" );

   var mad = view.computeOrFetchProperty( "MAD" );
   mad.mul( 1.4826 ); // coherent with a normal distribution

   if ( rgbLinked )
   {
      /*
       * Try to find how many channels look as channels of an inverted image.
       * We know a channel has been inverted because the main histogram peak is
       * located over the right-hand half of the histogram. Seems simplistic
       * but this is consistent with astronomical images.
       */
      var invertedChannels = 0;
      for ( var c = 0; c < n; ++c )
         if ( median.at( c ) > 0.5 )
            ++invertedChannels;

      if ( invertedChannels < n )
      {
         /*
          * Noninverted image
          */
         var c0 = 0, m = 0;
         for ( var c = 0; c < n; ++c )
         {
            if ( 1 + mad.at( c ) != 1 )
               c0 += median.at( c ) + shadowsClipping * mad.at( c );
            m  += median.at( c );
         }
         c0 = Math.range( c0/n, 0.0, 1.0 );
         m = Math.mtf( targetBackground, m/n - c0 );

         stf.STF = [ // c0, c1, m, r0, r1
                     [c0, 1, m, 0, 1],
                     [c0, 1, m, 0, 1],
                     [c0, 1, m, 0, 1],
                     [0, 1, 0.5, 0, 1] ];
      }
      else
      {
         /*
          * Inverted image
          */
         var c1 = 0, m = 0;
         for ( var c = 0; c < n; ++c )
         {
            m  += median.at( c );
            if ( 1 + mad.at( c ) != 1 )
               c1 += median.at( c ) - shadowsClipping * mad.at( c );
            else
               c1 += 1;
         }
         c1 = Math.range( c1/n, 0.0, 1.0 );
         m = Math.mtf( c1 - m/n, targetBackground );

         stf.STF = [ // c0, c1, m, r0, r1
                     [0, c1, m, 0, 1],
                     [0, c1, m, 0, 1],
                     [0, c1, m, 0, 1],
                     [0, 1, 0.5, 0, 1] ];
      }
   }
   else
   {
      /*
       * Unlinked RGB channnels: Compute automatic stretch functions for
       * individual RGB channels separately.
       */
      var A = [ // c0, c1, m, r0, r1
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1] ];

      for ( var c = 0; c < n; ++c )
      {
         if ( median.at( c ) < 0.5 )
         {
            /*
             * Noninverted channel
             */
            var c0 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) + shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 0.0;
            var m  = Math.mtf( targetBackground, median.at( c ) - c0 );
            A[c] = [c0, 1, m, 0, 1];
         }
         else
         {
            /*
             * Inverted channel
             */
            var c1 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) - shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 1.0;
            var m  = Math.mtf( c1 - median.at( c ), targetBackground );
            A[c] = [0, c1, m, 0, 1];
         }
      }

      stf.STF = A;
   }

	var t = false;
	if (t)
	{
		Console.writeln( "<end><cbr/><br/><b>", view.fullId, "</b>:" );
		for ( var c = 0; c < n; ++c )
		{
			Console.writeln( "channel #", c );
			Console.writeln( format( "c0 = %.6f", stf.STF[c][0] ) );
			Console.writeln( format( "m  = %.6f", stf.STF[c][2] ) );
			Console.writeln( format( "c1 = %.6f", stf.STF[c][1] ) );
		}
	}

   stf.executeOn( view );

   if (t) Console.writeln( "<end><cbr/><br/>" );
}

function ApplyHistogram(view)
{
Console.writeln('ApplyHistogram '+view.id);
	var stf = view.stf;

	var H = [[  0, 0.0, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0]];;

	if (view.image.isColor)
	{
		for (var c = 0; c < 3; c++)
		{
			H[c][0] = stf[c][1];
			H[c][1] = stf[c][0];
		}
	}
	else
	{
		H[3][0] = stf[0][1];
		H[3][1] = stf[0][0];
	}

	var STF = new ScreenTransferFunction;

	view.stf =  [ // c0, c1, m, r0, r1
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000]
	];

	STF.executeOn(view)

	var HT = new HistogramTransformation;
	HT.H = H;
	HT.executeOn(view);
}


function plotter(curves, mue, nbId, bbId, csId, smId)
{
   // fetch the program from temp
   //
   var GNUPlot = gnuplotExecutable()

   if (GNUPlot == "")
   {
      Console.writeln("GNUPlot program file missing");
      return;
   }

   nbId = nbId.replaceAll('_', "\\\\\\\_");
   bbId = bbId.replaceAll('_', "\\\\\\\_");
   csId = csId.replaceAll('_', "\\\\\\\_");
   if (smId != "") smId = smId.replaceAll('_', "\\\\\\\_");
   var mueStr = "mue = " + mue.toFixed(6);

   var scriptPath = tempFile("gbnuScript", "plt");
   var imagePath  = tempFile("image", "svg");
   var outputPath = tempFile("output", "txt");
   var dataPath   = tempFile("cs_data", "csv");
   //
   // generate data file
   //
   var a = [];
   var t = 0.01;	// 1%

   for (var i in curves)
   {
      t = 0;
      a.push(curves[i].x.toFixed(8) + '\t' +
             curves[i].y.toFixed(8) + '\t' +
             curves[i].slope.toFixed(8));
   }
   File.writeTextFile(dataPath, a.join('\n') );

   var minx = curves[0].x;
   var maxx = curves[curves.length - 1].x;
   var cent = (minx + maxx) / 2;

   // write GNUPlot script

   var script = [];
   script.push("set terminal svg size 600,500 enhanced background rgb 'white' font \"Helvetica,10\"");
   script.push("set output \"" + imagePath + "\"");
   var title =" set title font \"Times Bold, 20\" enhanced \"Continuum Subtraction";
   title += "\\n{/*0.8 Narrowband: " + nbId + '}';
   title += "\\n{/*0.8 Broadband: " + bbId + '}';
   if (smId != "")
      title += "\\n{/*0.8 Starmask: " + smId + '}';
   else
      title += "\\n{/*0.8 No mask" + smId + '}';
   title += "\\n{/*0.8 Subtracted: " + csId + '}';
   title += '\"';
   script.push(title);
   script.push("set xlabel \"" + mueStr + "\" font \"Courier, 12\"");
   script.push("set ylabel \"Normalized data\" font \"Helvetica, 12\"");
   script.push("set style line 1 lc rgb 'black' lt 1 lw 1 dashtype 0");
   script.push("set style line 2 lc rgb 'black' lt 1 lw 1 dashtype 1");
   script.push("set style line 3 lc rgb 'grey' lt 0 lw 1 dashtype '-'");
   script.push("set grid back ls 3");

   script.push("set key left top");

   script.push("set arrow 1 from " + mue.toString() + ",0 to " +
      mue.toString() + ",1 nohead filled back lw 1");

   if (mue < cent)
      script.push("set key right top");
   else
      script.push("set key left top");
   script.push("plot \"" + dataPath + "\"  using 1:2 title 'Blackness' with lines ls 1, \\");
   script.push(" \"" + dataPath + "\"  using 1:3 title '1st Deviation' with lines ls 2");
   script.push("quit");

   File.writeTextFile( scriptPath, script.join('\n'));

   var P = new ExternalProcess();
      P.workingDirectory = File.systemTempDirectory;

      P.redirectStandardInput( scriptPath );
      P.redirectStandardOutput( outputPath );

      P.onStarted = function()
      {
         Console.writeln("Start " + GNUPlot);
      }

      P.onError = function( errorCode )
      {
         Console.writeln("Fehler# " + errorCode);
      }

      P.onFinished = function( exitCode, exitStatus )
      {
         Console.writeln("End Exit code " + exitCode + '\t' +
                         ", Status " + exitStatus);
      }

      P.start(GNUPlot);
      P.waitForFinished();

   var txt = File.readTextFile( outputPath );

   Console.writeln(txt);
   Console.flush();

   // load image

   if (File.exists(imagePath))
   {
      try
      {
         var bm = new Bitmap(imagePath);
         var window = new ImageWindow(bm.width, bm.height, 3, 32, true, true, "CS_Plot");
         window.mainView.beginProcess(UndoFlag.NoSwapFile);
         window.mainView.image.blend( bm );
         window.mainView.endProcess();
         window.show();
      }
      catch (ex)
      {
         Console.writeln("Image load error: " + ex);
      }
      File.remove( imagePath );
   }

   File.remove( scriptPath );
   File.remove( outputPath );
   File.remove( dataPath );

   function tempFile(name, ext)
   {
      var workingDir = File.systemTempDirectory;
      workingDir = workingDir.replaceAll('\\', '/');
      if (!workingDir.endsWith('/')) workingDir += '/';
      var filename = "";
      var index = 0;
      while (true)
      {
         if (index == 0)
            filename = workingDir + name + '.' + ext;
         else
            filename = workingDir + name + index.toString() + '.' + ext;
         if (!File.exists(filename)) break;
         index += 1;
      }
      return filename;
   }

   function gnuplotExecutable()
   {
      var gnu = File.systemTempDirectory + "/gnuplot.exe";
      if (File.exists(gnu)) return gnu;
      var f = File.currentWorkingDirectory;
      if (!f.endsWith("/bin")) f += "/bin";
      f += "/gnuplot.exe";
      if (File.exists(f))
      {
         File.copyFile( gnu, f );
         return gnu;
      }
      return "";  // not found
   }
}

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.split(search).join(replacement);
};

/*
                                 Math

 ========================================================================
   Polynomials functions
 ========================================================================
*/

function solveQ (a, b, c)
{
	// a quadratic term
	// b linear
	// c const
	var x1 = (-b - Math.sqrt(b*b - 4*a*c)) / (2*a);
	var x2 = (-b + Math.sqrt(b*b - 4*a*c)) / (2*a);
	return  [x1, x2];
}

function Polynomials(points, degree)
{
   // find polynomials
   // input points [0..n.1] x and y
   // try degree
   var d = degree;
   var coeff = [];
   while (d > 0)
   {
      coeff = FindPolynomialLeastSquaresFit(points, d);
      var cnt = 0;
      for (var i = 0; i < coeff.length; i++)
      {
         if (isValid(coeff[i])) cnt +=1;   // count valid coefficients
      }
      if (coeff.length == cnt) break;
      d -=1;
   }
   return coeff;
}

function yValue(x, A)
{
   var y = 0;
   for (var j = 0; j < A.length; j++)
   {
      y += A[j] * Math.pow(x, j);
   }
   return y;
}

// Find the least squares linear fit.
function  FindPolynomialLeastSquaresFit( points,  degree)
{
   // input points []
   // Allocate space for (degree + 1) equations with
   // (degree + 2) terms each (including the constant term).
  // var coeffs = new double[degree + 1][degree + 2];
   var rows = degree + 1;
   var cols = degree + 2;
   var coeffs = new Matrix(rows, cols);

   // Calculate the coefficients for the equations.
   for (var j = 0; j <= degree; j++)
   {
      // Calculate the constant term for this equation.
      coeffs.at(j, degree + 1, 0);
      for (var i = 0; i < points.length; i++)
      {
         var a = coeffs.at(j, degree + 1);
         a -= Math.pow(points[i].x, j) * points[i].y;  // Y
         coeffs.at(j, degree + 1, a);
      }

      // Calculate the other coefficients.
      for (var a_sub = 0; a_sub <= degree; a_sub++)
      {
         // Calculate the dth coefficient.
         //coeffs[j][a_sub] = 0;
         coeffs.at(j, a_sub, 0);
         for (var i = 0; i < points.length; i++)
         {
            //coeffs[j][a_sub] -= Math.pow(pt.X, a_sub + j);
            var a = coeffs.at(j, a_sub);
            a -= Math.pow(points[i].x, a_sub + j);
            coeffs.at(j, a_sub, a);
         }
      }
   }

   // Solve the equations.
    var answer = Solve(coeffs);

   // Return the result converted into a List<double>.
   return answer;
}
// Computes the solution of a linear equation system.
// @param M
// The system of linear equations as an augmented matrix[row, col] where (rows + 1 == cols).
// It will contain the solution in "row canonical form" if the function returns "true".

// @return Returns whether the matrix has a unique solution or not.

function Solve( M )
{
   // input checks
   if (M == null) throw ("Coefficient matrix is empty");
   if (M.cols != M.rows + 1)
   {
      throw new RuntimeException("The algorithm must be provided with a (n x n+1) matrix.");
   }
   var rowCount = M.rows;
   if (rowCount < 1)
   {
      throw new RuntimeException("The matrix must at least have one row.");
   }

   // pivoting
   for (var col = 0; col + 1 < rowCount; col++)
   {
      if (M.at(col, col) == 0)
      {
      // check for zero coefficients
         // find non-zero coefficient
         var swapRow = col + 1;
         for (; swapRow < rowCount; swapRow++)
         {
            if (M.at(swapRow, col) != 0)
            {
               break;
            }
         }

         if (M.at(swapRow, col) != 0) // found a non-zero coefficient?
         {
            // yes, then swap it with the above
            var tmp = new Array(rowCount + 1);
            for (var i = 0; i < rowCount + 1; i++)
            {
               tmp[i] = M.at(swapRow, i);
               M.at(swapRow, i, M.at(col, i));
               M.at(col, i, tmp[i]);
            }
         }
         else
         {
            return false; // no, then the matrix has no unique solution
         }
      }
   }

   // elimination
   for (var sourceRow = 0; sourceRow + 1 < rowCount; sourceRow++)
   {
      for (var destRow = sourceRow + 1; destRow < rowCount; destRow++)
      {
         var df = M.at(sourceRow, sourceRow);
         var sf = M.at(destRow, sourceRow);
         for (var i = 0; i < rowCount + 1; i++)
         {
            M.at(destRow, i, M.at(destRow, i) * df - M.at(sourceRow, i) * sf);
         }
      }
   }

   // back-insertion
   for (var row = rowCount - 1; row >= 0; row--)
   {
      var f = M.at(row, row);
      if (f == 0)
      {
         return false;
      }

      for (var i = 0; i < rowCount + 1; i++)
      {
         var a = M.at(row, i);
         a /= f;
         M.at(row, i, a);
      }
      for (var destRow = 0; destRow < row; destRow++)
      {
         var a = M.at(destRow, rowCount);
         a -= M.at(destRow, row) * M.at(row, rowCount);
         M.at(destRow, rowCount, a);
         M.at(destRow, row, 0);
      }
   }

   for (var r = 0; r < M.rows; r++)
   {
      for (var c = 0; c < M.cols; c++)
      {
        // Console.writeln("M " + r + '\t' + c  + '\t' + M.at(r, c));
      }
   }
   // collect A1, A2, ..
   var coeff = [];
   for (var i = 0; i < rowCount; i++)
   {
      coeff.push(M.at(i, M.cols-1));
   }
   return coeff;
}


function isValid(v)
{
   if (!isFinite(v)) return false;
   if (isNaN(v))     return false;
   return true;
}

// The function.
function poly(coeffs, x)
{
    var total = 0;
    var x_factor = 1;
    for (var i = 0; i < coeffs.length; i++)
    {
        total += x_factor * coeffs[i];
        x_factor *= x;
    }
    return total;
}

// Helper functions

function getNewName(name, suffix)
{
   var newName = TempView + name + suffix;
   let n = 1;
   while (!ImageWindow.windowById(newName).isNull)
   {
      ++n;
      newName = name + suffix + n.toString();
   }
   return newName;
}

function stringOf(chr, count)
{
   var s = new String();
   for (var i = 0; i < count; i++) s = s.concat(chr);
   return s;
}

function message(txt)
{
   var bx = new MessageBox(txt, "Error");
   bx.execute();
}

function getAllMainViews()
{
   var mainViews = [];
   var images = ImageWindow.windows;
   for ( var i in images )
   {
      if (images[i].mainView.isMainView) mainViews.push(images[i].mainView);
   }
   return mainViews;
}

function setDisposal(view, b)
{
	//
	// set/reset disposal flag in view
	//
	view.setPropertyValue(Dispose, b);
}

function houseKeeping()
{
	var views = getAllMainViews();
	for (var i = 0; i < views.length; i++)
	{
		if (views[i].hasProperty( Dispose ))
		{
			var dispose = views[i].propertyValue(Dispose);
			if (dispose) views[i].window.forceClose();
		}
	}
}


String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.split(search).join(replacement);
};
//////////////////////////////////////////////////////////////////////////////
//
// Main script entry point
//
//////////////////////////////////////////////////////////////////////////////
function main()
{
	houseKeeping();
   // get active image window.
   var window = ImageWindow.activeWindow;
   if ( window.isNull )
   {
      message( "No active image" );
   }
   else
   {
      var img = window.currentView.image;
      if (!img.isColor)
      {
         message( "This script for RGB images only" );
      }
      else
      {
         Console.hide();
			Console.show();
		   Console.abortEnabled = true;

         try
         {
            var dialog = new showDialog(window.currentView);
            dialog.execute();
         }
         catch (ex)
         {
            Console.writeln(ex);
         }
         houseKeeping();
         // V8: gc() removed -- deprecated, V8 handles GC automatically
      }
   }
}

main();
