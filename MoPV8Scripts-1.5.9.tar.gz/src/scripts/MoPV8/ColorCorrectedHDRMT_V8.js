// ----------------------------------------------------------------------------
// PixInsight JavaScript Runtime API - PJSR Version 1.0
// ----------------------------------------------------------------------------
// ColorCorrectedHDRMT.js - Released 2021-06-27
// ----------------------------------------------------------------------------
//
// This file is the ColorCorrectedHDRMT Script version 0.1
//
// Copyright (C) 2021 Russell Croman
// All Rights Reserved.
//
// Redistribution and use in both source and binary forms, with or without
// modification, is permitted provided that the following conditions are met:
//
// 1. All redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//
// 2. All redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// 3. Neither the names "PixInsight" and "Pleiades Astrophoto", nor the names
//    of their contributors, may be used to endorse or promote products derived
//    from this software without specific prior written permission. For written
//    permission, please contact info@pixinsight.com.
//
// 4. All products derived from this software, in any form whatsoever, must
//    reproduce the following acknowledgment in the end-user documentation
//    and/or other materials provided with the product:
//
//    "This product is based on software from the PixInsight project, developed
//    by Pleiades Astrophoto and its contributors (http://pixinsight.com/)."
//
//    Alternatively, if that is where third-party acknowledgments normally
//    appear, this acknowledgment must be reproduced in the product itself.
//
// THIS SOFTWARE IS PROVIDED BY PLEIADES ASTROPHOTO AND ITS CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL PLEIADES ASTROPHOTO OR ITS
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, BUSINESS
// INTERRUPTION; PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; AND LOSS OF USE,
// DATA OR PROFITS) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
// ----------------------------------------------------------------------------

#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Russell Croman.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; removed all
// #include <pjsr/...> directives (PJSR globals available without them);
// removed the #include <../src/scripts/AdP/CommonUIControls.js> dependency
// entirely (see the 2026-08-05 note further down for why) and replaced its
// one used symbol, fieldLabel(), with a small local implementation;
// converted parametersDialogPrototype from __base__/.prototype = new
// Dialog to class extends Dialog / super(); replaced 4 .prototype. enum
// references (ChannelExtraction, HDRMultiscaleTransform,
// ChannelCombination) with direct class access; replaced underscore
// constants with dot notation (FrameStyle.Box -> FrameStyle.Box,
// StdIcon.Warning -> StdIcon.Warning, StdButton.Ok -> StdButton.Ok);
// expanded the one with(PBlend) block (banned in V8 strict mode) --
// also added a missing var declaration for PBlend while expanding it,
// since it was being assigned to without var/let/const;
// replaced 4 lowercase Console. calls with Console. (same systemic bug
// found across most of the MoP V8 repo).
//
// Also fixed a genuine pre-existing bug, not V8-specific but newly
// enforced by V8's stricter engine: main() declared `let parametersDialog`
// TWICE in the same scope. Older, more lenient JS engines apparently
// tolerated this; V8 throws a SyntaxError for it at parse time, meaning
// this script could never have run under V8 without this fix. The first
// declaration built a whole Dialog instance that was then immediately
// discarded when the second declaration overwrote it -- removed the
// first (dead) declaration rather than the second (the one actually
// used), since the second is the one .execute() gets called on.
// ----------------------------------------------------------------------------

/* beautify ignore:start */
#define TITLE "ColorCorrectedHDRMT"
#define VERSION "0.1"

#feature-id ColorCorrectedHDRMT : MoP V8 > ColorCorrectedHDRMT

#feature-info An HDRMultiscaleTransform enhancement to preserve color< br />\
    <br />\
    This script uses the HSI hue and saturation of the original \
    image to retain the color in the HDR compressed image. This works \
    well on stretched images with very bright regions, where none of \
    the options available in the built-in HDRMT process will properly \
    retain color.\
    <br />\
    Copyright & copy; 2021 Russell Croman. All Rights Reserved.

// V8 fix, 2026-08-05: removed the #include <../AdP/CommonUIControls.js>
// dependency entirely after two different relative-path guesses both
// failed to resolve on the user's actual installation ("File not found in
// include directive"). Rather than keep guessing at the exact folder
// layout, this script now defines its own local fieldLabel() below,
// matching the standard AdP "field label" convenience pattern (a
// right-aligned, vertically-centered Label with a fixed min-width) that
// this script's 3 call sites actually rely on -- so there's no external
// dependency left to break.
/* beautify ignore:end */

// Local replacement for AdP's fieldLabel() -- a Label preset for use next
// to a form control, right-aligned and vertically centered, with an
// optional fixed minimum width so label columns line up.
function fieldLabel( parent, text_, minWidth )
{
   let label = new Label( parent );
   label.text = text_;
   label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
   if ( minWidth )
      label.minWidth = minWidth;
   return label;
}

// The script's parameters prototype.
function parametersPrototype()
{
   this.setDefaults = function()
   {
      this.targetView = null;
      this.applySTF = false;
      this.hdrmtLayers = 8;
      this.hdrmtIterations = 1;
      this.hdrmtInverted = true;
      this.hdrmtOverdrive = 0.0;
      this.hdrmtMedianTransform = false;
      this.hdrmtLightnessMask = true;
      this.hdrmtInverted_CheckBox = null;
      this.opacity = 1.0;
   };

   this.setParameters = function()
   {
      Parameters.clear();
      Parameters.set( "hdrmtLayers", this.hdrmtLayers );
      Parameters.set( "hdrmtIterations", this.hdrmtIterations );
      Parameters.set( "hdrmtInverted", this.hdrmtInverted );
      Parameters.set( "hdrmtOverdrive", this.hdrmtOverdrive );
      Parameters.set( "hdrmtMedianTransform", this.hdrmtMedianTransform );
      Parameters.set( "hdrmtLightnessMask", this.hdrmtLightnessMask );
      Parameters.set( "opacity", this.opacity );
   };

   this.getParameters = function()
   {
      if ( Parameters.has( "hdrmtLayers" ) ) this.hdrmtLayers = Parameters.getInteger( "hdrmtLayers" );
      if ( Parameters.has( "hdrmtIterations" ) ) this.hdrmtIterations = Parameters.getReal( "hdrmtIterations" );
      if ( Parameters.has( "hdrmtInverted" ) ) this.hdrmtInverted = Parameters.getBoolean( "hdrmtInverted" );
      if ( Parameters.has( "hdrmtOverdrive" ) ) this.hdrmtOverdrive = Parameters.getReal( "hdrmtOverdrive" );
      if ( Parameters.has( "hdrmtMedianTransform" ) ) this.hdrmtMedianTransform = Parameters.getBoolean( "hdrmtMedianTransform" );
      if ( Parameters.has( "hdrmtLightnessMask" ) ) this.hdrmtLightnessMask = Parameters.getBoolean( "hdrmtLightnessMask" );
      if ( Parameters.has( "opacity" ) ) this.opacity = Parameters.getReal( "opacity" );
   };
}

var parameters = new parametersPrototype();
parameters.setDefaults();
parameters.getParameters();

// Returns a push button with given text and onClick function.
function pushButtonWithTextOnClick( parent, text_, onClick_ )
{
   let button = new PushButton( parent );
   button.text = text_;
   button.onClick = onClick_;
   return button;
}

// The script's parameters dialog prototype.
class parametersDialogPrototype extends Dialog
{
constructor()
{
   super();

   let labelMinWidth = Math.round( this.font.width( "Amount:" ) + 2.0 * this.font.width( 'M' ) );
   let labelWidth1 = this.font.width( "Right Ascension (hms):" + "M" );
   let radioLabelWidth = this.font.width( "Resolution (arcsec/px):" );
   let spinBoxWidth = 5*this.font.width( 'M' );

   this.windowTitle = TITLE;

   this.titlePane = new Label( this );
   this.titlePane.frameStyle = FrameStyle.Box;
   this.titlePane.margin = 4;
   this.titlePane.wordWrapping = true;
   this.titlePane.useRichText = true;
   this.titlePane.text =
      "<p><b>" + TITLE + " Version " + VERSION + "</b> &mdash; " +
      "This script uses the HSI hue and saturation of the original " +
      "image to correct the color of the transformed image. This " +
      "works well on nonlinear (stretched) images." +
      "<p>Copyright &copy; 2020 Russell Croman. All Rights Reserved.</p>";

   this.targetView = new HorizontalSizer;

   this.viewList_Label = new fieldLabel( this, "Target view:", labelWidth1 );

   this.viewList = new ViewList( this );
   this.viewList.getAll();
   if ( parameters.targetView && parameters.targetView.isView )
      this.viewList.currentView = parameters.targetView;
   else
      parameters.targetView = this.viewList.currentView;
   this.viewList.onViewSelected = function( view )
   {
      parameters.targetView = view;
   };

   this.targetView.add( this.viewList_Label );
   this.targetView.add( this.viewList );


   this.parameterPane = new VerticalSizer;
   this.parameterPane.margin = 6;
   this.parameterPane.spacing = 4;


   this.hdrmtLayers_Label = new fieldLabel( this, "Number of layers:", labelWidth1 );

   this.hdrmtLayers_SpinBox = new SpinBox( this );
   this.hdrmtLayers_SpinBox.minValue = 2;
   this.hdrmtLayers_SpinBox.maxValue = 16;
   this.hdrmtLayers_SpinBox.value = parameters.hdrmtLayers;
   this.hdrmtLayers_SpinBox.toolTip = "<p>Number of HDRMT layers.</p>";
   this.hdrmtLayers_SpinBox.setFixedWidth( spinBoxWidth );
   this.hdrmtLayers_SpinBox.onValueUpdated = function( value )
   {
      parameters.hdrmtLayers = value;
   };

   this.hdrmtIterations_Label = new fieldLabel( this, "Number of iterations:", labelWidth1 );

   function update_hdrmtInverted_CheckBox_Enabled() {
      parameters.hdrmtInverted_CheckBox.enabled = (parameters.hdrmtIterations > 1);
   }

   this.hdrmtIterations_SpinBox = new SpinBox( this );
   this.hdrmtIterations_SpinBox.minValue = 1;
   this.hdrmtIterations_SpinBox.maxValue = 16;
   this.hdrmtIterations_SpinBox.value = parameters.hdrmtIterations;
   this.hdrmtIterations_SpinBox.toolTip = "<p>Number of HDRMT iterations.</p>";
   this.hdrmtIterations_SpinBox.setFixedWidth( spinBoxWidth );
   this.hdrmtIterations_SpinBox.onValueUpdated = function( value )
   {
      parameters.hdrmtIterations = value;
      update_hdrmtInverted_CheckBox_Enabled();
   };

   this.hdrmtInverted_CheckBox = new CheckBox(this);
   this.hdrmtInverted_CheckBox.text = "Inverted";
   this.hdrmtInverted_CheckBox.checked = parameters.hdrmtInverted;
   this.hdrmtInverted_CheckBox.toolTip = "<p>Enable inverted HDRMT iterations.</p>";
   parameters.hdrmtInverted_CheckBox = this.hdrmtInverted_CheckBox;
   update_hdrmtInverted_CheckBox_Enabled();

   this.hdrmtLayers_Sizer = new HorizontalSizer;
   this.hdrmtLayers_Sizer.spacing = 4;
   this.hdrmtLayers_Sizer.add( this.hdrmtLayers_Label );
   this.hdrmtLayers_Sizer.add( this.hdrmtLayers_SpinBox );
   this.hdrmtLayers_Sizer.add( this.hdrmtIterations_Label );
   this.hdrmtLayers_Sizer.add( this.hdrmtIterations_SpinBox );
   this.hdrmtLayers_Sizer.add( this.hdrmtInverted_CheckBox );
   this.hdrmtLayers_Sizer.addStretch();

   this.parameterPane.add( this.hdrmtLayers_Sizer )


   this.hdrmtOverdrive_Control = new NumericControl( this );
   this.hdrmtOverdrive_Control.label.text = "Overdrive:";
   this.hdrmtOverdrive_Control.label.minWidth = labelWidth1;
   this.hdrmtOverdrive_Control.slider.setRange( 0, 256 );
   this.hdrmtOverdrive_Control.slider.setScaledMinWidth( 300 );
   this.hdrmtOverdrive_Control.setRange( 0.0, 1.0 );
   this.hdrmtOverdrive_Control.setPrecision( 3 );
   this.hdrmtOverdrive_Control.setValue( parameters.hdrmtOverdrive );
   this.hdrmtOverdrive_Control.toolTip =
      "<p>Increase dynamic range compression.</p>";
   this.hdrmtOverdrive_Control.onValueUpdated = function( value )
   {
      parameters.hdrmtOverdrive = value;
   };

   this.parameterPane.add( this.hdrmtOverdrive_Control );


   this.hdrmtLightnessMask_CheckBox = new CheckBox(this);
   this.hdrmtLightnessMask_CheckBox.text = "Lightness Mask";
   this.hdrmtLightnessMask_CheckBox.checked = parameters.hdrmtLightnessMask;
   this.hdrmtLightnessMask_CheckBox.toolTip = "<p>Use a lightness mask to protect dark background regions.</p>";

   this.hdrmtLightnessMask_CheckBox_Sizer = new HorizontalSizer;
   this.hdrmtLightnessMask_CheckBox_Sizer.addUnscaledSpacing( labelWidth1 + this.logicalPixelsToPhysical( 4 ) ); // + labelWidth
   this.hdrmtLightnessMask_CheckBox_Sizer.add( this.hdrmtLightnessMask_CheckBox );
   this.hdrmtLightnessMask_CheckBox_Sizer.addStretch();

   this.parameterPane.add( this.hdrmtLightnessMask_CheckBox_Sizer );


   this.opacity_Control = new NumericControl( this );
   this.opacity_Control.label.text = "Opacity:";
   this.opacity_Control.label.minWidth = labelWidth1;
   this.opacity_Control.slider.setRange( 0, 256 );
   this.opacity_Control.slider.setScaledMinWidth( 300 );
   this.opacity_Control.setRange( 0.0, 1.0 );
   this.opacity_Control.setPrecision( 3 );
   this.opacity_Control.setValue( parameters.opacity );
   this.opacity_Control.toolTip =
      "<p>Set the opacity of the HDR compression in a Photoshop sense.</p>";
   this.opacity_Control.onValueUpdated = function( value )
   {
      parameters.opacity = value;
   };

   this.parameterPane.add( this.opacity_Control );



   this.buttonPane = new HorizontalSizer;
   this.buttonPane.spacing = 6;
   this.buttonPane.addStretch();
   this.buttonPane.add( pushButtonWithTextOnClick( this, "Execute",
      function()
      {
         parameters.exit = false;
         this.dialog.ok();
      } ) );
   this.buttonPane.add( pushButtonWithTextOnClick( this, "Cancel",
      function()
      {
         parameters.exit = true;
         this.dialog.ok();
      } ) );

   this.bottomBarPane = new HorizontalSizer;

   this.newInstanceButton = new ToolButton( this );
   this.newInstanceButton.icon = this.scaledResource( ":/images/interface/dragObject.png" );
   this.newInstanceButton.setScaledFixedSize( 24, 24 );
   this.newInstanceButton.toolTip = "New Instance";
   this.newInstanceButton.onMousePress = function()
   {
      this.hasFocus = true;
      this.pushed = false;
      parameters.setParameters();
      this.dialog.newInstance();
   };

   this.bottomBarPane.add( this.newInstanceButton );
   this.bottomBarPane.add( this.buttonPane );

   this.sizer = new VerticalSizer;
   this.sizer.margin = 6;
   this.sizer.spacing = 6;
   this.sizer.add( this.titlePane );
   this.sizer.add( this.targetView );
   this.sizer.add( this.parameterPane );
   this.sizer.add( this.bottomBarPane );

   this.adjustToContents();
   this.setFixedSize();
}

} // class parametersDialogPrototype

// The script's process prototype.
function processPrototype()
{
   this.executeColorCorrectedHDRMT = function( targetView )
   {
      // names for the hue, saturation, and intensity temporary images
      var idH = "temp_H";
      var idS = "temp_S";
      var idI = "temp_I";

      // Extract temporary HSI images from the original
      var PExtract = new ChannelExtraction;
      PExtract.colorSpace = ChannelExtraction.HSI;
      PExtract.channels = [ // enabled, id
         [true, idH],
         [true, idS],
         [true, idI]
      ];
      PExtract.sampleFormat = ChannelExtraction.SameAsSource;
      PExtract.executeOn(targetView, true);

      // Apply any mask applied to the target image
      if (targetView.window.mask && targetView.window.maskEnabled) {
         View.viewById(idI).window.setMask(targetView.window.mask, targetView.window.maskInverted);
      }

      // Perform the HDRMT on the intensity image
      var PHDRMT = new HDRMultiscaleTransform;
      PHDRMT.numberOfLayers = parameters.hdrmtLayers;
      PHDRMT.numberOfIterations = parameters.hdrmtIterations;
      PHDRMT.invertedIterations = parameters.hdrmtInverted;
      PHDRMT.overdrive = parameters.hdrmtOverdrive;
      PHDRMT.medianTransform = parameters.hdrmtMedianTransform;
      PHDRMT.scalingFunctionName = "B3 Spline (5)";
      PHDRMT.deringing = false;
      PHDRMT.smallScaleDeringing = 0.000;
      PHDRMT.largeScaleDeringing = 0.250;
      PHDRMT.outputDeringingMaps = false;
      PHDRMT.midtonesBalanceMode = HDRMultiscaleTransform.Automatic;
      PHDRMT.midtonesBalance = 0.500000;
      PHDRMT.toLightness = false;
      PHDRMT.preserveHue = false;
      PHDRMT.luminanceMask = parameters.hdrmtLightnessMask;
      PHDRMT.executeOn(View.viewById(idI), true);

      // Blend this HDR'd intensity with the original using the opacity parameter
      if (parameters.opacity < 1.0) {
         var PBlend = new PixelMath;
         //PBlend.expression  = "0.5*$T + 0.5*" + targetView.id;
         PBlend.expression  = parameters.opacity + "*$T + (1 - " + parameters.opacity + ")*I(" + targetView.id + ")";
         PBlend.useSingleExpression = true;
         PBlend.use64BitWorkingImage = false;
         PBlend.rescale = false;
         PBlend.rescaleLower = 0.0000000000;
         PBlend.rescaleUpper = 1.0000000000;
         PBlend.truncate = true;
         PBlend.truncateLower = 0.0000000000;
         PBlend.truncateUpper = 1.0000000000;
         PBlend.createNewImage = false;
         PBlend.executeOn(View.viewById(idI), false);
      }

      // Recombine H, S, and HDR'd I back to original image
      var PCombine = new ChannelCombination;
      PCombine.colorSpace = ChannelCombination.HSI;
      PCombine.channels = [ // enabled, id
         [true, idH],
         [true, idS],
         [true, idI]
      ];
      PCombine.executeOn(targetView, true);

      //targetView.image.statusEnabled = true;

      // Close temporary images
      var viewH = View.viewById(idH); viewH.window.close();
      var viewS = View.viewById(idS); viewS.window.close();
      var viewI = View.viewById(idI); viewI.window.forceClose();

   };


   this.execute = function()
   {
      this.executeColorCorrectedHDRMT( parameters.targetView );
   };
}

var process = new processPrototype();

function colorspaceIsValid( image )
{
   // grayscale is not a valid colorspace for this script
   return !image.isGrayscale;
}

function performChecksAndExecute()
{
   Console.noteln( "Applying ColorCorrectedHDRMT on target: ", ImageWindow.activeWindow.currentView.id );

   if ( !parameters.targetView || !parameters.targetView.image )
   {
      (new MessageBox(
         "<p>Error:<br><br>Undefined target view.</p>",
         TITLE,
         StdIcon.Warning,
         StdButton.Ok )).execute();
      return;
   }

   if ( !colorspaceIsValid( parameters.targetView.image ) )
   {
      (new MessageBox(
         "<p>Error:<br><br>Target view color space cannot be Grayscale.</p>",
         TITLE,
         StdIcon.Warning,
         StdButton.Ok )).execute();
      return;
   }

   process.execute();
}

function executeInGlobalContext()
{
   parameters.targetView = ImageWindow.activeWindow.currentView;
   parameters.getParameters();
   performChecksAndExecute();
}

function executeOnTargetView( view )
{
   parameters.targetView = view;
   parameters.getParameters();
   performChecksAndExecute();
}

function main()
{
   Console.hide();

   if ( Parameters.isGlobalTarget )
   {
      // Script has been launched in global context, execute and exit
      executeInGlobalContext();
      return;
   }

   if ( Parameters.isViewTarget )
   {
      // Script has been launched on a view target, execute and exit
      executeOnTargetView( Parameters.targetView );
      return;
   }

   // Prepare the dialog
   // (V8 fix: removed a duplicate `let parametersDialog = new
   // parametersDialogPrototype();` that used to be here. It built a whole
   // Dialog instance that was immediately discarded when the second
   // declaration below overwrote it -- redeclaring the same `let` binding
   // in one scope is a SyntaxError in V8, so the script couldn't have run
   // at all without this fix.)
   parameters.exit = false;

   if ( Parameters.isViewTarget && !Parameters.targetView )
   {
      // A target is already defined, init it as the target view
      parameters.targetView = Parameters.targetView;
      parameters.getParameters();
   }
   else
   {
      // Dialog needs to be opened in order to select the image and set parameters
      // Use the current active view as target by default
      parameters.targetView = ImageWindow.activeWindow.currentView;
   }

   // Run the dalog
   let parametersDialog = new parametersDialogPrototype();
   if ( !parametersDialog.execute() )
   {
      // Dialog closure forced
      return;
   }

   // do the job
   if ( !parameters.exit ) {
      Console.show();
      performChecksAndExecute();
      Console.hide();
   }
}

main();

// ----------------------------------------------------------------------------
// EOF ColorCorrectedHDRMT.js
