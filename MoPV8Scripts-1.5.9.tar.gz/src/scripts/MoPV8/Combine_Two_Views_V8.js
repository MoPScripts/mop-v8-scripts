#engine v8

/////////////////////////////////////////////////////////////////////////////
//
// Combine two views using custom PixelMath expression with Embedded Preview
// V8 / PixInsight 1.9.4+ rebuild
//
// Pete Proulx May 2025
// Masters of PixInsight
//
/////////////////////////////////////////////////////////////////////////////

#define TITLE "Combine Images with Enhanced Zoom Preview - Masters of PixInsight"
#define VERSION "V8 Rebuild 2026-05-14"

#feature-id CombineTwoViews : MoP V8> Combine Two Views
#feature-info A script to combine 2 Views with enhanced zoom preview - www.mastersofpixinsight.com

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

const DEFAULT_AUTOSTRETCH_SCLIP = -2.80;
const DEFAULT_AUTOSTRETCH_TBGND =  0.25;

let parameters = {
   view1Id: "",
   view2Id: "",
   operation: "Screen",
   blendAmount: 0.5,
   autoSTF: false,
   autoSTFLinked: false,
   save: function()
   {
      Parameters.set( "view1Id", this.view1Id );
      Parameters.set( "view2Id", this.view2Id );
      Parameters.set( "operation", this.operation );
      Parameters.set( "blendAmount", this.blendAmount );
      Parameters.set( "autoSTF", this.autoSTF );
      Parameters.set( "autoSTFLinked", this.autoSTFLinked );
   },
   load: function()
   {
      if ( Parameters.has( "view1Id" ) ) this.view1Id = Parameters.getString( "view1Id" );
      if ( Parameters.has( "view2Id" ) ) this.view2Id = Parameters.getString( "view2Id" );
      if ( Parameters.has( "operation" ) ) this.operation = Parameters.getString( "operation" );
      if ( Parameters.has( "blendAmount" ) ) this.blendAmount = Parameters.getReal( "blendAmount" );
      if ( Parameters.has( "autoSTF" ) ) this.autoSTF = Parameters.getBoolean( "autoSTF" );
      if ( Parameters.has( "autoSTFLinked" ) ) this.autoSTFLinked = Parameters.getBoolean( "autoSTFLinked" );
   }
};

function safeViewById( id )
{
   if ( !id ) return null;
   let v = View.viewById( id );
   return (v && !v.isNull) ? v : null;
}

function safeWindowById( id )
{
   if ( !id ) return null;
   let w = ImageWindow.windowById( id );
   return (w && !w.isNull) ? w : null;
}

function uniqueImageId( base )
{
   let id = base.replace( /[^A-Za-z0-9_]/g, "_" );
   if ( !/^[A-Za-z_]/.test( id ) ) id = "Combined_" + id;
   let out = id;
   let n = 1;
   while ( safeWindowById( out ) !== null || safeViewById( out ) !== null )
      out = id + "_" + n++;
   return out;
}

function expressionForOperation( view1, view2, operation, blendAmount )
{
   let v1 = view1.fullId;
   let v2 = view2.fullId;
   if ( operation === "Screen" )
      return "combine(" + v1 + ", " + v2 + ", op_screen())";
   if ( operation === "Add" )
      return v1 + " + " + v2;
   if ( operation === "Average" )
      return "(" + v1 + " + " + v2 + ") / 2";
   return "(1-" + blendAmount + ")*" + v1 + " + " + blendAmount + "*" + v2;
}

function operationSuffix( operation, blendAmount )
{
   if ( operation === "Blend" )
      return "Blend_" + Math.round( blendAmount * 100 );
   return operation;
}

// ============================================================================
// PreviewControl
// ============================================================================

class PreviewControl extends Frame
{
   constructor( parent )
   {
      super( parent );

      this.referenceView = null;
      this.NoImage = true;
      this.previewImage = null;
      this.bitmap = null;
      this.scaledImage = null;
      this.metadata = null;
      this.dragging = false;
      this.zooming = false;
      this.mousePressed = false;
      this.dragFrom = new Point( 0, 0 );
      this.dragTo = new Point( 0, 0 );
      this.scrolling = null;
      this.zoom = 1;
      this.scale = 1;
      this.zoomOutLimit = -5;
      this.refPoint = null;

      this.setScaledMinSize( 640, 480 );
      this.backgroundColor = 0xffd8d7d3;

      this.zoomIn_Button = new ToolButton( this );
      this.zoomIn_Button.icon = this.scaledResource( ":/icons/zoom-in.png" );
      this.zoomIn_Button.setScaledFixedSize( 20, 20 );
      this.zoomIn_Button.toolTip = "Zoom In";
      this.zoomIn_Button.onMousePress = () => { this.UpdateZoom( this.zoom + 1 ); };

      this.zoomOut_Button = new ToolButton( this );
      this.zoomOut_Button.icon = this.scaledResource( ":/icons/zoom-out.png" );
      this.zoomOut_Button.setScaledFixedSize( 20, 20 );
      this.zoomOut_Button.toolTip = "Zoom Out";
      this.zoomOut_Button.onMousePress = () => { this.UpdateZoom( this.zoom - 1 ); };

      this.zoom11_Button = new ToolButton( this );
      this.zoom11_Button.icon = this.scaledResource( ":/icons/zoom-1-1.png" );
      this.zoom11_Button.setScaledFixedSize( 20, 20 );
      this.zoom11_Button.toolTip = "Zoom 1:1";
      this.zoom11_Button.onMousePress = () => { this.UpdateZoom( 1 ); };

      this.buttons_Sizer = new HorizontalSizer;
      this.buttons_Sizer.margin = 4;
      this.buttons_Sizer.spacing = 4;
      this.buttons_Sizer.add( this.zoomIn_Button );
      this.buttons_Sizer.add( this.zoomOut_Button );
      this.buttons_Sizer.add( this.zoom11_Button );
      this.buttons_Sizer.addStretch();

      this.scrollbox = new ScrollBox( this );
      this.scrollbox.autoScroll = true;
      this.scrollbox.tracking = true;
      this.scrollbox.cursor = new Cursor( StdCursor.Cross );

      this.scroll_Sizer = new HorizontalSizer;
      this.scroll_Sizer.add( this.scrollbox, 1 );

      this.zoomLabel_Label = new Label( this );
      this.zoomLabel_Label.text = "Zoom:";
      this.zoomVal_Label = new Label( this );
      this.zoomVal_Label.text = "1:1";
      this.hintsLabel = new Label( this );
      this.hintsLabel.text = "Mouse wheel: Zoom • Shift+Drag: Zoom rectangle • Right click: Zoom to fit";

      this.hintsFrame = new Frame( this );
      this.hintsFrame.sizer = new HorizontalSizer;
      this.hintsFrame.sizer.margin = 4;
      this.hintsFrame.sizer.spacing = 4;
      this.hintsFrame.sizer.add( this.zoomLabel_Label );
      this.hintsFrame.sizer.add( this.zoomVal_Label );
      this.hintsFrame.sizer.addSpacing( 8 );
      this.hintsFrame.sizer.add( this.hintsLabel );
      this.hintsFrame.sizer.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.add( this.buttons_Sizer );
      this.sizer.add( this.scroll_Sizer, 1 );
      this.sizer.add( this.hintsFrame );

      this.scrollbox.onHorizontalScrollPosUpdated = () => { this.scrollbox.viewport.update(); };
      this.scrollbox.onVerticalScrollPosUpdated = () => { this.scrollbox.viewport.update(); };

      this.scrollbox.viewport.onMouseWheel = ( x, y, delta, buttons, modifiers ) =>
      {
         // PixInsight V8/FAME pattern: positive delta zooms in.
         this.UpdateZoom( this.zoom + (delta > 0 ? 1 : -1), new Point( x, y ) );
      };

      this.scrollbox.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
      {
         if ( button === 2 )
         {
            this.UpdateZoom( this.zoomOutLimit );
            this.mousePressed = false;
            this.scrolling = null;
            this.scrollbox.cursor = new Cursor( StdCursor.Cross );
            return;
         }

         // Shift key is reported as 1 in current V8 examples.
         if ( modifiers === 1 )
         {
            if ( this.zoom <= 0 )
            {
               this.mousePressed = true;
               this.dragFrom = new Point( x, y );
               this.dragTo = new Point( x, y );
               this.scrollbox.cursor = new Cursor( StdCursor.Cross );
            }
         }
         else
         {
            this.scrollbox.cursor = new Cursor( StdCursor.ClosedHand );
            this.scrolling = {
               orgCursor: new Point( x, y ),
               orgScroll: new Point( this.scrollbox.horizontalScrollPosition, this.scrollbox.verticalScrollPosition )
            };
         }
      };

      this.scrollbox.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
      {
         if ( this.mousePressed )
         {
            this.dragTo = new Point( x, y );
            this.zooming = true;
            this.scrollbox.viewport.update();
            return;
         }

         if ( this.scrolling )
         {
            this.scrollbox.horizontalScrollPosition = this.scrolling.orgScroll.x - (x - this.scrolling.orgCursor.x);
            this.scrollbox.verticalScrollPosition = this.scrolling.orgScroll.y - (y - this.scrolling.orgCursor.y);
            this.scrollbox.cursor = new Cursor( StdCursor.ClosedHand );
         }
      };

      this.scrollbox.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
      {
         if ( this.mousePressed )
         {
            if ( this.getDragRect().area > 0 )
               this.SetZoomRect( this.getDragRect() );
            this.dragFrom = new Point( 0, 0 );
            this.dragTo = new Point( 0, 0 );
         }
         else if ( this.scrolling )
         {
            this.scrollbox.horizontalScrollPosition = this.scrolling.orgScroll.x - (x - this.scrolling.orgCursor.x);
            this.scrollbox.verticalScrollPosition = this.scrolling.orgScroll.y - (y - this.scrolling.orgCursor.y);
         }

         this.scrolling = null;
         this.scrollbox.cursor = new Cursor( StdCursor.Cross );
         this.mousePressed = false;
         this.dragging = false;
         this.zooming = false;
         this.scrollbox.viewport.update();
      };

      this.scrollbox.viewport.onResize = ( wNew, hNew, wOld, hOld ) =>
      {
         if ( this.metadata && this.scaledImage )
         {
            this.scrollbox.maxHorizontalScrollPosition = Math.max( 0, this.scaledImage.width - wNew );
            this.scrollbox.maxVerticalScrollPosition = Math.max( 0, this.scaledImage.height - hNew );
            this.SetZoomOutLimit();
            this.UpdateZoom( this.zoom );
         }
         this.mousePressed = false;
         this.scrolling = null;
         this.scrollbox.cursor = new Cursor( StdCursor.Cross );
         this.scrollbox.viewport.update();
      };

      this.scrollbox.viewport.onPaint = ( x0, y0, x1, y1 ) =>
      {
         let graphics = new Graphics( this.scrollbox.viewport );
         graphics.fillRect( x0, y0, x1, y1, new Brush( 0xff303030 ) );

         if ( !this.NoImage )
         {
            if ( this.scaledImage !== null )
            {
               let offsetX = (this.scrollbox.maxHorizontalScrollPosition > 0) ?
                  -this.scrollbox.horizontalScrollPosition : (this.scrollbox.viewport.width - this.scaledImage.width) / 2;
               let offsetY = (this.scrollbox.maxVerticalScrollPosition > 0) ?
                  -this.scrollbox.verticalScrollPosition : (this.scrollbox.viewport.height - this.scaledImage.height) / 2;
               graphics.translateTransformation( offsetX, offsetY );
            }

            if ( this.bitmap && this.scaledImage )
               graphics.drawBitmap( 0, 0, this.scaledImage );
            else if ( this.scaledImage )
               graphics.fillRect( 0, 0, this.scaledImage.width, this.scaledImage.height, new Brush( 0xff000000 ) );

            graphics.pen = new Pen( 0xffffffff, 0 );
            if ( this.scaledImage )
               graphics.drawRect( -1, -1, this.scaledImage.width + 1, this.scaledImage.height + 1 );
         }

         if ( this.mousePressed )
         {
            graphics.resetTransformation();
            graphics.fillRect( this.getDragRect(), new Brush( 0x20ffffff ) );
         }

         graphics.end();
      };
   }

   SetPreview( bitmap, view, metadata )
   {
      this.previewImage = bitmap;
      this.bitmap = bitmap;
      this.referenceView = view;
      this.metadata = metadata;
      this.NoImage = false;
      this.scaledImage = null;
      this.SetZoomOutLimit();
      this.UpdateZoom( this.zoom );
   }

   scaleImage( scale )
   {
      if ( this.bitmap !== null && this.bitmap !== undefined )
         return this.bitmap.scaled( scale );
      return null;
   }

   SetZoomOutLimit()
   {
      if ( this.metadata !== null && this.scrollbox.viewport.width > 0 && this.scrollbox.viewport.height > 0 )
      {
         let scaleX = Math.ceil( this.metadata.width / this.scrollbox.viewport.width );
         let scaleY = Math.ceil( this.metadata.height / this.scrollbox.viewport.height );
         let scale = Math.max( scaleX, scaleY );
         this.zoomOutLimit = -scale + 2;
      }
   }

   UpdateZoom( newZoom, refPoint )
   {
      newZoom = Math.max( this.zoomOutLimit, Math.min( 10, newZoom ) );
      if ( newZoom === this.zoom && this.scaledImage ) return;

      if ( refPoint == null )
         refPoint = new Point( this.scrollbox.viewport.width / 2, this.scrollbox.viewport.height / 2 );

      let imgx = null;
      if ( this.scrollbox.maxHorizontalScrollPosition > 0 )
         imgx = (refPoint.x + this.scrollbox.horizontalScrollPosition) / this.scale;
      let imgy = null;
      if ( this.scrollbox.maxVerticalScrollPosition > 0 )
         imgy = (refPoint.y + this.scrollbox.verticalScrollPosition) / this.scale;

      this.zoom = newZoom;
      this.scaledImage = null;
      // V8 fix (Rule 28): gc(true) removed -- deprecated, V8 handles GC
      // automatically. Missed in the original review pass because that
      // scan only matched empty gc() calls, not gc(true).

      if ( this.zoom > 0 )
      {
         this.scale = this.zoom;
         this.zoomVal_Label.text = format( "%d:1", this.zoom );
      }
      else
      {
         this.scale = 1 / (-this.zoom + 2);
         this.zoomVal_Label.text = format( "1:%d", -this.zoom + 2 );
      }

      if ( this.bitmap )
         this.scaledImage = this.scaleImage( this.scale );
      else if ( this.metadata )
         this.scaledImage = { width: this.metadata.width * this.scale, height: this.metadata.height * this.scale };

      if ( this.scaledImage )
      {
         this.scrollbox.maxHorizontalScrollPosition = Math.max( 0, this.scaledImage.width - this.scrollbox.viewport.width );
         this.scrollbox.maxVerticalScrollPosition = Math.max( 0, this.scaledImage.height - this.scrollbox.viewport.height );
      }

      if ( this.scrollbox.maxHorizontalScrollPosition > 0 && imgx !== null )
         this.scrollbox.horizontalScrollPosition = (imgx * this.scale) - refPoint.x;
      if ( this.scrollbox.maxVerticalScrollPosition > 0 && imgy !== null )
         this.scrollbox.verticalScrollPosition = (imgy * this.scale) - refPoint.y;

      this.scrollbox.viewport.update();
   }

   forceRedraw()
   {
      this.scrollbox.viewport.update();
   }

   getDragRect()
   {
      let dX0 = Math.min( this.dragFrom.x, this.dragTo.x );
      let dY0 = Math.min( this.dragFrom.y, this.dragTo.y );
      let dX1 = Math.max( this.dragFrom.x, this.dragTo.x );
      let dY1 = Math.max( this.dragFrom.y, this.dragTo.y );
      return new Rect( dX0, dY0, dX1, dY1 );
   }

   SetZoomRect( rect )
   {
      let scaleX = Math.ceil( rect.width / this.scrollbox.viewport.width );
      let scaleY = Math.ceil( rect.height / this.scrollbox.viewport.height );
      let scale = Math.max( scaleX, scaleY );
      this.UpdateZoom( Math.max( this.zoomOutLimit, Math.min( 10, scale ) ) );
   }
}

// ============================================================================
// Main Dialog
// ============================================================================

class ScreenCombineImagesDialog extends Dialog
{
   constructor()
   {
      super();
      parameters.load();

      this.windowTitle = "Combine Views with Preview - Masters of PixInsight";

      const uiMargin = 8;
      const labelWidth = 100;
      const comboBoxWidth = 400;
      const previewSize = 786;

      let controlsSizer = new VerticalSizer;
      controlsSizer.spacing = uiMargin;

      let titleLabel = new Label( this );
      titleLabel.text = "Combine Views with Preview";
      titleLabel.textAlignment = TextAlignment.Center;
      titleLabel.styleSheet = "font-weight: bold; font-size: 16px; padding: 8px;";
      controlsSizer.add( titleLabel );

      let websiteLabel = new Label( this );
      websiteLabel.text = "www.mastersofpixinsight.com";
      websiteLabel.textAlignment = TextAlignment.Center;
      websiteLabel.styleSheet = "font-size: 12px; padding: 4px;";
      controlsSizer.add( websiteLabel );

      let instructionsGroupBox = new GroupBox( this );
      instructionsGroupBox.title = "How This Script Works";
      instructionsGroupBox.titleCheckBox = false;

      let instructionsText = new Label( this );
      instructionsText.text =
         "This script combines two open Views using PixelMath operations:\n\n" +
         "• Select two Views from the dropdown menus below\n" +
         "• Choose your blending operation: Screen, Add, Average, or Blend\n" +
         "• Preview updates automatically when you change operations or Views\n" +
         "• Adjust the blend slider and click Refresh Preview to see changes\n" +
         "• Click Execute to create the final combined image\n\n" +
         "Preview controls:\n" +
         "• Mouse wheel zooming up to 10:1\n" +
         "• Shift+Drag for zoom rectangle selection\n" +
         "• Right-click to zoom to fit\n\n" +
         "Both Views must be open in PixInsight.";
      instructionsText.wordWrap = true;
      instructionsText.textAlignment = TextAlignment.Left;
      instructionsText.styleSheet = "line-height: 1.4;";

      let instructionsSizer = new VerticalSizer;
      instructionsSizer.margin = 8;
      instructionsSizer.add( instructionsText );
      instructionsGroupBox.sizer = instructionsSizer;
      controlsSizer.add( instructionsGroupBox );

      let imageGroupBox = new GroupBox( this );
      imageGroupBox.title = "Select Views to Combine";
      imageGroupBox.titleCheckBox = false;

      let views_Sizer = new VerticalSizer;
      views_Sizer.margin = 8;
      views_Sizer.spacing = uiMargin;

      let view1_Sizer = new HorizontalSizer;
      let view1_Label = new Label( this );
      view1_Label.text = "First View:";
      view1_Label.setFixedWidth( labelWidth );
      view1_Label.styleSheet = "font-weight: bold;";
      this.view1_ComboBox = new ComboBox( this );
      this.view1_ComboBox.setFixedWidth( comboBoxWidth );
      this.view1_ComboBox.onItemSelected = index => { this.updateSelectionsFromUI(); this.updatePreview(); };
      view1_Sizer.add( view1_Label );
      view1_Sizer.add( this.view1_ComboBox );
      views_Sizer.add( view1_Sizer );

      let view2_Sizer = new HorizontalSizer;
      let view2_Label = new Label( this );
      view2_Label.text = "Second View:";
      view2_Label.setFixedWidth( labelWidth );
      view2_Label.styleSheet = "font-weight: bold;";
      this.view2_ComboBox = new ComboBox( this );
      this.view2_ComboBox.setFixedWidth( comboBoxWidth );
      this.view2_ComboBox.onItemSelected = index => { this.updateSelectionsFromUI(); this.updatePreview(); };
      view2_Sizer.add( view2_Label );
      view2_Sizer.add( this.view2_ComboBox );
      views_Sizer.add( view2_Sizer );

      this.populateViewLists();

      this.autoSTF_CheckBox = new CheckBox( this );
      this.autoSTF_CheckBox.text = "Apply AutoSTF to preview";
      this.autoSTF_CheckBox.checked = parameters.autoSTF;
      this.autoSTF_CheckBox.styleSheet = "font-weight: bold;";
      this.autoSTF_CheckBox.onCheck = checked =>
      {
         this.autoSTFLinked_RadioButton.enabled = checked;
         this.autoSTFUnlinked_RadioButton.enabled = checked;
         this.updateSelectionsFromUI();
         this.updatePreview();
      };
      views_Sizer.add( this.autoSTF_CheckBox );

      let autoSTFMode_Sizer = new HorizontalSizer;
      autoSTFMode_Sizer.margin = 20;
      autoSTFMode_Sizer.spacing = 12;

      this.autoSTFLinked_RadioButton = new RadioButton( this );
      this.autoSTFLinked_RadioButton.text = "Linked";
      this.autoSTFLinked_RadioButton.checked = parameters.autoSTFLinked;
      this.autoSTFLinked_RadioButton.enabled = this.autoSTF_CheckBox.checked;
      this.autoSTFLinked_RadioButton.onCheck = checked => { if ( checked ) { this.updateSelectionsFromUI(); this.updatePreview(); } };
      autoSTFMode_Sizer.add( this.autoSTFLinked_RadioButton );

      this.autoSTFUnlinked_RadioButton = new RadioButton( this );
      this.autoSTFUnlinked_RadioButton.text = "Unlinked";
      this.autoSTFUnlinked_RadioButton.checked = !parameters.autoSTFLinked;
      this.autoSTFUnlinked_RadioButton.enabled = this.autoSTF_CheckBox.checked;
      this.autoSTFUnlinked_RadioButton.onCheck = checked => { if ( checked ) { this.updateSelectionsFromUI(); this.updatePreview(); } };
      autoSTFMode_Sizer.add( this.autoSTFUnlinked_RadioButton );
      autoSTFMode_Sizer.addStretch();
      views_Sizer.add( autoSTFMode_Sizer );

      imageGroupBox.sizer = views_Sizer;
      controlsSizer.add( imageGroupBox );

      let operation_GroupBox = new GroupBox( this );
      operation_GroupBox.title = "Operation";
      operation_GroupBox.titleCheckBox = false;

      let operation_MainSizer = new VerticalSizer;
      operation_MainSizer.margin = 8;
      operation_MainSizer.spacing = 6;

      let operation_Sizer = new HorizontalSizer;
      operation_Sizer.spacing = 8;

      this.operation_RadioButton1 = new RadioButton( this );
      this.operation_RadioButton1.text = "Screen";
      this.operation_RadioButton1.checked = parameters.operation === "Screen";
      this.operation_RadioButton1.styleSheet = "font-weight: bold;";
      this.operation_RadioButton1.onCheck = checked => { if ( checked ) { this.updateSelectionsFromUI(); this.updatePreview(); } };
      operation_Sizer.add( this.operation_RadioButton1 );

      this.operation_RadioButton2 = new RadioButton( this );
      this.operation_RadioButton2.text = "Add";
      this.operation_RadioButton2.checked = parameters.operation === "Add";
      this.operation_RadioButton2.styleSheet = "font-weight: bold;";
      this.operation_RadioButton2.onCheck = checked => { if ( checked ) { this.updateSelectionsFromUI(); this.updatePreview(); } };
      operation_Sizer.add( this.operation_RadioButton2 );

      this.operation_RadioButton3 = new RadioButton( this );
      this.operation_RadioButton3.text = "Average";
      this.operation_RadioButton3.checked = parameters.operation === "Average";
      this.operation_RadioButton3.styleSheet = "font-weight: bold;";
      this.operation_RadioButton3.onCheck = checked => { if ( checked ) { this.updateSelectionsFromUI(); this.updatePreview(); } };
      operation_Sizer.add( this.operation_RadioButton3 );

      this.operation_RadioButton4 = new RadioButton( this );
      this.operation_RadioButton4.text = "Blend";
      this.operation_RadioButton4.checked = parameters.operation === "Blend";
      this.operation_RadioButton4.styleSheet = "font-weight: bold;";
      this.operation_RadioButton4.onCheck = checked => { if ( checked ) { this.updateSelectionsFromUI(); this.updatePreview(); } };
      operation_Sizer.add( this.operation_RadioButton4 );

      if ( !this.operation_RadioButton1.checked && !this.operation_RadioButton2.checked &&
           !this.operation_RadioButton3.checked && !this.operation_RadioButton4.checked )
         this.operation_RadioButton1.checked = true;

      operation_MainSizer.add( operation_Sizer );

      let operationHelpText = new Label( this );
      operationHelpText.text = "Screen: Rescreen Stars • Add: Simple addition • Average: 50/50 mix • Blend: Custom ratio";
      operationHelpText.wordWrap = true;
      operationHelpText.styleSheet = "font-style: italic; font-size: 11px;";
      operation_MainSizer.add( operationHelpText );

      operation_GroupBox.sizer = operation_MainSizer;
      controlsSizer.add( operation_GroupBox );

      let blendGroupBox = new GroupBox( this );
      blendGroupBox.title = "Blend Amount (for Blend operation only)";
      blendGroupBox.titleCheckBox = false;

      let blend_MainSizer = new VerticalSizer;
      blend_MainSizer.margin = 8;
      blend_MainSizer.spacing = 6;

      this.blendAmount_NumericControl = new NumericControl( this );
      this.blendAmount_NumericControl.label.text = "Blend amount:";
      this.blendAmount_NumericControl.label.setFixedWidth( labelWidth );
      this.blendAmount_NumericControl.setRange( 0.0, 1.0 );
      this.blendAmount_NumericControl.slider.setRange( 0, 100 );
      this.blendAmount_NumericControl.setPrecision( 2 );
      this.blendAmount_NumericControl.setValue( parameters.blendAmount );
      this.blendAmount_NumericControl.setFixedWidth( comboBoxWidth + labelWidth );
      this.blendAmount_NumericControl.onValueUpdated = value => { this.updateSelectionsFromUI(); };
      blend_MainSizer.add( this.blendAmount_NumericControl );

      let blendHelpText = new Label( this );
      blendHelpText.text = "0.0 = Pure first view • 0.5 = Equal mix • 1.0 = Pure second view\nClick Refresh Preview after adjusting the slider.";
      blendHelpText.styleSheet = "font-style: italic; font-size: 11px;";
      blend_MainSizer.add( blendHelpText );

      this.preview_Button = new PushButton( this );
      this.preview_Button.text = "Refresh Preview";
      this.preview_Button.styleSheet = "font-weight: bold; padding: 6px 12px;";
      this.preview_Button.onClick = () => { this.updateSelectionsFromUI(); this.updatePreview(); };

      let previewButton_Sizer = new HorizontalSizer;
      previewButton_Sizer.addStretch();
      previewButton_Sizer.add( this.preview_Button );
      previewButton_Sizer.addStretch();
      blend_MainSizer.add( previewButton_Sizer );

      blendGroupBox.sizer = blend_MainSizer;
      controlsSizer.add( blendGroupBox );

      let buttons_Sizer = new HorizontalSizer;
      buttons_Sizer.spacing = 10;

      this.newInstanceButton = new ToolButton( this );
      this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
      this.newInstanceButton.setScaledFixedSize( 24, 24 );
      this.newInstanceButton.toolTip = "Create Process Icon - Drag to save current settings";
      this.newInstanceButton.onMousePress = () => { this.updateSelectionsFromUI(); parameters.save(); this.newInstance(); };
      buttons_Sizer.add( this.newInstanceButton );
      buttons_Sizer.addSpacing( 20 );

      this.ok_Button = new PushButton( this );
      this.ok_Button.text = "Execute";
      this.ok_Button.icon = this.scaledResource( ":/icons/ok.png" );
      this.ok_Button.styleSheet = "font-weight: bold; padding: 6px 12px;";
      this.ok_Button.onClick = () => { this.executeCombination(); };
      buttons_Sizer.add( this.ok_Button );

      this.cancel_Button = new PushButton( this );
      this.cancel_Button.text = "Cancel";
      this.cancel_Button.icon = this.scaledResource( ":/icons/cancel.png" );
      this.cancel_Button.onClick = () => { this.cancel(); };
      buttons_Sizer.add( this.cancel_Button );

      controlsSizer.add( buttons_Sizer );

      this.previewControl = new PreviewControl( this );
      this.previewControl.setFixedSize( previewSize, previewSize );
      this.previewControl.toolTip = "Enhanced Preview with 10:1 zoom, mouse wheel support, and zoom rectangle";
      this.previewControl.metadata = { width: previewSize, height: previewSize };

      let mainSizer = new HorizontalSizer;
      mainSizer.spacing = uiMargin;
      mainSizer.add( controlsSizer );
      mainSizer.add( this.previewControl );

      this.sizer = new VerticalSizer;
      this.sizer.margin = uiMargin;
      this.sizer.spacing = uiMargin;
      this.sizer.add( mainSizer );

      this.adjustToContents();

      this.onShow = () => { this.updatePreview(); };
   }

   populateViewLists()
   {
      let selected1 = parameters.view1Id;
      let selected2 = parameters.view2Id;
      let windows = ImageWindow.windows;

      for ( let i = 0; i < windows.length; ++i )
      {
         let id = String( windows[i].mainView.id );
         this.view1_ComboBox.addItem( id );
         this.view2_ComboBox.addItem( id );
         if ( id === selected1 ) this.view1_ComboBox.currentItem = i;
         if ( id === selected2 ) this.view2_ComboBox.currentItem = i;
      }

      if ( windows.length > 0 && this.view1_ComboBox.currentItem < 0 ) this.view1_ComboBox.currentItem = 0;
      if ( windows.length > 1 && this.view2_ComboBox.currentItem < 0 ) this.view2_ComboBox.currentItem = 1;
      else if ( windows.length > 0 && this.view2_ComboBox.currentItem < 0 ) this.view2_ComboBox.currentItem = 0;
   }

   getOperation()
   {
      if ( this.operation_RadioButton2.checked ) return "Add";
      if ( this.operation_RadioButton3.checked ) return "Average";
      if ( this.operation_RadioButton4.checked ) return "Blend";
      return "Screen";
   }

   updateSelectionsFromUI()
   {
      if ( this.view1_ComboBox.currentItem >= 0 ) parameters.view1Id = this.view1_ComboBox.itemText( this.view1_ComboBox.currentItem );
      if ( this.view2_ComboBox.currentItem >= 0 ) parameters.view2Id = this.view2_ComboBox.itemText( this.view2_ComboBox.currentItem );
      parameters.operation = this.getOperation();
      parameters.blendAmount = this.blendAmount_NumericControl.value;
      parameters.autoSTF = this.autoSTF_CheckBox.checked;
      parameters.autoSTFLinked = this.autoSTFLinked_RadioButton.checked;
   }

   copyView( view, newName )
   {
      let win = new ImageWindow( view.image.width, view.image.height,
                                view.image.numberOfChannels,
                                view.image.bitsPerSample, view.image.isReal,
                                view.image.isColor,
                                newName );
      win.hide();
      win.mainView.beginProcess( UndoFlag.NoSwapFile );
      win.mainView.image.assign( view.image );
      win.mainView.endProcess();
      return win.mainView;
   }

   applyAutoSTF( view, shadowsClipping, targetBackground, rgbLinked )
   {
      let stf = new ScreenTransferFunction;
      let n = view.image.isColor ? 3 : 1;
      let median = view.computeOrFetchProperty( "Median" );
      let mad = view.computeOrFetchProperty( "MAD" );
      mad.mul( 1.4826 );

      if ( rgbLinked )
      {
         let invertedChannels = 0;
         for ( let c = 0; c < n; ++c )
            if ( median.at( c ) > 0.5 ) ++invertedChannels;

         if ( invertedChannels < n )
         {
            let c0 = 0, m = 0;
            for ( let c = 0; c < n; ++c )
            {
               if ( 1 + mad.at( c ) !== 1 ) c0 += median.at( c ) + shadowsClipping * mad.at( c );
               m += median.at( c );
            }
            c0 = Math.range( c0/n, 0.0, 1.0 );
            m = Math.mtf( targetBackground, m/n - c0 );
            stf.STF = [[c0,1,m,0,1],[c0,1,m,0,1],[c0,1,m,0,1],[0,1,0.5,0,1]];
         }
         else
         {
            let c1 = 0, m = 0;
            for ( let c = 0; c < n; ++c )
            {
               m += median.at( c );
               if ( 1 + mad.at( c ) !== 1 ) c1 += median.at( c ) - shadowsClipping * mad.at( c );
               else c1 += 1;
            }
            c1 = Math.range( c1/n, 0.0, 1.0 );
            m = Math.mtf( c1 - m/n, targetBackground );
            stf.STF = [[0,c1,m,0,1],[0,c1,m,0,1],[0,c1,m,0,1],[0,1,0.5,0,1]];
         }
      }
      else
      {
         let A = [[0,1,0.5,0,1],[0,1,0.5,0,1],[0,1,0.5,0,1],[0,1,0.5,0,1]];
         for ( let c = 0; c < n; ++c )
         {
            if ( median.at( c ) < 0.5 )
            {
               let c0 = (1 + mad.at( c ) !== 1) ? Math.range( median.at( c ) + shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 0.0;
               let m = Math.mtf( targetBackground, median.at( c ) - c0 );
               A[c] = [c0, 1, m, 0, 1];
            }
            else
            {
               let c1 = (1 + mad.at( c ) !== 1) ? Math.range( median.at( c ) - shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 1.0;
               let m = Math.mtf( c1 - median.at( c ), targetBackground );
               A[c] = [0, c1, m, 0, 1];
            }
         }
         stf.STF = A;
      }
      stf.executeOn( view );
   }

   applyHistogram( view )
   {
      let stf = view.stf;
      let H = [[0,0.0,1.0,0,1.0],[0,0.5,1.0,0,1.0],[0,0.5,1.0,0,1.0],[0,0.5,1.0,0,1.0],[0,0.5,1.0,0,1.0]];
      if ( view.image.isColor )
      {
         for ( let c = 0; c < 3; c++ )
         {
            H[c][0] = stf[c][1];
            H[c][1] = stf[c][0];
         }
      }
      else
      {
         H[3][0] = stf[0][1];
         H[3][1] = stf[0][0];
      }

      let STF = new ScreenTransferFunction;
      view.stf = [[0,1,0.5,0,1],[0,1,0.5,0,1],[0,1,0.5,0,1],[0,1,0.5,0,1]];
      STF.executeOn( view );

      let HT = new HistogramTransformation;
      HT.H = H;
      HT.executeOn( view );
   }

   getWindowBmp( view )
   {
      let image = view.image;
      image.firstSelectedChannel = 0;
      image.lastSelectedChannel = image.numberOfChannels - 1;
      return image.render();
   }

   updatePreview()
   {
      try
      {
         if ( this.view1_ComboBox.currentItem < 0 || this.view2_ComboBox.currentItem < 0 ) return;

         let view1 = safeViewById( this.view1_ComboBox.itemText( this.view1_ComboBox.currentItem ) );
         let view2 = safeViewById( this.view2_ComboBox.itemText( this.view2_ComboBox.currentItem ) );
         if ( view1 === null || view2 === null ) return;

         let operation = this.getOperation();
         let blendAmount = this.blendAmount_NumericControl.value;
         let pm = new PixelMath;
         pm.expression = expressionForOperation( view1, view2, operation, blendAmount );
         pm.useSingleExpression = true;
         pm.createNewImage = true;
         pm.showNewImage = false;
         pm.newImageId = uniqueImageId( "PreviewCombinedImage" );
         pm.executeOn( view1 );

         let previewWindow = safeWindowById( pm.newImageId );
         if ( previewWindow !== null )
         {
            let previewView = previewWindow.mainView;
            if ( this.autoSTF_CheckBox.checked )
            {
               this.applyAutoSTF( previewView, DEFAULT_AUTOSTRETCH_SCLIP, DEFAULT_AUTOSTRETCH_TBGND, this.autoSTFLinked_RadioButton.checked );
               this.applyHistogram( previewView );
            }

            let previewBmp = this.getWindowBmp( previewView );
            let metadata = { width: previewView.image.width, height: previewView.image.height };
            this.previewControl.SetPreview( previewBmp, view1, metadata );
            this.previewControl.UpdateZoom( this.previewControl.zoomOutLimit );
            previewWindow.forceClose();
         }
      }
      catch ( error )
      {
         Console.writeln( "Preview update error: " + error.toString() );
      }
   }

   executeCombination()
   {
      this.updateSelectionsFromUI();
      parameters.save();

      let view1 = safeViewById( parameters.view1Id );
      let view2 = safeViewById( parameters.view2Id );
      if ( view1 === null || view2 === null )
      {
         new MessageBox( "One or both selected Views are not valid.", TITLE, StdIcon.Error, StdButton.Ok ).execute();
         return;
      }

      try
      {
         let operationName = operationSuffix( parameters.operation, parameters.blendAmount );
         let expressionText = expressionForOperation( view1, view2, parameters.operation, parameters.blendAmount );
         let newImageId = uniqueImageId( operationName + "_CombinedImage" );

         let combinationTool = new PixelMath;
         combinationTool.expression = expressionText;
         combinationTool.useSingleExpression = true;
         combinationTool.createNewImage = true;
         combinationTool.showNewImage = true;
         combinationTool.newImageId = newImageId;
         combinationTool.executeOn( view1 );

         Console.writeln( "════════════════════════════════════════" );
         Console.writeln( "IMAGE COMBINATION COMPLETE - MASTERS OF PIXINSIGHT" );
         Console.writeln( "════════════════════════════════════════" );
         Console.writeln( "Successfully created: " + newImageId );
         Console.writeln( "Operation: " + parameters.operation );
         Console.writeln( "════════════════════════════════════════" );

         let combinedWindow = safeWindowById( newImageId );
         if ( combinedWindow !== null ) combinedWindow.show();
         this.ok();
      }
      catch ( error )
      {
         Console.writeln( "════════════════════════════════════════" );
         Console.writeln( "COMBINATION ERROR" );
         Console.writeln( "════════════════════════════════════════" );
         Console.writeln( "Error creating combined image: " + error.toString() );
         Console.writeln( "════════════════════════════════════════" );
         new MessageBox( "Error creating combined image:\n\n" + error.toString(), TITLE, StdIcon.Error, StdButton.Ok ).execute();
      }
   }
}

function main()
{
   Console.show();
   if ( ImageWindow.windows.length < 2 )
   {
      Console.writeln( "════════════════════════════════════════" );
      Console.writeln( "INSUFFICIENT VIEWS ERROR" );
      Console.writeln( "════════════════════════════════════════" );
      Console.writeln( "There must be at least two open Views to combine." );
      Console.writeln( "════════════════════════════════════════" );
      new MessageBox( "There must be at least two open images to combine.", TITLE, StdIcon.Error, StdButton.Ok ).execute();
      return;
   }

   let dialog = new ScreenCombineImagesDialog();
   dialog.execute();
}

main();
