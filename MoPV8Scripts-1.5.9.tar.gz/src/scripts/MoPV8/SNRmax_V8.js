/*

SNRmax.js: Find image with best SNR
================================================================================

Sucht das Bild mit dem höchstem Signal-Rauschabstand aus einer Auswahl von
Bildern. Der Name des Files mit dem besten Wert kann danach bei der
ImageIntegration als Referenzbild ausgewählt werden.

Searches the image with the highest signal-to-noise ratio from a selection of
images. The name of the file with the best value can then be selected in the
Image Integration as a reference image.
================================================================================

 * * SNRmax
 *
 * Find file with max SNR
 *
 * Input:   fit-files
 *
 * Output:  the filename with maximum SNR found
 *
 * Copyright (C) 2014, Hartmut V. Bornemann
 *
 * Version history
 *          1.0    2014-10-08 first release
*/

#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Hartmut V. Bornemann.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; removed all
// #include <pjsr/...> directives (PJSR globals available without them);
// converted both SNRmaxDialog and helpdlg from __base__/.prototype = new
// Dialog to class extends Dialog / super(); replaced TextAlign_Center /
// TextAlign_Left / FrameStyle_Box with dot notation; replaced the legacy
// `for each (var v in results)` loop with `for (var v of results)`
// (for-each-in was a non-standard Mozilla extension V8 never supported,
// so this would have thrown a SyntaxError on parse); fixed the sort()
// comparator, which returned a boolean instead of a number; replaced the
// bare processEvents() call with CoreApplication.processEvents().
//
// Expanded 24 with() blocks total across both dialogs (20 in
// SNRmaxDialog, 4 in helpdlg) -- these needed careful hand-checking, not
// just mechanical prefixing. SNRmaxDialog uses several bare single-letter
// variables (x, y, h, maxx) declared in the outer constructor scope to
// track cumulative layout position across many controls, and those same
// names (e.g. "height") also happen to be real Control properties. A
// bare `with()` block resolves an identifier against the target object
// first and only falls through to the enclosing scope if the target
// doesn't have that property -- so `maxx = frameRect.right` inside
// with(btnAdd) reads the real btnAdd.frameRect property but assigns to
// the OUTER maxx variable, not a new btnAdd.maxx property. Blindly
// prefixing every bare identifier with the with-target gets this wrong
// in both directions -- turning outer-variable assignments into stray
// new properties on the control instead, while properties genuinely
// read off the control (like a bare "height" in `resize(150, height)`)
// need the target prefix added or they're left dangling once the with()
// wrapper is gone. Every line was checked individually against the
// actual outer-scope var declarations (x, y, h, maxx near the top of
// SNRmaxDialog) rather than assuming a single mechanical rule.
//
// One small discretionary change, not V8-required: helpdlg's OK button
// used `this.parent.ok()` to reach the dialog; changed to the more
// standard `this.dialog.ok()` used everywhere else in this codebase.
// Functionally equivalent here (OK_Button's parent at construction is
// the dialog itself), but .dialog is the safer, nesting-independent
// convention -- happy to revert if you'd rather keep it as written.
//
// 2026-08-05: two fixes found via user testing. (1) My own splicing
// mistake during the port: SNREvaluation, frameData, NoiseEvaluation,
// and ReadImageFile got dropped entirely -- the text range I replaced
// to convert SNRmaxDialog to a class accidentally spanned these four
// helper functions too, since they sat between the old
// "function SNRmaxDialog()" and "SNRmaxDialog.prototype = new Dialog;"
// markers in the original file. Re-added them verbatim (they needed no
// V8 changes of their own). (2) OpenFileDialog.fileNames is also
// deprecated in V8 (same as the singular .fileName from Rule 30) --
// fixed to .filePaths.
//
// 2026-08-06: two requested changes, not V8-related. (1) Default file
// filter in the Add Files dialog changed from FITS to XISF (also fixed
// "XIFS" -> "XISF" typo in the filter label). (2) ReadImageFile() used
// to reject any file containing more than one embedded image outright.
// That broke on autocrop XISF output, which legitimately stores a
// crop_mask alongside the main light. Now reads the first embedded
// image (the main light, per file order) and ignores the rest instead
// of erroring.
// ----------------------------------------------------------------------------

#feature-id SNRmax : MoP V8 > SNRmax

#define StdCursor_ArrowQuestion 17

#define TITLE "SNRmax"
#define VERSION "1.1.0"

#feature-info Find file with max SNR.<br>\
   <br>\Written by Hartmut V. Bornemann.<br>\
   <br>\
   References: None<br>\
   <br>\
#define strict 0

//////////////////////////////////////////////////////////////////////////////
//
// Find file with max SNR Dialog
//
//////////////////////////////////////////////////////////////////////////////


class SNRmaxDialog extends Dialog
{
constructor()
{
   super();

   var dlg = this;
   var closing = false;
   var column = 0;
   var maxx;
   var maxFile;
   var h = 24;
   var defaultProcess = "<default>";
   var processIcon = defaultProcess;

   /*
      begin: FileSelection
   */

   var tbx = new TreeBox(this);
   //
   // create a treebox with 2 columns
   // column 0 contains filenames
   // column 1 contains the full path
   //
   tbx.numberOfColumns = 2;
   tbx.position = new Point(8, 8);
   tbx.rootDecoration = false;
   tbx.height = 240;
   tbx.width  = 400;
   tbx.multipleSelection = true;
   tbx.setHeaderText(0, "Files");
   tbx.setHeaderText(1, "Full Path and FileNames");
   tbx.hideColumn(1);
   tbx.onNodeClicked = function( item, columnIndex )
   {
      enableButtons(false);
   }

   var x = tbx.frameRect.right + 8;
   var y = tbx.frameRect.top;

   var btnAdd = new PushButton(this);
   btnAdd.text = "Add Files";
   btnAdd.position = new Point(x, y);
   btnAdd.resize( 150 , btnAdd.height);
   y   += btnAdd.height + 8;
   maxx = btnAdd.frameRect.right;
   h    = btnAdd.height - 4;
   btnAdd.onClick  = function()
   {
      var ofd = new OpenFileDialog();
      ofd.multipleSelections = true;
      //ofd.filters = [ [ "FITS or XIFS Files", ".fit", ".fits", ".fts", ".xisf"]];
      ofd.filters = [ [ "XISF Files",  ".xisf"],
                      [ "FITS Files", ".fit", ".fits"]];

      if (ofd.execute())
      {
         for (var i = 0; i < ofd.filePaths.length; i++)
         {
            var filename =  ofd.filePaths[i];
            //
            // find filename in treebox column 1
            //
            var index = -1;
            for (var i = 0; i < tbx.numberOfChildren; i++)
            {
               if (tbx.child(i).text(1) == filename)
               {
                  index = i;
                  break;
               }
            }
            if (index < 0)
            {
               var n = new TreeBoxNode(tbx);
               n.setText(0, File.extractNameAndExtension(filename));
               n.setText(1, filename);
            }
         }
         enableButtons(false);
         lblCount.text = tbx.numberOfChildren.toString();
      }
   }

   var btnSelAll = new PushButton(this);
   btnSelAll.enabled = false;
   btnSelAll.text = "Select All";
   btnSelAll.position = new Point(x, y);
   btnSelAll.resize( 150 , btnSelAll.height);
   y += btnSelAll.height + 8;
   btnSelAll.onClick  = function()
   {
      tbx.selectAllNodes();
      enableButtons(false);
   }

   var btnInvertSel = new PushButton(this);
   btnInvertSel.enabled = false;
   btnInvertSel.text = "Invert Selection";
   btnInvertSel.position = new Point(x, y);
   btnInvertSel.resize( 150 , btnInvertSel.height);
   y += btnInvertSel.height + 8;
   btnInvertSel.onClick  = function()
   {
      for (var i = 0; i < tbx.numberOfChildren; i++)
      {
         var n = tbx.child(i);
         n.selected = !n.selected;
      }
      enableButtons(false);
   }

   var btnRemove = new PushButton(this);
   btnRemove.enabled = false;
   btnRemove.text = "Remove Selected";
   btnRemove.position = new Point(x, y);
   btnRemove.resize( 150 , btnRemove.height);
   y += btnRemove.height + 8;
   btnRemove.onClick  = function()
   {
      var nodes  = tbx.selectedNodes;
      for (var i = 0; i < nodes.length; i++)
      {
         var c = tbx.childIndex(nodes[i]);
         tbx.remove(c);
      }
      enableButtons(false);
   }

   var btnClear = new PushButton(this);
   btnClear.enabled = false;
   btnClear.text = "Clear";
   btnClear.position = new Point(x, y);
   btnClear.resize( 150 , btnClear.height);
   y += btnClear.height + 8;
   btnClear.onClick  = function()
   {
      tbx.clear();
      enableButtons(false);
   }

   var cbFullNames = new CheckBox(this);
   cbFullNames.enabled = false;
   y = tbx.frameRect.bottom - cbFullNames.height;
   cbFullNames.position = new Point(x, y);
   cbFullNames.text = "Full names";
   cbFullNames.onCheck = function(checked)
   {
      tbx.hideColumn(column);
      column = 1-column;
      tbx.showColumn(column);
      if (lblFilename.text != "")
      {
         if (checked)
            lblFilename.text = maxFile;
         else
            lblFilename.text = File.extractNameAndExtension(maxFile);
      }
   }

   /*
      end: FileSelection
   */

   x  = tbx.frameRect.left;
   y  = tbx.frameRect.bottom + 16;

   var lblCount = new Label(this);
   lblCount.backgroundColor = Color.rgbaColor(255, 255, 255, 255);
   lblCount.position = new Point(x,y);
   lblCount.resize (80, h);
   lblCount.textAlignment = TextAlignment.Center;

   var btnExec = new PushButton(this);
   btnExec.enabled = false;
   btnExec.text = "Execute";
   btnExec.position = new Point(tbx.frameRect.right - btnExec.width, y);
   btnExec.onClick = function()
   {
      enableButtons(true);
      var maxdb = 0;
      var results = new Array();
      var count = tbx.numberOfChildren;
      for (var i = 0; i < tbx.numberOfChildren; i++)
      {
         lblCount.text = format("%d",(i + 1)) + "(" + tbx.numberOfChildren.toString() + ")";
         var input_filename = tbx.child(i).text(1);
         var img = ReadImageFile(input_filename);
         // evaluate mainview channels
         for ( var c = 0; c < img.numberOfChannels; ++c )
         {
            CoreApplication.processEvents();
            if (Console.abortRequested || closing)
            {
               enableButtons(false);
               Console.warningln("Abort requested");
               return;
            }
            img.selectedChannel = c;
            var channel = "K";
            if (img.numberOfChannels > 1) channel = "RGB"[c];
            var snr = new SNREvaluation ( img );
            results = results.concat(new frameData(
               File.extractNameAndExtension(input_filename),
               snr.db, channel, snr.E.msg));
            if (snr.db > maxdb)
            {
               maxdb = snr.db;
               maxFile = input_filename;
               if (cbFullNames.checked)
                  lblFilename.text = maxFile;
               else
                  lblFilename.text = File.extractNameAndExtension(maxFile);
               lblSNR.text = format("%.2f db", maxdb);
            }
         }
         img = null;
      }

      Console.writeln("");
      Console.writeln("Summary:");
      Console.writeln("========");

      results.sort(function(a, b)
         {
            if (a.filename > b.filename) return -1;
            if (a.filename < b.filename) return 1;
            return 0;
         });
      for (var v of results) {
      if (v.channel == "K" | v.channel == "R") Console.writeln("");
      Console.writeln(format("SNR = %.2f db", v.snr) +
         ", " + v.channel + " " + v.filename + " " + v.comment);
      }

      Console.writeln("");
      Console.noteln("Max. SNR found in " + maxFile);
      Console.writeln("End SNRmax");
      Console.flush();
      var info = new MessageBox("Max. SNR found in " + maxFile, "SNRmax");
      info.execute();
      enableButtons(false);
   }

   var btnReady = new PushButton(this);
   btnReady.text = "Close";
   btnReady.position = new Point(maxx - btnReady.width, y);
   btnReady.onClick = function()
   {
      closing = true;
      dlg.ok();
   }

   // my ©
   x  = tbx.frameRect.left;
   y += 32;

   var lblCopyright = new Label(this)
   lblCopyright.position  = new Point(8, y);
   lblCopyright.text      = "©";
   lblCopyright.cursor    = new Cursor(StdCursor_ArrowQuestion);
   lblCopyright.onMousePress = function(x, y, button, buttonState, modifiers )
   {
     var dlg = new helpdlg();
     dlg.execute();
   }

   y += 24;

   var lblmaxVal = new Label(this);
   lblmaxVal.position = new Point(x,y);
   lblmaxVal.text = "Max. Value:";

   var lblSNR = new Label(this);
   lblSNR.backgroundColor = Color.rgbaColor(255, 255, 255, 255);
   lblSNR.textAlignment = TextAlignment.Center;
   lblSNR.lineWidth = 1;
   lblSNR.resize (80, h);
   lblSNR.position = new Point(lblmaxVal.frameRect.right + 4, y);

   y += 32;

   var lblmaxFile = new Label(this);
   lblmaxFile.position = new Point(x,y);
   lblmaxFile.text = "File:";

   var lblFilename = new Label(this);
   lblFilename.backgroundColor = Color.rgbaColor(255, 255, 255, 255);
   lblFilename.lineWidth = 1;
   lblFilename.textAlignment = TextAlignment.Left;
   x = lblmaxVal.frameRect.right + 4;
   lblFilename.resize (btnAdd.frameRect.right - x, h);
   lblFilename.position = new Point(lblmaxVal.frameRect.right + 4, y);

   this.width  = maxx + 8;
   this.height = lblmaxFile.frameRect.bottom + 4;
   this.windowTitle = "Find file with max SNR";
   this.userResizable = false;

   function enableButtons(executing)
   {
      if (executing)
      {
         btnAdd.enabled    = false;
         btnExec.enabled   = false;
         btnSelAll.enabled = false;
         btnClear.enabled  = false;
         btnRemove.enabled = false;
         btnInvertSel.enabled = false;
         cbFullNames.enabled  = false;
      }
      else
      {
         btnAdd.enabled    = true;
         btnExec.enabled   = tbx.numberOfChildren > 0;
         btnSelAll.enabled = tbx.numberOfChildren > 0;
         btnClear.enabled  = tbx.numberOfChildren > 0;
         btnRemove.enabled = tbx.selectedNodes.length > 0;
         btnInvertSel.enabled = tbx.selectedNodes.length > 0;
         cbFullNames.enabled  = tbx.numberOfChildren > 0;
      }
   }
}

} // class SNRmaxDialog

function SNREvaluation ( img )
{
   this.E = new NoiseEvaluation( img );
   var snr = img.meanOfSquares(img.selectedRect)/ this.E.sigma / this.E.sigma;
   this.db = 10 * Math.log10(snr);
}

function frameData(filename, snr, channel, comment)
{
   this.filename = filename;
   this.snr = snr;
   this.channel = channel;
   this.comment = comment;
}

function NoiseEvaluation( img )
{
   this.msg = "";
   var a, n = 4, m = 0.01 * img.selectedRect.area;
   for ( ;; )
   {
      a = img.noiseMRS( n );
      if ( a[1] >= m )
         break;
      if ( --n == 1 )
      {
         this.msg = "k-sigma noise estimate";
         a = img.noiseKSigma();
         break;
      }
   }
   this.sigma = a[0]; // estimated stddev of Gaussian noise
   this.count = a[1]; // number of pixels in the noise pixels set
   this.layers = n;   // number of layers used for noise evaluation
}

function ReadImageFile(filePath)
{
   var suffix = File.extractExtension( filePath ).toLowerCase();
   var F = new FileFormat( suffix, true/*toRead*/, false/*toWrite*/ );
   if ( F.isNull )
      throw new Error( "No installed file format can read \'" + suffix + "\' files." );

   var f = new FileFormatInstance( F );
   if ( f.isNull )
      throw new Error( "Unable to instantiate file format: " + F.name );

   var d = f.open( filePath);
   if ( d.length < 1 )
      throw new Error( "Unable to open file: " + filePath );

   if ( d.length > 1 )
      Console.writeln( "Note: this file contains " + d.length + " embedded images (e.g. an autocrop mask alongside the main light); reading the first one only." );

   var image = new Image();
   if ( !f.readImage( image ) )
      throw new Error( "Unable to read file: " + filePath );
   f.close();
   return image;
}



class helpdlg extends Dialog
{
constructor()
{
   super();

   this.minHeight = 400;
   this.minWidth  = 500;

   this.windowTitle = "SNRmax Dialog Help";

   this.OK_Button = new PushButton (this);
   this.OK_Button.text = "OK";
   this.OK_Button.maxWidth = 100;

   this.OK_Button.onClick = function()
   {
      this.dialog.ok();
   }

   this.helpText = new TextBox( this );
   this.helpText.frameStyle = FrameStyle.Box;
   this.helpText.margin = 4;
   this.helpText.readOnly = true;
   this.helpText.wordWrapping = true;
   this.helpText.useRichText = true;

   this.helpText.text = "<b>" + TITLE + " V" + VERSION +
   " Find file with the maximum SNR.</b>" +
   "<p>Read and evaluate a list of image files and find the best one with the highest SNR (Signal to Noise Ratio). " +
   " This can be helpful to know the reference image for the " +
   "<b>ImageIntegration</b> process.</p>" +
   "Usage: select files and press 'Execute'. The filename with the best SNR is shown in the bottom label of the dialog window at the end of successful execution." +
   "<p>Early termination is possible by clicking Pause/Abort in the console window.</p>" +
   "<p>Copyright © Hartmut Bornemann, 2014, mailto:hvb356@yahoo.com</p>";

   this.buttonSizer = new HorizontalSizer;
   this.buttonSizer.spacing = 4;
   this.buttonSizer.add (this.OK_Button);


   this.sizer = new VerticalSizer;
   this.sizer.margin = 6;
   this.sizer.spacing = 6;
   this.sizer.add( this.helpText );
   this.sizer.add( this.buttonSizer );

   this.helpText.home();
}

} // class helpdlg


function main()
{
   Console.show();
   Console.abortEnabled = true;
   var dialog = new SNRmaxDialog();
   dialog.execute();
}

main();

// ****************************************************************************
// EOF SNRmax.js - Released 2014/10/08 12:00:00 UTC
