/*
SNRViews.js: SNR of all views
================================================================================

Der SNR (SNR = 10 lg10 [NutzSignalLeistung/RauschLeistung]) aller Views wird mit
SNRViews tabellarisch auf der Konsole ausgegeben und dient der Beurteilung der
Qualität.
Beispiel: verbessert sich der Wert von 35 db für Rohbilder nach der Verarbeitung
auf 50 db, entspricht das einer Steigerung um den Faktor 31 (= 10^15/10).
Werte darüber führen schnell zu ‘glatten’ und unnatürlichen Bildern.
Hinweis: der SNR-Wert für JPEGs ist immer geringer als das vorausgehende Bild im
internen PixInsight Format.
Previews sind in der Liste eingeschlossen.

List SNR values of all views using SNREvaluation() - Previews included
Estimation of the signal-to-noise ratio function as seen below

================================================================================
 *
 * SNREvaluation()
 * Estimation of the signal-to-noise ratio function:
 *
 * SNR(f,g) = E(f^2) / E((f - g)^2)
 *
 * where f is a distribution function, g is a sample, and E(.) is the expected
 * value of the argument. The denominator is the mean square error, which we
 * approximate with the variance of the noise.
 *
 * Source PCL\src\modules\processes\ImageIntegration\ImageIntegrationInstance.cpp
 *
 * Changelog:
 * 1.1.0: 2014-04-23 SNREvaluation and NoiseEvaluation used as objects
 */

#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. No original author byline was present in the source file.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; replaced 3
// lowercase Console. calls with Console. (the rest of the file already
// used Console. correctly -- this one was just inconsistent); replaced
// the legacy `for each (var v in results)` loop with a standard
// `for (var v of results)` -- `for each...in` was a non-standard Mozilla
// SpiderMonkey extension that V8 never supported at all, so this would
// have thrown a SyntaxError immediately on parse, not just at runtime;
// fixed the sort() comparator, which returned a boolean (a.filename <
// b.filename) instead of a number -- Array.sort() comparators must
// return negative/zero/positive, so replaced with a proper 3-way string
// comparison. No #include directives, with() statements, .prototype.
// enum references, or underscore constants were present.
// ----------------------------------------------------------------------------

#feature-id SNRViews : MoP V8 > SNRViews
#define VERSION "1.1.0"


function frameData(filename, snr, channel, comment)
{
   this.filename = filename;
   this.snr = snr;
   this.channel = channel;
   this.comment = comment;
}

function SNREvaluation ( img )
{
   this.E = new NoiseEvaluation( img );
   var snr = img.meanOfSquares(img.selectedRect)/ this.E.sigma / this.E.sigma;
   this.db = 10 * Math.log10(snr);
}

function NoiseEvaluation( img )
{
   this.msg = "";
   var a, n = 4, m = 0.01*img.selectedRect.area;
   for ( ;; )
   {
      a = img.noiseMRS( n );
      if ( a[1] >= m )
         break;
      if ( --n == 1 )
      {
         this.msg = "k-sigma noise estimate";
         a = img.noiseKSigma();
         break;
      }
   }
   this.sigma = a[0]; // estimated stddev of Gaussian noise
   this.count = a[1]; // number of pixels in the noise pixels set
   this.layers = n;   // number of layers used for noise evaluation
}

function main()
{
   // Get access to the current active image window.
   var window = ImageWindow.activeWindow;
   if ( window.isNull ) throw new Error( "No active image" );

   Console.show();
   Console.writeln( "Calculating SNR" );
   Console.abortEnabled = true;

   var windows = ImageWindow.windows;

   var results = new Array();
   var cancel = false;

   for ( var i = 0; i < windows.length; i++ )
   {
      var win  = windows[i];
      var view = win.mainView;
      var img  = view.image;
      var id   = view.id;
      // evaluate mainview channels
      for ( var c = 0; c < img.numberOfChannels; ++c )
      {
         img.selectedChannel = c;
         var channel = "K";
         if (img.numberOfChannels > 1) channel = "RGB"[c];
         var snr = new SNREvaluation ( img );
         results = results.concat(new frameData(id,
                  snr.db, channel, snr.E.msg));
         cancel = Console.abortRequested;
         if (cancel) break;
      }
      if (cancel) break; // leave main loop over all windows
      // evaluate previews
      for ( var j = 0; j < win.previews.length; ++j )
      {
         view = win.previews[j];
         img  = view.image;
         id   = view.id;
         for ( var c = 0; c < img.numberOfChannels; ++c )
         {
            img.selectedChannel = c;
            var channel = "K";
            if (img.numberOfChannels > 1) channel = "RGB"[c];
            var snr = new SNREvaluation ( img );
            results = results.concat(new frameData(id,
                  snr.db, channel, snr.E.msg));
            cancel = Console.abortRequested;
            if (cancel) break;
         }
         if (cancel) break;
      }
      if (cancel) break; // leave main loop over all windows
   }

   if (cancel)
   {
      throw "Abort!!";
   }
   else
   {
      Console.writeln("");
      Console.writeln("Summary:");
      Console.writeln("========");
      {
         results.sort(function(a, b){
            if (a.filename < b.filename) return -1;
            if (a.filename > b.filename) return 1;
            return 0;
         });
         for (var v of results) {
         if (v.channel == "K" | v.channel == "R") Console.writeln("");
         Console.writeln(format("SNR = %.2f db", v.snr) +
            ", " + v.channel + " " + v.filename + " " + v.comment);
         }
      }
      Console.writeln("");
      Console.writeln("End SNRViews");
   }

   Console.flush();
}

main();

