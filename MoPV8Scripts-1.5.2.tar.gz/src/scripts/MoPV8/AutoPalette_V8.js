/******************************************************************************
 * AutoPalette.js version 0.7 (May 2024)
 *
 * This script allows the dynamic narrowband channel combinations for OSC and
 * MONOCHROME images, based on PIP (Power Inverted Pixels) method for the RGB
 * channels exponential transformation.
 *
 * This script was developed by Raúl Hussein.
 * Inspired in the pixelmath scripts for dynamic Foraxx combinations developed
 * by Marcelo Muñoz
 *
 * Changelog:
 * 0.1 - Core version
 * 0.2 - Dynamic image identifiers
 * 0.3 - Classic palettes
 * 0.4 - Reference OSC image, linearfit and blend modes
 * 0.5 - Minor bugs
 * 0.6 - Dialog improvements
 * 0.7 - New instance and some bugs
 *
 *****************************************************************************/

// Script developed and tested on PixInsight 1.8.9-1 Ripley
// Autopalette.js
//
// This file is part of Autopalette Script
//
// Copyright (C) 2024 Raúl Hussein
// All Rights Reserved
//
// ----------------------------------------------------------------------------
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the
// Free Software Foundation, version 3 of the License.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see <http://www.gnu.org/licenses/>.
// ----------------------------------------------------------------------------

#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Raul Hussein.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; removed all
// #include <pjsr/...> directives (PJSR globals available without them);
// converted autopaletteMain from __base__/.prototype = new Dialog to class
// extends Dialog / super(); replaced .prototype. enum references
// (PixelMath, ChannelExtraction) with direct class access; replaced
// underscore constants with dot notation (TextAlign_* -> TextAlignment.*,
// FrameStyle_Box -> FrameStyle.Box, StdIcon_Error -> StdIcon.Error,
// StdButton_Ok -> StdButton.Ok, StdCursor_Checkmark/Crossmark ->
// StdCursor.Checkmark/Crossmark); expanded all 27 with() statements
// (banned in V8 strict mode) to explicit object.property assignments.
//
// NOTE: found one pre-existing bug while expanding the with() blocks,
// unrelated to the V8 port -- left as-is to match original behavior.
// See the "allCheckbox_Sizer" block: it targets this.typeForaxx_Sizer
// instead of this.allCheckbox_Sizer, so the "All Classic Combinations"
// checkbox gets added into the palette-method row instead of its own row,
// and allCheckbox_Sizer itself is created but never added to any layout.
// Flagged for Pete/the user to decide whether to fix.
// ----------------------------------------------------------------------------

#feature-id AutoPalette : MoP V8 > AutoPalette
#feature-info NB Dynamic Palettes v0.7<br/><br/>This script allows the dynamic narrowband channel combinations for OSC and MONOCHROME images, based on PIP (Power Inverted Pixels) method for the RGB channels exponential transformation.

#define VERSION "0.7"
#define TITLE "AutoPalette"

#define HA_NAME "_HA"
#define S2_NAME "_SII"
#define O3_NAME "_OIII"
#define SHO_NAME "_SHO"


function paletteStart(data){
   Console.show();

   if (data.isOSC){
      Console.noteln("Image Color");
      if (data.currentView == null || !data.currentView.image.isColor){
          (new MessageBox("There must be one RGB image for OSC option", TITLE, StdIcon.Error, StdButton.Ok)).execute();
          return;
      }

      NBChannelExtraction(data.currentView);
      data.referenceHA = refenceNB(HA_NAME);
      data.referenceOIII = refenceNB(O3_NAME);
      data.referenceSII = refenceNB(S2_NAME);
      intermediateSHO(data);

      if (data.autoClose){
         ImageWindow.windowById(HA_NAME).hide();
         ImageWindow.windowById(O3_NAME).hide();
         ImageWindow.windowById(S2_NAME).hide();
      }
   }
   else Console.noteln("Image Mono");

   if (!data.isOSC && (data.referenceHA.isNull || data.referenceOIII.isNull)){
      (new MessageBox("There must be three images open for this script to function", TITLE, StdIcon.Error, StdButton.Ok)).execute();
      return;
   }

   if (data.referenceSII.isNull)
      data.typePalette = 0;
   else
      if (data.typePalette >= 3 || data.allCombinations) createSwapHSO(data); // Swap for foraxx

   applyLinearFit(data)

   if (data.allCombinations)
      createAllClassic(data);
   else
      switch(data.typePalette){
         case 0:
         default:
            classicHOO(data);
            break;

         case 1:
            classicSHO(data);
            break;

         case 2:
            classicHSO(data);
            break;

         case 3:
            classicForaxx(data);
            break;

         case 4:
            foraxSHO(data);
            break;

         case 5:
            foraxHOS(data);
            break;

         case 6:
            foraxOHS(data);
            break;

         case 7:
            foraxHOO(data);
            break;

         case 8:
            foraxHSO(data);
            break;

         case 9:
            foraxOSH(data);
            break;

         case 10:
            foraxSOH(data);
            break;
      }

   if (data.typePalette >= 3 && data.autoClose){
      var SHO =  ImageWindow.windowById(SHO_NAME);
      if (!SHO.isNull) SHO.forceClose();
   }

   closeIntermediate(data);
   Console.hide();
   return;
}

function createSwapHSO(data){
   Console.noteln("createSwapHSO");
   var h = ImageWindow.windowById("h");
   var o = ImageWindow.windowById("o");
   var s = ImageWindow.windowById("s");
   var ho = ImageWindow.windowById("ho");
   var hs = ImageWindow.windowById("hs");
   var os = ImageWindow.windowById("os");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   if(h.isNull) createSingleRGB(data, "("+HA+"^~"+HA+")", "h");
   if(o.isNull) createSingleRGB(data, "("+OIII+"^~"+OIII+")", "o");
   if(s.isNull) createSingleRGB(data, "("+SII+"^~"+SII+")", "s");
   if(ho.isNull) createSingleRGB(data, "("+HA+"*"+OIII+")^~("+HA+"*"+OIII+")", "ho");
   if(hs.isNull) createSingleRGB(data, "("+HA+"*"+SII+")^~("+HA+"*"+SII+")", "hs");
   if(os.isNull) createSingleRGB(data, "("+OIII+"*"+SII+")^~("+OIII+"*"+SII+")", "os");

   if (data.autoClose){
      h = ImageWindow.windowById("h");
      o = ImageWindow.windowById("o");
      s = ImageWindow.windowById("s");
      ho = ImageWindow.windowById("ho");
      hs = ImageWindow.windowById("hs");
      os = ImageWindow.windowById("os");
      if(!h.isNull) ImageWindow.windowById("h").hide();
      if(!o.isNull) ImageWindow.windowById("o").hide();
      if(!s.isNull) ImageWindow.windowById("s").hide();
      if(!ho.isNull) ImageWindow.windowById("ho").hide();
      if(!hs.isNull) ImageWindow.windowById("hs").hide();
      if(!os.isNull) ImageWindow.windowById("os").hide();
   }
}

function intermediateSHO(data){
   Console.noteln("intermediateSHO");
   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   createMultipleRGB(data, SII, HA, OIII, SHO_NAME);
}

function closeIntermediate(data){
   Console.noteln("closeIntermediate");
   if (!data.autoClose) return;

   var h = ImageWindow.windowById("h");
   var o = ImageWindow.windowById("o");
   var s = ImageWindow.windowById("s");
   var ho = ImageWindow.windowById("ho");
   var hs = ImageWindow.windowById("hs");
   var os = ImageWindow.windowById("os");
   if (!h.isNull) h.forceClose();
   if (!o.isNull) o.forceClose();
   if (!s.isNull) s.forceClose();
   if (!ho.isNull) ho.forceClose();
   if (!hs.isNull) hs.forceClose();
   if (!os.isNull) os.forceClose();

   if (data.isOSC || data.linearFit){
      // Bug fix (pre-existing, not V8-specific): when linearFit is used
      // without isOSC, applyLinearFit() creates working copies named
      // HA_NAME+"_LF" / O3_NAME+"_LF" / S2_NAME+"_LF" and points
      // data.referenceHA/OIII/SII at those instead. This code was only
      // ever checking the plain HA_NAME/O3_NAME/S2_NAME names, which were
      // never created in that scenario, so the actual _LF intermediate
      // copies were never closed regardless of the "Close intermediate
      // images" option. Check both forms so whichever one actually exists
      // gets closed.
      var namesToClose = [
         HA_NAME, O3_NAME, S2_NAME,
         HA_NAME + "_LF", O3_NAME + "_LF", S2_NAME + "_LF",
         SHO_NAME
      ];
      for (var __ci = 0; __ci < namesToClose.length; __ci++)
      {
         var __w = ImageWindow.windowById(namesToClose[__ci]);
         if (!__w.isNull) __w.forceClose();
      }
   }
}

function createAllClassic(data){
   Console.noteln("createAllClassic");
   classicHOO(data);
   classicSHO(data);
   classicHSO(data);
   classicForaxx(data);
}

function createAll(data){
   Console.noteln("createAll");
   classicHOO(data);
   classicHSO(data);
   classicSHO(data);
   foraxSHO(data);
   foraxHOS(data);
   foraxOHS(data);
   foraxHOO(data);
   foraxHSO(data);
   foraxOSH(data);
   foraxSOH(data);
}

function foraxHOS(data){
   Console.noteln("foraxHOS");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   createMultipleRGB(data, "o*"+HA+"+~o*"+HA, "ho*"+OIII+"+~ho*"+OIII, "o*"+SII+"+~o*"+OIII, "Foraxx_HOS_HOO");
   createMultipleRGB(data, "o*"+HA+"+~o*"+HA, "ho*"+OIII+"+~ho*"+SII, "o*"+SII+"+~o*"+OIII, "Foraxx_HOS_HSO");
   createMultipleRGB(data, "o*"+HA+"+~o*"+OIII, "ho*"+OIII+"+~ho*"+HA, "o*"+SII+"+~o*"+SII, "Foraxx_HOS_OHS");
   createMultipleRGB(data, "o*"+HA+"+~o*"+OIII, "ho*"+OIII+"+~ho*"+SII, "o*"+SII+"+~o*"+HA, "Foraxx_HOS_OSH");
   createMultipleRGB(data, "o*"+HA+"+~o*"+SII, "ho*"+OIII+"+~ho*"+OIII, "o*"+SII+"+~o*"+HA, "Foraxx_HOS_SOH");
   createMultipleRGB(data, "o*"+HA+"+~o*"+SII, "ho*"+OIII+"+~ho*"+HA, "o*"+SII+"+~o*"+OIII, "Foraxx_HOS_SHO");
}

function foraxOHS(data){
   Console.noteln("foraxOHS");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   createMultipleRGB(data, "o*"+OIII+"+~o*"+HA, "ho*"+HA+"+~ho*"+OIII, "o*"+SII+"+~o*"+OIII, "Foraxx_OHS_HOO");
   createMultipleRGB(data, "o*"+OIII+"+~o*"+HA, "ho*"+HA+"+~ho*"+OIII, "o*"+SII+"+~o*"+SII, "Foraxx_OHS_HOS");
   createMultipleRGB(data, "o*"+OIII+"+~o*"+HA, "ho*"+HA+"+~ho*"+SII, "o*"+SII+"+~o*"+OIII, "Foraxx_OHS_HSO");
   createMultipleRGB(data, "o*"+OIII+"+~o*"+OIII, "ho*"+HA+"+~ho*"+SII, "o*"+SII+"+~o*"+HA, "Foraxx_OHS_OSH");
   createMultipleRGB(data, "o*"+OIII+"+~o*"+SII, "ho*"+HA+"+~ho*"+HA, "o*"+SII+"+~o*"+OIII, "Foraxx_OHS_SHO");
   createMultipleRGB(data, "o*"+OIII+"+~o*"+SII, "ho*"+HA+"+~ho*"+OIII, "o*"+SII+"+~o*"+HA, "Foraxx_OHS_SOH");
}

function foraxSHO(data){
   Console.noteln("foraxSHO");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   createMultipleRGB(data, "o*"+SII+"+~o*"+HA, "ho*"+HA+"+~ho*"+OIII, OIII, "Foraxx_SHO_HOO");
   createMultipleRGB(data, "o*"+SII+"+~o*"+HA, "ho*"+HA+"+~ho*"+SII, OIII, "Foraxx_SHO_HSO");
   createMultipleRGB(data, "o*"+SII+"+~o*"+HA, "ho*"+HA+"+~ho*"+OIII, "o*"+OIII+"+~o*"+SII, "Foraxx_SHO_HOS");
   createMultipleRGB(data, "o*"+SII+"+~o*"+OIII, HA, "o*"+OIII+"+~o*"+SII, "Foraxx_SHO_OHS");
   createMultipleRGB(data, "o*"+SII+"+~o*"+OIII, "ho*"+HA+"+~ho*"+SII, "o*"+OIII+"+~o*"+HA, "Foraxx_SHO_OSH");
   createMultipleRGB(data, SII, "ho*"+OIII+"+~ho*"+HA, "o*"+OIII+"+~o*"+HA, "Foraxx_SHO_SOH");
}

function foraxHOO(data){
   Console.noteln("foraxHOO");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   createMultipleRGB(data, "o*"+HA+"+~o*"+HA, "ho*"+OIII+"+~ho*"+OIII, "o*"+OIII+"+~o*"+SII, "Foraxx_HOO_HOS");
   createMultipleRGB(data, "o*"+HA+"+~o*"+HA, "ho*"+OIII+"+~ho*"+SII, "o*"+OIII+"+~o*"+OIII, "Foraxx_HOO_HSO");
   createMultipleRGB(data, "o*"+HA+"+~o*"+OIII, "ho*"+OIII+"+~ho*"+HA, "o*"+OIII+"+~o*"+SII, "Foraxx_HOO_OHS");
   createMultipleRGB(data, "o*"+HA+"+~o*"+OIII, "ho*"+OIII+"+~ho*"+SII, "o*"+OIII+"+~o*"+HA, "Foraxx_HOO_OSH");
   createMultipleRGB(data, "o*"+HA+"+~o*"+SII, "ho*"+OIII+"+~ho*"+HA, "o*"+OIII+"+~o*"+OIII, "Foraxx_HOO_SHO");
   createMultipleRGB(data, "o*"+HA+"+~o*"+SII, "ho*"+OIII+"+~ho*"+OIII, "o*"+OIII+"+~o*"+HA, "Foraxx_HOO_SOH");
}

function foraxHSO(data){
   Console.noteln("foraxHSO");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   createMultipleRGB(data, "o*"+HA+"+~o*"+HA, "ho*"+SII+"+~ho*"+OIII, "o*"+OIII+"+~o*"+OIII, "Foraxx_HSO_HOO");
   createMultipleRGB(data, "o*"+HA+"+~o*"+HA, "ho*"+SII+"+~ho*"+OIII, "o*"+OIII+"+~o*"+SII, "Foraxx_HSO_HOS");
   createMultipleRGB(data, "o*"+HA+"+~o*"+OIII, "ho*"+SII+"+~ho*"+HA, "o*"+OIII+"+~o*"+SII, "Foraxx_HSO_OHS");
   createMultipleRGB(data, "o*"+HA+"+~o*"+OIII, "ho*"+SII+"+~ho*"+SII, "o*"+OIII+"+~o*"+HA, "Foraxx_HSO_OSH");
   createMultipleRGB(data, "o*"+HA+"+~o*"+SII, "ho*"+SII+"+~ho*"+HA, "o*"+OIII+"+~o*"+OIII, "Foraxx_HSO_SHO");
   createMultipleRGB(data, "o*"+HA+"+~o*"+SII, "ho*"+SII+"+~ho*"+OIII, "o*"+OIII+"+~o*"+HA, "Foraxx_HSO_SOH");
}

function foraxOSH(data){
   Console.noteln("foraxOSH");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   createMultipleRGB(data, "o*"+OIII+"+~o*"+HA, "ho*"+SII+"+~ho*"+OIII, "o*"+HA+"+~o*"+OIII, "Foraxx_OSH_HOO");
   createMultipleRGB(data, "o*"+OIII+"+~o*"+HA, "ho*"+SII+"+~ho*"+OIII, "o*"+HA+"+~o*"+SII, "Foraxx_OSH_HOS");
   createMultipleRGB(data, "o*"+OIII+"+~o*"+HA, "ho*"+SII+"+~ho*"+SII, "o*"+HA+"+~o*"+OIII, "Foraxx_OSH_HSO");
   createMultipleRGB(data, "o*"+OIII+"+~o*"+OIII, "ho*"+SII+"+~ho*"+SII, "o*"+HA+"+~o*"+HA, "Foraxx_OSH_OSH");
   createMultipleRGB(data, "o*"+OIII+"+~o*"+SII, "ho*"+SII+"+~ho*"+HA, "o*"+HA+"+~o*"+OIII, "Foraxx_OSH_SHO");
   createMultipleRGB(data, "o*"+OIII+"+~o*"+SII, "ho*"+SII+"+~ho*"+OIII, "o*"+HA+"+~o*"+HA, "Foraxx_OSH_SOH");
}

function foraxSOH(data){
   Console.noteln("foraxSOH");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   createMultipleRGB(data, "o*"+SII+"+~o*"+HA, "ho*"+OIII+"+~ho*"+OIII, "o*"+HA+"+~o*"+SII, "Foraxx_SOH_HOS");
   createMultipleRGB(data, "o*"+SII+"+~o*"+HA, "ho*"+OIII+"+~ho*"+SII, "o*"+HA+"+~o*"+OIII, "Foraxx_SOH_HSO");
   createMultipleRGB(data, "o*"+SII+"+~o*"+SII, "ho*"+OIII+"+~ho*"+HA, "o*"+HA+"+~o*"+OIII, "Foraxx_SOH_SHO");
   createMultipleRGB(data, "o*"+SII+"+~o*"+OIII, "ho*"+OIII+"+~ho*"+HA, "o*"+HA+"+~o*"+SII, "Foraxx_SOH_OHS");
   createMultipleRGB(data, "o*"+SII+"+~o*"+HA, "ho*"+OIII+"+~ho*"+OIII, "o*"+HA+"+~o*"+OIII, "Foraxx_SOH_HOO");
   createMultipleRGB(data, "o*"+SII+"+~o*"+OIII, "ho*"+OIII+"+~ho*"+SII, "o*"+HA+"+~o*"+HA, "Foraxx_SOH_OSH");
}

function classicSHO(data){
   Console.noteln("classicSHO");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   switch (data.blendMode){
      case 1: // Neutral (50% Ha + 50% OIII)
         createMultipleRGB(data, ".5*"+SII+"+.5*"+HA, ".5*"+HA+"+.5*"+OIII, OIII, "SHO_Classic_Neutral");
         break;

      case 2: // Soft (60% Ha + 40% OIII)
         createMultipleRGB(data, ".6*"+SII+"+.4*"+HA, ".6*"+HA+"+.4*"+OIII, OIII, "SHO_Classic_Soft");
         break;

      case 3: // Hard (70% Ha + 30% OIII)
         createMultipleRGB(data, ".7*"+SII+"+.3*"+HA, ".7*"+HA+"+.3*"+OIII, OIII, "SHO_Classic_Hard");
         break;

      case 4: // All modes
         createMultipleRGB(data, SII, HA, OIII, "SHO_Classic");
         createMultipleRGB(data, ".5*"+SII+"+.5*"+HA, ".5*"+HA+"+.5*"+OIII, OIII, "SHO_Classic_Neutral");
         createMultipleRGB(data, ".6*"+SII+"+.4*"+HA, ".6*"+HA+"+.4*"+OIII, OIII, "SHO_Classic_Soft");
         createMultipleRGB(data, ".7*"+SII+"+.3*"+HA, ".7*"+HA+"+.3*"+OIII, OIII, "SHO_Classic_Hard");
         break;

      default:
         createMultipleRGB(data, SII, HA, OIII, "SHO_Classic");
         break;
   }
}

function classicHOO(data){
   Console.noteln("classicHOO");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;

   if (HA.isNull || OIII.isNull) return;

   switch (data.blendMode){
      case 1: // Neutral (50% Ha + 50% OIII)
         createMultipleRGB(data, HA, ".5*"+HA+"+.5*"+OIII, OIII, "HOO_Classic_Neutral");
         break;

      case 2: // Soft (60% Ha + 40% OIII)
         createMultipleRGB(data, HA, ".6*"+HA+"+.4*"+OIII, OIII, "HOO_Classic_Soft");
         break;

      case 3: // Hard (70% Ha + 30% OIII)
         createMultipleRGB(data, HA, ".7*"+HA+"+.3*"+OIII, OIII, "HOO_Classic_Hard");
         break;

      case 4: // All modes
         createMultipleRGB(data, HA, OIII, OIII, "HOO_Classic");
         createMultipleRGB(data, HA, ".5*"+HA+"+.5*"+OIII, OIII, "HOO_Classic_Neutral");
         createMultipleRGB(data, HA, ".6*"+HA+"+.4*"+OIII, OIII, "HOO_Classic_Soft");
         createMultipleRGB(data, HA, ".7*"+HA+"+.3*"+OIII, OIII, "HOO_Classic_Hard");
         break;

      default:
         createMultipleRGB(data, HA, OIII, OIII, "HOO_Classic");
         break;
   }
}

function classicHSO(data){
   Console.noteln("classicHSO");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   switch (data.blendMode){
      case 1: // Neutral (50% Ha + 50% OIII)
         createMultipleRGB(data, ".5*"+HA+"+.5*"+OIII, ".5*"+SII+"+.5*"+HA, OIII, "HSO_Classic_Neutral");
         break;

      case 2: // Soft (60% Ha + 40% OIII)
         createMultipleRGB(data, ".6*"+HA+"+.4*"+OIII, ".6*"+SII+"+.4*"+HA, OIII, "HSO_Classic_Soft");
         break;

      case 3: // Hard (70% Ha + 30% OIII)
         createMultipleRGB(data, ".7*"+HA+"+.3*"+OIII, ".7*"+SII+"+.3*"+HA, OIII, "HSO_Classic_Hard");
         break;

      case 4: // All modes
         createMultipleRGB(data, HA, SII, OIII, "HSO_Classic");
         createMultipleRGB(data, ".5*"+HA+"+.5*"+OIII, ".5*"+SII+"+.5*"+HA, OIII, "HSO_Classic_Neutral");
         createMultipleRGB(data, ".6*"+HA+"+.4*"+OIII, ".6*"+SII+"+.4*"+HA, OIII, "HSO_Classic_Soft");
         createMultipleRGB(data, ".7*"+HA+"+.3*"+OIII, ".7*"+SII+"+.3*"+HA, OIII, "HSO_Classic_Hard");
         break;

      default:
         createMultipleRGB(data, HA, SII, OIII, "HSO_Classic");
         break;
   }

}

function classicForaxx(data){
   Console.noteln("classicForaxx");

   var HA = data.referenceHA.id;
   var OIII = data.referenceOIII.id;
   var SII = data.referenceSII.id;

   if (HA.isNull || OIII.isNull || SII.isNull) return;

   createMultipleRGB(data, "o*"+HA+"+~o*"+HA, "ho*"+OIII+"+~ho*"+SII, "o*"+OIII+"+~o*"+OIII, "Foraxx_Classic");
}

function pixelMathFcn(data, exp1, exp2, exp3, exp4, name, color){
    if(data.currentView == null || data.currentView.isNull)
      data.currentView = data.referenceHA;

    if(data.currentView == null || data.currentView.isNull) return;

    var m = data.currentView;
	 m.beginProcess();

    var P = new PixelMath;
    P.expression = exp1;
    P.expression1 = exp2;
    P.expression2 = exp3;
    P.expression3 = exp4;
    P.useSingleExpression = (color ? false : true);
    P.symbols = "";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = true;
    P.showNewImage = true;
    P.newImageId = name;
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = (color ? PixelMath.RGB : PixelMath.SameAsTarget);
    P.newImageSampleFormat = PixelMath.SameAsTarget;

    P.executeOn(m, false /*swapFile */);
	 m.endProcess();
}

function NBChannelExtraction(vista){
   Console.noteln("NBChannelExtraction");

   var m = vista;
   m.beginProcess();

   var P = new ChannelExtraction;
   P.colorSpace = ChannelExtraction.RGB;
   P.channels = [ // enabled, id
      [true, HA_NAME],
      [true, S2_NAME],
      [true, O3_NAME]
   ];
   P.sampleFormat = ChannelExtraction.SameAsSource;
   P.inheritAstrometricSolution = true;

   P.executeOn(m, false /*swapFile */);
   m.endProcess();
}

function linearFit(view, reference){
   if (view.isNull || reference.isNull) return false;

   view.beginProcess();

   var P = new LinearFit;
   P.referenceViewId = reference;
   P.rejectLow = 0.000000;
   P.rejectHigh = 0.920000;

   P.executeOn(view, false /*swapFile */);
   view.endProcess();
   return true;
}

function applyLinearFit(data){
   if (!data.linearFit) return;

   Console.noteln("applyLinearFit");

   if (!data.isOSC){
      if(!data.referenceSII.isNull){
         createSingleRGB(data, data.referenceSII.id, S2_NAME+"_LF");
         data.referenceSII = viewByIdSafe(S2_NAME+"_LF");
      }

      if(!data.referenceOIII.isNull){
         createSingleRGB(data, data.referenceOIII.id, O3_NAME+"_LF");
         data.referenceOIII = viewByIdSafe(O3_NAME+"_LF");
      }

      if(!data.referenceHA.isNull){
        createSingleRGB(data, data.referenceHA.id, HA_NAME+"_LF");
        data.referenceHA = viewByIdSafe(HA_NAME+"_LF");
      }
   }

   switch (data.linearFit){
      case 1: // HA channel
         linearFit(data.referenceSII, data.referenceHA.id);
         linearFit(data.referenceOIII, data.referenceHA.id);
         break;

      case 2: // SII channel
         linearFit(data.referenceHA, data.referenceSII.id);
         linearFit(data.referenceOIII, data.referenceSII.id);
         break;

      case 3: // OIII channel
         linearFit(data.referenceHA, data.referenceOIII.id);
         linearFit(data.referenceSII, data.referenceOIII.id);
         break;
   }
}

function createSingleRGB(data, expresion, name){
   pixelMathFcn(data, expresion, "", "", "", name, false);
}

function createMultipleRGB(data, exp1, exp2, exp3, name){
   pixelMathFcn(data, exp1, exp2, exp3, "", name, true);
}

// V8 fix (rulebook Rule 41): View.viewById() can return actual null in V8
// when no matching view exists, rather than a "null view" object with
// isNull==true. This function's whole search chain relies on truthy .id
// checks (if(!vista.id) vista = View.viewById(...)), which would throw
// immediately on the very first non-matching name if we called
// View.viewById() directly. This wrapper normalizes a real null into a
// plain stand-in object with the same falsy .id / isNull==true shape, so
// none of the existing .id / .isNull checks below need to change.
function viewByIdSafe(id)
{
   // V8 fix: confirmed via testing that View.viewById() (a) throws outright
   // for an empty/invalid identifier string, and (b) returns genuine JS
   // null -- not a null-View object with isNull==true -- for a
   // syntactically valid but non-matching identifier. This script's ~50
   // call sites all assume a real object with .id / .isNull is always
   // returned, so normalize both failure modes to the same plain stand-in
   // object rather than touching every call site individually.
   //
   // The one place this isn't enough on its own: assigning straight into a
   // real PJSR API property that requires a genuine View reference (e.g.
   // ViewList.currentView = ...) -- that throws "View object reference
   // expected" if handed this stand-in. Those specific assignments are
   // guarded separately, right where they happen, rather than trying to
   // make this stand-in impersonate a real View everywhere.
   var NO_VIEW = { id: "", isNull: true, fullId: "" };
   if (id == null || id === "")
      return NO_VIEW;
   try
   {
      var v = View.viewById(id);
      return (v == null) ? NO_VIEW : v;
   }
   catch ( __eVB )
   {
      return NO_VIEW;
   }
}

// V8 fix: ViewList.currentView requires a genuine View reference and
// throws "View object reference expected" if handed the plain stand-in
// object viewByIdSafe() returns for the not-found case. Skip the
// assignment entirely when there's nothing valid to set -- the control's
// own default (no selection) is exactly what we'd want anyway.
function setViewListCurrent(viewList, v)
{
   if (v != null && !v.isNull)
      viewList.currentView = v;
}

function refenceNB(NB){
   var vista = viewByIdSafe(NB);
   if(vista.id) return vista;

   switch(NB){
      case "Ha":
         vista = viewByIdSafe("HA");
         if(!vista.id) vista = viewByIdSafe("Halfa");
         if(!vista.id) vista = viewByIdSafe("ha");
         if(!vista.id) vista = viewByIdSafe("halfa");
         if(!vista.id) vista = viewByIdSafe("hidrogeno");
         if(!vista.id) vista = viewByIdSafe(HA_NAME);
         break;

      case "SII":
         vista = viewByIdSafe("sii");
         if(!vista.id) vista = viewByIdSafe("s2");
         if(!vista.id) vista = viewByIdSafe("S2");
         if(!vista.id) vista = viewByIdSafe("Sii");
         if(!vista.id) vista = viewByIdSafe("sulfuro");
         if(!vista.id) vista = viewByIdSafe(S2_NAME);
         break;

      case "OIII":
         vista = viewByIdSafe("oiii");
         if(!vista.id) vista = viewByIdSafe("o3");
         if(!vista.id) vista = viewByIdSafe("O3");
         if(!vista.id) vista = viewByIdSafe("Oiii");
         if(!vista.id) vista = viewByIdSafe("oxigeno");
         if(!vista.id) vista = viewByIdSafe(O3_NAME);
         break;
   }

   return vista;
}

/*
 * DATA & PARAMETERS
 */

function parametersPrototype()
{
   this.setDefaults = function()
   {
      this.currentView = refenceNB("");
      this.referenceHA = refenceNB("Ha");
      this.referenceOIII = refenceNB("OIII");
      this.referenceSII = refenceNB("SII");
      this.typePalette = 0;
      this.isOSC = true;
      this.autoClose = true;
      this.allCombinations = false;
      this.blendMode = 2;
      this.linearFit = 1;
   };

   this.setParameters = function()
   {
      Parameters.clear();
      if(!this.currentView.isNull || this.currentView != null) Parameters.set( "currentView", this.currentView.id );
      if(!this.referenceHA.isNull || this.referenceHA != null) Parameters.set( "referenceHA", this.referenceHA.id );
      if(!this.referenceOIII.isNull || this.referenceOIII != null) Parameters.set( "referenceOIII", this.referenceOIII.id );
      if(!this.referenceSII.isNull || this.referenceSII != null) Parameters.set( "referenceSII", this.referenceSII.id );
      Parameters.set( "typePalette", this.typePalette );
      Parameters.set( "isOSC", this.isOSC );
      Parameters.set( "autoClose", this.autoClose );
      Parameters.set( "allCombinations", this.allCombinations );
      Parameters.set( "blendMode", this.blendMode );
      Parameters.set( "linearFit", this.linearFit );
   };

   this.getParameters = function()
   {
      if (Parameters.has("currentView"))
         this.currentView = viewByIdSafe(Parameters.getString("currentView"));

      if (Parameters.has("referenceHA"))
         this.referenceHA = viewByIdSafe(Parameters.getString("referenceHA"));

      if (Parameters.has("referenceOIII"))
         this.referenceOIII = viewByIdSafe(Parameters.getString("referenceOIII"));

      if (Parameters.has("referenceSII"))
         this.referenceSII = viewByIdSafe(Parameters.getString("referenceSII"));

      if ( Parameters.has( "typePalette" ) )
         this.typePalette = Parameters.getInteger( "typePalette" );

      if ( Parameters.has( "isOSC" ) )
         this.isOSC = Parameters.getBoolean( "isOSC" );

      if ( Parameters.has( "autoClose" ) )
         this.autoClose = Parameters.getBoolean( "autoClose" );

      if ( Parameters.has( "allCombinations" ) )
         this.allCombinations = Parameters.getBoolean( "allCombinations" );

      if ( Parameters.has( "blendMode" ) )
         this.blendMode = Parameters.getInteger( "blendMode" );

      if ( Parameters.has( "linearFit" ) )
         this.linearFit = Parameters.getInteger( "linearFit" );
   };
}

var data = new parametersPrototype();
data.setDefaults();
data.getParameters();

/* DIALOGO PRINCIPAL
 */
class autopaletteMain extends Dialog
{
constructor()
{
    super();

    var dlg = this;
    var labelWidth = this.font.width("Brightness Control:");

    this.headerLabel = new Label( this );
    this.headerLabel.backgroundColor = 0x8dd0f8ff;
    this.headerLabel.textColor = 0x570069;
    this.headerLabel.useRichText = true;
    this.headerLabel.textAlignment = TextAlignment.Center|TextAlignment.VertCenter;
    this.headerLabel.margin = 4;
    this.headerLabel.text = "<p><b>" + TITLE + " - Version " + VERSION + "</b></p>";

    this.helpLabel = new Label(this);
    
        this.helpLabel.frameStyle   = FrameStyle.Box;
        this.helpLabel.margin       = 4;
        this.helpLabel.wordWrapping = true;
        this.helpLabel.useRichText  = true;
        this.helpLabel.text         = "This script allows the dynamic narrowband channel combinations for OSC and MONOCHROME images, based on <i>PIP (Power Inverted Pixels)</i> method for the RGB channels exponential transformation."+
      "<br><br>Available palettes (45 combinations):"+
      "<ul>"+
      "<li><b>Classic:</b> HOO, SHO, HSO and Foraxx</i></li>"+
      "<li><b>Foraxx Combinations:</b> SHO, HOS, OHS, HOO, HSO, OSH, SHO"+
      "</ul>"+
      "Image minimum <b>requisites</b>:"+
      "<ol>"+
      "<li>Background extraction and neutralization</li>"+
      "<li>Color calibration</li>"+
      "<li>No-linear or streched images</li>"+
      "</ol>"+
      "This script was developed by <b>Raúl Hussein</b><br />"+
		"Inspired in dynamic Foraxx combinations developed by <b>Marcelo Muñoz</b><br /><br />"+
		"More info in <a href='https://www.youtube.com/@astrocitas'>Astrocitas Youtube Channel</a><br />";
    

   /*
    * Radio Buttons
    */
   this.rbOSC = new RadioButton( this );
   
      this.rbOSC.checked = true;
      this.rbOSC.text = "OSC Dualband";
      this.rbOSC.toolTip = "<p>Select color DB Image</p>";
      this.rbOSC.onCheck = function ( checked ){
         dlg.referenceOSC_ViewList.enabled = checked;
         dlg.referenceHA_ViewList.enabled = !checked;
         dlg.referenceOIII_ViewList.enabled = !checked;
         dlg.referenceSII_ViewList.enabled = !checked;
         data.isOSC = !checked;
      }
   

   this.rbMonochrome = new RadioButton( this );
   
      this.rbMonochrome.text = "Monochrome NarrowBand";
      this.rbMonochrome.toolTip = "<p>Select monochrome NB Image</p>";
      this.rbMonochrome.onCheck = function ( checked ){
         data.isOSC = !checked;
      }
   

   this.radioButtons_Sizer = new HorizontalSizer;
   
      this.radioButtons_Sizer.spacing = 4;
      this.radioButtons_Sizer.addStretch();
      this.radioButtons_Sizer.add (this.rbOSC );
      this.radioButtons_Sizer.add (this.rbMonochrome);
   

   /*
    * Reference view list
    */
   // OSC
	this.referenceOSC_Label = new Label(this);
    
        this.referenceOSC_Label.text          = "Reference View:";
        this.referenceOSC_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;
        this.referenceOSC_Label.minWidth      = labelWidth;
    

	this.referenceOSC_ViewList = new ViewList(this);
    
        this.referenceOSC_ViewList.getAll();
        this.referenceOSC_ViewList.enable         = false;
        this.referenceOSC_ViewList.minWidth       = 300;
        setViewListCurrent( this.referenceOSC_ViewList, data.currentView );
        this.referenceOSC_ViewList.toolTip        = "<p>Select an OSC image</p>";
        this.referenceOSC_ViewList.onViewSelected = function(view) {
            data.currentView = view;
        };
   

	// HA
	this.referenceHA_Label = new Label(this);
    
        this.referenceHA_Label.text          = "Reference Ha:";
        this.referenceHA_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;
        this.referenceHA_Label.minWidth      = labelWidth;
    

	this.referenceHA_ViewList = new ViewList(this);
    
        this.referenceHA_ViewList.getAll();
        this.referenceHA_ViewList.enable         = false;
        this.referenceHA_ViewList.minWidth       = 300;
        setViewListCurrent( this.referenceHA_ViewList, data.referenceHA );
        this.referenceHA_ViewList.toolTip        = "<p>Select an Ha image</p>";
        this.referenceHA_ViewList.onViewSelected = function(view) {
            data.referenceHA = view;
        };
    

	// OIII
	this.referenceOIII_Label = new Label(this);
    
        this.referenceOIII_Label.text          = "Reference OIII:";
        this.referenceOIII_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;
        this.referenceOIII_Label.minWidth      = labelWidth;
    

	this.referenceOIII_ViewList = new ViewList(this);
    
        this.referenceOIII_ViewList.getAll();
        this.referenceOIII_ViewList.minWidth       = 300;
        this.referenceOIII_ViewList.enable         = false;
        setViewListCurrent( this.referenceOIII_ViewList, data.referenceOIII );
        this.referenceOIII_ViewList.toolTip        = "<p>Select an OIII image</p>";
        this.referenceOIII_ViewList.onViewSelected = function(view) {
            data.referenceOIII = view;
        };
    

	// SII
	this.referenceSII_Label = new Label(this);
    
        this.referenceSII_Label.text          = "Reference SII:";
        this.referenceSII_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;
        this.referenceSII_Label.minWidth      = labelWidth;
    

	this.referenceSII_ViewList = new ViewList(this);
    
        this.referenceSII_ViewList.getAll();
        this.referenceSII_ViewList.minWidth       = 300;
        this.referenceSII_ViewList.enable         = false;
        setViewListCurrent( this.referenceSII_ViewList, data.referenceSII );
        this.referenceSII_ViewList.toolTip        = "<p>Select an SII image</p>";
        this.referenceSII_ViewList.onViewSelected = function(view) {
            data.referenceSII = view;
        };
    


   dlg.referenceOSC_ViewList.enabled = true;
   dlg.referenceHA_ViewList.enabled = false;
   dlg.referenceOIII_ViewList.enabled = false;
   dlg.referenceSII_ViewList.enabled = false;


   this.referenceOSC_Sizer = new HorizontalSizer;
    
        this.referenceOSC_Sizer.spacing = 4;
        this.referenceOSC_Sizer.add(this.referenceOSC_Label);
        this.referenceOSC_Sizer.add(this.referenceOSC_ViewList, 200);
   

   this.referenceHA_Sizer = new HorizontalSizer;
    
        this.referenceHA_Sizer.spacing = 4;
        this.referenceHA_Sizer.add(this.referenceHA_Label);
        this.referenceHA_Sizer.add(this.referenceHA_ViewList, 100);
   

	this.referenceOIII_Sizer = new HorizontalSizer;
    
        this.referenceOIII_Sizer.spacing = 4;
        this.referenceOIII_Sizer.add(this.referenceOIII_Label);
        this.referenceOIII_Sizer.add(this.referenceOIII_ViewList, 100);
    

	this.referenceSII_Sizer = new HorizontalSizer;
    
        this.referenceSII_Sizer.spacing = 4;
        this.referenceSII_Sizer.add(this.referenceSII_Label);
        this.referenceSII_Sizer.add(this.referenceSII_ViewList, 100);
    


   /*
    * Palette Type
    */
	this.forax_Label               = new Label(this);
   this.forax_Label.text          = "Palette Method:";
   this.forax_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;
   this.forax_Label.minWidth      = labelWidth;

   this.forax_Combo = new ComboBox(this);
   this.forax_Combo.editEnabled = false;
   this.forax_Combo.toolTip = "<p>Select method to create the palette</p>1. Classic HOO/SHO/Hubble/Foraxx<br />2. Foraxx SHO/HOS/OHS/HOO/OSH/SOH<br />";
   this.forax_Combo.minWidth = labelWidth;
   this.forax_Combo.addItem("Classic HOO");
   this.forax_Combo.addItem("Classic SHO");
   this.forax_Combo.addItem("Classic Hubble (HSO)");
   this.forax_Combo.addItem("Classic Foraxx");
   this.forax_Combo.addItem("Foraxx SHO combinations");
   this.forax_Combo.addItem("Foraxx HOS combinations");
   this.forax_Combo.addItem("Foraxx OHS combinations");
	this.forax_Combo.addItem("Foraxx HOO combinations");
	this.forax_Combo.addItem("Foraxx HSO combinations");
	this.forax_Combo.addItem("Foraxx OSH combinations");
	this.forax_Combo.addItem("Foraxx SOH combinations");

	if (data.typePalette != null){
        this.forax_Combo.currentItem = data.typePalette;
   }

   this.forax_Combo.onItemSelected = function (){
        data.typePalette = this.currentItem;

        if (data.typePalette >= 3)
           dlg.blendMode_Combo.enabled = false;
        else
           dlg.blendMode_Combo.enabled = true;
    };

   this.all_CheckBox = new CheckBox(this);
	
		this.all_CheckBox.text = "All Classic Combinations";
		this.all_CheckBox.checked = false;
		this.all_CheckBox.onCheck = function (checked) {
         data.allCombinations = checked;
         dlg.forax_Combo.enabled = !checked;
      };
	

	this.typeForaxx_Sizer = new HorizontalSizer;
    
		this.typeForaxx_Sizer.spacing = 4;
		this.typeForaxx_Sizer.add(this.forax_Label);
		this.typeForaxx_Sizer.add(this.forax_Combo, 150);
    

   this.allCheckbox_Sizer = new HorizontalSizer;
    
		this.typeForaxx_Sizer.spacing = 4;
		this.typeForaxx_Sizer.add(this.all_CheckBox);
    

   /*
    * Linear Fit
    */
   this.linearfit_Label               = new Label(this);
   this.linearfit_Label.text          = "LinearFit mode:";
   this.linearfit_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;
   this.linearfit_Label.minWidth      = labelWidth;

   this.linearfit_Combo = new ComboBox(this);
   this.linearfit_Combo.editEnabled = false;
   this.linearfit_Combo.toolTip = "<p><b>LinearFit Mode</b></p>Select an reference image to apply LinearFit process to others images. <br /><br />"+
   "1. Ha as reference image <i>(recommended)</i><br />2. SII as reference image<br />3. OIII as reference image";
   this.linearfit_Combo.minWidth = labelWidth;
   //this.linearfit_Combo.maxWidth = 150;
   this.linearfit_Combo.addItem("None");
   this.linearfit_Combo.addItem("HA as reference");
   this.linearfit_Combo.addItem("SII as reference");
   this.linearfit_Combo.addItem("OIII as reference");
   this.linearfit_Combo.currentItem = data.linearFit;

   this.linearfit_Combo.onItemSelected = function (){
      data.linearFit = this.currentItem;
   };

   this.linearfit_Sizer = new HorizontalSizer;
   
      this.linearfit_Sizer.spacing = 4;
      this.linearfit_Sizer.add(this.linearfit_Label);
      this.linearfit_Sizer.add(this.linearfit_Combo, 80);
      this.linearfit_Sizer.addStretch();
   

    /*
     * Blend Mode
     */
    this.blendMode_Label               = new Label(this);
    this.blendMode_Label.text          = "Blend mode:";
    this.blendMode_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;
    this.blendMode_Label.minWidth      = labelWidth;

    this.blendMode_Combo = new ComboBox(this);
    this.blendMode_Combo.editEnabled = false;
    this.blendMode_Combo.toolTip = "<p><b>Blend Mode</b> <i>(Only for Classic Palettes)</i></p>Here we have three options to help create"+
    "the synthetic <u>green channel</u> using the Ha and OIII data.<br /><br />1. None<br />2. Neutral (50% Ha + 50% OIII)<br />"+
    "3. Soft (60% Ha + 40% OIII) <i>recommended</i><br />4. Hard (70% Ha + 30% OIII)<br />5. All modes<br />";
    this.blendMode_Combo.minWidth = labelWidth;
    this.blendMode_Combo.addItem("None");
    this.blendMode_Combo.addItem("Neutral (50% Ha + 50% OIII)");
    this.blendMode_Combo.addItem("Soft (60% Ha + 40% OIII)");
    this.blendMode_Combo.addItem("Hard (70% Ha + 30% OIII)");
    this.blendMode_Combo.addItem("All modes");
    this.blendMode_Combo.hideList();

    if (data.blendMode != null) this.blendMode_Combo.currentItem = data.blendMode;
    this.blendMode_Combo.onItemSelected = function (){
        data.blendMode = this.currentItem;
    };

    this.blendMode_Sizer = new HorizontalSizer;
    
        this.blendMode_Sizer.spacing = 4;
        this.blendMode_Sizer.add(this.blendMode_Label);
        this.blendMode_Sizer.add(this.blendMode_Combo, 150);
        this.blendMode_Sizer.addStretch();
    


   /*
    * OK, Cancel buttons
    */
    this.autoCloseCheck = new CheckBox( this );
    
      this.autoCloseCheck.checked = true;
      this.autoCloseCheck.text = "Close intermediate images  ";
      this.autoCloseCheck.onCheck = function( checked ) { data.autoClose = checked;  }
    

    this.ok_Button         = new PushButton(this);
    this.ok_Button.text    = "Calculate";
    this.ok_Button.cursor  = new Cursor(StdCursor.Checkmark);
    this.ok_Button.onClick = function() { this.dialog.ok(); };

    this.cancel_Button = new PushButton(this);
    this.cancel_Button.text    = "Cancel";
    this.cancel_Button.cursor  = new Cursor(StdCursor.Crossmark);
    this.cancel_Button.onClick = function() { this.dialog.cancel(); };

    this.newInstanceButton = new ToolButton( this );
    this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
    this.newInstanceButton.setScaledFixedSize( 24, 24 );
    this.newInstanceButton.toolTip = "New Instance";
    this.newInstanceButton.onMousePress = function()
    {
       this.hasFocus = true;
       this.pushed = false;
       data.setParameters();
       this.dialog.newInstance();
    };

    this.buttons_Sizer = new HorizontalSizer;
    this.buttons_Sizer.spacing = 6;
    this.buttons_Sizer.addStretch();
    this.buttons_Sizer.add(this.newInstanceButton);
    this.buttons_Sizer.addSpacing(110);
    this.buttons_Sizer.add(this.autoCloseCheck);
    this.buttons_Sizer.add(this.ok_Button);
    this.buttons_Sizer.add(this.cancel_Button);

   /*
    * Print Dialog
    */

   this.image_GroupBox = new GroupBox( this );
   
      this.image_GroupBox.title = "Select Image";
      this.image_GroupBox.sizer = new VerticalSizer;
   

   
      this.image_GroupBox.sizer.margin  = 6;
      this.image_GroupBox.sizer.spacing = 6;
      this.image_GroupBox.sizer.add(this.radioButtons_Sizer);
      this.image_GroupBox.sizer.addSpacing(4);
      this.image_GroupBox.sizer.add(this.referenceOSC_Sizer);
      this.image_GroupBox.sizer.addSpacing(4);
      this.image_GroupBox.sizer.add(this.referenceHA_Sizer);
      this.image_GroupBox.sizer.add(this.referenceOIII_Sizer);
      this.image_GroupBox.sizer.add(this.referenceSII_Sizer);
   

   this.palettee_GroupBox = new GroupBox( this );
   
      this.palettee_GroupBox.title = "Palette Creation";
      this.palettee_GroupBox.sizer = new VerticalSizer;
   

   
      this.palettee_GroupBox.sizer.margin  = 6;
      this.palettee_GroupBox.sizer.spacing = 6;
      this.palettee_GroupBox.sizer.add(this.typeForaxx_Sizer);
      this.palettee_GroupBox.sizer.addSpacing(4);
      this.palettee_GroupBox.sizer.add(this.linearfit_Sizer);
      this.palettee_GroupBox.sizer.addSpacing(4);
      this.palettee_GroupBox.sizer.add(this.blendMode_Sizer);
   

    this.sizer = new VerticalSizer;
    
        this.sizer.margin  = 6;
        this.sizer.spacing = 6;
        this.sizer.add(this.headerLabel);
        this.sizer.add(this.helpLabel);
        this.sizer.addSpacing(4);
        this.sizer.add(this.image_GroupBox);
		  this.sizer.addSpacing(8);
		  this.sizer.add(this.palettee_GroupBox);
        this.sizer.addSpacing(16);
        this.sizer.add(this.buttons_Sizer);
    

   this.windowTitle = TITLE;
   this.adjustToContents();
   this.setFixedSize();
}

} // class autopaletteMain


function main() {
   // Pop up the console and start writing out info
   Console.writeln("");
   Console.noteln("<b>",  TITLE , " " , VERSION, "</b>:");
   Console.hide();

   // Create the dialog and start looping
   var dialog = new autopaletteMain();
   for ( ;; ) {
       if (!dialog.execute()) break;

       paletteStart(data);
       //break;
   }

   return;
}


main();
