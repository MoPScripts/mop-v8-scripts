// PSFImage
//
// 	Create a PSF view
//
// 2018-09-12 max number of stars added
//
// changes:
// 24.03.21   2.1.12 changed loop variable in line 1118
// 09.05.20   2.1.9  bug in progressbar painting
// 23.04.20   2.1.8  cancel button added
// 03.04.20   2.1.7  save stars as .csv file
// 25.12.19   2.1.6  parameters saved as fits keys
// 14.03.19   2.1.5  syntax corrected in line 217
// 17.02.19   2.1.4  move pfs view image window near dialog window

#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// ----------------------------------------------------------------------------
// V8 PORT NOTICE
// ----------------------------------------------------------------------------
// Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
// (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
// July 2026. Original script copyright remains with Hartmut V. Bornemann.
// No rights to the original work are claimed or implied.
//
// V8 changes: added #engine v8 directive and version guard; removed all
// 14 #include <pjsr/...> directives (PJSR globals available without them);
// converted showDialog (extends Dialog), PreviewControl (extends Frame),
// and ViewDialog (extends Dialog) from __base__/.prototype = new X to
// class extends X / super(); replaced 12 .prototype. enum references
// (ChannelExtraction, DynamicPSF, PixelMath) with direct class access;
// replaced underscore constants with dot notation (TextAlign_Center/
// VertCenter, FrameStyle_Box, StdCursor_Arrow, UndoFlag_NoSwapFile,
// DataType_Boolean/Double); SaveFileDialog.fileName -> .filePath (2
// occurrences); removed one deprecated gc(true) call; added null-safety
// to 2 View.viewById() calls immediately following a new-view creation.
//
// Same "cancel" collision found in EmissionLineIntegration: showDialog
// used this.cancel as a custom boolean flag, colliding with Dialog's
// own built-in cancel() method -- V8 protects the built-in and throws
// "Cannot assign to read only property 'cancel'" where the old engine
// tolerated the overwrite silently. Renamed to cancelRequested
// throughout (10 occurrences, confirmed no genuine dialog.cancel()
// method calls existed anywhere in this file to conflict with it).
//
// Expanded all 18 with() blocks by hand, following the same methodology
// established on EmissionLineIntegration -- checking every bare
// identifier (including inside nested onClick/onPaint callback bodies,
// since with() extends its scope into nested closures) against the
// target's real properties and the enclosing function's own local
// variables, rather than a blind mechanical prefix. One block
// (btnCreate) had a nested with(this.parent.evaluation) inside its
// onClick handler; another (drawingProfile's onPaint) declares local
// cx/cy/rot variables that shadow same-named properties on the
// evaluation object it also reads from, so only the genuinely
// unshadowed properties (n, box, b, a, beta, sx, sy) needed prefixing
// there, not all of them. On the first pass through this file I
// initially converted a nested with() block but left its outer
// wrapper untouched -- caught via the follow-up with()-count grep
// check, not by assuming success from a diff -- worth remembering
// that a partial conversion can look plausible at a glance.
// ----------------------------------------------------------------------------

#feature-id    PSFImage : MoP V8 > PSFImage

#feature-info  Generates PSF image(s) for the use as External PSF in Deconvolution.<br/>\
               <br/>\
               Copyright &copy; 2018 Hartmut V. Bornemann

#define PSF_starIndex   0
#define PSF_function    1
#define PSF_circular    2
#define PSF_status      3
#define PSF_B           4
#define PSF_A           5
#define PSF_cx          6
#define PSF_cy          7
#define PSF_sx          8
#define PSF_sy          9
#define PSF_theta      10
#define PSF_beta       11
#define PSF_residual   12
#define PSF_mad   	  12
#define PSF_x0         13
#define PSF_y0         14
#define PSF_x1         15
#define PSF_y1         16

#define star_x0			3
#define star_y0			4
#define star_x1			5
#define star_y1			6
#define Dispose "dispose"
#define tab '\t'

#define ID     "PSFImage"
// Shadows clipping point in (normalized) MAD units from the median.
#define DEFAULT_AUTOSTRETCH_SCLIP  -2.80
// Target mean background in the [0,1] range.
#define DEFAULT_AUTOSTRETCH_TBGND   0.25
#define DEFAULT_AUTOSTRETCH_CLINK   true

#define maxStars     200
#define useStars      50
#define SensitivityDefault 1

#define TITLE  "PSF Image Creator"
#define VERSION "2.1.12"

// https://pixinsight.com/doc/tools/DynamicPSF/DynamicPSF.html

/* *****************************************************************************
 * *****************************************************************************
 *		DIALOG
 * *****************************************************************************
 * *****************************************************************************
*/

class showDialog extends Dialog
{
constructor(view, id)
{
   super();
   this.userResizable = true;

	var dlg   = this;
	this.view = view;
   this.id   = id;
	this.selectedStars = [];
	this.usedStars = [];
	this.psfImage = null;
	this.minMAD = 1;
	this.maxMAD = 0;
   this.cancelRequested = false;

	this.evaluation = null;

   var progressValue = 0;

   Console.writeln("Source " + id);

	// design window

   // my ©


   this.lblCopyright = new Label(this)
   this.lblCopyright.text = "© 2017, Hartmut V. Bornemann, ver. " + VERSION;

   this.lblViewID = new Label(this);
   this.lblViewID.useRichText = true;
   this.lblViewID.text = "<b>" + id + "</b>";

	this.gbx1 = new GroupBox(this);
	this.gbx1.title = "PSF function selection";

	this.cbMoffatPSF    = new CheckBox(this);
	this.cbMoffat10PSF  = new CheckBox(this);
	this.cbMoffat8PSF   = new CheckBox(this);
	this.cbMoffat6PSF   = new CheckBox(this);
	this.cbMoffat4PSF   = new CheckBox(this);
	this.cbMoffat25PSF  = new CheckBox(this);
	this.cbMoffat15PSF  = new CheckBox(this);

   this.cbMoffatPSF.checked = true;

	this.cbMoffatPSF.text   = "Moffat";
	this.cbMoffat10PSF.text = "Moffat10";
	this.cbMoffat8PSF.text  = "Moffat8";
	this.cbMoffat6PSF.text  = "Moffat6";
	this.cbMoffat4PSF.text  = "Moffat4";
	this.cbMoffat25PSF.text = "Moffat25";
	this.cbMoffat15PSF.text = "Moffat15";

	this.gbx1.sizer = new VerticalSizer(this);
      this.gbx1.sizer.margin = 8;
		this.gbx1.sizer.add(this.cbMoffatPSF);
		this.gbx1.sizer.add(this.cbMoffat10PSF);
		this.gbx1.sizer.add(this.cbMoffat8PSF);
		this.gbx1.sizer.add(this.cbMoffat6PSF);
		this.gbx1.sizer.add(this.cbMoffat4PSF);
		this.gbx1.sizer.add(this.cbMoffat25PSF);
		this.gbx1.sizer.add(this.cbMoffat15PSF);

   this.summary = new TextBox(this);
   this.summary.readOnly = true;

	this.gbx2 = new GroupBox(this);
	this.gbx2.title = "Numeric limits";

	this.numMax = new NumericEdit(this);
	this.numMax.label.text = "Amplitude maximum";
	this.numMax.label.width = 60;
	this.numMax.setPrecision( 2 );
	this.numMax.setRange(0, 1);
	this.numMax.setValue(0.8);

	this.numMin = new NumericEdit(this);
	this.numMin.label.text = "Amplitude minimum";
	this.numMin.setPrecision( 2 );
	this.numMin.setRange(0, 1);
	this.numMin.setValue(0.02);

   this.numSensitivity = new NumericControl(this);
   this.numSensitivity.real = true;
   this.numSensitivity.label.text = "Sensitivity:";
   this.numSensitivity.setRange(-3, 3);
   this.numSensitivity.slider.minWidth = 250;
   this.numSensitivity.setPrecision(2);
   this.numSensitivity.setValue( SensitivityDefault );
   this.numSensitivity.toolTip = "<p>Star detection sensitivity. " +
      "Increase the value to detect less stars. " +
      "Double click to set to default = " +
      SensitivityDefault + "</p>";
	this.numSensitivity.onValueUpdated = function( value ) {
		dlg.selectedStars = [];
	}
   this.numSensitivity.onMouseDoubleClick = function( x, y, buttonState,  modifiers )
		{dlg.numSensitivity.setValue(SensitivityDefault);}

   this.numN = new NumericControl(this);
   this.numN.real = false;
   this.numN.label.text = "Max N:";
   this.numN.setRange(1, maxStars);
   this.numN.slider.minWidth = 250;
   this.numN.setPrecision(0);
   this.numN.setValue( useStars );
   this.numN.toolTip = "<p>Set maximum number of stars.</p>";
   this.numN.onMouseDoubleClick = function( x, y, buttonState,  modifiers )
		{dlg.numN.setValue(useStars);}

	this.gbx2.sizer = new VerticalSizer(this);
      this.gbx2.sizer.margin = 8;
		this.gbx2.sizer.add(this.numSensitivity);
		this.gbx2.sizer.add(this.numMax);
		this.gbx2.sizer.add(this.numMin);
		this.gbx2.sizer.add(this.numN);

   this.progressBar = new Label(this);
      this.progressBar.lineWidth  = 1;
      this.progressBar.frameStyle = FrameStyle.Box;
      this.progressBar.textAlignment = TextAlignment.Center | TextAlignment.VertCenter;

      this.progressBar.onPaint = function( x0, y0, x1, y1 )
      {
         var g = new Graphics(dlg.progressBar);
         g.fillRect( x0, y0, x1, y1, new Brush(0xFFFFFFFF));
         if (progressValue > 0)
         {
            var l = (x1 - x0 + 1) * progressValue;
            g.fillRect( x0, y0, l, y1, new Brush(0xFF00EFE0));
         }
         g.end();
         dlg.progressBar.text = (progressValue * 100).toFixed(0) + "%";
      }

	this.btnEval = new PushButton(this);
      this.btnEval.icon = this.scaledResource(":/icons/execute.png");
		this.btnEval.text = "Evaluate";
      this.btnEval.toolTip = "<p>Collect stars and evaluate the best fitting function for each location</p>";
		this.btnEval.onClick = function(checked) {
         if (this.parent.selectedStars.length > 0)
         {
            message("Change sensitivity and re-run");
         }
         else
         {
            progressValue = 0;
            this.parent.summary.enabled = false;
            this.parent.gbx1.enabled = false;
            this.parent.gbx2.enabled = false;
            this.parent.btnCreate.enabled = false;
            this.parent.btnOK.enabled = false;
            this.parent.btnEval.enabled = false;
            this.parent.numRot.enabled = false;
            dlg.cancelButton.enabled = true;
            dlg.cancelRequested = false;
            dlg.progress(0);
            this.psfImage = null;
            this.parent.btnView.enabled = false;
            //
            this.parent.evaluation = this.parent.evaluate();
            //
            this.parent.btnView.enabled = this.parent.selectedStars.length > 0;
            dlg.cancelButton.enabled = false;
            this.parent.numRot.enabled = true;
            this.parent.btnEval.enabled = true;
            this.parent.btnOK.enabled = true;
            this.parent.gbx2.enabled = true;
            this.parent.gbx1.enabled = true;
            this.parent.summary.enabled = true;

            this.parent.drawingProfile.repaint();
            this.parent.drawingStar.repaint();
         }
		}

   this.cancelButton = new ToolButton(this);
      this.cancelButton.icon = this.scaledResource(":/icons/delete.png");
      this.cancelButton.enabled = false;
      this.cancelButton.onPress = function()
      {
         dlg.cancelRequested = true;
      }

	this.btnCreate = new PushButton(this);
		this.btnCreate.enabled = false;
		this.btnCreate.text = "Create";
      this.btnCreate.toolTip = "<p>Create a star profile image</p>";
		this.btnCreate.onClick = function(checked)
		{
			var psfName = getNewName("psf","");

			this.parent.summary.text += '\n' + "View" + '\t'  + psfName;

			var iw = new ImageWindow(this.parent.psfImage.width, this.parent.psfImage.height,
												1 , 32, true, false, psfName);
			iw.mainView.beginProcess(UndoFlag.NoSwapFile);
			iw.mainView.image.assign(this.parent.psfImage);
			iw.mainView.endProcess();
			iw.show();
			iw.visible = true;

         if (dlg.position.y < (iw.height + 100))
         {
            iw.position = new Point(dlg.position.x + dlg.width / 2 - 30,
                                    dlg.position.y + dlg.height);
         }
         else
         {
            iw.position = new Point(dlg.position.x + 64, // dlg.width / 2 - 30,
                                    dlg.position.y - iw.height - 100);
         }

			var keywords = [];

			var e = this.parent.evaluation;
				keywords.push( new FITSKeyword( "HISTORY", "", "Created with PSFImage.jy"));
				keywords.push( new FITSKeyword( "COMMENT", "", "Source " + this.parent.id));
				keywords.push( new FITSKeyword( "COMMENT", "", "Stars selected " + e.n));
				for (var i in e.functions)
				{
               if (e.functionList[i].count > 0)
                  keywords.push( new FITSKeyword( "COMMENT", "", "Function applied '" +
                  e.functionList[i].functionName + "' " + e.functionList[i].count + " stars"))
				}
				keywords.push( new FITSKeyword( "COMMENT", "", "Sensitivity = " + this.parent.numSensitivity.value));
				keywords.push( new FITSKeyword( "COMMENT", "", "Amplitudes = " + this.parent.numMax.value + " .. " +
                                                                          this.parent.numMin.value));
            keywords.push( new FITSKeyword( "B",      e.b.toString()));
				keywords.push( new FITSKeyword( "A",      e.a.toString()));
				keywords.push( new FITSKeyword( "SX",     e.sx.toString()));
				keywords.push( new FITSKeyword( "SY",     e.sy.toString()));
				keywords.push( new FITSKeyword( "THETA",  e.theta.toString()));
				keywords.push( new FITSKeyword( "BETA",   e.beta.toString()));
				keywords.push( new FITSKeyword( "R",      e.r.toString()));
				keywords.push( new FITSKeyword( "FWHMX",  e.FWHMx.toString()));
				keywords.push( new FITSKeyword( "FWHMY",  e.FWHMy.toString()));
			iw.keywords = keywords;
 		}

   this.lblState = new Label(this);
   this.lblState.text = "";
   //this.lblState.onMousePress = function( x, y, button, buttonState, modifiers ) {dlg.cancelRequested = true;}

	this.btnView = new PushButton(this);
	this.btnView.enabled = false;
	this.btnView.text = "View stars";
	this.btnView.toolTip = "<p>View selected stars.</p>";
	this.btnView.onClick = function(checked)
	{
		var dialog = new ViewDialog(this.parent.view, this.parent.usedStars);
		dialog.execute();
	}

	this.btnOK = new PushButton(this);
      this.btnOK.icon = this.scaledResource(":/icons/ok.png");
		this.btnOK.text = "OK";
      this.btnOK.toolTip = "<p>Quit this script and save settings</p>";
		this.btnOK.onClick = function(checked)
		{
			//
			// save settings
			//
			Settings.write(ID + "_sensitivity", DataType.Double, this.parent.numSensitivity.value);
			Settings.write(ID + "_max", DataType.Double, this.parent.numMax.value);
			Settings.write(ID + "_min", DataType.Double, this.parent.numMin.value);
			Settings.write(ID + "_moffatPSF", DataType.Boolean, this.parent.cbMoffatPSF.checked);
			Settings.write(ID + "_moffat10PSF", DataType.Boolean, this.parent.cbMoffat10PSF.checked);
			Settings.write(ID + "_moffat8PSF", DataType.Boolean, this.parent.cbMoffat8PSF.checked);
			Settings.write(ID + "_moffat6PSF", DataType.Boolean, this.parent.cbMoffat6PSF.checked);
			Settings.write(ID + "_moffat4PSF", DataType.Boolean, this.parent.cbMoffat4PSF.checked);
			Settings.write(ID + "_moffat25PSF", DataType.Boolean, this.parent.cbMoffat25PSF.checked);
			Settings.write(ID + "_moffat15PSF", DataType.Boolean, this.parent.cbMoffat15PSF.checked);
			//
         Console.hide();
			dialog.done(0);
		}

	this.drawingProfile = new Frame();
	this.drawingProfile.onPaint = function( x0, y0, x1, y1 )
		{
			var g = new Graphics( this );
			g.drawRect( x0, y0, x1, y1 );
			g.pen = new Pen(0xffff0000);
			g.drawText( 16, 16, "X Projection" );
			g.pen = new Pen(0xff0000ff);
			g.drawText( 16, 32, "Y Projection" );
			if (this.parent.evaluation != null)
			{
				var e = this.parent.evaluation;
					var ml = (x1 + x0) / 2;
					var cx = 0;
					var cy = 0;

					if (e.n > 0)
					{
						var rot = this.parent.numRot.value;
						var d = Math.sqrt(2 * e.box * e.box);
						var r = d / 2 ;

						var X = [];
						var Y = [];

						var c = Math.floor(e.box / 2) + 1;

						var x = 0;
						var y = 0;

						var max = moffat(cx, cy, e.b, e.a, cx, cy, e.beta, e.sx, e.sy);
						var min = moffat(c , c , e.b, e.a, cx, cy, e.beta, e.sx, e.sy);

						var f = 1 / (max-min);

						var xScale = (x1 - x0) / (2 * r);
						x = 0;
						y = 0;

						while (x < d)
						{
							var t = new transformXY(- c + x, 0, rot);
							var m = moffat(t.x + cx, t.y + cy, e.b, e.a, cx, cy, e.beta, e.sx, e.sy);
							m = (m - min) * f * y1;
							X.push(new Point(ml + (x - c) * xScale , y1 - m));
							x += 0.05;
						}

						x = 0;
						while (x < d)
						{
							var t = new transformXY(0, - c + x, rot);
							var m = moffat(t.x + cx, t.y + cy, e.b, e.a, cx, cy, e.beta, e.sx, e.sy);
							m = (m - min) * f * y1;
							Y.push(new Point(ml + (x - c) * xScale , y1 - m));
							x += 0.05;
						}
						g.antialiasing = true;
						g.pen = new Pen(0xffff0000);
						g.drawPolyline(X);
						g.pen = new Pen(0xff0000ff);
						g.drawPolyline(Y);
						g.pen = new Pen(0xff000000);
						g.drawLine(ml, y0, ml, y1);
					}
			}
			g.end();
		}

	this.drawingStar = new Frame();
	this.drawingStar.onPaint = function( x0, y0, x1, y1 )
		{
			var e = this.parent.evaluation;
			if (e == null) return;

			var g = new Graphics( this );
			g.drawRect( x0, y0, x1, y1 );
			var starBox = (y1 + y0) * 0.9 ;
			var z = (x0 + x1) / 2;


			if (e.n > 0)
			{
				var p = new Point(z - starBox / 2, (y1 + y0) * 0.05);
				starBox /= e.box;
				starBox = Math.floor(starBox) * e.box;
				var starRect = new Rect(p.x, p.y, p.x + starBox, p.y + starBox);
				g.drawRect(starRect);

				var zoom = starBox / this.parent.psfImage.width;
				var bmp = this.parent.psfImage.render(zoom);
				g.drawScaledBitmap(starRect, bmp );
				//
				// draw rotated ellipsoid
				//
 				g.pen= new Pen(0xffff0000, 2);
            g.drawText(starRect.x0 + 8, starRect.top + 16, "PSF X");

 				g.pen= new Pen(0xff4080ff, 2);
            g.drawText(starRect.x0 + 8, starRect.top + 32, "PSF Y");

 				g.pen= new Pen(0xff32CD32, 2);
            g.drawText(starRect.x0 + 8, starRect.top + 48, "FWHM");

				g.pen= new Pen(0x8f40ffff);
				g.drawLine(starRect.x0, starRect.center.y, starRect.x1,  starRect.center.y);
				g.drawLine(starRect.center.x, starRect.y0, starRect.center.x,  starRect.y1);

				g.antialiasing  = true;
				g.translateTransformation( starRect.center.x, starRect.center.y);

				var a = e.FWHMx * zoom;
				var b = e.FWHMy * zoom;
				g.rotateTransformation(e.theta * Math.PI / 180);

 				g.pen= new Pen(0xff32CD32);

				g.drawEllipse( - a / 2, - b / 2, a / 2, b / 2);

 				g.pen= new Pen(0xffff0000);

				g.drawLine(- a, 0, a, 0);

 				g.pen= new Pen(0xff4080ff);

				g.drawLine(0, - b, 0, b);

			 	g.resetTransformation();
			}

			g.end();
		}

   this.numRot = new NumericControl(this);
   this.numRot.real = true;
   this.numRot.label.text = "Rotation:";
   this.numRot.setRange(-90, 90);
   this.numRot.slider.setRange(-90, 90);
   this.numRot.slider.minWidth = 250;
   this.numRot.setPrecision(1);
   this.numRot.setValue( 0 );
   this.numRot.toolTip = "<p>Rotate star profile drawing.</p>";
	this.numRot.onValueUpdated = function( value ) {this.parent.drawingProfile.repaint();}
	this.numRot.onMouseDoubleClick = function( x, y, buttonState,  modifiers )
		{this.parent.numRot.setValue(0);}

	var buttonSizer = new HorizontalSizer();
	buttonSizer.margin = 8;
		buttonSizer.add(this.btnEval);
      buttonSizer.spacing = 8;
      buttonSizer.add(this.cancelButton);
		buttonSizer.spacing = 8;
		buttonSizer.add( this.btnCreate );
		buttonSizer.spacing = 8;
      buttonSizer.add(this.btnView);
		buttonSizer.addStretch();
		buttonSizer.spacing = 8;
		buttonSizer.add( this.btnOK );

   // left panel

   this.pnlLeft = new VerticalSizer;
      this.pnlLeft.margin = 8;
      this.pnlLeft.add(this.lblCopyright);
      this.pnlLeft.add(this.lblViewID);
      this.pnlLeft.add( this.gbx1 );
      this.pnlLeft.spacing = 8;
      this.pnlLeft.add( this.gbx2 );
      this.pnlLeft.add( this.summary);
      this.pnlLeft.spacing = 8;
      this.pnlLeft.add(this.progressBar);
      this.pnlLeft.spacing = 8;
      this.pnlLeft.add( buttonSizer );
      this.pnlLeft.spacing = 8;
      this.pnlLeft.add(this.lblState);

   // right panel

   this.pnlRight = new VerticalSizer;
      this.pnlRight.margin = 8;
		this.pnlRight.add(this.drawingProfile);
		this.pnlRight.spacing = 8;
		this.pnlRight.add(this.numRot);
		this.pnlRight.spacing = 8;
		this.pnlRight.add(this.drawingStar);

   this.sizer = new HorizontalSizer;
      this.sizer.margin = 8;
		this.sizer.add (this.pnlLeft);
		this.sizer.add (this.pnlRight );
   // window
   this.windowTitle = TITLE + " - " + VERSION;
   this.adjustToContents();
   this.userResizable = false;
   //
   // read settings
   //
   var x;
   x = Settings.read(ID + "_sensitivity",DataType.Double);
   if (Settings.lastReadOK) this.numSensitivity.setValue( x );

   x = Settings.read(ID + "_max",DataType.Double);
   if (Settings.lastReadOK) this.numMax.setValue( x );

   x = Settings.read(ID + "_min",DataType.Double);
   if (Settings.lastReadOK) this.numMin.setValue( x );

   x = Settings.read(ID + "_moffatPSF",DataType.Boolean);
   if (Settings.lastReadOK) this.cbMoffatPSF.checked   = x;

   x = Settings.read(ID + "_moffat10PSF",DataType.Boolean);
   if (Settings.lastReadOK) this.cbMoffat10PSF.checked = x;

   x = Settings.read(ID + "_moffat8PSF",DataType.Boolean);
   if (Settings.lastReadOK) this.cbMoffat8PSF.checked  = x;

   x = Settings.read(ID + "_moffat6PSF",DataType.Boolean);
   if (Settings.lastReadOK) this.cbMoffat6PSF.checked  = x;

   x = Settings.read(ID + "_moffat4PSF",DataType.Boolean);
   if (Settings.lastReadOK) this.cbMoffat4PSF.checked  = x;

   x = Settings.read(ID + "_moffat25PSF",DataType.Boolean);
   if (Settings.lastReadOK) this.cbMoffat25PSF.checked = x;

   x = Settings.read(ID + "_moffat15PSF",DataType.Boolean);
   if (Settings.lastReadOK) this.cbMoffat15PSF.checked = x;

	this.evaluate = function()
	{
      dlg.cancelRequested = false;
		this.summary.clear();
		this.usedStars = [];
		var sensitivity = this.numSensitivity.value;
		var Max = this.numMax.value;
		var Min = this.numMin.value;
		//
		// collect all fitted stars
		//
		var functions = [];

		if (this.cbMoffatPSF.checked) functions.push(DynamicPSF.Function_Moffat);
		if (this.cbMoffat10PSF.checked) functions.push(DynamicPSF.Function_Moffat10);
		if (this.cbMoffat8PSF.checked) functions.push(DynamicPSF.Function_Moffat8);
		if (this.cbMoffat6PSF.checked) functions.push(DynamicPSF.Function_Moffat6);
		if (this.cbMoffat4PSF.checked) functions.push(DynamicPSF.Function_Moffat4);
		if (this.cbMoffat25PSF.checked) functions.push(DynamicPSF.Function_Moffat25);
		if (this.cbMoffat15PSF.checked) functions.push(DynamicPSF.Function_Moffat15);

      var functionList = [];
      for (var i in functions)
      {
         var functionIndex = functions[i];
         var functionName  = "";

         if (functionIndex == DynamicPSF.Function_Moffat)   functionName  = "Moffat";
         if (functionIndex == DynamicPSF.Function_Moffat10) functionName  = "Moffat10";
         if (functionIndex == DynamicPSF.Function_Moffat8)  functionName  = "Moffat8";
         if (functionIndex == DynamicPSF.Function_Moffat6)  functionName  = "Moffat6";
         if (functionIndex == DynamicPSF.Function_Moffat4)  functionName  = "Moffat4";
         if (functionIndex == DynamicPSF.Function_Moffat25) functionName  = "Moffat25";
         if (functionIndex == DynamicPSF.Function_Moffat15) functionName  = "Moffat15";

         functionList.push({functionName:functionName, count:0});
      }

		var A = [];
		var B = [];
		var SX = [];
		var SY = [];
		var THETA = [];
		var BETA = [];

		var madLimit = 0;

		if (this.selectedStars.length == 0)
		{
			this.lblState.text = "***scanning";
			this.lblState.repaint();
			CoreApplication.processEvents();
			this.selectedStars = getStars(this.view, sensitivity, dlg);


         if (dlg.cancelRequested)
         {
            this.lblState.text = "***cancel";
            CoreApplication.processEvents();
            return null;
         }

			this.lblState.text = "***ready";
			CoreApplication.processEvents();

			// get min max MAD
			for (var i in this.selectedStars)
			{
				var sp = this.selectedStars[i];
				if (sp.mad > this.maxMAD) this.maxMAD = sp.mad;
				if (sp.mad < this.minMAD) this.minMAD = sp.mad;
			}

			var nValue = this.numN.value;
			if (this.selectedStars.length > 0)
			{
				this.numN.setRange(1, Math.min( this.selectedStars.length, maxStars));
				if (this.selectedStars.length < nValue)
					this.numN.setValue(this.selectedStars.length);
			}
		}
      else
      {
         this.lblState.text = "***re-select";
      }

		for (var i = 0; i < this.selectedStars.length; i++)
		{
			var sp = this.selectedStars[i];

			var index = functions.indexOf(sp.psf_function);

			if (index < 0) continue;

			if (sp.a < Min || sp.a > Max) continue;

			A.push(sp.a);
			B.push(sp.b);
			SX.push(sp.sx);
			SY.push(sp.sy);
			THETA.push(sp.theta);
			BETA.push(sp.beta);
			madLimit = sp.mad;
			this.usedStars.push(sp);

         functionList[index].count += 1;

			if (A.length == this.numN.value) break;
		}

		if (A.length > 0)
		{
			var b 	 = average(B);
			var a	 	 = average(A);
			var sx 	 = average(SX);
			var sy 	 = average(SY);
			var theta = average(THETA);
			var beta  = average(BETA);
			var r     = sy / sx;

			var FWHMx = 2 * sx * Math.sqrt(Math.pow(2, 1 / beta) - 1);
			var FWHMy = 2 * sy * Math.sqrt(Math.pow(2, 1 / beta) - 1);

			this.psfImage = createStarImage(b, a, sx, sy, theta, beta);

			var description =
				"Summary" + '\n' +
				"=======" + '\n' +
				"Source " + '\t' + this.id + '\n' +
				"N" + '\t'  + A.length + " (" + this.selectedStars.length + ")" + '\n' +
				"B" + '\t'  + b.toFixed(6) + '\n' +
				"A" + '\t'  + a.toFixed(6) + '\n' +
				"sx" + '\t'  + sx.toFixed(6) + '\n' +
				"sy" + '\t'  + sy.toFixed(6) + '\n' +
				"theta" + '\t'  + theta.toFixed(6) + '\n' +
				"beta" + '\t'  + beta.toFixed(6) + '\n' +
				"r" + '\t'  + r.toFixed(6) + '\n' +
				"FWHMx" + '\t'  + FWHMx.toFixed(2) + '\n' +
				"FWHMy" + '\t'  + FWHMy.toFixed(2) + '\n' +
				"MAD" + '\t'  + madLimit.toFixed(6) + " (" + this.minMAD.toFixed(6) +
							" .. " + this.maxMAD.toFixed(6) + ")";
            var functionsText = "";
            for (var i in functionList)
            {
               if (functionList[i].count > 0)
                  functionsText += '\n' + functionList[i].functionName + '\t' +
                                       functionList[i].count + " stars";
            }
            description += functionsText;

			this.summary.text = description;
			this.btnCreate.enabled = true;
			return {n:A.length, cx:0, cy:0, b:b, a:a, sx:sx, sy:sy, theta:theta,
					  beta:beta, r:r, functions:functions, functionList:functionList,
                 box:this.psfImage.width, FWHMx:FWHMx, FWHMy:FWHMy};
		}
		else
		{
			this.btnCreate.enabled = false;
			this.lblState.text = "***error";
			message("No stars found, change options and re-run");
			return null;// {n:0};
		}
	}

   this.progress = function(n)
   {
      progressValue = n;// Math.min(n, 1);
      dlg.progressBar.repaint();
   }
}

} // class showDialog

function createStarImage(b, a, sx, sy, theta, beta)
{
	//
	// implements Moffat function
	//
	var box = boxSize(b, a, beta, sx, sy, theta);

   var c = Math.floor(box / 2);

	var cx = c + 1;
	var cy = c + 1;

	var img = new Image(box, box);

	var max = moffat( cx, cy, b, a, cx, cy, beta, sx, sy);
	var min = moffat(0, 0, b, a, cx, cy, beta, sx, sy);

	var f = 1 / (max-min);

	for (var y = 0; y < img.height; y++)
	{
		for (var x = 0; x < img.width; x++)
		{
			var t = new transformXY(- c + x, - c + y, theta);
			var m = moffat(t.x + cx, t.y + cy, b, a, cx, cy, beta, sx, sy);
			m = (m - min) * f;
			img.setSample(m, x, img.height - y - 1);
		}
	}

	return img;
}

function boxSize(b, a, beta, sx, sy, theta)
{
   var max = moffat(0, 0, b, a, 0, 0, beta, sx, sy);

   var x = 0;
   var y = 0;
   var v = 2;

   while (true)
   {
      var t = new transformXY(x, 0, theta);
      var mx = moffat(x, 0, b, a, 0, 0, beta, sx, sy);
      mx /= max;

      if (v - mx < 0.01) break;

      v = mx;

      x += 1;

      if (x > 32) break;
   }

   v = 2;

   while (true)
   {
      var t = new transformXY(x, y, theta);
      var my = moffat(0, y, b, a, 0, 0, beta, sx, sy);
      my /= max;

      if (v - my < 0.01) break;

      v = my;

      y += 1;

      if (y > 32) break;
   }

   var box = Math.max( x - 1, y - 1);

   box *= 2;

   box +=1;

   return box;
}

function transformXY(x, y, theta)
{
   this.x =  x * Math.cos(theta * Math.RAD) + y * Math.sin(theta * Math.RAD);
   this.y = -x * Math.sin(theta * Math.RAD) + y * Math.cos(theta * Math.RAD);
}

function moffat(x, y, B, A, cx, cy, beta, sigmax, sigmay)
{
	var sqx = sigmax * sigmax;
	var sqy = sigmay * sigmay;
	var dx2 = Math.pow(x - cx, 2);
	var dy2 = Math.pow(y - cy, 2);

	return B + A / Math.pow((1 + dx2 / sqx + dy2 / sqy), beta);
}

function getStars(view, sensitivity, dlg)
{
   var std = new StarDetector();
   std.sensitivity = Math.pow(10.0, sensitivity);

   var stars = std.stars(view.image);

   if (stars == null) return [];
   if (stars.length == 0) return [];

   var barycenters = new Array;

   var s = stars[0];

   var keys = Object.keys(s);

   for (var k in keys) Console.writeln('Property ' + keys[k]);

   for (var i = 0; i != stars.length; ++i)
   {
      barycenters.push({
         position: stars[i].pos,
         radius: Math.max(3, Math.ceil(Math.sqrt(stars[i].size)))
      });
      CoreApplication.processEvents();
      if (dlg.cancelRequested) break;
   }

   dlg.lblState.text = '***' + barycenters.length.toString() + ' stars';

   if (dlg.cancelRequested)
   {
      return [];
   }

	// P.stars = [ // viewIndex, channel, status, x0, y0, x1, y1, x, y

   var dynamicPSF = new DynamicPSF;
   var radius = Math.round(0.75 * dynamicPSF.searchRadius);

   stars = [];

   for (var i = 0; i != barycenters.length; ++i) {
      stars.push(new Array(
         0, 0, DynamicPSF.Star_DetectedOk,
         barycenters[i].position.x - barycenters[i].radius,
         barycenters[i].position.y - barycenters[i].radius,
         barycenters[i].position.x + barycenters[i].radius,
         barycenters[i].position.y + barycenters[i].radius,
         barycenters[i].position.x,
         barycenters[i].position.y
      ));
   }
   Console.writeln("Detected stars "+ barycenters.length);

   var starProfiles = new Array;
   var increment = Math.floor(stars.length / 100);
   if (increment == 0) increment = stars.length;

   var remain = stars.length - increment * 100;

   //
   // PSF analysis
   //

	dynamicPSF.autoPSF = true;		// start with auto, select by function codes
	dynamicPSF.gaussianPSF = false;
   var views = new Array;
   views.push(new Array(view.id));
   dynamicPSF.views = views;
 	dynamicPSF.views[0] = view.id;
   dynamicPSF.signedAngles = true;
   dynamicPSF.regenerate = true;

   var progress = 0;

   var allStars = [];

   dlg.progress(progress);

   var index = 0;

   while (index < stars.length)
   {
      var starsSubset = [];

      var count = increment;

      if ((index + count >= stars.length) || (progress == 99))
         count = stars.length - index;

      if (remain > 0)
      {
         count += 1;
         remain -= 1;
      }

      for (var i = 0; i < count; i++) starsSubset.push(stars[index + i]);

      //Console.writeln('progress ' + progress + '\t' + index +  '\t' + count);

      dynamicPSF.stars = starsSubset;

      dynamicPSF.executeGlobal();

      Console.writeln("PSF stars "+dynamicPSF.psf.length);

      for (var i = 0; i < dynamicPSF.psf.length; ++i) {
         var psfRow = dynamicPSF.psf[i];
         allStars.push(psfRow);
         if (psfRow[PSF_status] == DynamicPSF.PSF_FittedOk)
         {
            starProfiles.push(new starProfile(
               psfRow[PSF_function],
               psfRow[PSF_circular],
               psfRow[PSF_status],
               psfRow[PSF_B],
               psfRow[PSF_A],
               psfRow[PSF_cx],
               psfRow[PSF_cy],
               psfRow[PSF_sx],
               psfRow[PSF_sy],
               psfRow[PSF_theta],
               psfRow[PSF_beta],
               psfRow[PSF_mad]
            ));
         }
      }

      index += count;
      progress = index / stars.length;

      CoreApplication.processEvents();
      dlg.progress(progress);

      if (dlg.cancelRequested) break;
   }

   if (dlg.cancelRequested) return [];


	var a = uniqueArray(starProfiles, starProfileCompareMAD);
	return a;
}

function starProfile(psf_function, psf_circular, psf_status, B, A, cx, cy,
							sx, sy, theta, beta, mad)//, x0, y0, x1, y1)
{
	this.psf_function = psf_function;
	this.psf_circular = psf_circular;
	this.psf_status = psf_status;
	this.a = A;
	this.b = B;
	this.cx = cx;
	this.cy = cy;
	this.sx = sx;
	this.sy = sy;
	this.theta = theta;
	this.beta = beta;
	this.mad = mad;
}

function starProfileCompare(a, b) {
   var ax = Math.round(a.cx);
   var ay = Math.round(a.cy);
   var bx = Math.round(b.cx);
   var by = Math.round(b.cy);
   return ax < bx ? -1 : ax > bx ? 1 : ay < by ? -1 : ay > by ? 1 : 0;
}

function starProfileCompareMAD(a, b) {
   return a.mad < b.mad ? -1 : 1;
}

function uniqueArray(values, compareFunction) {
   if (values.length < 2) {
      return values;
   }
   values.sort(compareFunction);

   var j = 0;
   for (var i = 1; i != values.length; ++i) {
      if (compareFunction(values[j], values[i]) == -1) {
         ++j;
         values[j] = values[i];
      }
   }
   return values.slice(0, j + 1);
}

function average(a)
{
	if (a == null) return 0;
	if (a.length == 0) return 0;
	return Math.sum(a) / a.length;
}

function getNewName(name, suffix)
{
   var newName = name + suffix;
   let n = 1;
   while (!ImageWindow.windowById(newName).isNull)
   {
      ++n;
      newName = name + suffix + n;
   }
   return newName;
}

function getAllMainViews()
{
   var mainViews = [];
   var images = ImageWindow.windows;
   for ( var i = 0; i < images.length; i++ )
   {
      if (images[i].mainView.isMainView) mainViews.push(images[i].mainView);
   }
   return mainViews;
}

function message(txt)
{
   var bx = new MessageBox(txt, "Error");
   bx.execute();
}

function copyView( view, newName)
{
   var P = new PixelMath;
   P.expression = "$T";
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.symbols = "";
   P.generateOutput = true;
   P.singleThreaded = false;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = true;
   P.showNewImage = false;//true;
   P.newImageId = newName;
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.SameAsTarget;
   P.newImageSampleFormat = PixelMath.SameAsTarget;
   if (P.executeOn(view))
	{
      var newView = View.viewById(newName);
      if (newView == null)
      {
         message("Could not find newly-created view '" + newName + "'", "Error");
         return null;
      }
      return newView;
	}
   {
      message("Mask creation failed in function copyView", "Error");
      return null;
   }
}

function GetWindowBmp(window)
{
   var imageOrg = window.mainView.image;
   var tmpW = null;
   try
   {
      tmpW = new ImageWindow(imageOrg.width, imageOrg.height, imageOrg.numberOfChannels,
         window.bitsPerSample, window.isFloatSample, imageOrg.isColor, "Aux");
      tmpW.mainView.beginProcess(UndoFlag.NoSwapFile);
      tmpW.mainView.image.apply(imageOrg);
     // ApplySTF(tmpW.mainView, window.mainView.stf);
      tmpW.mainView.endProcess();
      var bmp = new Bitmap(imageOrg.width, imageOrg.height);
      bmp.assign(tmpW.mainView.image.render());
      return bmp;
   } finally
   {
      tmpW.forceClose();
   }
}

// ********************************************************************************************
// Copyright (C) 2013, Andres del Pozo, modifications HVB
//
// ********************************************************************************************
class PreviewControl extends Frame
{
constructor(parent)
{
	super(parent);

   this.SetImage = function(image, metadata)
   {
      this.image = image;
      this.metadata = metadata;
      this.scaledImage = null;
      this.SetZoomOutLimit();
      this.UpdateZoom(-100);
      //this.stf_Button.visible = true;
   }

   this.UpdateZoom = function (newZoom, refPoint)
   {
      newZoom = Math.max(this.zoomOutLimit, Math.min(2, newZoom));
      if (newZoom == this.zoom && this.scaledImage)
         return;

      if(refPoint==null)
         refPoint=new Point(this.scrollbox.viewport.width/2, this.scrollbox.viewport.height/2);
      var imgx=null;
      if(this.scrollbox.maxHorizontalScrollPosition>0)
         imgx=(refPoint.x+this.scrollbox.horizontalScrollPosition)/this.scale;
      var imgy=null;
      if(this.scrollbox.maxVerticalScrollPosition>0)
         imgy=(refPoint.y+this.scrollbox.verticalScrollPosition)/this.scale;

      this.zoom = newZoom;
      this.scaledImage = null;
      // V8: gc(true) removed -- deprecated, V8 handles GC automatically
      if (this.zoom > 0)
      {
         this.scale = this.zoom;
         this.zoomVal_Label.text = format("%d:1", this.zoom);
      }
      else
      {
         this.scale = 1 / (-this.zoom + 2);
         this.zoomVal_Label.text = format("1:%d", -this.zoom + 2);
      }
      if (this.image)
         this.scaledImage = this.image.scaled(this.scale);
      else
         this.scaledImage = {width:this.metadata.width * this.scale, height:this.metadata.height * this.scale};

      this.scrollbox.maxHorizontalScrollPosition = Math.max(0, this.scaledImage.width - this.scrollbox.viewport.width);
      this.scrollbox.maxVerticalScrollPosition = Math.max(0, this.scaledImage.height - this.scrollbox.viewport.height);

      if (this.scrollbox.maxHorizontalScrollPosition>0 && imgx!=null)
         this.scrollbox.horizontalScrollPosition = (imgx*this.scale)-refPoint.x;
      if (this.scrollbox.maxVerticalScrollPosition>0 && imgy!=null)
         this.scrollbox.verticalScrollPosition = (imgy*this.scale)-refPoint.y;

      this.scrollbox.viewport.update();
   }

	this.zoomIn_Button = new ToolButton( this );
   this.zoomIn_Button.icon = this.scaledResource( ":/icons/zoom-in.png" );
   this.zoomIn_Button.setScaledFixedSize( 20, 20 );
   this.zoomIn_Button.toolTip = "Zoom in";
   this.zoomIn_Button.onMousePress = function()
   {
      this.parent.UpdateZoom(this.parent.zoom+1);
   };

   this.zoomOut_Button = new ToolButton( this );
   this.zoomOut_Button.icon = this.scaledResource( ":/icons/zoom-out.png" );
   this.zoomOut_Button.setScaledFixedSize( 20, 20 );
   this.zoomOut_Button.toolTip = "Zoom in";
   this.zoomOut_Button.onMousePress = function()
   {
      this.parent.UpdateZoom(this.parent.zoom-1);
   };


   this.zoom11_Button = new ToolButton( this );
   this.zoom11_Button.icon = this.scaledResource( ":/icons/zoom-1-1.png" );
   this.zoom11_Button.setScaledFixedSize( 20, 20 );
   this.zoom11_Button.toolTip = "Zoom 1:1";
   this.zoom11_Button.onMousePress = function()
   {
      this.parent.UpdateZoom(1);
   };

/*
 * this.stf_Button =  new ToolButton( this );
   this.stf_Button.text = "STF";
   this.stf_Button.visible = false;
   this.stf_Button.toolTip = "ScreenTransferFunction";
   this.stf_Button.onMousePress = function()
   {
      var preview = this.parent;
      preview.onCustomSTF.call(this);
   }
*/

   this.buttons_Sizer = new HorizontalSizer;
   this.buttons_Sizer.add( this.zoomIn_Button );
   this.buttons_Sizer.add( this.zoomOut_Button );
   this.buttons_Sizer.add( this.zoom11_Button );
   this.buttons_Sizer.addStretch();
 	//this.buttons_Sizer.add( this.stf_Button );

   this.setScaledMinSize(300,200);
   this.zoom = 1;
   this.scale = 1;
   this.zoomOutLimit = -5;
   this.mp = new Point();
   this.scrollbox = new ScrollBox(this);
   //this.scrollbox.autoScroll = true;
   this.scrollbox.tracking = true;
   this.scrollbox.cursor = new Cursor(StdCursor.Arrow);

   this.scroll_Sizer = new HorizontalSizer;
   this.scroll_Sizer.add( this.scrollbox );

   this.SetZoomOutLimit = function()
   {
      var scaleX = Math.ceil(this.metadata.width/this.scrollbox.viewport.width);
      var scaleY = Math.ceil(this.metadata.height/this.scrollbox.viewport.height);
      var scale = Math.max(scaleX,scaleY);
      this.zoomOutLimit = -scale + 2;
   }

   this.scrollbox.onHorizontalScrollPosUpdated = function (newPos)
   {
      this.viewport.update();
   }
   this.scrollbox.onVerticalScrollPosUpdated = function (newPos)
   {
      this.viewport.update();
   }

   this.forceRedraw = function()
   {
      this.scrollbox.viewport.update();
   };

   this.scrollbox.viewport.onMouseWheel = function (x, y, delta, buttonState, modifiers)
   {
      var preview = this.parent.parent;
      preview.UpdateZoom(preview.zoom + (delta > 0 ? -1 : 1), new Point(x,y));
   }

   this.scrollbox.viewport.onMousePress = function ( x, y, button, buttonState, modifiers )
   {
      var preview = this.parent.parent;

      if(preview.onCustomMouseDown)
      {
         var p = preview.transform(x, y, preview);
         preview.onCustomMouseDown.call(this, p.x, p.y, button, buttonState, modifiers )
         if (modifiers == 1)
         {
         }
      }
      else
      {
         this.parent.parent.mp = new Point(x, y);
      }
   }

   this.scrollbox.viewport.onMouseMove = function ( x, y, buttonState, modifiers )
   {
      var preview = this.parent.parent;
      var p =  preview.transform(x, y, preview);

      preview.Xval_Label.text = p.x.toString();
      preview.Yval_Label.text = p.y.toString();

      if(preview.onCustomMouseMove)
      {
         preview.onCustomMouseMove.call(this, p.x, p.y, buttonState, modifiers )
      }
      else if (buttonState == 1)
      {
         var dx = x - this.parent.parent.mp.x;
         var dy = y - this.parent.parent.mp.y;

         var xn = this.parent.parent.scrollbox.horizontalScrollPosition - dx;
         var yn = this.parent.parent.scrollbox.verticalScrollPosition - dy;

         this.parent.parent.scrollbox.setScrollPosition( xn, yn);
         CoreApplication.processEvents();
         this.parent.parent.mp = new Point(x, y);
      }
   }

   this.scrollbox.viewport.onMouseRelease = function (x, y, button, buttonState, modifiers)
   {
      var preview = this.parent.parent;

      var p =  preview.transform(x, y, preview);
      if(preview.onCustomMouseUp)
      {
         preview.onCustomMouseUp.call(this, p.x, p.y, button, buttonState, modifiers )
      }
   }

   this.scrollbox.viewport.onResize = function (wNew, hNew, wOld, hOld)
   {
      var preview = this.parent.parent;
      if(preview.metadata && preview.scaledImage)
      {
         this.parent.maxHorizontalScrollPosition = Math.max(0, preview.scaledImage.width - wNew);
         this.parent.maxVerticalScrollPosition = Math.max(0, preview.scaledImage.height - hNew);
         preview.SetZoomOutLimit();
         preview.UpdateZoom(preview.zoom);
      }
      this.update();
   }

   this.scrollbox.viewport.onPaint = function (x0, y0, x1, y1)
   {
      var preview = this.parent.parent;
      var graphics = new Graphics(this);

      graphics.fillRect(x0,y0, x1, y1, new Brush(0xff202020));
      var offsetX = this.parent.maxHorizontalScrollPosition>0 ?
            -this.parent.horizontalScrollPosition :
               (this.width-preview.scaledImage.width)/2;
      var offsetY = this.parent.maxVerticalScrollPosition>0 ?
            -this.parent.verticalScrollPosition:
               (this.height-preview.scaledImage.height)/2;
      graphics.translateTransformation(offsetX, offsetY);
      if(preview.image)
         graphics.drawBitmap(0, 0, preview.scaledImage);
      else
         graphics.fillRect(0, 0, preview.scaledImage.width, preview.scaledImage.height, new Brush(0xff000000));

      graphics.pen = new Pen(0xffffffff,0);
      graphics.drawRect(-1, -1, preview.scaledImage.width + 1, preview.scaledImage.height + 1);

      if(preview.onCustomPaint)
      {
         graphics.antialiasing = true;
         graphics.scaleTransformation(preview.scale,preview.scale);
         preview.onCustomPaint.call(this, graphics, x0, y0, x1, y1);
      }
      graphics.end();
   }

   this.transform = function(x, y, preview)
   {
      var scrollbox = preview.scrollbox;
      var ox = 0;
      var oy = 0;
      ox = scrollbox.maxHorizontalScrollPosition>0 ?
            -scrollbox.horizontalScrollPosition :
               (scrollbox.viewport.width-preview.scaledImage.width)/2;

      oy = scrollbox.maxVerticalScrollPosition>0 ?
            -scrollbox.verticalScrollPosition:
               (scrollbox.viewport.height-preview.scaledImage.height)/2;

      var coordPx = new Point((x - ox) / preview.scale, (y - oy) / preview.scale);
      return new Point(coordPx.x, coordPx.y);
   }

   this.center = function()
   {
      var preview = this;
      var scrollbox = preview.scrollbox;
      var x = scrollbox.viewport.width / 2;
      var y = scrollbox.viewport.height / 2;
      var p =  this.transform(x, y, preview);
      return p;
   }

   this.zoomLabel_Label =new Label(this);
   this.zoomLabel_Label.text = "Zoom:";
   this.zoomVal_Label =new Label(this);
   this.zoomVal_Label.text = "1:1";

   this.Xlabel_Label = new Label(this);
   this.Xlabel_Label .text = "X:";
   this.Xval_Label = new Label(this);
   this.Xval_Label.text = "---";
   this.Ylabel_Label = new Label(this);
   this.Ylabel_Label.text = "Y:";
   this.Yval_Label = new Label(this);
   this.Yval_Label.text = "---";

   this.coords_Frame = new Frame(this);
   this.coords_Frame.backgroundColor = 0xffffffff;
   this.coords_Frame.sizer = new HorizontalSizer;
   this.coords_Frame.sizer.margin = 2;
   this.coords_Frame.sizer.spacing = 4;
   this.coords_Frame.sizer.add(this.zoomLabel_Label);
   this.coords_Frame.sizer.add(this.zoomVal_Label);
   this.coords_Frame.sizer.addSpacing(6);
   this.coords_Frame.sizer.add(this.Xlabel_Label);
   this.coords_Frame.sizer.add(this.Xval_Label);
   this.coords_Frame.sizer.addSpacing(6);
   this.coords_Frame.sizer.add(this.Ylabel_Label);
   this.coords_Frame.sizer.add(this.Yval_Label);

   this.coords_Frame.sizer.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.add(this.buttons_Sizer);
   this.sizer.add(this.scroll_Sizer);
   this.sizer.add(this.coords_Frame);
}

} // class PreviewControl

// ************************************ PreviewControl definition end

class ViewDialog extends Dialog
{
constructor(fo, selectedStars)
{
   super();

   var dlg = this;

 	this.view = copyView(fo.window.mainView, "view");
	//
	// FITS files must be stretched
	//
	ApplyAutoSTF( this.view,
						DEFAULT_AUTOSTRETCH_SCLIP,
						DEFAULT_AUTOSTRETCH_TBGND, true);

   stfHisto(this.view);

   this.bitmap = GetWindowBmp(this.view.window);

   this.view.window.forceClose();

	var g = new Graphics( this.bitmap );

	g.antialiasing = true;
   g.pen= new Pen(0xffff00ff, 2); //   g.pen= new Pen(0xff32CD32, 2);
	for (var i in selectedStars)
	{
		var s = selectedStars[i];
		g.drawCircle( s.cx, s.cy, 9 );
	}
	g.end();

   fo.window.zoomToOptimalFit();

	this.previewControl = new PreviewControl(this);
	this.previewControl.setMinSize(fo.window.viewportWidth + 20,
      fo.window.viewportHeight +
      this.previewControl.coords_Frame.height +
      this.previewControl.zoomIn_Button.height + 20);
	this.previewControl.SetImage(this.bitmap, this.bitmap);
   this.previewControl.UpdateZoom(-1, new Point());// fo.window.zoomFactor);

   this.btnCSV = new PushButton(this);
   this.btnCSV.text ="Write csv-file";
      this.btnCSV.onClick = function(checked)
      {
         var d = new SaveFileDialog();
         d.overwritePrompt = true;
         d.caption = "Save Star List to .csv";
         d.filters = [["Tabulated file", "*.csv"]];

         if (d.execute())
         {
            var header = ['cx', 'cy', 'a', 'b', 'sx', 'sy', 'theta', 'beta', 'mad'];
            try
            {
               var file = new File();
               file.create(d.filePath);

               var items = [];

               items.push(header[0]);
               items.push(header[1]);
               items.push(header[2].toUpperCase());
               items.push(header[3].toUpperCase());
               items.push(header[4]);
               items.push(header[5]);
               items.push(header[6]);
               items.push(header[7]);
               items.push(header[8].toUpperCase());

               file.outTextLn(items.join('\t'));

               for (var i in selectedStars)
               {
                  var row = selectedStars[i];
                  items = [];

                  items.push(row.cx.toFixed(2));
                  items.push(row.cy.toFixed(2));
                  items.push(row.a.toFixed(6));
                  items.push(row.b.toFixed(6));
                  items.push(row.sx.toFixed(2));
                  items.push(row.sy.toFixed(2));
                  items.push(row.theta.toFixed(2));
                  items.push(row.beta.toFixed(2));
                  items.push(row.mad.toExponential());

                  file.outTextLn(items.join('\t'));
               }
               file.close();
               new MessageBox("Stars saved as " + d.filePath).execute();
            }
            catch (ex)
            {
               new MessageBox("Write failed, stars not saved: " + ex.message).execute();
            }
         }
      }

   this.btnOK = new PushButton(this);
      this.btnOK.text = 'OK';
      this.btnOK.onClick = function(checked)
      {
         dlg.done(0);
      }


   this.buttonFrame = new Frame(this);
   this.buttonFrame.sizer = new HorizontalSizer();
      this.buttonFrame.sizer.margin = 8;
      this.buttonFrame.sizer.add(this.btnCSV);
      this.buttonFrame.sizer.addStretch();
      this.buttonFrame.sizer.add(this.btnOK)


   this.sizer= new VerticalSizer();
	this.sizer.add(this.previewControl);
   this.sizer.add(this.buttonFrame);
   this.windowTitle = "View " + fo.id;
   this.adjustToContents();
}

} // class ViewDialog

/*
 * STF Auto Stretch routine
 */
function ApplyAutoSTF( view, shadowsClipping, targetBackground, rgbLinked )
{
   var stf = new ScreenTransferFunction;

   var n = view.image.isColor ? 3 : 1;

   var median = view.computeOrFetchProperty( "Median" );

   var mad = view.computeOrFetchProperty( "MAD" );
   mad.mul( 1.4826 ); // coherent with a normal distribution

   if ( rgbLinked )
   {
      /*
       * Try to find how many channels look as channels of an inverted image.
       * We know a channel has been inverted because the main histogram peak is
       * located over the right-hand half of the histogram. Seems simplistic
       * but this is consistent with astronomical images.
       */
      var invertedChannels = 0;
      for ( var c = 0; c < n; ++c )
         if ( median.at( c ) > 0.5 )
            ++invertedChannels;

      if ( invertedChannels < n )
      {
         /*
          * Noninverted image
          */
         var c0 = 0, m = 0;
         for ( var c = 0; c < n; ++c )
         {
            if ( 1 + mad.at( c ) != 1 )
               c0 += median.at( c ) + shadowsClipping * mad.at( c );
            m  += median.at( c );
         }
         c0 = Math.range( c0/n, 0.0, 1.0 );
         m = Math.mtf( targetBackground, m/n - c0 );

         stf.STF = [ // c0, c1, m, r0, r1
                     [c0, 1, m, 0, 1],
                     [c0, 1, m, 0, 1],
                     [c0, 1, m, 0, 1],
                     [0, 1, 0.5, 0, 1] ];
      }
      else
      {
         /*
          * Inverted image
          */
         var c1 = 0, m = 0;
         for ( var c = 0; c < n; ++c )
         {
            m  += median.at( c );
            if ( 1 + mad.at( c ) != 1 )
               c1 += median.at( c ) - shadowsClipping * mad.at( c );
            else
               c1 += 1;
         }
         c1 = Math.range( c1/n, 0.0, 1.0 );
         m = Math.mtf( c1 - m/n, targetBackground );

         stf.STF = [ // c0, c1, m, r0, r1
                     [0, c1, m, 0, 1],
                     [0, c1, m, 0, 1],
                     [0, c1, m, 0, 1],
                     [0, 1, 0.5, 0, 1] ];
      }
   }
   else
   {
      /*
       * Unlinked RGB channnels: Compute automatic stretch functions for
       * individual RGB channels separately.
       */
      var A = [ // c0, c1, m, r0, r1
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1],
               [0, 1, 0.5, 0, 1] ];

      for ( var c = 0; c < n; ++c )
      {
         if ( median.at( c ) < 0.5 )
         {
            /*
             * Noninverted channel
             */
            var c0 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) + shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 0.0;
            var m  = Math.mtf( targetBackground, median.at( c ) - c0 );
            A[c] = [c0, 1, m, 0, 1];
         }
         else
         {
            /*
             * Inverted channel
             */
            var c1 = (1 + mad.at( c ) != 1) ? Math.range( median.at( c ) - shadowsClipping * mad.at( c ), 0.0, 1.0 ) : 1.0;
            var m  = Math.mtf( c1 - median.at( c ), targetBackground );
            A[c] = [0, c1, m, 0, 1];
         }
      }

      stf.STF = A;
   }
   stf.executeOn( view );

//   console.writeln( "<end><cbr/><br/>" );
}

function stfHisto(view)
{

   var stf = view.stf;

	var H = [[  0, 0.0, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0],
				[  0, 0.5, 1.0, 0, 1.0]];;

	if (view.image.isColor)
	{
		for (var c = 0; c < 3; c++)
		{
			H[c][0] = stf[c][1];
			H[c][1] = stf[c][0];
		}
	}
	else
	{
		H[3][0] = stf[0][1];
		H[3][1] = stf[0][0];
	}

	var STF = new ScreenTransferFunction;

	view.stf =  [ // c0, c1, m, r0, r1
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000],
	[0.00000, 1.00000, 0.50000, 0.00000, 1.00000]
	];

	STF.executeOn(view)

	var HT = new HistogramTransformation;
	HT.H = H;
	HT.executeOn(view);
}


function houseKeeping()
{
   //Console.writeln("Remove temporary files");
	var views = getAllMainViews();
	for (var i = 0; i < views.length; i++)
	{
      //Console.writeln("Check " + views[i].id);
		if (views[i].hasProperty( Dispose ))
		{
         //Console.writeln("dispose " + views[i].id);
			var dispose = views[i].propertyValue(Dispose);
			if (dispose)
			{
				views[i].window.forceClose();
			}
		}
	}
}




//////////////////////////////////////////////////////////////////////////////
//
// Main script entry point
//
function main()
{
   Console.hide();
   //Console.show();
   // Get access to the current active image window.
	houseKeeping();
   //return;
   var window = ImageWindow.activeWindow;
   if ( window.isNull )
   {
      message( "No active image" );
   }
   else
   {
      var id = window.currentView.fullId;
      if (window.currentView.image.isColor)
      {
			var L = getNewName("temp", "L");
			var P = new ChannelExtraction;
			P.colorSpace = ChannelExtraction.CIELab;
			P.channels = [ // enabled, id
				[true, L],
				[false, ""],
				[false, ""]
			];
			P.sampleFormat = ChannelExtraction.SameAsSource;
			P.executeOn(window.currentView);
			var view = View.viewById(L);
         if (view == null)
         {
            message("Could not find newly-extracted luminance view '" + L + "'");
            return;
         }
         view.window.hide();
			window = view.window;
      }
      else if (window.currentView.isPreview)
      {
         var L = getNewName("temp", "L");
         var img = new Image(window.currentView.image);
         window = new ImageWindow( img.width, img.height );
         window.mainView.beginProcess();
         window.mainView.image.assign(img);
         window.mainView.endProcess();
      }
      else
      {
         var tempView = copyView(window.currentView, "temp");
         window = tempView.window;
      }

      window.hide();
      window.mainView.setPropertyValue(Dispose, true);

		Console.abortEnabled = true;
      try
      {
		   var dialog = new showDialog(window.mainView, id);
		   dialog.execute();
      }
      catch (ex) {Console.writeln(ex);}
      Console.writeln("PSFImage closed");
		houseKeeping();
 	}
}

main();
