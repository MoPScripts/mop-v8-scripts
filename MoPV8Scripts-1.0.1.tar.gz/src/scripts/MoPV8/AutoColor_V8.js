#engine v8
CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/*
AutoColor.js: Automatic ColorCalibration
================================================================================

Automatischer Weißabgleich und Hintergrund-Neutralisierung
AutoColor ersetzt die Prozesse BackgroundNeutralization und ColorCalibration.
Aus dem kombinierten RGB wird ein kalibriertes RGB, mit dem die weitere
Bearbeitung erfolgen kann (Schmalband, Delinearisierung, Luminanz, ...).

Automatic BackgroundNeutralization and ColorCalibration

AutoColor substitutes the BackgroundNeutralization and ColorCalibration
processes in a single step. The channel combined RGB becomes a calibrated image
ready for further processing (narrowband, delinearization, luminance, ...).
================================================================================

 *
 *    Copyright Hartmut V. Bornemann, 2016
 *
 * Image calibration is performed by background evaluation and calculation of
 * mean intensities over background of each channel.
 * These values are used by PixInsight standard processes
 * BackgroundNeutralizaion and ImageCalibration, which
 * perform the adjustment of background and colors as usual.
 * In addition, all values are written to the Process Console for manual
 * adjustments, if neccessary.
 *
 * History
 * 01.11.2016 Iterations set to 100
 *
 * ----------------------------------------------------------------------------
 * V8 PORT NOTICE
 * ----------------------------------------------------------------------------
 * Ported to PixInsight 1.9.4 V8 JavaScript engine by Peter Proulx
 * (peterproulx@gmail.com), Masters of PixInsight (www.mastersofpixinsight.com)
 * June 2026. Original script copyright remains with Hartmut V. Bornemann.
 * No rights to the original work are claimed or implied.
 *
 * V8 changes: added #engine v8 directive and version guard; replaced the
 * single .prototype. enum reference (BackgroundNeutralization.prototype.
 * TargetBackground -> BackgroundNeutralization.TargetBackground) required
 * by the V8 engine's process parameter binding. No other changes were
 * necessary - this script contains no dialogs, no with() statements, and
 * no legacy __base__/.prototype inheritance patterns.
 * ----------------------------------------------------------------------------
*/

#feature-id    AutoColor : MoP V8> AutoColor

#define VERSION "1.1.2"

#feature-info neutralize background and calibrate the rgb image.<br>\
   <br>\Written by Hartmut V. Bornemann.<br>\
   <br>\
   References: None<br>\
   <br>\
/**/

#define Iterations 100


function main()
{
   // Get access to the current active image window.
   var window = ImageWindow.activeWindow;
   if ( window.isNull ) throw new Error( "No active image" );

   console.show();
   console.writeln( "Auto Color Calibration: " + window.currentView.fullId);
   console.flush();

   var img = window.currentView.image;
   if (img.numberOfChannels == 3)
   {

      var channelR;
      var channelG;
      var channelB;
      var target;
      var sigma;
      var nSigma = 0;

      console.writeln(format("Image size       %i x %i", img.width, img.height));

      var subImage = new Image(img);

      var w = subImage.width;
      var h = subImage.height;

      if (w > 256 && h > 255)
      {
         subImage.cropTo( w * 0.1, h * 0.1, w * 0.9, h * 0.9);
         console.writeln(format("Measure subframe %i x %i", subImage.width,
               subImage.height));
      }

      console.writeln( "Channel intensities over background");
      console.flush();

      var S      = [0, 0, 0];
      var I      = [0, 0, 0];
      var strRGB = "RGB";

      for (var channel = 0; channel < 3; channel++)
      {
         subImage.selectedChannel = channel;
         S[channel] = ImageBackgroundMean(subImage, Iterations, 1);
         I[channel] = subImage.mean() - S[channel];
         console.writeln(format("Intensity %c %.8f, Background %.8f",
                              strRGB[channel], I[channel], S[channel]));
         console.flush();
      }

      var m = Math.min(I[0], I[1], I[2]);
      channelR = m / I[0];
      channelG = m / I[1];
      channelB = m / I[2];

      target = Math.max(S[0], S[1], S[2]);

      var index = S.indexOf(target);    // which channel makes the target?
      var sigmaOfTarget = 0;
      subImage.selectedChannel = index;
      sigma = subImage.stdDev();
      nSigma = 3 * sigma;
      console.writeln( format("Target channel: %c", strRGB[index]));
      console.writeln( format("Target value    %.8f" , target));
      console.writeln( format("Sigma           %.8f" , sigma));

      // exec processes

      bgNeutralization(window.currentView, target, nSigma);

      calibration(window.currentView, channelR, channelG, channelB, target + nSigma);

      console.writeln( format("White balance correction factors:"));
      console.writeln( format("Red    %.6f" , channelR));
      console.writeln( format("Green  %.6f" , channelG));
      console.writeln( format("Blue   %.6f" , channelB));
      console.writeln( "");
   }
   else
   {
      console.writeln( "this is not a color image" );
   }
}

function ImageBackgroundMean(img, mxiter, readnoise)
{
   // This is a translation from DAOPHOT sub MMM
   //
   // INPUTS:
   //       img - Image, is unaltered by this program.
   // OUTPUTS
   // skymod    - Scalar giving estimated mode of the sky values
   // SIGMA     - Scalar giving standard deviation of the peak in the sky
   //             histogram.  If for some reason it is impossible to derive
   //             skymod, then SIGMA = -1.0
   // SKEW      - Scalar giving skewness of the peak in the sky histogram

   if (mxiter == 0) mxiter = 50;
   var minsky = 20;
   var sky = [];
   img.getSamples (sky);

   var nsky = sky.length;
   var nlast = nsky-1;        // Subscript of last pixel in SKY array
   sky.sort(function (a, b) {return a - b;}); // Sort SKY in ascending values
   // Median of all sky values
   var skymid = 0.5*sky[Int((nsky-1)/2)] + 0.5*sky[Int(nsky/2)];
   var defSky = skymid;
   var cut = Math.min( skymid-sky[0],sky[nsky-1] - skymid );
   var cut2 = skymid + cut;
   var cut1 = skymid - cut;

   // Select the pixels between Cut1 and Cut2

   var j1 = -1;
   var j2 = 0;

   for (var i = 0; i < nsky; i++)
   {
      if (sky[i] >= cut1)
      {
         j1 = i;
         j2 = i;
         for (var j = 0; j < nsky; j++)
         {
            if (sky[j] <= cut2)
               j2 = j;
            else
               break;
         }
         break;
      }
   }

   if (j1 < 0)
   {
      Console.writeln("ERROR - No sky values fall within " +
                        cut1.toFixed(2) + " and " + cut2.toFixed(3));
      return -1;
   }

   var good = j2 - j1 + 1;

   var delta  = new Array(good);
   for (var i = 0; i < good; i++)
   {
      delta[i] = sky[j1 + i] - skymid; //Subtract median to improve arithmetic accuracy
   }
   var sum = total(delta);
   var sumsq = totalSqrd(delta);
   // Highest value accepted at upper end of vector
   var maximm = j2;
   // Highest value reject at lower end of vector
   var minimm = j1 - 1;
   // Compute mean and sigma (from the first pass).
   var skymed = 0.5*sky[Int((minimm+maximm+1)/2)] +
                0.5*sky[Int((minimm+maximm)/2 ) + 1];   // median
   var skymn = sum/(maximm-minimm);                     // mean
   var sigma = Math.sqrt(sumsq/(maximm-minimm)-Math.pow(skymn,2)); // sigma
   skymn = skymn + skymid; // Add median which was subtracted off earlier
   // If mean is less than the mode, then the contamination is slight, and the
   //    mean value is what we really want.
   var skymod =  (skymed < skymn) ? 3.0 * skymed - 2.0 * skymn : skymn;
   // Console.writeln("skymod "+skymod);
   // Rejection and recomputation loop:
   var clamp = 1;
   var old   = 0;
   var niter = 0;
   while (true)
   {
      niter += 1;
      if (niter > mxiter)
      {
         Console.writeln("ERROR - Too many (" + mxiter + ") iterations, " +
                         "unable to compute sky, default returned");
         return defSky;
      }
      if ( (maximm-minimm) < minsky )
      {
         Console.writeln("ERROR - Too few ("+ (maximm-minimm).toString() +
                         ") valid sky elements, unable to compute sky");
         return -1;
      }
      // Compute Chauvenet rejection criterion
      var  r = Math.log10( maximm-minimm );
      r = Math.max( 2.0, ( -0.1042*r + 1.1695)*r + 0.8895 );
      // Compute rejection limits (symmetric about the current mode)
      var cut = r*sigma + 0.5*Math.abs(skymn-skymod);
      cut1 = skymod - cut;
      cut2 = skymod + cut;
      // Recompute mean and sigma by adding and/or subtracting sky values
      // at both ends of the interval of acceptable values.
      var redo = false;
      var newmin = minimm;
      var tst_min = sky[newmin+1] >= cut1; // Is minimm+1 above current CUT?
      var done = (newmin == -1) & tst_min;   // Are we at first pixel of SKY?
      if (!done) done = (sky[Math.max(newmin, 0)] < cut1) & tst_min;
      if (!done)
      {
         var istep = 1 - 2 * boolToInteger(tst_min);
         while (!done)
         {
            newmin = newmin + istep;
            done = (newmin == -1) || (newmin == nlast);
            if (!done) done = (sky[newmin] <= cut1) && (sky[newmin+1] >= cut1);
         }
         if (tst_min)
            delta = SkySub(sky, newmin + 1, minimm, skymid);
         else
            delta = SkySub(sky, minimm + 1, newmin, skymid);

         sum   -= istep * total(delta);
         sumsq -= istep * totalSqrd(delta);
         redo   = true;
         minimm = newmin;
      }

      //

      var newmax = maximm;
      var tst_max = sky[maximm] <= cut2;  // Is current maximum below upper cut?
      done = (maximm == nlast) && tst_max; // Are we at last pixel of SKY array?
      if (!done) done = tst_max && (sky[Math.min((maximm+1), nlast)] > cut2);
      if (!done)
      {
         istep = -1 + 2 * boolToInteger(tst_max); // Increment up or down?
         while (!done)
         {
            newmax = newmax + istep;
            done = (newmax == nlast) || (newmax == -1);
            if (!done)
               done = ( sky[newmax] <= cut2 ) && ( sky[newmax+1] >= cut2 );
         }
         if (tst_max)
            delta = SkySub(sky, maximm + 1, newmax, skymid);
         else
            delta = SkySub(sky, newmax + 1, maximm, skymid);
         sum   += istep * total(delta);
         sumsq += istep * totalSqrd(delta);
         redo   = true;
         maximm = newmax;
      }
     /*
         Compute mean and sigma (from this pass).
     */
      nsky = maximm - minimm;
      if ( nsky < minsky )
      {
         Console.writeln("ERROR - Outlier rejection left too few sky elements");
         return -1;
      }

      skymn = sum/nsky;
      sigma = Math.sqrt(Math.max(sumsq / nsky - Math.pow(skymn, 2), 0));
      skymn = skymn + skymid;
      /*
            Determine a more robust median by averaging the central 20% of pixels.
            Estimate the median using the mean of the central 20 percent of sky
            values.   Be careful to include a perfectly symmetric sample of pixels about
            the median, whether the total number is even or odd within the acceptance
            interval
      */
      var center = (minimm + 1 + maximm)/2.0;
      var side = Math.round(0.2 * (maximm - minimm)) / 2.0 + 0.25;
      var J = Math.round(center - side);
      var K = Math.round(center + side);
      /*
         In case  the data has a large number of of the same (quantized)
         intensity, expand the range until both limiting values differ from the
         central value by at least 0.25 times the read noise.
      */
      if (readnoise > 0)
      {
         var L = Math.round(center - 0.25);
         var M = Math.round(center + 0.25);
         while ((J > K) & (K < nsky - 1) &
                      (((sky[L] - sky[J]) < r) | ((sky[K] - sky[M]) < r)))
         {
            J -= 1
            K += 1
         }
      }

      skymed = total(SkySub(sky, J, K, 0)) / (K - J + 1);

      /*
         If the mean is less than the median, then the problem of contamination
         is slight, and the mean is what we really want.
      */

      var dmod;
      if (skymed < skymn)
         dmod = 3.0*skymed-2.0*skymn-skymod;
      else
         dmod = skymn - skymod;
      // prevent oscillations by clamping down if sky adjustments are changing sign
      if (dmod*old < 0) clamp = 0.5*clamp;
      skymod = skymod + clamp*dmod;
      old = dmod;

      if(!redo) break;
   }

   // for later use:
   // skew = (skymn - skymod) / Math.max(1.0, sigma);
   // nsky = maximm - minimm;

   return skymod;
}

function SkySub( Values, StartIndex, EndIndex, Reduction)
{
   //
   // copy a subarray and subtract a constant value
   //
   var v = new Array(EndIndex - StartIndex + 1);
   for (var i = 0; i <= v.length - 1; i++)
   {
      v[i] = Values[i + StartIndex] - Reduction;
   }
   return v;
}

function boolToInteger(b)
{
   if (b)
      return 1;
   else
      return 0;
}

function Int(f)
{
   if (f < 0)
      return Math.ceil(f);
   else
      return Math.floor(f);
}

function total(array)
{
   var sum = 0;
   for (var i=0; i<array.length; i++)
   {
      sum += array[i];
   }
   return sum;
}

function totalSqrd(array)
{
   var sum = 0;
   for (var i=0; i<array.length; i++)
   {
      sum += Math.pow(array[i], 2);
   }
   return sum;
}

function bgNeutralization(view, target, nSigma)
{
   var P = new BackgroundNeutralization;
   P.backgroundReferenceViewId = "";
   P.backgroundLow = 0.0000000;
   P.backgroundHigh = target + nSigma;
   P.useROI = false;
   P.roiX0 = 0;
   P.roiY0 = 0;
   P.roiX1 = 0;
   P.roiY1 = 0;
   P.mode = BackgroundNeutralization.TargetBackground;
   P.targetBackground = target;
   P.executeOn(view);
}

function calibration(view, r, g, b, target)
{
   var P = new ColorCalibration;
   P.whiteReferenceViewId = "";
   P.whiteLow = 0.0000000;
   P.whiteHigh = 0.9000000;
   P.whiteUseROI = false;
   P.whiteROIX0 = 0;
   P.whiteROIY0 = 0;
   P.whiteROIX1 = 0;
   P.whiteROIY1 = 0;
   P.structureDetection = false;
   P.structureLayers = 5;
   P.noiseLayers = 1;
   P.manualWhiteBalance = true;
   P.manualRedFactor = r;
   P.manualGreenFactor = g;
   P.manualBlueFactor = b;
   P.backgroundReferenceViewId = "";
   P.backgroundLow = 0.0000000;
   P.backgroundHigh = target;
   P.backgroundUseROI = false;
   P.backgroundROIX0 = 0;
   P.backgroundROIY0 = 0;
   P.backgroundROIX1 = 0;
   P.backgroundROIY1 = 0;
   P.outputWhiteReferenceMask = false;
   P.outputBackgroundReferenceMask = false;
   P.executeOn(view);
}


main();
