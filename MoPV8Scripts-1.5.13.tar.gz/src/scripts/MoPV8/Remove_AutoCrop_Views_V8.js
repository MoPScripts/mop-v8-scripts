#engine v8

////////////////////////////////////////////////////////////////////////////
//
// Remove AutoCrop Views - Masters of PixInsight
// V8 / PixInsight 1.9.4+ rebuild using direct CheckBox selection controls
//
// Pete Proulx, May 2025
// Ron Brecher Technical Reviewer
// Masters of PixInsight
//
////////////////////////////////////////////////////////////////////////////

#define TITLE   "Remove AutoCrop Views - Masters of PixInsight"
#define VERSION "V8 Checkbox v9 - abbreviated id, full-name filename"

// v8 fix (2026-10-02): the saved ACR file's identifier kept coming back as
// the full filter name (e.g. "MasterLight_Blue") instead of the R/G/B/L
// abbreviation whenever the file was reopened fresh, even though the
// in-session view looked correct right after the script ran. Two earlier
// attempts at a fix, in order, both failed:
//   1. Reassigning mainView.id on the already-open window and re-saving --
//      confirmed by testing to do nothing; a fresh reopen still showed the
//      old full-name identifier.
//   2. Abbreviating the filter name in the SAVED FILENAME instead (theory:
//      PixInsight derives the default id from the filename) -- confirmed by
//      testing that the filename changed correctly (e.g. "..._ACR_B.xisf")
//      but the identifier on reopen still didn't, proving the id is not
//      filename-derived either.
// The actual mechanism (confirmed by a screenshot of the same file open as
// two windows: the live "integration_B" session window, and a fresh reopen
// of the identical file showing "MasterLight_Blue", its original pre-script
// id): PixInsight tracks the id a window had at CREATION time and keeps
// embedding that into the file on every save, ignoring any later
// reassignment of mainView.id. Fixed by building a brand new ImageWindow
// with the correct id baked in from construction (same approach the V8
// migration rules already require elsewhere for ImageWindow.duplicate(),
// Rule 37: a window's identity has to be set at birth, not patched in after
// the fact), copying the processed image and FITS keywords into it, and
// saving that window instead of the renamed one. The saved filename keeps
// the full filter name (Red/Green/Blue/Luminance) -- the identifier and the
// filename are independent.

#feature-id RemoveAutoCropViews : MoP V8> Remove AutoCrop Views
#feature-info Remove AutoCrop Views - Select Specific Views, Rename by FILTER, Save Final ACR Files

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

let parameters = {
   saveMode: true,
   save: function()
   {
      Parameters.set( "saveMode", this.saveMode );
   },
   load: function()
   {
      if ( Parameters.has( "saveMode" ) )
         this.saveMode = Parameters.getBoolean( "saveMode" );
   }
};

function safeString( v )
{
   return v === undefined || v === null ? "" : String( v );
}

function normalizedId( id )
{
   return safeString( id ).toLowerCase();
}

function isAutoCropViewId( id )
{
   let s = normalizedId( id );
   return s.indexOf( "integration_autocrop" ) !== -1 ||
          s.indexOf( "integration_auto_crop" ) !== -1 ||
          (s.indexOf( "integration" ) !== -1 && s.indexOf( "autocrop" ) !== -1);
}

function isCleanedAcrViewId( id )
{
   let s = normalizedId( id );
   return s.indexOf( "_acr_" ) !== -1 ||
          s.indexOf( "acr_" ) === 0 ||
          s.indexOf( "_autocrop_removed" ) !== -1;
}

function hasMatchingCropMask( id, cropMaskIds )
{
   let s = normalizedId( id );
   if ( isCropMaskViewId( s ) || isCleanedAcrViewId( s ) )
      return false;

   // Strict rule: only process a view when the exact companion crop mask
   // is open. This prevents already-clean ACR files from being processed again.
   return cropMaskIds.indexOf( s + "_crop_mask" ) >= 0 ||
          cropMaskIds.indexOf( s + "_cropmask" ) >= 0 ||
          cropMaskIds.indexOf( s.replace( /_autocrop$/, "" ) + "_crop_mask" ) >= 0;
}

function isCropMaskViewId( id )
{
   let s = normalizedId( id );
   return s.indexOf( "crop_mask" ) !== -1 || s.indexOf( "cropmask" ) !== -1;
}

function sanitizeFilterName( filter )
{
   try
   {
      let result = safeString( filter ).trim();
      if ( result.length === 0 )
         return "Unknown";

      if ( result.charAt( 0 ) === "'" || result.charAt( 0 ) === '"' )
         result = result.substring( 1 );
      if ( result.length > 0 && (result.charAt( result.length - 1 ) === "'" || result.charAt( result.length - 1 ) === '"') )
         result = result.substring( 0, result.length - 1 );

      let cleaned = "";
      for ( let i = 0; i < result.length && i < 50; ++i )
      {
         let ch = result.charAt( i );
         if ( (ch >= "A" && ch <= "Z") ||
              (ch >= "a" && ch <= "z") ||
              (ch >= "0" && ch <= "9") ||
               ch === "-" || ch === "." || ch === "_" )
            cleaned += ch;
         else
            cleaned += "_";
      }

      cleaned = cleaned.replace( /^_+/, "" ).replace( /_+$/, "" );
      return cleaned.length > 0 ? cleaned : "FilterUnknown";
   }
   catch ( e )
   {
      Console.warningln( "sanitizeFilterName error: " + e );
      return "FilterError";
   }
}

function abbreviateFilterName( filter )
{
   // Abbreviate common Red/Green/Blue/Luminance variants to R/G/B/L
   // for ChannelCombination compatibility.
   // All other filter names (Ha, SII, OIII, OSC, LQUAD, etc.) pass through unchanged.
   // Unknown passes through as-is.
   let f = filter.trim().toLowerCase();
   if ( f === "red"       ) return "R";
   if ( f === "rd"        ) return "R";
   if ( f === "green"     ) return "G";
   if ( f === "grn"       ) return "G";
   if ( f === "gr"        ) return "G";
   if ( f === "blue"      ) return "B";
   if ( f === "blu"       ) return "B";
   if ( f === "bl"        ) return "B";
   if ( f === "luminance" ) return "L";
   if ( f === "lum"       ) return "L";
   if ( f === "l"         ) return "L";
   return filter;
}

function getFilterNameFromWindow( win )
{
   try
   {
      let keywords = win.keywords;
      for ( let i = 0; i < keywords.length; ++i )
      {
         if ( safeString( keywords[i].name ).toUpperCase() === "FILTER" )
            return sanitizeFilterName( keywords[i].value );
      }
   }
   catch ( e )
   {
      Console.warningln( "Could not read FILTER keyword: " + e );
   }
   return "Unknown";
}

function getOpenWindowsSnapshot()
{
   let raw = [];
   let cropMaskIds = [];
   let windows = ImageWindow.windows;

   for ( let i = 0; i < windows.length; ++i )
   {
      let win = windows[i];
      if ( win && !win.isNull )
      {
         let id = safeString( win.mainView.id );
         let isMask = isCropMaskViewId( id );
         if ( isMask )
            cropMaskIds.push( normalizedId( id ) );

         raw.push( {
            window: win,
            viewId: id,
            isCropMask: isMask,
            width: win.mainView.image.width,
            height: win.mainView.image.height,
            filterName: getFilterNameFromWindow( win )
         } );
      }
   }

   for ( let j = 0; j < raw.length; ++j )
   {
      let info = raw[j];
      info.hasCropMask = hasMatchingCropMask( info.viewId, cropMaskIds );

      // V6 strict behavior:
      // A view is processable only if it has an actual matching _crop_mask view.
      // Do not process MasterLight/integration/ACR files based on name or FILTER alone.
      info.isAutocrop = !info.isCropMask && !isCleanedAcrViewId( info.viewId ) && info.hasCropMask;
   }

   return raw;
}

function makeUniqueViewId( desiredId )
{
   let newId = desiredId;
   let n = 1;

   for ( ;; )
   {
      let exists = false;
      try
      {
         let w = ImageWindow.windowById( newId );
         exists = w && !w.isNull;
      }
      catch ( e1 )
      {
         try
         {
            let v = View.viewById( newId );
            exists = v && !v.isNull;
         }
         catch ( e2 )
         {
            exists = false;
         }
      }

      if ( !exists )
         return newId;

      newId = desiredId + "_" + n.toString();
      ++n;
   }
}

function waitBriefly( ms )
{
   let t0 = Date.now();
   while ( Date.now() - t0 < ms ) {}
}

class ProgressTracker
{
   constructor( total )
   {
      this.total = Math.max( total, 1 );
      this.current = 0;
      this.errors = [];
      this.warnings = [];
   }

   step( message )
   {
      ++this.current;
      let percent = Math.round( (this.current / this.total) * 100 );
      Console.writeln( "Progress [" + percent + "%] (" + this.current + "/" + this.total + ") " + message );
   }

   addError( message )
   {
      this.errors.push( message );
      Console.warningln( "ERROR: " + message );
   }

   addWarning( message )
   {
      this.warnings.push( message );
      Console.warningln( "WARNING: " + message );
   }

   summary()
   {
      return {
         processed: this.current,
         total: this.total,
         errors: this.errors.length,
         warnings: this.warnings.length,
         success: Math.max( 0, this.current - this.errors.length )
      };
   }
}

function removePreviews( win )
{
   try
   {
      let count = 0;
      if ( typeof win.previewCount !== "undefined" )
         count = win.previewCount;
      else if ( typeof win.numberOfPreviews !== "undefined" )
         count = win.numberOfPreviews;

      for ( let i = count - 1; i >= 0; --i )
         win.deletePreview( i );

      Console.writeln( count > 0 ? "Removed " + count + " previews from " + win.mainView.id : "No previews to remove from " + win.mainView.id );
   }
   catch ( e )
   {
      Console.warningln( "Could not remove previews from " + win.mainView.id + ": " + e );
   }
}

class ViewSelectionDialog extends Dialog
{
   constructor()
   {
      super();
      parameters.load();

      this.windowTitle = TITLE;
      this.minWidth = 760;
      this.minHeight = 620;

      this.viewData = [];
      this.checkBoxes = [];
      this.allAutocropSelected = true;

      this.titleLabel = new Label( this );
      this.titleLabel.text = "Remove AutoCrop Views";
      this.titleLabel.textAlignment = TextAlignment.Center;
      this.titleLabel.styleSheet = "font-weight: bold; font-size: 16px; padding: 8px;";

      this.websiteLabel = new Label( this );
      this.websiteLabel.text = "www.mastersofpixinsight.com";
      this.websiteLabel.textAlignment = TextAlignment.Center;

      this.instructions = new TextBox( this );
      this.instructions.readOnly = true;
      this.instructions.frameStyle = FrameStyle.Box;
      this.instructions.setScaledMinHeight( 125 );
      this.instructions.text =
         "This V8 build uses direct CheckBox controls instead of a TreeBox checklist.\n\n" +
         "• Only views with an actual matching _crop_mask view are detected and checked automatically.\n" +
         "• Already-clean ACR files are ignored, even if they are open with the original files.\n" +
         "• Uncheck any view you do not want to process.\n" +
         "• The script removes previews, reads the FILTER keyword, saves ACR files, and reopens the clean views.\n" +
         "• _crop_mask views are not listed here; matching crop_mask views are closed after processing.";

      this.selectionGroup = new GroupBox( this );
      this.selectionGroup.title = "Detected Views With Matching Crop Masks";

      this.selectAllButton = new PushButton( this );
      this.selectAllButton.text = "Select All";
      this.selectAllButton.onClick = () =>
      {
         for ( let i = 0; i < this.checkBoxes.length; ++i )
            this.checkBoxes[i].checked = true;
         this.updateCount();
      };

      this.selectNoneButton = new PushButton( this );
      this.selectNoneButton.text = "Select None";
      this.selectNoneButton.onClick = () =>
      {
         for ( let i = 0; i < this.checkBoxes.length; ++i )
            this.checkBoxes[i].checked = false;
         this.updateCount();
      };

      this.refreshButton = new PushButton( this );
      this.refreshButton.text = "Refresh Views";
      this.refreshButton.onClick = () => { this.refreshViewList(); };

      this.countLabel = new Label( this );
      this.countLabel.text = "Views selected: 0";
      this.countLabel.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      this.countLabel.styleSheet = "font-weight: bold;";

      this.controlsSizer = new HorizontalSizer;
      this.controlsSizer.spacing = 8;
      this.controlsSizer.add( this.selectAllButton );
      this.controlsSizer.add( this.selectNoneButton );
      this.controlsSizer.add( this.refreshButton );
      this.controlsSizer.addStretch();
      this.controlsSizer.add( this.countLabel );

      this.listBox = new Control( this );
      this.listSizer = new VerticalSizer;
      this.listSizer.margin = 6;
      this.listSizer.spacing = 4;
      this.listBox.sizer = this.listSizer;

      this.selectionSizer = new VerticalSizer;
      this.selectionSizer.margin = 8;
      this.selectionSizer.spacing = 8;
      this.selectionSizer.add( this.controlsSizer );
      this.selectionSizer.add( this.listBox, 100 );
      this.selectionGroup.sizer = this.selectionSizer;

      this.modeGroup = new GroupBox( this );
      this.modeGroup.title = "Output Mode";

      this.saveMode = new RadioButton( this );
      this.saveMode.text = "Save ACR files to disk - Keeps your original XISF masters intact";
      this.saveMode.checked = parameters.saveMode;
      this.saveMode.onCheck = () => { if ( this.saveMode.checked ) parameters.saveMode = true; };

      this.viewOnlyMode = new RadioButton( this );
      this.viewOnlyMode.text = "View-only mode - Load clean views, then delete the ACR files";
      this.viewOnlyMode.checked = !parameters.saveMode;
      this.viewOnlyMode.onCheck = () => { if ( this.viewOnlyMode.checked ) parameters.saveMode = false; };

      this.modeSizer = new VerticalSizer;
      this.modeSizer.margin = 8;
      this.modeSizer.spacing = 6;
      this.modeSizer.add( this.saveMode );
      this.modeSizer.add( this.viewOnlyMode );
      this.modeGroup.sizer = this.modeSizer;

      this.newInstanceButton = new ToolButton( this );
      this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
      this.newInstanceButton.setScaledFixedSize( 24, 24 );
      this.newInstanceButton.toolTip = "Create Process Icon - Drag to save current settings";
      this.newInstanceButton.onMousePress = () => { parameters.save(); this.newInstance(); };

      this.processButton = new PushButton( this );
      this.processButton.text = "Process Selected Views";
      this.processButton.defaultButton = true;
      this.processButton.icon = this.scaledResource( ":/icons/ok.png" );
      this.processButton.onClick = () => { parameters.saveMode = this.saveMode.checked; parameters.save(); this.ok(); };

      this.cancelButton = new PushButton( this );
      this.cancelButton.text = "Cancel";
      this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
      this.cancelButton.onClick = () => { this.cancel(); };

      this.buttonSizer = new HorizontalSizer;
      this.buttonSizer.spacing = 10;
      this.buttonSizer.add( this.newInstanceButton );
      this.buttonSizer.addStretch();
      this.buttonSizer.add( this.processButton );
      this.buttonSizer.add( this.cancelButton );

      this.mainSizer = new VerticalSizer;
      this.mainSizer.margin = 12;
      this.mainSizer.spacing = 12;
      this.mainSizer.add( this.titleLabel );
      this.mainSizer.add( this.websiteLabel );
      this.mainSizer.add( this.instructions );
      this.mainSizer.add( this.selectionGroup, 100 );
      this.mainSizer.add( this.modeGroup );
      this.mainSizer.add( this.buttonSizer );
      this.sizer = this.mainSizer;

      this.refreshViewList();
      this.adjustToContents();
      this.setMinWidth( Math.max( this.width, 760 ) );
      this.setMinHeight( Math.max( this.height, 620 ) );
   }

   clearListSizer()
   {
      while ( this.listSizer.numberOfItems > 0 )
         this.listSizer.remove( 0 );
      this.checkBoxes = [];
   }

   refreshViewList()
   {
      this.clearListSizer();
      let snapshot = getOpenWindowsSnapshot();
      this.viewData = snapshot.filter( info => info.isAutocrop );

      if ( this.viewData.length === 0 )
      {
         let noneLabel = new Label( this );
         noneLabel.text = "No views with matching _crop_mask views were found. Open the original WBPP master views and their crop_mask views first, then click Refresh Views. Already-clean ACR files are intentionally ignored.";
         noneLabel.wordWrap = true;
         noneLabel.textAlignment = TextAlignment.Left;
         this.listSizer.add( noneLabel );
         this.updateCount();
         return;
      }

      for ( let i = 0; i < this.viewData.length; ++i )
      {
         let info = this.viewData[i];
         let cb = new CheckBox( this );
         cb.text = info.viewId + "    |    " + info.width + " × " + info.height + "    |    FILTER: " + info.filterName;
         cb.checked = true;
         cb.onCheck = () => { this.updateCount(); };
         this.checkBoxes.push( cb );
         this.listSizer.add( cb );
      }

      this.listSizer.addStretch();
      this.updateCount();
      Console.writeln( "View scan complete: processable views found = " + this.viewData.length );
   }

   updateCount()
   {
      let selected = 0;
      for ( let i = 0; i < this.checkBoxes.length; ++i )
         if ( this.checkBoxes[i].checked )
            ++selected;
      this.countLabel.text = "Views selected: " + selected + " of " + this.checkBoxes.length;
   }

   getSelectedViews()
   {
      let selected = [];
      for ( let i = 0; i < this.checkBoxes.length && i < this.viewData.length; ++i )
      {
         if ( this.checkBoxes[i].checked )
            selected.push( { id: this.viewData[i].viewId, window: this.viewData[i].window } );
      }
      return selected;
   }
}

function tempPathForOriginalPath( originalPath )
{
   if ( originalPath.indexOf( "_autocrop.xisf" ) >= 0 )
      return originalPath.replace( "_autocrop.xisf", "_temp.xisf" );
   if ( originalPath.toLowerCase().endsWith( ".xisf" ) )
      return originalPath.substring( 0, originalPath.length - 5 ) + "_temp.xisf";
   return originalPath + "_temp.xisf";
}

function processAutocropView( win, progress )
{
   try
   {
      progress.step( "Processing " + win.mainView.id );
      removePreviews( win );

      let originalPath = safeString( win.filePath );
      if ( originalPath.length === 0 )
      {
         progress.addWarning( "Skipping unsaved view: " + win.mainView.id + ". Save the master XISF first, then run the script again." );
         return null;
      }

      let tempPath = tempPathForOriginalPath( originalPath );
      win.saveAs( tempPath, false, false, true, false );
      Console.writeln( "Saved temp file: " + tempPath );
      return tempPath;
   }
   catch ( e )
   {
      progress.addError( "Failed to process " + win.mainView.id + ": " + e );
      return null;
   }
}

function renameAndFinalizeView( tempPath, progress )
{
   let reopened = null;
   let newWin = null;

   try
   {
      if ( !File.exists( tempPath ) )
      {
         progress.addError( "Temp file not found: " + tempPath );
         return null;
      }

      waitBriefly( 100 );
      reopened = ImageWindow.open( tempPath );
      if ( !reopened || reopened.length === 0 )
      {
         progress.addError( "Failed to reopen temp file: " + tempPath );
         return null;
      }

      let tempWin = reopened[0];
      if ( !tempWin || tempWin.isNull )
      {
         progress.addError( "Opened window is null: " + tempPath );
         return null;
      }

      let filterName = getFilterNameFromWindow( tempWin );
      if ( filterName === "Unknown" )
         progress.addWarning( "Missing FILTER keyword in: " + tempPath );

      let filterAbbrev = abbreviateFilterName( filterName );
      let desiredId = "integration_" + filterAbbrev;

      if ( !/^[A-Za-z_][A-Za-z0-9_]*$/.test( desiredId ) )
         desiredId = "integration_Filter";

      let newId = makeUniqueViewId( desiredId );
      if ( newId !== desiredId )
         progress.addWarning( "View ID conflict resolved, using: " + newId );

      // v8 fix (2026-10-02): reassigning mainView.id on the reopened window
      // (the old approach, and two earlier attempts at fixing this) never
      // actually changed what gets embedded in the saved file -- confirmed
      // by testing (screenshot showing the same file reopening as
      // "MasterLight_Blue", its ORIGINAL pre-script identifier, even though
      // the live session window had been renamed to "integration_B" and the
      // filename itself correctly said "_ACR_B.xisf"). PixInsight apparently
      // keeps tracking whatever id a window was given at creation, not any
      // id assigned to it afterward. Fix: build a brand new ImageWindow with
      // the correct id baked in from construction (same approach the V8
      // migration rules require for ImageWindow.duplicate(), Rule 37: a
      // window's identity has to be set at birth, not patched in after the
      // fact), copy the processed image and FITS keywords into it, and save
      // that window instead of the reopened one.
      let srcImage = tempWin.mainView.image;
      let isFloat = (srcImage.sampleType != 0);   // Rule 34: sampleType==0 is integer
      let isColor = (srcImage.colorSpace != ColorSpace.Gray);

      newWin = new ImageWindow(
         srcImage.width,
         srcImage.height,
         srcImage.numberOfChannels,
         srcImage.bitsPerSample,
         isFloat,
         isColor,
         newId
      );

      newWin.mainView.beginProcess( UndoFlag.NoSwapFile );
      newWin.mainView.image.assign( srcImage );
      newWin.mainView.endProcess();
      newWin.keywords = tempWin.keywords;   // carry the FITS header (including FILTER) across

      tempWin.forceClose();
      reopened = null;

      Console.writeln( "Renamed view to: " + newId + " (filter: " + filterName + " -> " + filterAbbrev + ")" );

      let basePath = tempPath.replace( "_temp.xisf", "" );
      // Filename keeps the full filter name for readability on disk -- the
      // identifier (newId, set above at window construction) is what
      // actually controls the abbreviation PixInsight shows/uses, and the
      // two are independent now that the id no longer depends on the
      // filename.
      let finalPath = basePath + "_ACR_" + filterName + ".xisf";

      newWin.saveAs( finalPath, false, false, true, false );
      Console.writeln( "Saved final file: " + finalPath );

      try
      {
         File.remove( tempPath );
         Console.writeln( "Deleted temp file: " + tempPath );
      }
      catch ( cleanupError )
      {
         progress.addWarning( "Could not delete temp file: " + cleanupError );
      }

      newWin.forceClose();
      return { finalPath: finalPath, viewId: newId };
   }
   catch ( e )
   {
      progress.addError( "Failed to rename/finalize " + tempPath + ": " + e );
      if ( reopened && reopened.length > 0 )
      {
         for ( let i = 0; i < reopened.length; ++i )
            try { if ( reopened[i] && !reopened[i].isNull ) reopened[i].forceClose(); } catch ( ignored ) {}
      }
      try { if ( newWin && !newWin.isNull ) newWin.forceClose(); } catch ( ignored2 ) {}
      return null;
   }
}

function loadFinalViews( processedFiles, mode, progress )
{
   let loadedViews = [];

   for ( let i = 0; i < processedFiles.length; ++i )
   {
      let fileInfo = processedFiles[i];
      if ( !fileInfo )
         continue;

      try
      {
         let reopenedFinal = ImageWindow.open( fileInfo.finalPath );
         if ( reopenedFinal && reopenedFinal.length > 0 )
         {
            let finalWin = reopenedFinal[0];
            // Re-apply the view ID — PixInsight reloads the embedded image name
            // from the XISF rather than the view ID set before saving.
            finalWin.mainView.id = fileInfo.viewId;
            finalWin.bringToFront();
            loadedViews.push( finalWin.mainView.id );
            Console.writeln( "Loaded final view: " + finalWin.mainView.id );

            if ( mode === "viewOnly" )
            {
               try
               {
                  File.remove( fileInfo.finalPath );
                  Console.writeln( "Deleted ACR file because view-only mode is active: " + fileInfo.finalPath );
               }
               catch ( e )
               {
                  progress.addWarning( "Could not delete view-only ACR file: " + e );
               }
            }
         }
         else
            progress.addError( "Failed to load final view from: " + fileInfo.finalPath );
      }
      catch ( e )
      {
         progress.addError( "Error loading final view: " + e );
      }
   }

   return loadedViews;
}

function cleanupCropMaskViewsByPosition( processedPositions )
{
   try
   {
      let cropMaskViews = getOpenWindowsSnapshot().filter( info => info.isCropMask );
      if ( cropMaskViews.length === 0 )
      {
         Console.writeln( "No crop_mask views found." );
         return;
      }

      let closedCount = 0;
      let preservedCount = 0;

      for ( let i = 0; i < cropMaskViews.length; ++i )
      {
         if ( processedPositions.indexOf( i ) >= 0 )
         {
            try
            {
               Console.writeln( "Closing crop_mask view at position " + i + ": " + cropMaskViews[i].viewId );
               cropMaskViews[i].window.forceClose();
               ++closedCount;
            }
            catch ( e )
            {
               Console.warningln( "Could not close crop_mask view " + cropMaskViews[i].viewId + ": " + e );
            }
         }
         else
         {
            Console.writeln( "Preserving crop_mask view at position " + i + ": " + cropMaskViews[i].viewId );
            ++preservedCount;
         }
      }

      Console.writeln( "Closed " + closedCount + " crop_mask view(s). Preserved " + preservedCount + "." );
   }
   catch ( e )
   {
      Console.warningln( "Error during crop_mask cleanup: " + e );
   }
}

function showCompletionSummary( summary, mode )
{
   Console.writeln( "═══════════════════════════════════════" );
   Console.writeln( "PROCESSING SUMMARY" );
   Console.writeln( "═══════════════════════════════════════" );
   Console.writeln( "Successfully processed: " + summary.success + "/" + summary.total );
   Console.writeln( "Warnings: " + summary.warnings );
   Console.writeln( "Errors: " + summary.errors );
   Console.writeln( "Mode: " + (mode === "save" ? "Final ACR files retained" : "Views loaded, ACR files deleted") );
   Console.writeln( "═══════════════════════════════════════" );
}

function main()
{
   Console.show();
   Console.writeln( "Starting Remove AutoCrop Views process - Masters of PixInsight " + VERSION );

   let dialog = new ViewSelectionDialog();
   if ( !dialog.execute() )
   {
      Console.writeln( "Operation cancelled by user." );
      return;
   }

   let mode = dialog.saveMode.checked ? "save" : "viewOnly";
   let selectedViews = dialog.getSelectedViews();

   if ( selectedViews.length === 0 )
   {
      new MessageBox( "Please select at least one AutoCrop view to process.", "No AutoCrop Views Selected", StdIcon.Error, StdButton.Ok ).execute();
      return;
   }

   let msg = "Ready to process " + selectedViews.length + " view(s):\n\n" +
             "Mode: " + (mode === "save" ? "Save ACR files to disk" : "View-only temporary mode") + "\n\n" +
             "Selected views:\n";

   for ( let i = 0; i < Math.min( selectedViews.length, 8 ); ++i )
      msg += "• " + selectedViews[i].id + "\n";
   if ( selectedViews.length > 8 )
      msg += "• ... and " + (selectedViews.length - 8) + " more\n";

   msg += "\nOnly selected views will be processed. Continue?";

   let confirmResult = new MessageBox( msg, "Confirm Processing", StdIcon.Question, StdButton.Yes, StdButton.No ).execute();
   if ( confirmResult !== StdButton.Yes )
   {
      Console.writeln( "Processing cancelled by user." );
      return;
   }

   let processableViewsBefore = getOpenWindowsSnapshot()
      .filter( info => info.isAutocrop )
      .sort( ( a, b ) => a.viewId.localeCompare( b.viewId ) );

   let processedPositions = [];
   for ( let s = 0; s < selectedViews.length; ++s )
      for ( let p = 0; p < processableViewsBefore.length; ++p )
         if ( processableViewsBefore[p].viewId === selectedViews[s].id )
            processedPositions.push( p );

   let progress = new ProgressTracker( selectedViews.length );
   let tempFiles = [];
   let processedWindows = [];

   Console.writeln( "Phase 1: Processing selected views and saving temporary files..." );
   for ( let i = 0; i < selectedViews.length; ++i )
   {
      let win = selectedViews[i].window;
      if ( !win || win.isNull )
      {
         progress.addError( "View no longer available: " + selectedViews[i].id );
         continue;
      }

      let tempPath = processAutocropView( win, progress );
      if ( tempPath )
      {
         tempFiles.push( tempPath );
         processedWindows.push( win );
      }
   }

   if ( tempFiles.length === 0 )
   {
      Console.warningln( "No views were successfully processed in Phase 1." );
      return;
   }

   Console.writeln( "Closing processed source views only..." );
   for ( let i = 0; i < processedWindows.length; ++i )
   {
      try
      {
         let id = processedWindows[i].mainView.id;
         processedWindows[i].forceClose();
         Console.writeln( "Closed processed view: " + id );
      }
      catch ( e )
      {
         Console.warningln( "Could not close processed view: " + e );
      }
   }

   Console.writeln( "Phase 2: Renaming views and creating final files..." );
   progress = new ProgressTracker( tempFiles.length );
   let processedFiles = [];
   for ( let i = 0; i < tempFiles.length; ++i )
   {
      let result = renameAndFinalizeView( tempFiles[i], progress );
      if ( result )
         processedFiles.push( result );
   }

   if ( processedFiles.length === 0 )
   {
      Console.warningln( "No files were successfully finalized in Phase 2." );
      return;
   }

   Console.writeln( "Phase 3: Loading final views..." );
   let loadedViews = loadFinalViews( processedFiles, mode, progress );

   Console.writeln( "Phase 4: Closing associated crop_mask views..." );
   cleanupCropMaskViewsByPosition( processedPositions );

   let summary = progress.summary();
   summary.success = loadedViews.length;
   showCompletionSummary( summary, mode );

   new MessageBox( "Processing completed. Successfully loaded " + loadedViews.length + " clean view(s).\n\nCheck the console for warnings or errors.",
                   "Remove AutoCrop Views Complete", StdIcon.Information, StdButton.Ok ).execute();
}

main();
